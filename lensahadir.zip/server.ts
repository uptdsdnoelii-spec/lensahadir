import 'dotenv/config';
import crypto from 'crypto';
import express from 'express';
import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type, ThinkingLevel } from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const LOCAL_DB_DIR = path.resolve(__dirname, '.data');
const LOCAL_DB_FILE = path.join(LOCAL_DB_DIR, 'lensahadir-db.json');

const SESSION_SECRET = process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex');

function timingSafeEqualStr(a: string, b: string): boolean {
  const bufA = Buffer.from(String(a), 'utf8');
  const bufB = Buffer.from(String(b), 'utf8');
  if (bufA.length !== bufB.length) return false;
  return crypto.timingSafeEqual(bufA, bufB);
}

function signSessionToken(payload: { id: string; username: string; role: string }): string {
  const body = Buffer.from(
    JSON.stringify({
      ...payload,
      iat: Date.now(),
      exp: Date.now() + 1000 * 60 * 60 * 24 * 7,
    })
  ).toString('base64url');
  const sig = crypto.createHmac('sha256', SESSION_SECRET).update(body).digest('base64url');
  return `${body}.${sig}`;
}

function verifySessionToken(
  authHeader?: string
): { id: string; username: string; role: string } | null {
  if (!authHeader || typeof authHeader !== 'string') return null;
  if (!authHeader.startsWith('Bearer ')) return null;
  const token = authHeader.slice(7).trim();
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [body, sig] = parts;
  if (!body || !sig) return null;
  const expectedSig = crypto.createHmac('sha256', SESSION_SECRET).update(body).digest('base64url');
  if (!timingSafeEqualStr(sig, expectedSig)) return null;
  try {
    const decoded = JSON.parse(Buffer.from(body, 'base64url').toString('utf8'));
    if (!decoded || typeof decoded.exp !== 'number' || decoded.exp < Date.now()) return null;
    if (typeof decoded.id !== 'string' || typeof decoded.role !== 'string') return null;
    return {
      id: decoded.id,
      username: typeof decoded.username === 'string' ? decoded.username : '',
      role: decoded.role,
    };
  } catch {
    return null;
  }
}

function upsertById(list: any[], item: any) {
  const arr = Array.isArray(list) ? list : [];
  if (!item || !item.id) return arr;
  return [item, ...arr.filter((x) => x && x.id !== item.id)];
}

function mergeUsersNonDestructive(existing: any[], incoming: any[], deletedIds: string[]) {
  const deletedSet = new Set(Array.isArray(deletedIds) ? deletedIds : []);
  const map = new Map<string, any>();
  for (const u of Array.isArray(existing) ? existing : []) {
    if (u && u.id && !deletedSet.has(u.id)) map.set(u.id, u);
  }
  for (const u of Array.isArray(incoming) ? incoming : []) {
    if (!u || !u.id || deletedSet.has(u.id)) continue;
    const prev = map.get(u.id);
    const prevTs = Number(prev?.profileUpdatedAt || prev?.createdAt || 0);
    const nextTs = Number(u.profileUpdatedAt || u.createdAt || 0);
    if (!prev || nextTs >= prevTs) {
      map.set(u.id, u);
    }
  }
  return Array.from(map.values());
}

async function readLocalSyncState(): Promise<any | null> {
  try {
    const raw = await fs.readFile(LOCAL_DB_FILE, 'utf-8');
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

async function writeLocalSyncState(data: any): Promise<void> {
  await fs.mkdir(LOCAL_DB_DIR, { recursive: true });
  await fs.writeFile(LOCAL_DB_FILE, JSON.stringify(data), 'utf-8');
}

function applySyncMutation(current: any, body: any) {
  const base =
    current && typeof current === 'object'
      ? { ...current }
      : {
          version: 1,
          updatedAt: Date.now(),
          users: [],
          records: [],
          adminSubmissions: [],
          recoveryNotifications: [],
          adminRegistrations: [],
        };

  const { type, payload, id } = body || {};
  const now = Date.now();
  const isAdminLocked = Boolean(base.lockConfig?.adminDataLocked);

  switch (type) {
    case 'full_replace': {
      const incoming = payload && typeof payload === 'object' ? payload : {};
      const mergedDeletedUsers = Array.from(
        new Set([
          ...(Array.isArray(base.deletedUserIds) ? base.deletedUserIds : []),
          ...(Array.isArray(incoming.deletedUserIds) ? incoming.deletedUserIds : []),
        ].filter(Boolean))
      ).slice(-500);
      const nextLockConfig =
        isAdminLocked && base.lockConfig
          ? {
              ...(incoming.lockConfig || base.lockConfig),
              adminDataLocked: true,
              adminDataLockedAt: base.lockConfig.adminDataLockedAt ?? now,
            }
          : incoming.lockConfig || base.lockConfig;
      return {
        ...base,
        ...incoming,
        // Never overwrite locked Admin credentials/settings or clear Admin lock via background full_replace
        lockConfig: nextLockConfig,
        adminProfile:
          isAdminLocked && base.adminProfile ? base.adminProfile : incoming.adminProfile || base.adminProfile,
        settings:
          isAdminLocked && base.settings ? base.settings : incoming.settings || base.settings,
        adminContact:
          isAdminLocked && base.adminContact ? base.adminContact : incoming.adminContact || base.adminContact,
        // Never wipe existing user login directory with an empty array from another browser
        users: mergeUsersNonDestructive(base.users, incoming.users, mergedDeletedUsers),
        deletedUserIds: mergedDeletedUsers,
        version: 1,
        updatedAt: now,
      };
    }
    case 'save_settings':
      return { ...base, settings: payload, updatedAt: now };
    case 'save_admin_profile':
      return { ...base, adminProfile: payload, updatedAt: now };
    case 'save_admin_contact':
      return { ...base, adminContact: payload, updatedAt: now };
    case 'save_lock_config':
      return { ...base, lockConfig: payload, updatedAt: now };
    case 'save_user':
      return {
        ...base,
        users: upsertById(base.users, { ...payload, profileUpdatedAt: now }),
        deletedUserIds: (Array.isArray(base.deletedUserIds) ? base.deletedUserIds : []).filter(
          (x: string) => x !== payload?.id
        ),
        updatedAt: now,
      };
    case 'activate_all_users':
      return {
        ...base,
        users: (Array.isArray(base.users) ? base.users : []).map((u: any) =>
          u ? { ...u, aktif: true, profileUpdatedAt: now } : u
        ),
        updatedAt: now,
      };
    case 'delete_user':
      return {
        ...base,
        users: (Array.isArray(base.users) ? base.users : []).filter((u: any) => u && u.id !== id),
        deletedUserIds: Array.from(
          new Set([
            ...(Array.isArray(base.deletedUserIds) ? base.deletedUserIds : []),
            id,
          ].filter(Boolean))
        ).slice(-500),
        updatedAt: now,
      };
    case 'save_record':
      return {
        ...base,
        records: upsertById(base.records, payload),
        deletedRecordIds: (Array.isArray(base.deletedRecordIds) ? base.deletedRecordIds : []).filter(
          (x: string) => x !== payload?.id
        ),
        updatedAt: now,
      };
    case 'delete_record':
      return {
        ...base,
        records: (Array.isArray(base.records) ? base.records : []).filter(
          (r: any) => r && r.id !== id
        ),
        deletedRecordIds: Array.from(
          new Set([
            ...(Array.isArray(base.deletedRecordIds) ? base.deletedRecordIds : []),
            id,
          ].filter(Boolean))
        ).slice(-500),
        updatedAt: now,
      };
    case 'save_submission':
      return {
        ...base,
        adminSubmissions: upsertById(base.adminSubmissions, payload),
        deletedSubmissionIds: (Array.isArray(base.deletedSubmissionIds)
          ? base.deletedSubmissionIds
          : []
        ).filter((x: string) => x !== payload?.id),
        updatedAt: now,
      };
    case 'delete_submission':
      return {
        ...base,
        adminSubmissions: (Array.isArray(base.adminSubmissions)
          ? base.adminSubmissions
          : []
        ).filter((s: any) => s && s.id !== id),
        deletedSubmissionIds: Array.from(
          new Set([
            ...(Array.isArray(base.deletedSubmissionIds) ? base.deletedSubmissionIds : []),
            id,
          ].filter(Boolean))
        ).slice(-500),
        updatedAt: now,
      };
    case 'save_recovery':
      return {
        ...base,
        recoveryNotifications: upsertById(base.recoveryNotifications, payload),
        updatedAt: now,
      };
    case 'mark_recovery_done':
      return {
        ...base,
        recoveryNotifications: (Array.isArray(base.recoveryNotifications)
          ? base.recoveryNotifications
          : []
        ).map((n: any) => (n && n.id === id ? { ...n, status: 'selesai' } : n)),
        updatedAt: now,
      };
    case 'delete_recovery':
      return {
        ...base,
        recoveryNotifications: (Array.isArray(base.recoveryNotifications)
          ? base.recoveryNotifications
          : []
        ).filter((n: any) => n && n.id !== id),
        updatedAt: now,
      };
    case 'save_registration':
      return {
        ...base,
        adminRegistrations: upsertById(base.adminRegistrations, payload),
        updatedAt: now,
      };
    case 'mark_registration_contacted':
      return {
        ...base,
        adminRegistrations: (Array.isArray(base.adminRegistrations)
          ? base.adminRegistrations
          : []
        ).map((r: any) => (r && r.id === id ? { ...r, status: 'dihubungi' } : r)),
        updatedAt: now,
      };
    case 'delete_registration':
      return {
        ...base,
        adminRegistrations: (Array.isArray(base.adminRegistrations)
          ? base.adminRegistrations
          : []
        ).filter((r: any) => r && r.id !== id),
        updatedAt: now,
      };
    default:
      return base;
  }
}

const PORT = Number(process.env.PORT) || 3000;
const isProd = process.env.NODE_ENV === 'production';

function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error(
      'GEMINI_API_KEY belum terkonfigurasi. Silakan periksa pengaturan API key di panel Settings > Secrets.'
    );
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      timeout: 35000,
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

const RECAP_RESPONSE_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    bulan: {
      type: Type.INTEGER,
      description: 'Nomor bulan 1 sampai 12 jika terdeteksi (misal Oktober = 10)',
    },
    tahun: {
      type: Type.INTEGER,
      description: 'Tahun 4 digit jika terdeteksi (misal 2026)',
    },
    hariKerjaEfektif: {
      type: Type.INTEGER,
      description: 'Jumlah hari kerja efektif dalam bulan tersebut',
    },
    summary: {
      type: Type.STRING,
      description: 'Ringkasan singkat sumber dokumen yang berhasil dibaca',
    },
    rows: {
      type: Type.ARRAY,
      description: 'Daftar lengkap guru/pegawai dan rekap jumlah hari kehadiran',
      items: {
        type: Type.OBJECT,
        properties: {
          nama: { type: Type.STRING, description: 'Nama lengkap dan gelar' },
          nip: { type: Type.STRING, description: 'NIP pegawai atau -' },
          jabatan: { type: Type.STRING, description: 'Tugas atau jabatan pegawai' },
          golongan: { type: Type.STRING, description: 'Golongan ruang atau GTT/IX/-' },
          kategori: {
            type: Type.STRING,
            description: 'Salah satu dari: PNS, PPPK, GTT, Lainnya',
          },
          h: { type: Type.INTEGER, description: 'Jumlah hari Hadir (H)' },
          td: { type: Type.INTEGER, description: 'Jumlah hari Tugas Dinas (TD)' },
          i: { type: Type.INTEGER, description: 'Jumlah hari Izin/Ijin/Cuti (I)' },
          s: { type: Type.INTEGER, description: 'Jumlah hari Sakit (S)' },
          tk: {
            type: Type.INTEGER,
            description: 'Jumlah hari Tanpa Keterangan/Tanpa Berita/Alpa (TK)',
          },
        },
        required: ['nama', 'h', 'td', 'i', 's', 'tk'],
      },
    },
  },
  required: ['rows'],
};

async function generateWithFallback(
  ai: GoogleGenAI,
  parts: Array<
    | { text: string }
    | { inlineData: { mimeType: string; data: string } }
  >
) {
  // Use ultra-fast free-tier gemini-3.1-flash-lite first, falling back to gemini-4-hydrogen if needed
  const attempts: { model: string; thinkingLevel: ThinkingLevel }[] = [
    { model: 'gemini-3.1-flash-lite', thinkingLevel: ThinkingLevel.MINIMAL },
    { model: 'gemini-4-hydrogen', thinkingLevel: ThinkingLevel.LOW },
  ];

  let lastErr: any;
  for (let i = 0; i < attempts.length; i++) {
    const { model, thinkingLevel } = attempts[i];
    try {
      const response = await ai.models.generateContent({
        model,
        contents: { parts },
        config: {
          thinkingConfig: { thinkingLevel },
          responseMimeType: 'application/json',
          responseSchema: RECAP_RESPONSE_SCHEMA,
        },
      });
      return response;
    } catch (err: any) {
      lastErr = err;
      const status = err?.status || err?.code;
      const msg = String(err?.message || '');
      const isTransient =
        status === 503 ||
        status === 500 ||
        status === 504 ||
        msg.includes('UNAVAILABLE') ||
        msg.includes('high demand') ||
        msg.includes('overloaded') ||
        msg.includes('timeout') ||
        msg.includes('AbortError');

      if (!isTransient) {
        throw err;
      }
      await new Promise((r) => setTimeout(r, 400));
    }
  }

  throw lastErr;
}

async function createServer() {
  const app = express();

  // Allow embedding cleanly inside Blogspot / Blogger custom domain themes
  app.use((_req, res, next) => {
    res.removeHeader('X-Frame-Options');
    res.setHeader('Content-Security-Policy', 'frame-ancestors *');
    res.setHeader('Permissions-Policy', 'camera=*, microphone=*, fullscreen=*');
    next();
  });

  // Support large multi-page PDF uploads & photo sync payloads
  app.use(express.json({ limit: '35mb' }));

  // =========================================================================
  // API ROUTE: Fast Cross-Browser & Mobile HP Login Verification
  // Allows any active Guru/Pegawai, Pimpinan, or Admin to sign in immediately
  // from any browser or smartphone without waiting for large photo syncs.
  // =========================================================================
  app.post('/api/auth/login', async (req, res) => {
    try {
      const rawUser = typeof req.body?.username === 'string' ? req.body.username.trim() : '';
      const rawPass = typeof req.body?.password === 'string' ? req.body.password : '';
      if (!rawUser || !rawPass || rawUser.length > 120 || rawPass.length > 200) {
        return res.status(400).json({
          ok: false,
          code: 'INVALID',
          error: 'Masukkan Username dan Password terlebih dahulu.',
        });
      }

      const data = await readLocalSyncState();
      if (!data) {
        return res.status(404).json({ ok: false, code: 'UNSEEDED' });
      }

      // 1. Verify Administrator Utama
      const adminProfile = data.adminProfile;
      if (adminProfile && typeof adminProfile.username === 'string') {
        const adminUsername = adminProfile.username.trim();
        if (
          rawUser.toLowerCase() === adminUsername.toLowerCase() &&
          typeof adminProfile.password === 'string' &&
          timingSafeEqualStr(rawPass, adminProfile.password)
        ) {
          const adminSession = {
            id: 'admin_primary',
            username: adminUsername,
            nama: adminProfile.nama || 'Administrator Utama',
            role: 'Admin',
            nip: adminProfile.nip || '',
            jabatan: adminProfile.jabatan || 'Administrator Utama Lembaga / Satuan Dinas',
          };
          const token = signSessionToken({
            id: adminSession.id,
            username: adminSession.username,
            role: adminSession.role,
          });
          return res.json({ ok: true, session: adminSession, token });
        }
      }

      // 2. Verify Managed Users (Guru/Pegawai & Pimpinan) — Always Active across all browsers & HP
      const usersList = Array.isArray(data.users) ? data.users : [];
      const matched = usersList.find(
        (u: any) =>
          u &&
          typeof u.username === 'string' &&
          u.username.trim().toLowerCase() === rawUser.toLowerCase() &&
          typeof u.password === 'string' &&
          timingSafeEqualStr(rawPass, u.password)
      );

      if (!matched) {
        return res.status(401).json({
          ok: false,
          code: 'INVALID',
          error: 'Username atau Password salah! Periksa kembali data masuk Anda.',
        });
      }

      if (matched.aktif === false) {
        return res.status(403).json({
          ok: false,
          code: 'INACTIVE',
          error: 'Akun ini sedang dinonaktifkan oleh Admin. Silakan hubungi Admin instansi.',
        });
      }

      const userSession = {
        id: matched.id,
        username: matched.username,
        nama: matched.nama,
        role: matched.role,
        nip: matched.nip || '',
        golRuang: matched.golRuang || '',
        statusPegawai: matched.statusPegawai,
        jabatan: matched.jabatan || '',
      };
      const token = signSessionToken({
        id: userSession.id,
        username: userSession.username,
        role: userSession.role,
      });
      return res.json({ ok: true, session: userSession, token });
    } catch (err: any) {
      return res.status(500).json({ ok: false, error: err?.message || 'Login error' });
    }
  });

  // =========================================================================
  // API ROUTE: Built-in Persistent Data Sync Store (/api/sync-data)
  // =========================================================================
  app.get('/api/sync-data', async (_req, res) => {
    try {
      const data = await readLocalSyncState();
      return res.json({ ok: true, data });
    } catch (err: any) {
      return res.status(500).json({ ok: false, error: err?.message || 'Read error' });
    }
  });

  app.post('/api/sync-data', async (req, res) => {
    try {
      if (!req.body || typeof req.body !== 'object' || typeof req.body.type !== 'string') {
        return res.status(400).json({ ok: false, error: 'Payload sinkronisasi tidak valid.' });
      }

      const mutationType = req.body.type;
      const authHeader = req.headers.authorization;
      const verifiedActor = authHeader ? verifySessionToken(authHeader) : null;

      if (authHeader && !verifiedActor) {
        return res.status(401).json({
          ok: false,
          code: 'INVALID_TOKEN',
          error: 'Sesi login telah kedaluwarsa. Silakan login kembali.',
        });
      }

      const ADMIN_ONLY_MUTATIONS = new Set([
        'save_lock_config',
        'save_admin_profile',
        'save_settings',
        'save_admin_contact',
        'delete_user',
        'activate_all_users',
        'delete_submission',
        'mark_recovery_done',
        'delete_recovery',
        'mark_registration_contacted',
        'delete_registration',
      ]);

      if (verifiedActor && verifiedActor.role !== 'Admin') {
        if (ADMIN_ONLY_MUTATIONS.has(mutationType)) {
          return res.status(403).json({
            ok: false,
            code: 'FORBIDDEN',
            error: 'Aksi ini hanya dapat dilakukan oleh akun Admin.',
          });
        }
        if (mutationType === 'save_user') {
          const targetPayload = req.body.payload;
          if (
            !targetPayload ||
            targetPayload.id !== verifiedActor.id ||
            targetPayload.role === 'Admin'
          ) {
            return res.status(403).json({
              ok: false,
              code: 'FORBIDDEN',
              error: 'Anda hanya dapat memperbarui profil akun Anda sendiri.',
            });
          }
        }
      }

      const existing = await readLocalSyncState();
      const adminLocked = Boolean(existing?.lockConfig?.adminDataLocked);

      // Server-side guard: while Kunci Data Admin is active, block accidental edits to Admin credentials/settings or deleting users
      if (
        adminLocked &&
        (mutationType === 'save_admin_profile' ||
          mutationType === 'save_settings' ||
          mutationType === 'save_admin_contact' ||
          mutationType === 'delete_user')
      ) {
        return res.status(423).json({
          ok: false,
          code: 'ADMIN_LOCKED',
          error:
            'Kunci Data Admin sedang aktif. Nonaktifkan Kunci Data Admin terlebih dahulu untuk mengubah data Admin atau menghapus akun.',
        });
      }

      const updated = applySyncMutation(existing, req.body);
      await writeLocalSyncState(updated);
      return res.json({ ok: true, data: updated });
    } catch (err: any) {
      return res.status(500).json({ ok: false, error: err?.message || 'Write error' });
    }
  });

  // =========================================================================
  // API ROUTE: Multimodal Monthly Attendance PDF / Document Extractor
  // Supports BOTH fast extracted text AND native multimodal PDF/image vision
  // for scanned PDFs, daily 1-31 grids, summary tables, or TimeMark cards.
  // =========================================================================
  app.post('/api/parse-recap-document', async (req, res) => {
    try {
      const { base64Data, mimeType, extractedText, fileName, defaultWorkDays } = req.body || {};

      const hasText = typeof extractedText === 'string' && extractedText.trim().length > 60;
      const hasBinary = typeof base64Data === 'string' && base64Data.length > 0;

      if (!hasText && !hasBinary) {
        return res.status(400).json({ error: 'Data file tidak valid atau kosong.' });
      }

      const safeMime =
        typeof mimeType === 'string' && mimeType.trim()
          ? mimeType.trim()
          : 'application/pdf';

      const ai = getGeminiClient();

      const prompt = `Anda adalah sistem pembaca dan penghitung dokumen administrasi absensi sekolah Indonesia.
Tugas Anda: Baca SELURUH isi dokumen absensi (nama file: "${fileName || 'Rekapan_Absensi.pdf'}") dengan teliti dan ekstrak data rekapitulasi absensi setiap guru/pegawai untuk 1 bulan.

Dokumen ini bisa berbentuk salah satu dari format berikut:
1. Tabel rekapitulasi bulanan (kolom Nama, NIP, Jabatan, Golongan, dan jumlah H/Hadir, TD/Tugas Dinas, I/Ijin/Izin/Cuti, S/Sakit, TK/TB/Alpa/Tanpa Keterangan).
2. Matriks absensi harian tanggal 1 sampai 30/31 (setiap kolom tanggal berisi kode H, TD, I, S, TK/TB/A, C, L/Libur, atau tanda centang) -> HITUNG jumlah hari masing-masing status secara akurat untuk setiap pegawai!
3. Kumpulan kartu absensi harian / Laporan Disiplin Jam Kerja Harian / Foto TimeMark beberapa hari dalam 1 bulan -> GABUNGKAN berdasarkan nama pegawai dan HITUNG berapa hari masing-masing pegawai tercatat Hadir (h), Tugas Dinas/Tugas Belajar (td), Ijin/Izin/Cuti (i), Sakit (s), dan Tanpa Berita/Tanpa Keterangan/Alpa (tk).
4. Tabel hasil scan / foto / ekspor Word / Excel dalam bentuk PDF dengan format kolom bebas.

Aturan ketat ekstraksi:
- Pertahankan penulisan gelar akademik pada nama persis seperti di dokumen (misal: "S.Pd", "S.Pd.SD", "S.Pd.Gr", "A.Ma.Pd", "M.Pd"), JANGAN ubah menjadi huruf kapital semua.
- Jika NIP terdiri dari 18 digit, rapikan dengan spasi standar "YYYYMMDD YYYYMM G NNN". Jika tidak ada NIP (misal GTT/Honor), isi "-".
- Kategori pegawai: "PNS" (jika Golongan I/a-IV/e atau PNS/ASN), "PPPK" (jika Golongan Romawi seperti VII/IX/X atau tertulis PPPK), "GTT" (jika tertulis GTT/PTT/Honor), atau "Lainnya".
- Pastikan SEMUA pegawai dari baris 1 sampai baris terakhir terbaca lengkap (jangan potong daftar dan jangan masukkan baris "JUMLAH" / "TOTAL" / "RATA-RATA" sebagai pegawai).
- Deteksi bulan (angka 1-12, contoh Oktober = 10, September = 9), tahun (contoh 2026), dan hariKerjaEfektif (jumlah hari kerja efektif pada bulan tersebut; jika tidak tertulis eksplisit, gunakan nilai maksimum (h+td+i+s+tk) dari pegawai atau default ${Number(defaultWorkDays) || 26}).
- Berikan ringkasan singkat dalam bahasa Indonesia pada field "summary".`;

      const parts: Array<
        | { text: string }
        | { inlineData: { mimeType: string; data: string } }
      > = [];

      if (hasText && !hasBinary) {
        parts.push({
          text: `${prompt}\n\n=== ISI TEKS DOKUMEN ===\n${extractedText.slice(0, 60000)}`,
        });
      } else if (hasBinary) {
        parts.push({
          inlineData: {
            mimeType: safeMime,
            data: base64Data,
          },
        });
        parts.push({
          text: hasText
            ? `${prompt}\n\nTeks referensi tambahan hasil ekstrak PDF:\n${extractedText.slice(0, 25000)}`
            : prompt,
        });
      }

      const response = await generateWithFallback(ai, parts);

      const rawText = (response.text ?? '').trim();
      if (!rawText) {
        return res.status(502).json({
          error: 'Dokumen tidak menghasilkan data terbaca. Pastikan file PDF tidak rusak atau kosong.',
        });
      }

      let parsed: any;
      try {
        parsed = JSON.parse(rawText);
      } catch {
        const cleaned = rawText.replace(/^```json\s*/i, '').replace(/```\s*$/, '').trim();
        parsed = JSON.parse(cleaned);
      }

      if (!parsed || !Array.isArray(parsed.rows) || parsed.rows.length === 0) {
        return res.status(422).json({
          error:
            'Tidak ditemukan daftar pegawai pada file PDF tersebut. Pastikan file berisi daftar nama dan catatan kehadiran guru/pegawai.',
        });
      }

      return res.json(parsed);
    } catch (err: any) {
      console.error('Error in /api/parse-recap-document:', err);
      const status = err?.status || err?.code || 500;
      const errMsg = String(err?.message || 'Gagal membaca dokumen PDF.');

      if (status === 403 || errMsg.includes('PERMISSION_DENIED') || errMsg.includes('API_KEY_INVALID')) {
        return res.status(403).json({
          error:
            'Kunci API tidak valid atau belum memiliki izin. Silakan periksa API Key pada panel Settings > Secrets.',
        });
      }
      if (status === 429 || errMsg.includes('RESOURCE_EXHAUSTED')) {
        return res.status(429).json({
          error:
            'Batas pemrosesan dokumen sementara tercapai. Silakan coba lagi beberapa saat atau unggah dalam format Excel (.xlsx).',
        });
      }
      if (status === 503 || errMsg.includes('UNAVAILABLE')) {
        return res.status(503).json({
          error:
            'Server pembaca dokumen sedang sibuk sementara. Silakan klik upload ulang dalam beberapa detik.',
        });
      }

      return res.status(typeof status === 'number' && status >= 400 && status < 600 ? status : 500).json({
        error: errMsg,
      });
    }
  });

  // =========================================================================
  // FRONTEND SERVING (Vite dev middleware in dev, dist/ static in prod)
  // =========================================================================
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('/{*splat}', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`LensaHadir server running on http://0.0.0.0:${PORT}`);
  });
}

createServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
