/**
 * Phase 0 Security TDD Specification & Payload Assertions for LensaHadir Firestore Rules.
 * Verifies all 12 "Dirty Dozen" adversarial payloads and expected PERMISSION_DENIED boundaries
 * against the collections declared in firebase-blueprint.json and firestore.rules.
 */

export interface AdversarialCase {
  id: number;
  name: string;
  collectionPath: string;
  operation: 'get' | 'list' | 'create' | 'update' | 'delete';
  actor: {
    uid: string | null;
    email?: string;
    email_verified?: boolean;
  };
  payload?: Record<string, unknown>;
  expectedResult: 'PERMISSION_DENIED';
  enforcedByRule: string;
}

export const DIRTY_DOZEN_CASES: AdversarialCase[] = [
  {
    id: 1,
    name: 'Unverified Admin Email Spoof',
    collectionPath: '/adminConfig/profile',
    operation: 'get',
    actor: { uid: 'spoof_1', email: 'longya332@gmail.com', email_verified: false },
    expectedResult: 'PERMISSION_DENIED',
    enforcedByRule: 'isVerified() requires request.auth.token.email_verified == true',
  },
  {
    id: 2,
    name: 'Shadow Field Injection on User Profile',
    collectionPath: '/users/user_1',
    operation: 'update',
    actor: { uid: 'guru_uid_1', email: 'guru@school.id', email_verified: true },
    payload: { nama: 'Budi', isAdmin: true },
    expectedResult: 'PERMISSION_DENIED',
    enforcedByRule: 'isValidManagedUser() hasOnly() + affectedKeys().hasOnly()',
  },
  {
    id: 3,
    name: 'Self-Role Escalation to Pimpinan',
    collectionPath: '/pimpinanRoles/guru_uid_1',
    operation: 'create',
    actor: { uid: 'guru_uid_1', email: 'guru@school.id', email_verified: true },
    payload: { uid: 'guru_uid_1', userId: 'user_1', usernameKey: 'guru1' },
    expectedResult: 'PERMISSION_DENIED',
    enforcedByRule: 'loginDirectory role must equal Pimpinan and linkedUid == request.auth.uid',
  },
  {
    id: 4,
    name: 'Privilege Escalation via Profile Update',
    collectionPath: '/users/user_1',
    operation: 'update',
    actor: { uid: 'guru_uid_1', email: 'guru@school.id', email_verified: true },
    payload: { role: 'Pimpinan' },
    expectedResult: 'PERMISSION_DENIED',
    enforcedByRule: 'Self-profile update enforces incoming().role == existing().role and affectedKeys allowlist',
  },
  {
    id: 5,
    name: 'Cross-User PII Scraping',
    collectionPath: '/users/user_other',
    operation: 'get',
    actor: { uid: 'guru_uid_1', email: 'guru@school.id', email_verified: true },
    expectedResult: 'PERMISSION_DENIED',
    enforcedByRule: 'users get requires existing().linkedUid == request.auth.uid or isAdmin()',
  },
  {
    id: 6,
    name: 'Admin Secret Theft',
    collectionPath: '/adminUserSecrets/user_1',
    operation: 'get',
    actor: { uid: 'guru_uid_1', email: 'guru@school.id', email_verified: true },
    expectedResult: 'PERMISSION_DENIED',
    enforcedByRule: 'adminUserSecrets strictly restricted to isAdmin()',
  },
  {
    id: 7,
    name: 'Ownership Spoofing on Attendance Record',
    collectionPath: '/attendanceRecords/DOC_999',
    operation: 'create',
    actor: { uid: 'guru_uid_1', email: 'guru@school.id', email_verified: true },
    payload: { id: 'DOC_999', ownerUid: 'victim_uid', nama: 'Spoofed' },
    expectedResult: 'PERMISSION_DENIED',
    enforcedByRule: 'attendanceRecords create requires incoming().ownerUid == request.auth.uid',
  },
  {
    id: 8,
    name: 'Orphaned Admin Submission',
    collectionPath: '/adminSubmissions/SUB_999',
    operation: 'create',
    actor: { uid: 'guru_uid_1', email: 'guru@school.id', email_verified: true },
    payload: { id: 'SUB_999', recordId: 'NON_EXISTENT_DOC', ownerUid: 'guru_uid_1' },
    expectedResult: 'PERMISSION_DENIED',
    enforcedByRule: 'adminSubmissions create checks exists(/attendanceRecords/$(incoming().recordId))',
  },
  {
    id: 9,
    name: 'ID Poisoning Attack',
    collectionPath: '/attendanceRecords/invalid..id$$$',
    operation: 'create',
    actor: { uid: 'guru_uid_1', email: 'guru@school.id', email_verified: true },
    payload: { id: 'invalid..id$$$', ownerUid: 'guru_uid_1' },
    expectedResult: 'PERMISSION_DENIED',
    enforcedByRule: 'isValidId() regex ^[a-zA-Z0-9_\\-]+$ and <= 128 chars',
  },
  {
    id: 10,
    name: 'Client-Spoofed Timestamp',
    collectionPath: '/attendanceRecords/DOC_123',
    operation: 'create',
    actor: { uid: 'guru_uid_1', email: 'guru@school.id', email_verified: true },
    payload: { id: 'DOC_123', ownerUid: 'guru_uid_1', createdAt: '2020-01-01T00:00:00Z' },
    expectedResult: 'PERMISSION_DENIED',
    enforcedByRule: 'Temporal Integrity enforces incoming().createdAt == request.time',
  },
  {
    id: 11,
    name: 'Oversized Payload / Denial of Wallet',
    collectionPath: '/attendanceRecords/DOC_456',
    operation: 'create',
    actor: { uid: 'guru_uid_1', email: 'guru@school.id', email_verified: true },
    payload: { id: 'DOC_456', ownerUid: 'guru_uid_1', catatan: 'A'.repeat(10000) },
    expectedResult: 'PERMISSION_DENIED',
    enforcedByRule: 'isValidAttendanceRecord enforces data.catatan.size() <= 500',
  },
  {
    id: 12,
    name: 'Terminal State Bypass on Recovery Notification',
    collectionPath: '/recoveryNotifications/REC_1',
    operation: 'create',
    actor: { uid: 'guru_uid_1', email: 'guru@school.id', email_verified: true },
    payload: { id: 'REC_1', requesterUid: 'guru_uid_1', status: 'selesai' },
    expectedResult: 'PERMISSION_DENIED',
    enforcedByRule: 'recoveryNotifications create mandates incoming().status == "menunggu"',
  },
];
