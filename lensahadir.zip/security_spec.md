# Security Specification — LensaHadir Firestore Rules

## 1. Data Invariants
1. **Default Deny**: All unmatched paths are explicitly denied (`allow read, write: if false`).
2. **Email Verification Gate**: Every authenticated write requires `request.auth != null && request.auth.token.email_verified == true`.
3. **Bootstrapped & Trusted Admin**: Admin privileges belong exclusively to the verified runtime owner (`longya332@gmail.com` with `email_verified == true`) or UIDs registered in `/admins/{uid}`. No non-admin can create or modify `/admins/{uid}` or `/adminConfig/{configId}` or `/adminUserSecrets/{userId}`.
4. **No Self-Assigned Roles**: A user cannot assign themselves `Admin` or `Pimpinan`. A `/pimpinanRoles/{uid}` document can only be created by a user whose `request.auth.uid` is bound to an active `role == 'Pimpinan'` entry in `/loginDirectory/{usernameKey}` created by Admin.
5. **PII & Secret Isolation**: User passwords and confirmation contacts live in `/adminUserSecrets/{userId}` (Admin-only). `/users/{userId}` is strictly readable only by Admin or its bound owner (`linkedUid == request.auth.uid`). `/loginDirectory/{usernameKey}` stores zero PII and forbids non-admin `list`.
6. **Self-Profile Update Boundaries**: A Guru/Pegawai or Pimpinan updating their own `/users/{userId}` can ONLY mutate `['nama', 'nip', 'golRuang', 'statusPegawai', 'jabatan', 'profileUpdatedBySelf', 'updatedAt']` — never `role`, `username`, `usernameKey`, `aktif`, `linkedUid`, or `createdAt`.
7. **Ownership & Global Consistency**: Every `attendanceRecords` creation enforces `ownerUid == request.auth.uid` (unless Admin). Every `adminSubmissions` creation enforces `ownerUid == request.auth.uid` AND `exists(/databases/$(database)/documents/attendanceRecords/$(incoming().recordId))`.
8. **Temporal Integrity & Terminal States**: All `createdAt` / `updatedAt` timestamps must match `request.time`. Once `recoveryNotifications.status == 'selesai'` or `adminRegistrations.status == 'dihubungi'`, non-admins cannot reopen or modify them.
9. **Path Hardening & Size Bounds**: Every single-doc operation validates `isValidId()` (`^[a-zA-Z0-9_\-]+$`, `<= 128` chars), and every string enforces explicit `.size()` boundaries.

## 2. The "Dirty Dozen" Adversarial Payloads (Must All Return PERMISSION_DENIED)
1. **Unverified Admin Email Spoof**: `{ email: "longya332@gmail.com", email_verified: false }` reading `/adminConfig/profile`.
2. **Shadow Field Injection on User Profile**: Updating `/users/u1` with `{ nama: "Budi", isAdmin: true, updatedAt: serverTimestamp() }`.
3. **Self-Role Escalation to Pimpinan**: Non-admin creating `/pimpinanRoles/{attackerUid}` pointing to a non-existent or `Guru/Pegawai` `loginDirectory` entry.
4. **Privilege Escalation via Profile Update**: Guru updating `/users/u1` with `{ role: "Pimpinan", updatedAt: serverTimestamp() }`.
5. **Cross-User PII Scraping**: Authenticated Guru attempting `get` on `/users/otherUserId` or `list` on `/users` without `linkedUid == uid`.
6. **Admin Secret Theft**: Authenticated Guru or Pimpinan attempting `get` or `list` on `/adminUserSecrets/u1`.
7. **Ownership Spoofing on Attendance Record**: Guru creating `/attendanceRecords/DOC_999` with `{ ownerUid: "victimUid", ... }`.
8. **Orphaned Admin Submission**: Guru creating `/adminSubmissions/SUB_999` referencing a non-existent `recordId: "FAKE_ID"`.
9. **ID Poisoning Attack**: Creating `/attendanceRecords/../../adminConfig` or a 300-char document ID.
10. **Client-Spoofed Timestamp**: Creating `/attendanceRecords/DOC_123` with `createdAt` set to a past client date instead of `request.time`.
11. **Oversized Payload / Denial of Wallet**: Creating `/attendanceRecords/DOC_456` with `catatan` of 10,000 characters (`> 500` limit).
12. **Terminal State Bypass on Recovery Notification**: Non-admin creating `/recoveryNotifications/REC_1` directly with `status: "selesai"` or modifying a completed notification.
