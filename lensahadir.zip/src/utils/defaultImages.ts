/**
 * Generates crisp SVG Data URLs for default placeholders and dummy avatars
 * to prevent any broken external URLs or network dependency issues.
 */

export const createPlaceholderImage = (label: string, sublabel: string, iconType: 'masuk' | 'keluar'): string => {
  const isMasuk = iconType === 'masuk';
  const bgColor = isMasuk ? '#1e3a8a' : '#047857';
  const lightBg = isMasuk ? '#eff6ff' : '#ecfdf5';
  const accent = isMasuk ? '#3b82f6' : '#10b981';

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="800" viewBox="0 0 600 800">
    <rect width="600" height="800" fill="${lightBg}"/>
    <rect x="20" y="20" width="560" height="760" rx="16" fill="none" stroke="${accent}" stroke-width="4" stroke-dasharray="12 8" opacity="0.6"/>
    
    <!-- User Silhouette / Camera target -->
    <g transform="translate(300, 360)">
      <circle cx="0" cy="-60" r="90" fill="${accent}" opacity="0.2"/>
      <circle cx="0" cy="-60" r="70" fill="${bgColor}"/>
      <!-- Person head -->
      <circle cx="0" cy="-75" r="34" fill="#ffffff"/>
      <!-- Person body -->
      <path d="M -48,-15 C -48,-42 48,-42 48,-15 C 48,15 -48,15 -48,-15 Z" fill="#ffffff"/>
      
      <!-- Lens badge -->
      <circle cx="45" cy="-20" r="28" fill="#ffffff" stroke="${bgColor}" stroke-width="4"/>
      <path d="M 35,-26 L 55,-26 L 55,-14 L 35,-14 Z M 45,-20 A 4 4 0 1 1 45,-19.9" fill="${bgColor}"/>
    </g>

    <!-- Text Labels -->
    <text x="300" y="520" text-anchor="middle" font-family="Plus Jakarta Sans, sans-serif" font-weight="800" font-size="28" fill="${bgColor}" letter-spacing="1">
      ${label.toUpperCase()}
    </text>
    <text x="300" y="560" text-anchor="middle" font-family="Plus Jakarta Sans, sans-serif" font-weight="500" font-size="18" fill="#64748b">
      ${sublabel}
    </text>

    <!-- Bottom Stamp box -->
    <rect x="60" y="660" width="480" height="64" rx="12" fill="#ffffff" stroke="#cbd5e1" stroke-width="2"/>
    <text x="300" y="700" text-anchor="middle" font-family="Plus Jakarta Sans, sans-serif" font-weight="600" font-size="16" fill="#475569">
      Klik untuk Unggah Foto
    </text>
  </svg>`;

  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
};

export const defaultFotoMasuk = createPlaceholderImage("Foto Masuk", "Upload foto TimeMark kehadiran masuk", "masuk");
export const defaultFotoKeluar = createPlaceholderImage("Foto Keluar", "Upload foto TimeMark selesai/pulang", "keluar");

/**
 * Creates sample photo for demo mode
 */
export const createSampleTeacherPhoto = (name: string, type: 'masuk' | 'keluar', timeStr: string): string => {
  const isMasuk = type === 'masuk';
  const tagColor = isMasuk ? '#1d4ed8' : '#059669';
  const tagTitle = isMasuk ? 'VERIFIKASI MASUK' : 'VERIFIKASI PULANG';
  
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="800" viewBox="0 0 600 800">
    <defs>
      <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#1e293b"/>
        <stop offset="50%" stop-color="#334155"/>
        <stop offset="100%" stop-color="#0f172a"/>
      </linearGradient>
      <linearGradient id="shirtGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#d97706"/>
        <stop offset="100%" stop-color="#92400e"/>
      </linearGradient>
    </defs>
    <!-- Background wall -->
    <rect width="600" height="800" fill="url(#bgGrad)"/>
    <rect x="0" y="550" width="600" height="250" fill="#0f172a" opacity="0.6"/>

    <!-- School classroom background lines -->
    <line x1="0" y1="200" x2="600" y2="200" stroke="#475569" stroke-width="2" opacity="0.4"/>
    <rect x="80" y="80" width="440" height="180" rx="8" fill="#1e293b" stroke="#64748b" stroke-width="3" opacity="0.5"/>
    <text x="300" y="180" text-anchor="middle" font-family="Plus Jakarta Sans, sans-serif" font-size="20" font-weight="700" fill="#94a3b8" letter-spacing="2">RUANG GURU / KANTOR</text>

    <!-- Teacher silhouette / portrait -->
    <g transform="translate(300, 480)">
      <!-- Shoulders & Batik/Khaki uniform -->
      <path d="M -180,240 C -180,100 -120,40 0,40 C 120,40 180,100 180,240 Z" fill="url(#shirtGrad)"/>
      <path d="M -40,40 L 0,110 L 40,40 Z" fill="#f8fafc"/>
      <polygon points="0,70 -14,140 0,220 14,140" fill="#b45309"/>
      
      <!-- Neck -->
      <rect x="-35" y="-10" width="70" height="60" rx="10" fill="#fbcfe8"/>
      <!-- Face -->
      <ellipse cx="0" cy="-90" rx="75" ry="95" fill="#fed7aa"/>
      <!-- Hair -->
      <path d="M -80,-110 C -80,-190 80,-190 80,-110 C 80,-80 70,-40 60,-40 C 50,-100 -50,-100 -60,-40 C -70,-40 -80,-80 -80,-110 Z" fill="#1c1917"/>
      <!-- Glasses -->
      <rect x="-55" y="-100" width="42" height="28" rx="6" fill="none" stroke="#0f172a" stroke-width="4"/>
      <rect x="13" y="-100" width="42" height="28" rx="6" fill="none" stroke="#0f172a" stroke-width="4"/>
      <line x1="-13" y1="-86" x2="13" y2="-86" stroke="#0f172a" stroke-width="4"/>
      <!-- Smile -->
      <path d="M -25,-45 Q 0,-30 25,-45" fill="none" stroke="#9a3412" stroke-width="3" stroke-linecap="round"/>
      <!-- Pegawai Badge ID -->
      <rect x="70" y="110" width="46" height="60" rx="4" fill="#ffffff" stroke="#cbd5e1" stroke-width="2"/>
      <rect x="76" y="116" width="34" height="20" fill="#93c5fd"/>
      <line x1="76" y1="145" x2="110" y2="145" stroke="#64748b" stroke-width="3"/>
    </g>

    <!-- Watermark Stamp Overlay -->
    <rect x="20" y="660" width="560" height="110" rx="12" fill="rgba(15, 23, 42, 0.88)" stroke="${tagColor}" stroke-width="2"/>
    <rect x="36" y="675" width="160" height="26" rx="6" fill="${tagColor}"/>
    <text x="116" y="693" text-anchor="middle" font-family="Plus Jakarta Sans, sans-serif" font-weight="800" font-size="12" fill="#ffffff" letter-spacing="1">
      ${tagTitle}
    </text>
    <text x="36" y="730" font-family="JetBrains Mono, monospace" font-size="16" font-weight="700" fill="#f8fafc">
      JAM: ${timeStr} WIB
    </text>
    <text x="36" y="754" font-family="Plus Jakarta Sans, sans-serif" font-size="13" font-weight="500" fill="#cbd5e1">
      Pegawai: ${name} (Terverifikasi LensaHadir)
    </text>
  </svg>`;

  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
};
