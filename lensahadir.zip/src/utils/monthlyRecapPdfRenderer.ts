import { jsPDF } from 'jspdf';
import { AppSettings, MonthlyRecapConfig, MonthlyRecapRow } from '../types/attendance';
import {
  computeMonthlyStats,
  INDONESIAN_MONTHS,
  MonthlyComputedStats,
} from './monthlyRecapParser';
import { formatIndonesianShortDate } from './dailyReportCanvasRenderer';

/**
 * Crisp default left emblem (Lambang Daerah / Pemerintah Daerah style) when user hasn't uploaded a custom PNG
 */
export const DEFAULT_LOGO_KIRI =
  'data:image/svg+xml;charset=utf-8,' +
  encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120">
    <path d="M60 8 L104 26 L98 76 C94 96 78 108 60 114 C42 108 26 96 22 76 L16 26 Z" fill="#15803d" stroke="#b45309" stroke-width="5"/>
    <path d="M60 16 L96 31 L91 74 C88 90 74 100 60 105 C46 100 32 90 29 74 L24 31 Z" fill="#dc2626" stroke="#facc15" stroke-width="2.5"/>
    <circle cx="60" cy="58" r="22" fill="#facc15" stroke="#991b1b" stroke-width="2"/>
    <polygon points="60,22 63,31 72,31 65,36 68,45 60,40 52,45 55,36 48,31 57,31" fill="#facc15"/>
    <rect x="46" y="54" width="28" height="16" rx="2" fill="#1e3a8a"/>
    <path d="M40 74 L80 74 L74 84 L46 84 Z" fill="#ffffff"/>
    <text x="60" y="82" text-anchor="middle" font-family="Arial,sans-serif" font-size="8" font-weight="bold" fill="#1e3a8a">PEMDA</text>
  </svg>`);

/**
 * Crisp default right emblem (Tut Wuri Handayani style) when user hasn't uploaded a custom PNG
 */
export const DEFAULT_LOGO_KANAN =
  'data:image/svg+xml;charset=utf-8,' +
  encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120">
    <polygon points="60,8 106,42 88,104 32,104 14,42" fill="#0284c7" stroke="#0369a1" stroke-width="4"/>
    <polygon points="60,16 98,45 83,96 37,96 22,45" fill="#ffffff"/>
    <polygon points="60,21 93,47 80,91 40,91 27,47" fill="#0ea5e9"/>
    <circle cx="60" cy="56" r="19" fill="#ffffff"/>
    <path d="M44 58 L60 44 L76 58 L71 70 L49 70 Z" fill="#0284c7"/>
    <circle cx="60" cy="48" r="5" fill="#facc15"/>
    <rect x="46" y="61" width="28" height="6" rx="2" fill="#ffffff"/>
    <text x="60" y="85" text-anchor="middle" font-family="Arial,sans-serif" font-size="7.5" font-weight="bold" fill="#ffffff">TUT WURI HANDAYANI</text>
  </svg>`);

export interface MonthlyPdfPage {
  pageNumber: number;
  totalPages: number;
  rows: MonthlyRecapRow[];
  startIndex: number;
  isFirstPage: boolean;
  isLastPage: boolean;
}

/**
 * Paginates monthly table rows cleanly across A4 pages.
 * Up to 14 rows fit comfortably on Page 1 alongside Kop, 4 KPIs, Charts, Notes, and Signature.
 * Larger schools automatically flow cleanly to Page 2, 3, etc.
 */
export const paginateMonthlyRows = (rows: MonthlyRecapRow[]): MonthlyPdfPage[] => {
  if (rows.length === 0) {
    return [
      {
        pageNumber: 1,
        totalPages: 1,
        rows: [],
        startIndex: 0,
        isFirstPage: true,
        isLastPage: true,
      },
    ];
  }

  // Fit up to 14 rows on 1 single page (matches the 11-row PDF reference cleanly)
  const MAX_FIRST_PAGE_WITH_FOOTER = 14;
  const MAX_FIRST_PAGE_CONTINUATION = 17;
  const MAX_NEXT_PAGE = 26;

  if (rows.length <= MAX_FIRST_PAGE_WITH_FOOTER) {
    return [
      {
        pageNumber: 1,
        totalPages: 1,
        rows,
        startIndex: 0,
        isFirstPage: true,
        isLastPage: true,
      },
    ];
  }

  const chunks: { rows: MonthlyRecapRow[]; startIndex: number }[] = [];
  chunks.push({ rows: rows.slice(0, MAX_FIRST_PAGE_CONTINUATION), startIndex: 0 });

  let cursor = MAX_FIRST_PAGE_CONTINUATION;
  while (cursor < rows.length) {
    chunks.push({
      rows: rows.slice(cursor, cursor + MAX_NEXT_PAGE),
      startIndex: cursor,
    });
    cursor += MAX_NEXT_PAGE;
  }

  const totalPages = chunks.length;
  return chunks.map((chunk, idx) => ({
    pageNumber: idx + 1,
    totalPages,
    rows: chunk.rows,
    startIndex: chunk.startIndex,
    isFirstPage: idx === 0,
    isLastPage: idx === totalPages - 1,
  }));
};

const loadImageSafe = (src: string): Promise<HTMLImageElement> => {
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = () => resolve(img);
    img.src = src;
  });
};

function drawRoundedRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number
) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

function wrapTextLines(
  ctx: CanvasRenderingContext2D,
  text: string,
  maxWidth: number
): string[] {
  const words = text.split(/\s+/).filter(Boolean);
  if (words.length === 0) return [''];
  const lines: string[] = [];
  let current = words[0];
  for (let i = 1; i < words.length; i++) {
    const candidate = `${current} ${words[i]}`;
    if (ctx.measureText(candidate).width <= maxWidth) {
      current = candidate;
    } else {
      lines.push(current);
      current = words[i];
    }
  }
  lines.push(current);
  return lines;
}

export const getDefaultAdminNotes = (
  config: MonthlyRecapConfig,
  stats: MonthlyComputedStats
): string[] => {
  if (config.catatanAdmin && config.catatanAdmin.trim().length > 0) {
    return config.catatanAdmin
      .split(/\r?\n/)
      .map((l) => l.replace(/^[•\-*]\s*/, '').trim())
      .filter(Boolean);
  }

  const monthName = INDONESIAN_MONTHS[config.bulan - 1] || 'Bulan';
  const tpStart = config.bulan >= 7 ? config.tahun : config.tahun - 1;
  const tpEnd = tpStart + 1;

  const note1 = `Berdasarkan Kalender Pendidikan TP ${tpStart}/${tpEnd}, ${monthName} ${config.tahun} memiliki ${config.hariKerjaEfektif} Hari Kerja Efektif (${config.polaHariKerja}).`;
  const note2 = `Data presensi divalidasi melalui rekapitulasi kamera berstempel digital TimeMark (Waktu & Geotagging Lokasi Sekolah) yang sinkron dengan daftar hadir fisik harian.`;

  let note3: string;
  if (stats.totalTD > 0 && stats.totalAbsenNonTugas === 0) {
    note3 = `Tercatat ${stats.totalTD} hari tugas kedinasan (TD) resmi. Seluruh tenaga pendidik dan kependidikan menuntaskan beban tugas mengajar ${stats.tingkatDisiplinPct.toFixed(1)}%.`;
  } else if (stats.totalAbsenNonTugas > 0) {
    note3 = `Tercatat ${stats.totalTD} hari Tugas Dinas (TD), ${stats.totalI} hari Izin, ${stats.totalS} hari Sakit, dan ${stats.totalTK} hari Tanpa Keterangan dengan tingkat disiplin tugas sebesar ${stats.tingkatDisiplinPct.toFixed(1)}%.`;
  } else {
    note3 = `Seluruh ${stats.totalPersonil} tenaga pendidik dan kependidikan hadir penuh tanpa catatan absen/alpa dan menuntaskan beban tugas ${stats.tingkatDisiplinPct.toFixed(1)}%.`;
  }

  return [note1, note2, note3];
};

/**
 * Renders one A4 Portrait page (1240 x 1754 px @ 150 DPI) of the
 * "LAPORAN REKAPITULASI ABSENSI FOTO TIMEMARK" matching the uploaded PDF design.
 */
export const renderMonthlyRecapPageToCanvas = async (
  page: MonthlyPdfPage,
  allRows: MonthlyRecapRow[],
  config: MonthlyRecapConfig,
  settings: AppSettings
): Promise<HTMLCanvasElement | null> => {
  const canvas = document.createElement('canvas');
  const width = 1240;
  const height = 1754;
  canvas.width = width;
  canvas.height = height;

  const ctx = canvas.getContext('2d');
  if (!ctx) return null;

  const sans = '"Plus Jakarta Sans", -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif';
  const marginX = 64;
  const contentW = width - marginX * 2; // 1112
  const monthName = INDONESIAN_MONTHS[config.bulan - 1] || 'Bulan';
  const stats = computeMonthlyStats(
    allRows,
    config.hariKerjaEfektif,
    config.bulan,
    config.tahun,
    config.customWeeklyTrend
  );

  // 1. Crisp white A4 background
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, width, height);

  let y = 52;

  // =========================================================================
  // HEADER KOP DENGAN 2 LOGO (HALAMAN 1)
  // =========================================================================
  if (page.isFirstPage) {
    const [logoL, logoR] = await Promise.all([
      loadImageSafe(config.logoKiri || DEFAULT_LOGO_KIRI),
      loadImageSafe(config.logoKanan || DEFAULT_LOGO_KANAN),
    ]);

    const logoSize = 104;
    if (logoL.width > 0) {
      ctx.drawImage(logoL, marginX + 18, y + 8, logoSize, logoSize);
    }
    if (logoR.width > 0) {
      ctx.drawImage(logoR, width - marginX - logoSize - 18, y + 8, logoSize, logoSize);
    }

    const headerLines = (settings.namaInstansi || 'PEMERINTAH KABUPATEN\nDINAS PENDIDIKAN')
      .split(/\r?\n/)
      .map((l) => l.trim())
      .filter(Boolean);

    ctx.textAlign = 'center';
    ctx.textBaseline = 'top';

    let hy = y;
    ctx.fillStyle = '#334155';
    ctx.font = `700 17px ${sans}`;
    if (headerLines[0]) {
      ctx.fillText(headerLines[0].toUpperCase(), width / 2, hy);
      hy += 23;
    }
    if (headerLines[1]) {
      ctx.fillStyle = '#475569';
      ctx.font = `700 16px ${sans}`;
      ctx.fillText(headerLines[1].toUpperCase(), width / 2, hy);
      hy += 23;
    }

    ctx.fillStyle = '#0f172a';
    ctx.font = `800 25px ${sans}`;
    ctx.fillText('LAPORAN REKAPITULASI ABSENSI FOTO TIMEMARK', width / 2, hy + 2);
    hy += 33;

    ctx.fillStyle = '#1d4ed8';
    ctx.font = `800 20px ${sans}`;
    const subTitle = `${(settings.subInstansi || 'SATUAN PENDIDIKAN').toUpperCase()} – BULAN ${monthName.toUpperCase()} ${config.tahun}`;
    ctx.fillText(subTitle, width / 2, hy + 2);
    hy += 29;

    ctx.fillStyle = '#64748b';
    ctx.font = `500 14.5px ${sans}`;
    ctx.fillText(
      `Berdasarkan Kalender Pendidikan & Rekap Kehadiran Digital (TimeMark)  •  Periode: ${stats.periodLabel}`,
      width / 2,
      hy + 4
    );

    y = Math.max(y + logoSize + 20, hy + 30);

    // Garis biru tegas di bawah kop
    ctx.fillStyle = '#1e40af';
    ctx.fillRect(marginX, y, contentW, 3.5);
    y += 18;

    // =========================================================================
    // 4 KPI SUMMARY CARDS
    // =========================================================================
    const kpiGap = 14;
    const kpiW = (contentW - kpiGap * 3) / 4;
    const kpiH = 92;

    const kpiCards = [
      {
        accent: '#2563eb',
        label: 'HARI KERJA EFEKTIF',
        value: `${config.hariKerjaEfektif} Hari`,
        sub: config.polaHariKerja,
      },
      {
        accent: '#16a34a',
        label: 'TINGKAT DISIPLIN TUGAS',
        value: `${stats.tingkatDisiplinPct.toFixed(1)}%`,
        sub: `${stats.totalAbsenNonTugas} Absen / Alpa / Bolos`,
      },
      {
        accent: '#4f46e5',
        label: 'TOTAL GURU & TENDIK',
        value: `${stats.totalPersonil} Personil`,
        sub: stats.personilBreakdownText,
      },
      {
        accent: '#d97706',
        label: 'PRESENSI FISIK DI SEKOLAH',
        value: `${stats.presensiFisikPct.toFixed(2)}%`,
        sub: `${stats.totalH} Hadir • ${stats.totalTD} Tugas Dinas`,
      },
    ];

    for (let i = 0; i < kpiCards.length; i++) {
      const card = kpiCards[i];
      const cx = marginX + i * (kpiW + kpiGap);

      ctx.save();
      drawRoundedRect(ctx, cx, y, kpiW, kpiH, 8);
      ctx.fillStyle = '#ffffff';
      ctx.fill();
      ctx.strokeStyle = '#e2e8f0';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Colored left bar
      ctx.clip();
      ctx.fillStyle = card.accent;
      ctx.fillRect(cx, y, 5, kpiH);
      ctx.restore();

      ctx.textAlign = 'left';
      ctx.textBaseline = 'top';
      ctx.fillStyle = '#64748b';
      ctx.font = `700 12.5px ${sans}`;
      ctx.fillText(card.label, cx + 16, y + 13);

      ctx.fillStyle = '#0f172a';
      ctx.font = `800 24px ${sans}`;
      ctx.fillText(card.value, cx + 16, y + 32);

      ctx.fillStyle = '#64748b';
      ctx.font = `500 12px ${sans}`;
      ctx.fillText(card.sub, cx + 16, y + 66);
    }

    y += kpiH + 16;

    // =========================================================================
    // VISUAL ANALYTICS BOX (KURVA TREN + DISTRIBUSI STATUS KEHADIRAN)
    // =========================================================================
    const chartBoxH = 166;
    drawRoundedRect(ctx, marginX, y, contentW, chartBoxH, 10);
    ctx.fillStyle = '#ffffff';
    ctx.fill();
    ctx.strokeStyle = '#e2e8f0';
    ctx.lineWidth = 1.5;
    ctx.stroke();

    const leftPaneW = Math.round(contentW * 0.56);
    const rightPaneX = marginX + leftPaneW + 24;
    const rightPaneW = contentW - leftPaneW - 44;

    // Left Pane Title + Badge
    ctx.textAlign = 'left';
    ctx.textBaseline = 'top';
    ctx.fillStyle = '#0f172a';
    ctx.font = `700 15px ${sans}`;
    ctx.fillText(
      `Kurva Tren Kehadiran Harian Pegawai (1–${stats.daysInMonth} ${monthName} ${config.tahun})`,
      marginX + 18,
      y + 14
    );

    const badgeText =
      stats.tingkatDisiplinPct >= 99.5
        ? `Sempurna / ${stats.totalPersonil} Pegawai Aktif`
        : `${stats.totalPersonil} Pegawai Aktif`;
    ctx.font = `700 12px ${sans}`;
    const bW = Math.min(205, ctx.measureText(badgeText).width + 20);
    const bX = marginX + leftPaneW - bW - 8;
    drawRoundedRect(ctx, bX, y + 11, bW, 24, 6);
    ctx.fillStyle = '#dcfce7';
    ctx.fill();
    ctx.fillStyle = '#15803d';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(badgeText, bX + bW / 2, y + 23);

    // Draw Area/Line Chart
    const plotX = marginX + 52;
    const plotY = y + 54;
    const plotW = leftPaneW - 72;
    const plotH = 74;
    const maxVal = Math.max(1, stats.totalPersonil);

    // Grid lines
    ctx.strokeStyle = '#e2e8f0';
    ctx.lineWidth = 1;
    for (const frac of [0, 0.45, 1]) {
      const gy = plotY + plotH * (1 - frac);
      ctx.beginPath();
      ctx.moveTo(plotX, gy);
      ctx.lineTo(plotX + plotW, gy);
      ctx.stroke();
    }

    // Y axis labels
    ctx.fillStyle = '#94a3b8';
    ctx.font = `600 11px ${sans}`;
    ctx.textAlign = 'right';
    ctx.textBaseline = 'middle';
    ctx.fillText(String(maxVal), plotX - 10, plotY + 2);
    if (maxVal > 1) {
      ctx.fillText(String(maxVal - 1), plotX - 10, plotY + plotH * 0.55);
    }
    ctx.fillText('0', plotX - 10, plotY + plotH);

    // Build smooth plotted points (emphasizing subtle 1-person dip when TD occurs, matching PDF visual)
    const pts = stats.weeklyTrend;
    const chartCoords = pts.map((pt, idx) => {
      const px = plotX + (pts.length > 1 ? (idx / (pts.length - 1)) * plotW : plotW / 2);
      // Map [maxVal-1 .. maxVal] visually clearly like the PDF
      const norm =
        pt.present >= maxVal
          ? 1
          : pt.present === maxVal - 1
          ? 0.55
          : Math.max(0.08, (pt.present / maxVal) * 0.55);
      const py = plotY + plotH * (1 - norm);
      return { x: px, y: py, pt };
    });

    if (chartCoords.length >= 2) {
      // Area gradient under curve
      const grad = ctx.createLinearGradient(0, plotY, 0, plotY + plotH);
      grad.addColorStop(0, 'rgba(37, 99, 235, 0.18)');
      grad.addColorStop(1, 'rgba(37, 99, 235, 0.02)');
      ctx.beginPath();
      ctx.moveTo(chartCoords[0].x, plotY + plotH);
      for (const c of chartCoords) ctx.lineTo(c.x, c.y);
      ctx.lineTo(chartCoords[chartCoords.length - 1].x, plotY + plotH);
      ctx.closePath();
      ctx.fillStyle = grad;
      ctx.fill();

      // Line stroke
      ctx.beginPath();
      ctx.moveTo(chartCoords[0].x, chartCoords[0].y);
      for (let i = 1; i < chartCoords.length; i++) {
        ctx.lineTo(chartCoords[i].x, chartCoords[i].y);
      }
      ctx.strokeStyle = '#2563eb';
      ctx.lineWidth = 3;
      ctx.stroke();

      // Highlight any dip point (TD / absence) with orange circle + annotation pill
      for (const c of chartCoords) {
        if (c.pt.td > 0 || c.pt.absent > 0) {
          ctx.beginPath();
          ctx.arc(c.x, c.y, 5.5, 0, Math.PI * 2);
          ctx.fillStyle = '#f59e0b';
          ctx.fill();
          ctx.strokeStyle = '#ffffff';
          ctx.lineWidth = 2;
          ctx.stroke();

          const noteTxt =
            c.pt.td > 0
              ? `${c.pt.td} TD (Dinas Luar)`
              : `${c.pt.absent} Izin/Sakit/TK`;
          ctx.font = `700 10.5px ${sans}`;
          const pillW = ctx.measureText(noteTxt).width + 14;
          drawRoundedRect(ctx, c.x - pillW / 2, c.y + 9, pillW, 18, 4);
          ctx.fillStyle = '#fef3c7';
          ctx.fill();
          ctx.strokeStyle = '#f59e0b';
          ctx.lineWidth = 1;
          ctx.stroke();
          ctx.fillStyle = '#b45309';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(noteTxt, c.x, c.y + 18);
        }
      }
    }

    // X-axis weekly labels
    ctx.fillStyle = '#64748b';
    ctx.font = `500 10.5px ${sans}`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'top';
    for (const c of chartCoords) {
      ctx.fillText(c.pt.label, c.x, plotY + plotH + 8);
    }

    // Right Pane: Distribusi Status Kehadiran
    ctx.textAlign = 'left';
    ctx.textBaseline = 'top';
    ctx.fillStyle = '#0f172a';
    ctx.font = `700 15px ${sans}`;
    ctx.fillText('Distribusi Status Kehadiran', rightPaneX, y + 14);

    const bars = [
      {
        color: '#16a34a',
        label: `Hadir TimeMark Fisik (${stats.presensiFisikPct.toFixed(2)}%)`,
        valText: `${stats.totalH} Hari`,
        pct: stats.presensiFisikPct,
      },
      {
        color: '#d97706',
        label: `Tugas Dinas / TD (${stats.tdPct.toFixed(2)}%)`,
        valText: `${stats.totalTD} Hari`,
        pct: stats.tdPct,
      },
      {
        color: '#dc2626',
        label: `Izin / Sakit / Alpa (${stats.absenPct.toFixed(2)}%)`,
        valText: `${stats.totalAbsenNonTugas} Hari`,
        pct: stats.absenPct,
      },
    ];

    let barY = y + 48;
    for (const bar of bars) {
      // Colored bullet dot
      ctx.beginPath();
      ctx.arc(rightPaneX + 5, barY + 7, 4, 0, Math.PI * 2);
      ctx.fillStyle = bar.color;
      ctx.fill();

      ctx.fillStyle = bar.color;
      ctx.font = `700 13px ${sans}`;
      ctx.textAlign = 'left';
      ctx.textBaseline = 'top';
      ctx.fillText(bar.label, rightPaneX + 15, barY);

      ctx.fillStyle = '#0f172a';
      ctx.font = `700 13px ${sans}`;
      ctx.textAlign = 'right';
      ctx.fillText(bar.valText, rightPaneX + rightPaneW, barY);

      // Progress track
      const trackY = barY + 21;
      drawRoundedRect(ctx, rightPaneX, trackY, rightPaneW, 7, 3.5);
      ctx.fillStyle = '#e2e8f0';
      ctx.fill();

      if (bar.pct > 0) {
        const fillW = Math.max(12, (bar.pct / 100) * rightPaneW);
        drawRoundedRect(ctx, rightPaneX, trackY, fillW, 7, 3.5);
        ctx.fillStyle = bar.color;
        ctx.fill();
      }

      barY += 38;
    }

    y += chartBoxH + 20;
  } else {
    // Page 2+ compact running header
    ctx.fillStyle = '#475569';
    ctx.font = `700 13px ${sans}`;
    ctx.textAlign = 'left';
    ctx.textBaseline = 'top';
    ctx.fillText(
      `LANJUTAN — LAPORAN REKAPITULASI ABSENSI BULAN ${monthName.toUpperCase()} ${config.tahun} (${settings.subInstansi || ''})`,
      marginX,
      y
    );
    ctx.fillStyle = '#1e40af';
    ctx.fillRect(marginX, y + 22, contentW, 2);
    y += 34;
  }

  // =========================================================================
  // MAIN TABLE: DAFTAR REKAPITULASI PRESENSI PEGAWAI
  // =========================================================================
  ctx.textAlign = 'left';
  ctx.textBaseline = 'top';
  ctx.fillStyle = '#0f172a';
  ctx.font = `800 15.5px ${sans}`;
  ctx.fillText(
    `DAFTAR REKAPITULASI PRESENSI PEGAWAI BULAN ${monthName.toUpperCase()} ${config.tahun}`,
    marginX,
    y
  );

  ctx.textAlign = 'right';
  ctx.fillStyle = '#475569';
  ctx.font = `600 13.5px ${sans}`;
  ctx.fillText(
    `Kebutuhan Hari Kerja Efektif: ${config.hariKerjaEfektif} Hari`,
    marginX + contentW,
    y + 1
  );

  y += 26;

  // Column widths summing strictly to contentW = 1112
  const cols = {
    no: 42,
    nama: 244,
    nip: 196,
    jabatan: 186,
    gol: 64,
    h: 44,
    td: 44,
    i: 42,
    s: 42,
    tk: 42,
    total: 74,
    pct: 92,
  };
  const xNo = marginX;
  const xNama = xNo + cols.no;
  const xNip = xNama + cols.nama;
  const xJab = xNip + cols.nip;
  const xGol = xJab + cols.jabatan;
  const xH = xGol + cols.gol;
  const xTD = xH + cols.h;
  const xI = xTD + cols.td;
  const xS = xI + cols.i;
  const xTK = xS + cols.s;
  const xTotal = xTK + cols.tk;
  const xPct = xTotal + cols.total;

  const hHeadTop = 28;
  const hHeadSub = 26;
  const hHead = hHeadTop + hHeadSub;

  // Table header background (deep royal blue)
  ctx.fillStyle = '#1e3a8a';
  ctx.fillRect(marginX, y, contentW, hHead);

  // Lighter royal blue for sub-header H TD I S TK
  ctx.fillStyle = '#2563eb';
  ctx.fillRect(xH, y + hHeadTop, cols.h + cols.td + cols.i + cols.s + cols.tk, hHeadSub);

  // Header gridlines
  ctx.strokeStyle = 'rgba(255,255,255,0.28)';
  ctx.lineWidth = 1;
  for (const gx of [xNama, xNip, xJab, xGol, xH, xTotal, xPct]) {
    ctx.beginPath();
    ctx.moveTo(gx, y);
    ctx.lineTo(gx, y + hHead);
    ctx.stroke();
  }
  ctx.beginPath();
  ctx.moveTo(xH, y + hHeadTop);
  ctx.lineTo(xTotal, y + hHeadTop);
  ctx.stroke();
  for (const gx of [xTD, xI, xS, xTK]) {
    ctx.beginPath();
    ctx.moveTo(gx, y + hHeadTop);
    ctx.lineTo(gx, y + hHead);
    ctx.stroke();
  }

  // Header texts
  ctx.fillStyle = '#ffffff';
  ctx.textBaseline = 'middle';
  ctx.font = `700 13.5px ${sans}`;

  ctx.textAlign = 'center';
  ctx.fillText('No', xNo + cols.no / 2, y + hHead / 2);
  ctx.textAlign = 'left';
  ctx.fillText('Nama Lengkap & Gelar', xNama + 10, y + hHead / 2);
  ctx.textAlign = 'center';
  ctx.fillText('NIP', xNip + cols.nip / 2, y + hHead / 2);
  ctx.textAlign = 'left';
  ctx.fillText('Tugas / Jabatan', xJab + 10, y + hHead / 2);
  ctx.textAlign = 'center';
  ctx.fillText('Gol.', xGol + cols.gol / 2, y + hHead / 2);

  ctx.font = `700 12.5px ${sans}`;
  ctx.fillText(
    'Rincian Kehadiran (Hari)',
    xH + (cols.h + cols.td + cols.i + cols.s + cols.tk) / 2,
    y + hHeadTop / 2
  );
  ctx.fillText('H', xH + cols.h / 2, y + hHeadTop + hHeadSub / 2);
  ctx.fillText('TD', xTD + cols.td / 2, y + hHeadTop + hHeadSub / 2);
  ctx.fillText('I', xI + cols.i / 2, y + hHeadTop + hHeadSub / 2);
  ctx.fillText('S', xS + cols.s / 2, y + hHeadTop + hHeadSub / 2);
  ctx.fillText('TK', xTK + cols.tk / 2, y + hHeadTop + hHeadSub / 2);

  ctx.font = `700 12.5px ${sans}`;
  ctx.fillText('Total', xTotal + cols.total / 2, y + hHead / 2 - 8);
  ctx.fillText('Efektif', xTotal + cols.total / 2, y + hHead / 2 + 8);
  ctx.fillText('% Hadir', xPct + cols.pct / 2, y + hHead / 2);

  y += hHead;

  // Dynamic row height so up to 14 rows fit comfortably on Page 1 with notes & signature
  const rowH = page.isFirstPage
    ? page.rows.length > 12
      ? 38
      : 44
    : 42;

  const safeWorkDays = Math.max(1, config.hariKerjaEfektif || 1);

  for (let i = 0; i < page.rows.length; i++) {
    const r = page.rows[i];
    const rowTop = y;
    const midY = rowTop + rowH / 2;

    // Alternating zebra stripe
    ctx.fillStyle = i % 2 === 1 ? '#f8fafc' : '#ffffff';
    ctx.fillRect(marginX, rowTop, contentW, rowH);

    // Subtle cell borders
    ctx.strokeStyle = '#cbd5e1';
    ctx.lineWidth = 1;
    ctx.strokeRect(marginX, rowTop, contentW, rowH);
    for (const gx of [xNama, xNip, xJab, xGol, xH, xTD, xI, xS, xTK, xTotal, xPct]) {
      ctx.beginPath();
      ctx.moveTo(gx, rowTop);
      ctx.lineTo(gx, rowTop + rowH);
      ctx.stroke();
    }

    ctx.textBaseline = 'middle';
    // No
    ctx.textAlign = 'center';
    ctx.fillStyle = '#334155';
    ctx.font = `600 13.5px ${sans}`;
    ctx.fillText(String(page.startIndex + i + 1), xNo + cols.no / 2, midY);

    // Nama Lengkap & Gelar (exact casing preserved!)
    ctx.textAlign = 'left';
    ctx.fillStyle = '#0f172a';
    ctx.font = `700 13.5px ${sans}`;
    const namaLines = wrapTextLines(ctx, r.nama || '-', cols.nama - 18);
    if (namaLines.length === 1) {
      ctx.fillText(namaLines[0], xNama + 10, midY);
    } else {
      ctx.fillText(namaLines[0], xNama + 10, midY - 7);
      ctx.fillText(namaLines[1], xNama + 10, midY + 8);
    }

    // NIP
    ctx.textAlign = 'center';
    ctx.fillStyle = '#334155';
    ctx.font = `500 12.5px ${sans}`;
    const nipLines = wrapTextLines(ctx, r.nip || '-', cols.nip - 12);
    if (nipLines.length === 1) {
      ctx.fillText(nipLines[0], xNip + cols.nip / 2, midY);
    } else {
      ctx.fillText(nipLines[0], xNip + cols.nip / 2, midY - 7);
      ctx.fillText(nipLines[1], xNip + cols.nip / 2, midY + 8);
    }

    // Tugas / Jabatan
    ctx.textAlign = 'left';
    ctx.fillStyle = '#1e293b';
    ctx.font = `500 13px ${sans}`;
    const jabLines = wrapTextLines(ctx, r.jabatan || '-', cols.jabatan - 16);
    if (jabLines.length === 1) {
      ctx.fillText(jabLines[0], xJab + 10, midY);
    } else {
      ctx.fillText(jabLines[0], xJab + 10, midY - 7);
      ctx.fillText(jabLines[1], xJab + 10, midY + 8);
    }

    // Gol.
    ctx.textAlign = 'center';
    ctx.fillStyle = '#334155';
    ctx.font = `600 13px ${sans}`;
    ctx.fillText(r.golongan || '-', xGol + cols.gol / 2, midY);

    // H, TD, I, S, TK
    const rowTotalEfektif = (r.h || 0) + (r.td || 0);
    const rowPct = Math.min(100, (rowTotalEfektif / safeWorkDays) * 100);

    ctx.font = `700 13.5px ${sans}`;
    ctx.fillStyle = '#0f172a';
    ctx.fillText(String(r.h || 0), xH + cols.h / 2, midY);

    ctx.fillStyle = r.td > 0 ? '#d97706' : '#64748b';
    ctx.font = `${r.td > 0 ? '700' : '500'} 13.5px ${sans}`;
    ctx.fillText(String(r.td || 0), xTD + cols.td / 2, midY);

    ctx.fillStyle = r.i > 0 ? '#2563eb' : '#64748b';
    ctx.font = `${r.i > 0 ? '700' : '500'} 13.5px ${sans}`;
    ctx.fillText(String(r.i || 0), xI + cols.i / 2, midY);

    ctx.fillStyle = r.s > 0 ? '#ea580c' : '#64748b';
    ctx.font = `${r.s > 0 ? '700' : '500'} 13.5px ${sans}`;
    ctx.fillText(String(r.s || 0), xS + cols.s / 2, midY);

    ctx.fillStyle = r.tk > 0 ? '#dc2626' : '#64748b';
    ctx.font = `${r.tk > 0 ? '700' : '500'} 13.5px ${sans}`;
    ctx.fillText(String(r.tk || 0), xTK + cols.tk / 2, midY);

    // Total Efektif
    ctx.fillStyle = '#0f172a';
    ctx.font = `700 13.5px ${sans}`;
    ctx.fillText(String(rowTotalEfektif), xTotal + cols.total / 2, midY);

    // % Hadir soft badge
    const badgeBg =
      rowPct >= 95 ? '#dcfce7' : rowPct >= 80 ? '#fef3c7' : '#fee2e2';
    const badgeFg =
      rowPct >= 95 ? '#15803d' : rowPct >= 80 ? '#b45309' : '#b91c1c';
    const pillW = 68;
    const pillH = 24;
    drawRoundedRect(
      ctx,
      xPct + (cols.pct - pillW) / 2,
      midY - pillH / 2,
      pillW,
      pillH,
      5
    );
    ctx.fillStyle = badgeBg;
    ctx.fill();
    ctx.fillStyle = badgeFg;
    ctx.font = `700 12.5px ${sans}`;
    ctx.fillText(`${rowPct.toFixed(1)}%`, xPct + cols.pct / 2, midY);

    y += rowH;
  }

  // Summary Footer Row on Last Page
  if (page.isLastPage) {
    const sumH = 38;
    ctx.fillStyle = '#f1f5f9';
    ctx.fillRect(marginX, y, contentW, sumH);
    ctx.strokeStyle = '#94a3b8';
    ctx.lineWidth = 1.2;
    ctx.strokeRect(marginX, y, contentW, sumH);

    ctx.strokeStyle = '#cbd5e1';
    ctx.lineWidth = 1;
    for (const gx of [xH, xTD, xI, xS, xTK, xTotal, xPct]) {
      ctx.beginPath();
      ctx.moveTo(gx, y);
      ctx.lineTo(gx, y + sumH);
      ctx.stroke();
    }

    const midY = y + sumH / 2;
    ctx.textBaseline = 'middle';
    ctx.textAlign = 'center';
    ctx.fillStyle = '#0f172a';
    ctx.font = `800 13.5px ${sans}`;
    ctx.fillText(
      'JUMLAH / RATA-RATA KESELURUHAN',
      xNo + (xH - xNo) / 2,
      midY
    );

    ctx.fillStyle = '#1d4ed8';
    ctx.fillText(String(stats.totalH), xH + cols.h / 2, midY);
    ctx.fillStyle = stats.totalTD > 0 ? '#d97706' : '#0f172a';
    ctx.fillText(String(stats.totalTD), xTD + cols.td / 2, midY);
    ctx.fillStyle = '#0f172a';
    ctx.fillText(String(stats.totalI), xI + cols.i / 2, midY);
    ctx.fillText(String(stats.totalS), xS + cols.s / 2, midY);
    ctx.fillStyle = stats.totalTK > 0 ? '#dc2626' : '#0f172a';
    ctx.fillText(String(stats.totalTK), xTK + cols.tk / 2, midY);

    ctx.fillStyle = '#0f172a';
    ctx.fillText(String(stats.totalEfektif), xTotal + cols.total / 2, midY);

    ctx.fillStyle = '#15803d';
    ctx.fillText(`${stats.tingkatDisiplinPct.toFixed(1)}%`, xPct + cols.pct / 2, midY);

    y += sumH + 22;

    // =========================================================================
    // BOTTOM SECTION: CATATAN & VERIFIKASI ADMINISTRASI + TTD KEPALA SEKOLAH
    // =========================================================================
    const notesW = Math.round(contentW * 0.58);
    const notesH = Math.min(198, Math.max(150, height - 74 - y));

    // Left Dashed Notes Box
    ctx.save();
    drawRoundedRect(ctx, marginX, y, notesW, notesH, 8);
    ctx.fillStyle = '#f8fafc';
    ctx.fill();
    ctx.strokeStyle = '#cbd5e1';
    ctx.lineWidth = 1.5;
    ctx.setLineDash([6, 4]);
    ctx.stroke();
    ctx.restore();

    ctx.textAlign = 'left';
    ctx.textBaseline = 'top';
    ctx.fillStyle = '#0f172a';
    ctx.font = `700 13.5px ${sans}`;
    ctx.fillText('Catatan & Verifikasi Administrasi:', marginX + 16, y + 14);

    const noteBullets = getDefaultAdminNotes(config, stats);
    ctx.fillStyle = '#334155';
    ctx.font = `500 12.5px ${sans}`;
    let ny = y + 38;
    for (const bullet of noteBullets) {
      if (ny > y + notesH - 18) break;
      ctx.fillText('•', marginX + 16, ny);
      const wrapped = wrapTextLines(ctx, bullet, notesW - 44);
      for (const line of wrapped) {
        if (ny > y + notesH - 16) break;
        ctx.fillText(line, marginX + 30, ny);
        ny += 18;
      }
      ny += 4;
    }

    // Right Signature Block (Kepala Sekolah dari Kop Instansi)
    const sigCenterX = marginX + notesW + (contentW - notesW) / 2;
    let sy = y + 4;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'top';
    ctx.fillStyle = '#0f172a';
    ctx.font = `500 14.5px ${sans}`;
    ctx.fillText(
      `${settings.kota || 'Tempat'}, ${formatIndonesianShortDate(config.tanggalTtd)}`,
      sigCenterX,
      sy
    );
    sy += 22;

    ctx.font = `700 14.5px ${sans}`;
    ctx.fillText(settings.jabatanPimpinan || 'Kepala Sekolah', sigCenterX, sy);
    sy += 92;

    const pimpinanName = settings.namaPimpinan?.trim() || '....................................';
    ctx.font = `800 15px ${sans}`;
    ctx.fillText(pimpinanName, sigCenterX, sy);

    const nameW = ctx.measureText(pimpinanName).width;
    ctx.strokeStyle = '#0f172a';
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.moveTo(sigCenterX - nameW / 2, sy + 19);
    ctx.lineTo(sigCenterX + nameW / 2, sy + 19);
    ctx.stroke();

    ctx.fillStyle = '#475569';
    ctx.font = `500 13.5px ${sans}`;
    ctx.fillText(`NIP. ${settings.nipPimpinan || '-'}`, sigCenterX, sy + 24);
  }

  // =========================================================================
  // PAGE FOOTER BAR
  // =========================================================================
  const footerY = height - 48;
  ctx.strokeStyle = '#e2e8f0';
  ctx.lineWidth = 1.2;
  ctx.beginPath();
  ctx.moveTo(marginX, footerY);
  ctx.lineTo(width - marginX, footerY);
  ctx.stroke();

  ctx.fillStyle = '#64748b';
  ctx.font = `500 12.5px ${sans}`;
  ctx.textBaseline = 'middle';

  ctx.textAlign = 'left';
  ctx.fillText(
    `Sistem Administrasi Kepegawaian & Absensi Digital ${settings.subInstansi || 'LensaHadir'}`,
    marginX,
    footerY + 22
  );

  ctx.textAlign = 'center';
  const centerFooter = settings.alamatInstansi || settings.kota || 'LensaHadir';
  ctx.fillText(
    centerFooter.length > 48 ? centerFooter.slice(0, 48) + '…' : centerFooter,
    width / 2,
    footerY + 22
  );

  ctx.textAlign = 'right';
  ctx.fillText(
    `Halaman ${page.pageNumber} dari ${page.totalPages}`,
    width - marginX,
    footerY + 22
  );

  return canvas;
};

/**
 * Generates a single-page or multi-page A4 Portrait PDF Blob ready for direct PC download
 */
export const renderMonthlyRecapToPdfBlob = async (
  rows: MonthlyRecapRow[],
  config: MonthlyRecapConfig,
  settings: AppSettings
): Promise<Blob | null> => {
  const pages = paginateMonthlyRows(rows);
  if (pages.length === 0) return null;

  const pdf = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
    compress: true,
  });

  for (let i = 0; i < pages.length; i++) {
    const canvas = await renderMonthlyRecapPageToCanvas(pages[i], rows, config, settings);
    if (!canvas) continue;
    if (i > 0) {
      pdf.addPage('a4', 'portrait');
    }
    const imgData = canvas.toDataURL('image/jpeg', 0.96);
    pdf.addImage(imgData, 'JPEG', 0, 0, 210, 297, undefined, 'FAST');
  }

  return pdf.output('blob');
};

/**
 * Generates a PNG Blob for a specific A4 page
 */
export const renderMonthlyRecapPageToPngBlob = async (
  pageIndex: number,
  rows: MonthlyRecapRow[],
  config: MonthlyRecapConfig,
  settings: AppSettings
): Promise<Blob | null> => {
  const pages = paginateMonthlyRows(rows);
  const page = pages[pageIndex];
  if (!page) return null;
  const canvas = await renderMonthlyRecapPageToCanvas(page, rows, config, settings);
  if (!canvas) return null;
  return new Promise((resolve) => canvas.toBlob((blob) => resolve(blob), 'image/png'));
};
