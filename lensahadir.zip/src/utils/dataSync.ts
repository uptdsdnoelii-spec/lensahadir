import {
  AdminAccountProfile,
  AdminConfirmationContact,
  AdminRegistrationRequest,
  AdminSubmissionRecord,
  AppSettings,
  AttendanceRecord,
  AuthSession,
  DataLockConfig,
  ManagedUser,
  RecoveryNotification,
} from '../types/attendance';

export interface LensaHadirDataBundle {
  version: number;
  updatedAt: number;
  settings?: AppSettings;
  adminProfile?: AdminAccountProfile;
  adminContact?: AdminConfirmationContact;
  lockConfig?: DataLockConfig;
  users?: ManagedUser[];
  records?: AttendanceRecord[];
  adminSubmissions?: AdminSubmissionRecord[];
  recoveryNotifications?: RecoveryNotification[];
  adminRegistrations?: AdminRegistrationRequest[];
  deletedRecordIds?: string[];
  deletedSubmissionIds?: string[];
  deletedUserIds?: string[];
}

export interface SyncMutationPayload {
  type:
    | 'full_replace'
    | 'save_settings'
    | 'save_admin_profile'
    | 'save_admin_contact'
    | 'save_lock_config'
    | 'save_user'
    | 'activate_all_users'
    | 'delete_user'
    | 'save_record'
    | 'delete_record'
    | 'save_submission'
    | 'delete_submission'
    | 'save_recovery'
    | 'mark_recovery_done'
    | 'delete_recovery'
    | 'save_registration'
    | 'mark_registration_contacted'
    | 'delete_registration';
  payload?: any;
  id?: string;
}

const SYNC_ENDPOINT = '/api/sync-data';
const LOGIN_ENDPOINT = '/api/auth/login';

// Held strictly in JS memory (never written to localStorage/sessionStorage)
let inMemoryBearerToken: string | null = null;

export const setAuthBearerToken = (token: string | null): void => {
  inMemoryBearerToken = token || null;
};

export type ServerLoginResult =
  | { ok: true; session: AuthSession; token?: string }
  | { ok: false; code: 'INVALID' | 'INACTIVE' | 'UNSEEDED' | 'OFFLINE'; error?: string };

export const loginViaServer = async (
  username: string,
  password: string
): Promise<ServerLoginResult> => {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 3500);
  try {
    const res = await fetch(LOGIN_ENDPOINT, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
      },
      body: JSON.stringify({ username, password }),
      signal: controller.signal,
    });
    const contentType = res.headers.get('content-type') || '';
    if (!contentType.includes('application/json')) {
      return { ok: false, code: 'OFFLINE' };
    }
    const json = await res.json();
    if (res.ok && json?.ok && json?.session) {
      if (typeof json.token === 'string' && json.token) {
        setAuthBearerToken(json.token);
      }
      return { ok: true, session: json.session as AuthSession, token: json.token };
    }
    if (res.status === 403 && json?.code === 'INACTIVE') {
      return {
        ok: false,
        code: 'INACTIVE',
        error:
          json.error ||
          'Akun ini sedang dinonaktifkan oleh Admin. Silakan hubungi Admin instansi.',
      };
    }
    if (res.status === 404 && json?.code === 'UNSEEDED') {
      return { ok: false, code: 'UNSEEDED' };
    }
    return {
      ok: false,
      code: 'INVALID',
      error:
        json?.error || 'Username atau Password salah! Periksa kembali data masuk Anda.',
    };
  } catch {
    return { ok: false, code: 'OFFLINE' };
  } finally {
    clearTimeout(timeout);
  }
};

/**
 * Compresses large smartphone photos so JSON sync payloads stay fast and lightweight.
 */
export const compressPhotoDataUrl = async (dataUrl: string): Promise<string> => {
  if (!dataUrl) return '';
  if (!dataUrl.startsWith('data:image/')) return dataUrl;
  if (dataUrl.length <= 160000) return dataUrl;

  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      try {
        const maxDim = 640;
        let w = img.width || 640;
        let h = img.height || 480;
        if (w > maxDim || h > maxDim) {
          if (w >= h) {
            h = Math.round((h * maxDim) / w);
            w = maxDim;
          } else {
            w = Math.round((w * maxDim) / h);
            h = maxDim;
          }
        }
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(dataUrl);
          return;
        }
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, w, h);
        ctx.drawImage(img, 0, 0, w, h);

        let quality = 0.68;
        let result = canvas.toDataURL('image/jpeg', quality);
        while (result.length > 220000 && quality > 0.28) {
          quality -= 0.12;
          result = canvas.toDataURL('image/jpeg', quality);
        }
        resolve(result);
      } catch {
        resolve(dataUrl);
      }
    };
    img.onerror = () => resolve(dataUrl);
    img.src = dataUrl;
  });
};

export const pullSyncedData = async (): Promise<LensaHadirDataBundle | null> => {
  try {
    const res = await fetch(SYNC_ENDPOINT, {
      method: 'GET',
      headers: { Accept: 'application/json' },
      cache: 'no-store',
    });
    if (!res.ok) return null;
    const contentType = res.headers.get('content-type') || '';
    if (!contentType.includes('application/json')) return null;
    const json = await res.json();
    if (json && json.ok && json.data) {
      return json.data as LensaHadirDataBundle;
    }
    return null;
  } catch {
    return null;
  }
};

export const pushSyncMutation = async (
  mutation: SyncMutationPayload
): Promise<LensaHadirDataBundle | null> => {
  try {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };
    if (inMemoryBearerToken) {
      headers.Authorization = `Bearer ${inMemoryBearerToken}`;
    }
    const res = await fetch(SYNC_ENDPOINT, {
      method: 'POST',
      headers,
      body: JSON.stringify(mutation),
    });
    if (!res.ok) return null;
    const contentType = res.headers.get('content-type') || '';
    if (!contentType.includes('application/json')) return null;
    const json = await res.json();
    if (json && json.ok && json.data) {
      return json.data as LensaHadirDataBundle;
    }
    return null;
  } catch {
    return null;
  }
};

export const exportBackupJsonFile = (bundle: LensaHadirDataBundle): string => {
  const today = new Date().toISOString().split('T')[0];
  const filename = `BACKUP_LENSAHADIR_${today}.json`;
  const jsonStr = JSON.stringify(
    {
      ...bundle,
      version: 1,
      updatedAt: Date.now(),
    },
    null,
    2
  );
  const blob = new Blob([jsonStr], { type: 'application/json;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  return filename;
};

export const parseBackupJsonFile = async (
  file: File
): Promise<{ ok: true; data: LensaHadirDataBundle } | { ok: false; message: string }> => {
  try {
    const text = await file.text();
    const parsed = JSON.parse(text);
    if (!parsed || typeof parsed !== 'object') {
      return { ok: false, message: 'Format file backup tidak valid.' };
    }
    const hasRecognizedKey =
      'settings' in parsed ||
      'adminProfile' in parsed ||
      'users' in parsed ||
      'records' in parsed ||
      'adminSubmissions' in parsed;
    if (!hasRecognizedKey) {
      return {
        ok: false,
        message: 'File JSON ini bukan file backup resmi dari LensaHadir.',
      };
    }
    return {
      ok: true,
      data: {
        version: 1,
        updatedAt: Number(parsed.updatedAt) || Date.now(),
        settings: parsed.settings,
        adminProfile: parsed.adminProfile,
        adminContact: parsed.adminContact,
        lockConfig: parsed.lockConfig,
        users: Array.isArray(parsed.users) ? parsed.users : undefined,
        records: Array.isArray(parsed.records) ? parsed.records : undefined,
        adminSubmissions: Array.isArray(parsed.adminSubmissions)
          ? parsed.adminSubmissions
          : undefined,
        recoveryNotifications: Array.isArray(parsed.recoveryNotifications)
          ? parsed.recoveryNotifications
          : undefined,
        adminRegistrations: Array.isArray(parsed.adminRegistrations)
          ? parsed.adminRegistrations
          : undefined,
      },
    };
  } catch {
    return { ok: false, message: 'Gagal membaca file backup. Pastikan file berformat .json.' };
  }
};

/**
 * Non-destructive union merge by `id` so background sync NEVER drops or flickers
 * existing attendance records or Admin submissions (only explicitly deleted IDs are excluded).
 */
export function mergeByIdNonDestructive<T extends { id: string }>(
  localItems: T[],
  remoteItems: T[] | undefined,
  deletedIds: Set<string>,
  getTimestamp: (item: T) => number
): { merged: T[]; localHadExtra: boolean } {
  const remoteArr = Array.isArray(remoteItems) ? remoteItems : [];
  const map = new Map<string, T>();

  for (const item of localItems) {
    if (item && item.id && !deletedIds.has(item.id)) {
      map.set(item.id, item);
    }
  }

  const remoteIdSet = new Set<string>();
  for (const item of remoteArr) {
    if (!item || !item.id || deletedIds.has(item.id)) continue;
    remoteIdSet.add(item.id);
    const existing = map.get(item.id);
    if (!existing || getTimestamp(item) >= getTimestamp(existing)) {
      map.set(item.id, item);
    }
  }

  let localHadExtra = false;
  for (const item of localItems) {
    if (item && item.id && !deletedIds.has(item.id) && !remoteIdSet.has(item.id)) {
      localHadExtra = true;
      break;
    }
  }

  const merged = Array.from(map.values()).sort((a, b) => getTimestamp(b) - getTimestamp(a));
  return { merged, localHadExtra };
}
