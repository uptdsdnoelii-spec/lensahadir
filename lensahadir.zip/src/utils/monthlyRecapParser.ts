import * as XLSX from 'xlsx';
import * as pdfjsLib from 'pdfjs-dist';
import pdfjsWorker from 'pdfjs-dist/build/pdf.worker.min.mjs?url';
import {
  AttendanceRecord,
  MonthlyRecapRow,
  PegawaiKategori,
  WeeklyTrendPoint,
} from '../types/attendance';

// Configure pdf.js worker safely for Vite builds
try {
  pdfjsLib.GlobalWorkerOptions.workerSrc = pdfjsWorker;
} catch {
  // Fallback if worker cannot be assigned
}

export const INDONESIAN_MONTHS = [
  'Januari',
  'Februari',
  'Maret',
  'April',
  'Mei',
  'Juni',
  'Juli',
  'Agustus',
  'September',
  'Oktober',
  'November',
  'Desember',
];

export const getDaysInMonth = (bulan: number, tahun: number): number => {
  return new Date(tahun, bulan, 0).getDate();
};

export const getDefaultEffectiveWorkDays = (
  bulan: number,
  tahun: number,
  isSixDays = true
): number => {
  const days = getDaysInMonth(bulan, tahun);
  let count = 0;
  for (let d = 1; d <= days; d++) {
    const dow = new Date(tahun, bulan - 1, d).getDay(); // 0=Sun, 6=Sat
    if (dow === 0) continue;
    if (!isSixDays && dow === 6) continue;
    count++;
  }
  return count;
};

export const inferKategoriFromGolongan = (
  golongan: string,
  statusHint?: string
): PegawaiKategori => {
  const g = (golongan || '').trim().toUpperCase();
  const s = (statusHint || '').trim().toUpperCase();

  if (s.includes('GTT') || s.includes('HONOR') || s.includes('PTT') || g === 'GTT' || g === 'PTT' || g === 'HONOR') {
    return 'GTT';
  }
  if (s.includes('PPPK') || g.includes('PPPK') || /^(I|II|III|IV|V|VI|VII|VIII|IX|X|XI|XII|XIII|XIV|XV|XVI|XVII)$/.test(g)) {
    // Pure Roman numerals like IX, VII, X without /a-/e are PPPK grades in Indonesia
    if (/^(V|VI|VII|VIII|IX|X|XI|XII|XIII|XIV|XV|XVI|XVII)$/.test(g) || s.includes('PPPK') || g.includes('PPPK')) {
      return 'PPPK';
    }
  }
  if (/^(I|II|III|IV)\s*\/?\s*[A-E]$/i.test(g) || s.includes('ASN') || s.includes('PNS')) {
    return 'PNS';
  }
  if (g === '-' || g === '') {
    return 'GTT';
  }
  return 'Lainnya';
};

export interface MonthlyComputedStats {
  totalPersonil: number;
  pnsCount: number;
  pppkCount: number;
  gttCount: number;
  otherCount: number;
  totalH: number;
  totalTD: number;
  totalI: number;
  totalS: number;
  totalTK: number;
  totalEfektif: number;
  targetTotal: number;
  totalAbsenNonTugas: number;
  tingkatDisiplinPct: number;
  presensiFisikPct: number;
  tdPct: number;
  absenPct: number;
  daysInMonth: number;
  periodLabel: string;
  weeklyTrend: WeeklyTrendPoint[];
  personilBreakdownText: string;
}

/**
 * Generates weekly labels Mg I..Mg V based on actual calendar days of the month
 */
export const buildWeeklyLabels = (bulan: number, tahun: number): string[] => {
  const days = getDaysInMonth(bulan, tahun);
  const ranges: [number, number][] = [];
  let start = 1;
  while (start <= days && ranges.length < 5) {
    // Skip Sunday if start is Sunday
    const startDow = new Date(tahun, bulan - 1, start).getDay();
    if (startDow === 0 && start < days) {
      start++;
    }
    let end = start;
    while (end < days) {
      const dow = new Date(tahun, bulan - 1, end).getDay();
      if (dow === 6) break;
      end++;
    }
    if (ranges.length === 4) {
      end = days;
    }
    ranges.push([start, end]);
    start = end + 1;
  }
  const roman = ['I', 'II', 'III', 'IV', 'V'];
  return ranges.map(([s, e], i) => `Mg ${roman[i]} (${s}-${e})`);
};

export const computeMonthlyStats = (
  rows: MonthlyRecapRow[],
  hariKerjaEfektif: number,
  bulan: number,
  tahun: number,
  customWeeklyTrend?: WeeklyTrendPoint[]
): MonthlyComputedStats => {
  const totalPersonil = rows.length;
  let pnsCount = 0;
  let pppkCount = 0;
  let gttCount = 0;
  let otherCount = 0;

  let totalH = 0;
  let totalTD = 0;
  let totalI = 0;
  let totalS = 0;
  let totalTK = 0;

  for (const r of rows) {
    if (r.kategori === 'PNS') pnsCount++;
    else if (r.kategori === 'PPPK') pppkCount++;
    else if (r.kategori === 'GTT') gttCount++;
    else otherCount++;

    totalH += Math.max(0, Number(r.h) || 0);
    totalTD += Math.max(0, Number(r.td) || 0);
    totalI += Math.max(0, Number(r.i) || 0);
    totalS += Math.max(0, Number(r.s) || 0);
    totalTK += Math.max(0, Number(r.tk) || 0);
  }

  const totalEfektif = totalH + totalTD;
  const totalAbsenNonTugas = totalI + totalS + totalTK;
  const safeWorkDays = Math.max(1, Number(hariKerjaEfektif) || 1);
  const targetTotal = Math.max(1, totalPersonil * safeWorkDays);

  const tingkatDisiplinPct =
    totalPersonil > 0 ? Math.min(100, (totalEfektif / targetTotal) * 100) : 0;
  const presensiFisikPct =
    totalPersonil > 0 ? Math.min(100, (totalH / targetTotal) * 100) : 0;
  const tdPct = totalPersonil > 0 ? Math.min(100, (totalTD / targetTotal) * 100) : 0;
  const absenPct =
    totalPersonil > 0 ? Math.min(100, (totalAbsenNonTugas / targetTotal) * 100) : 0;

  const daysInMonth = getDaysInMonth(bulan, tahun);
  const monthName = INDONESIAN_MONTHS[bulan - 1] || 'Bulan';
  const periodLabel = `1 s.d. ${daysInMonth} ${monthName} ${tahun}`;

  // Build personnel breakdown string e.g. "8 PNS • 1 PPPK • 2 GTT"
  const parts: string[] = [];
  if (pnsCount > 0) parts.push(`${pnsCount} PNS`);
  if (pppkCount > 0) parts.push(`${pppkCount} PPPK`);
  if (gttCount > 0) parts.push(`${gttCount} GTT`);
  if (otherCount > 0) parts.push(`${otherCount} Lainnya`);
  const personilBreakdownText = parts.length > 0 ? parts.join(' • ') : 'Belum ada data';

  // Build weekly trend curve (either from uploaded daily grid or synthesized cleanly from totals)
  let weeklyTrend: WeeklyTrendPoint[];
  if (customWeeklyTrend && customWeeklyTrend.length >= 2) {
    weeklyTrend = customWeeklyTrend;
  } else {
    const labels = buildWeeklyLabels(bulan, tahun);
    weeklyTrend = labels.map((label) => ({
      label,
      present: totalPersonil,
      td: 0,
      absent: 0,
    }));

    // Represent TD or absences visibly in middle week(s) when only summary counts are given
    if (totalPersonil > 0 && (totalTD > 0 || totalAbsenNonTugas > 0)) {
      const midIdx = Math.min(2, weeklyTrend.length - 1);
      const dropVal = Math.min(
        totalPersonil,
        Math.max(1, Math.round((totalTD + totalAbsenNonTugas) / Math.max(1, Math.ceil((totalTD + totalAbsenNonTugas) / 2))))
      );
      weeklyTrend[midIdx] = {
        ...weeklyTrend[midIdx],
        present: Math.max(0, totalPersonil - Math.min(dropVal, totalPersonil)),
        td: totalTD,
        absent: totalAbsenNonTugas,
      };
    }
  }

  return {
    totalPersonil,
    pnsCount,
    pppkCount,
    gttCount,
    otherCount,
    totalH,
    totalTD,
    totalI,
    totalS,
    totalTK,
    totalEfektif,
    targetTotal,
    totalAbsenNonTugas,
    tingkatDisiplinPct,
    presensiFisikPct,
    tdPct,
    absenPct,
    daysInMonth,
    periodLabel,
    weeklyTrend,
    personilBreakdownText,
  };
};

export interface ParsedRecapResult {
  rows: MonthlyRecapRow[];
  detectedHariKerja?: number;
  detectedBulan?: number;
  detectedTahun?: number;
  weeklyTrend?: WeeklyTrendPoint[];
  sourceSummary: string;
}

const cleanCellStr = (v: unknown): string => {
  if (v === null || v === undefined) return '';
  return String(v).replace(/\s+/g, ' ').trim();
};

const parseIntSafe = (v: unknown): number => {
  if (typeof v === 'number' && Number.isFinite(v)) return Math.max(0, Math.round(v));
  const str = cleanCellStr(v).replace(/[^0-9]/g, '');
  if (!str) return 0;
  return Math.max(0, parseInt(str, 10) || 0);
};

const classifyAttendanceCode = (
  raw: string
): 'h' | 'td' | 'i' | 's' | 'tk' | null => {
  const code = raw.trim().toUpperCase();
  if (!code || code === '-' || code === 'L' || code === 'LIBUR' || code === 'MINGGU') {
    return null;
  }
  if (code === 'H' || code.startsWith('HADIR') || code === '✓' || code === 'V') return 'h';
  if (code === 'TD' || code === 'DL' || code.includes('DINAS') || code.includes('TUGAS')) return 'td';
  if (code === 'I' || code.startsWith('IJIN') || code.startsWith('IZIN') || code === 'C' || code.startsWith('CUTI')) return 'i';
  if (code === 'S' || code.startsWith('SAKIT')) return 's';
  if (code === 'TK' || code === 'TB' || code === 'A' || code.includes('ALPA') || code.includes('TANPA')) return 'tk';
  return null;
};

/**
 * Parses uploaded Excel (.xlsx/.xls) or CSV (.csv) file into MonthlyRecapRow[].
 * Automatically supports:
 *  1) Summary table (Nama, NIP, Jabatan, Gol, H, TD, I, S, TK)
 *  2) Daily attendance matrix (Nama, NIP, ..., Day 1..31 with H/TD/I/S/TK codes)
 *  3) Daily log rows (multiple rows per employee with Date + Status)
 */
const parseSpreadsheetBuffer = (
  buffer: ArrayBuffer,
  defaultWorkDays: number
): ParsedRecapResult => {
  const workbook = XLSX.read(buffer, { type: 'array' });
  const sheetName = workbook.SheetNames[0];
  const sheet = workbook.Sheets[sheetName];
  const matrix: unknown[][] = XLSX.utils.sheet_to_json(sheet, {
    header: 1,
    defval: '',
    raw: true,
  });

  if (!matrix || matrix.length === 0) {
    throw new Error('File spreadsheet kosong.');
  }

  // Try to detect month/year in top rows
  let detectedBulan: number | undefined;
  let detectedTahun: number | undefined;
  for (let r = 0; r < Math.min(8, matrix.length); r++) {
    const joined = matrix[r].map(cleanCellStr).join(' ');
    for (let m = 0; m < INDONESIAN_MONTHS.length; m++) {
      if (joined.toLowerCase().includes(INDONESIAN_MONTHS[m].toLowerCase())) {
        detectedBulan = m + 1;
        break;
      }
    }
    const yearMatch = joined.match(/\b(202\d|203\d)\b/);
    if (yearMatch) {
      detectedTahun = parseInt(yearMatch[1], 10);
    }
  }

  // Locate header row (row containing 'nama' or 'pegawai')
  let headerRowIdx = -1;
  for (let r = 0; r < Math.min(20, matrix.length); r++) {
    const cells = matrix[r].map((c) => cleanCellStr(c).toLowerCase());
    if (cells.some((c) => c.includes('nama') || c.includes('pegawai'))) {
      headerRowIdx = r;
      break;
    }
  }

  if (headerRowIdx === -1) {
    throw new Error(
      'Header kolom tidak ditemukan. Pastikan file memiliki kolom "Nama" / "Nama Lengkap".'
    );
  }

  // Combine header row with potential sub-header row (e.g. merged "Rincian Kehadiran" over H, TD, I, S, TK)
  const mainHeaders = matrix[headerRowIdx].map((c) => cleanCellStr(c));
  const subHeaders =
    headerRowIdx + 1 < matrix.length
      ? matrix[headerRowIdx + 1].map((c) => cleanCellStr(c))
      : [];

  const hasSubHeader = subHeaders.some((s) =>
    ['h', 'td', 'i', 's', 'tk', 'tb', 'a', '1', '2', '3'].includes(s.toLowerCase())
  );

  const effectiveHeaders = mainHeaders.map((h, idx) => {
    const sub = hasSubHeader ? subHeaders[idx] || '' : '';
    return sub || h;
  });

  const dataStartIdx = headerRowIdx + (hasSubHeader ? 2 : 1);

  const findCol = (patterns: RegExp[]): number => {
    for (let i = 0; i < effectiveHeaders.length; i++) {
      const h = effectiveHeaders[i].toLowerCase();
      if (patterns.some((p) => p.test(h))) return i;
    }
    return -1;
  };

  const colNama = findCol([/nama/, /pegawai/]);
  const colNip = findCol([/^nip/, /id pegawai/]);
  const colJabatan = findCol([/jabatan/, /tugas/, /unit/]);
  const colGol = findCol([/^gol/, /pangkat/, /ruang/]);
  const colStatusPegawai = findCol([/status pegawai/, /kategori/, /kepegawaian/]);

  // Check if Format B: Daily matrix columns (1..31)
  const dayCols: { colIdx: number; dayNum: number }[] = [];
  for (let i = 0; i < effectiveHeaders.length; i++) {
    const h = effectiveHeaders[i].trim();
    if (/^\d{1,2}$/.test(h)) {
      const num = parseInt(h, 10);
      if (num >= 1 && num <= 31) {
        dayCols.push({ colIdx: i, dayNum: num });
      }
    }
  }

  // Check if Format A: Summary count columns (H, TD, I, S, TK)
  const colH = findCol([/^h$/, /^hadir/, /jml.*hadir/]);
  const colTD = findCol([/^td$/, /tugas\s*dinas/, /^dl$/]);
  const colI = findCol([/^i$/, /^ijin/, /^izin/, /^cuti/]);
  const colS = findCol([/^s$/, /^sakit/]);
  const colTK = findCol([/^tk$/, /^tb$/, /^a$/, /alpa/, /tanpa/]);

  // Check if Format C: Daily log rows (Status Kehadiran + Tanggal column)
  const colStatusKehadiran = findCol([/status\s*kehadiran/, /kehadiran/, /keterangan/]);

  const rows: MonthlyRecapRow[] = [];

  if (dayCols.length >= 5) {
    // FORMAT B: Daily Grid (Dates 1..31)
    let maxDaysSeen = 0;
    const weeklyBuckets: { presentDays: number; tdDays: number; absDays: number; workDays: Set<number> }[] =
      Array.from({ length: 5 }, () => ({
        presentDays: 0,
        tdDays: 0,
        absDays: 0,
        workDays: new Set<number>(),
      }));

    for (let r = dataStartIdx; r < matrix.length; r++) {
      const row = matrix[r];
      const nama = cleanCellStr(row[colNama]);
      if (!nama || /jumlah|total|rata-rata|kepala/i.test(nama)) continue;

      let h = 0;
      let td = 0;
      let iCnt = 0;
      let sCnt = 0;
      let tk = 0;

      for (const dc of dayCols) {
        const code = classifyAttendanceCode(cleanCellStr(row[dc.colIdx]));
        if (!code) continue;
        const wIdx = Math.min(4, Math.floor((dc.dayNum - 1) / 6));
        weeklyBuckets[wIdx].workDays.add(dc.dayNum);
        if (code === 'h') {
          h++;
          weeklyBuckets[wIdx].presentDays++;
        } else if (code === 'td') {
          td++;
          weeklyBuckets[wIdx].tdDays++;
        } else if (code === 'i') {
          iCnt++;
          weeklyBuckets[wIdx].absDays++;
        } else if (code === 's') {
          sCnt++;
          weeklyBuckets[wIdx].absDays++;
        } else if (code === 'tk') {
          tk++;
          weeklyBuckets[wIdx].absDays++;
        }
      }

      const personDays = h + td + iCnt + sCnt + tk;
      if (personDays > maxDaysSeen) maxDaysSeen = personDays;

      const golongan = colGol >= 0 ? cleanCellStr(row[colGol]) || '-' : '-';
      const statusHint = colStatusPegawai >= 0 ? cleanCellStr(row[colStatusPegawai]) : '';

      rows.push({
        id: `mrec_${Date.now()}_${r}`,
        nama,
        nip: colNip >= 0 ? cleanCellStr(row[colNip]) || '-' : '-',
        jabatan: colJabatan >= 0 ? cleanCellStr(row[colJabatan]) || '-' : '-',
        golongan,
        kategori: inferKategoriFromGolongan(golongan, statusHint),
        h,
        td,
        i: iCnt,
        s: sCnt,
        tk,
      });
    }

    const b = detectedBulan || new Date().getMonth() + 1;
    const t = detectedTahun || new Date().getFullYear();
    const weekLabels = buildWeeklyLabels(b, t);
    const weeklyTrend: WeeklyTrendPoint[] = weekLabels.map((label, idx) => {
      const bkt = weeklyBuckets[idx];
      const dayCount = Math.max(1, bkt.workDays.size);
      return {
        label,
        present: rows.length > 0 ? Math.min(rows.length, Math.round(bkt.presentDays / dayCount)) : 0,
        td: bkt.tdDays,
        absent: bkt.absDays,
      };
    });

    return {
      rows,
      detectedHariKerja: maxDaysSeen > 0 ? maxDaysSeen : defaultWorkDays,
      detectedBulan,
      detectedTahun,
      weeklyTrend,
      sourceSummary: `Berhasil membaca ${rows.length} pegawai dari matriks absensi harian (${dayCols.length} kolom tanggal).`,
    };
  }

  if (colH >= 0 || colTD >= 0 || colI >= 0 || colS >= 0 || colTK >= 0) {
    // FORMAT A: Monthly Summary Table
    let maxTotal = 0;
    for (let r = dataStartIdx; r < matrix.length; r++) {
      const row = matrix[r];
      const nama = cleanCellStr(row[colNama]);
      if (!nama || /jumlah|total|rata-rata|catatan|kepala\s+uptd|mengetahui/i.test(nama)) {
        continue;
      }

      const h = colH >= 0 ? parseIntSafe(row[colH]) : 0;
      const td = colTD >= 0 ? parseIntSafe(row[colTD]) : 0;
      const iCnt = colI >= 0 ? parseIntSafe(row[colI]) : 0;
      const sCnt = colS >= 0 ? parseIntSafe(row[colS]) : 0;
      const tk = colTK >= 0 ? parseIntSafe(row[colTK]) : 0;

      const total = h + td + iCnt + sCnt + tk;
      if (total > maxTotal) maxTotal = total;

      const golongan = colGol >= 0 ? cleanCellStr(row[colGol]) || '-' : '-';
      const statusHint = colStatusPegawai >= 0 ? cleanCellStr(row[colStatusPegawai]) : '';

      rows.push({
        id: `mrec_${Date.now()}_${r}`,
        nama,
        nip: colNip >= 0 ? cleanCellStr(row[colNip]) || '-' : '-',
        jabatan: colJabatan >= 0 ? cleanCellStr(row[colJabatan]) || '-' : '-',
        golongan,
        kategori: inferKategoriFromGolongan(golongan, statusHint),
        h,
        td,
        i: iCnt,
        s: sCnt,
        tk,
      });
    }

    return {
      rows,
      detectedHariKerja: maxTotal > 0 ? maxTotal : defaultWorkDays,
      detectedBulan,
      detectedTahun,
      sourceSummary: `Berhasil membaca ${rows.length} pegawai dari tabel rekapan bulanan.`,
    };
  }

  if (colStatusKehadiran >= 0) {
    // FORMAT C: Daily Log Rows (group by employee name)
    const map = new Map<string, MonthlyRecapRow>();
    for (let r = dataStartIdx; r < matrix.length; r++) {
      const row = matrix[r];
      const nama = cleanCellStr(row[colNama]);
      if (!nama || /jumlah|total/i.test(nama)) continue;

      const key = nama.toLowerCase();
      if (!map.has(key)) {
        const golongan = colGol >= 0 ? cleanCellStr(row[colGol]) || '-' : '-';
        const statusHint = colStatusPegawai >= 0 ? cleanCellStr(row[colStatusPegawai]) : '';
        map.set(key, {
          id: `mrec_${Date.now()}_${r}`,
          nama,
          nip: colNip >= 0 ? cleanCellStr(row[colNip]) || '-' : '-',
          jabatan: colJabatan >= 0 ? cleanCellStr(row[colJabatan]) || '-' : '-',
          golongan,
          kategori: inferKategoriFromGolongan(golongan, statusHint),
          h: 0,
          td: 0,
          i: 0,
          s: 0,
          tk: 0,
        });
      }
      const target = map.get(key)!;
      const code = classifyAttendanceCode(cleanCellStr(row[colStatusKehadiran]));
      if (code === 'h') target.h++;
      else if (code === 'td') target.td++;
      else if (code === 'i') target.i++;
      else if (code === 's') target.s++;
      else if (code === 'tk') target.tk++;
    }

    const groupedRows = Array.from(map.values());
    return {
      rows: groupedRows,
      detectedHariKerja: defaultWorkDays,
      detectedBulan,
      detectedTahun,
      sourceSummary: `Berhasil merekap ${groupedRows.length} pegawai dari data log kehadiran harian.`,
    };
  }

  throw new Error(
    'Format kolom kehadiran (H, TD, I, S, TK atau tanggal 1–31) tidak dikenali. Gunakan Template Excel yang disediakan atau pastikan header kolom jelas.'
  );
};

/**
 * Parses an uploaded PDF monthly attendance recap by extracting text items and detecting employee table rows.
 */
const parsePdfBuffer = async (
  buffer: ArrayBuffer,
  defaultWorkDays: number
): Promise<ParsedRecapResult> => {
  const loadingTask = pdfjsLib.getDocument({ data: new Uint8Array(buffer) });
  const pdf = await loadingTask.promise;

  let fullText = '';
  const allLines: string[] = [];

  for (let p = 1; p <= pdf.numPages; p++) {
    const page = await pdf.getPage(p);
    const content = await page.getTextContent();
    const items = content.items as Array<{ str: string; transform: number[] }>;

    // Group items by Y coordinate (within 6px tolerance)
    const rowBuckets: { y: number; cells: { x: number; text: string }[] }[] = [];
    for (const item of items) {
      const text = item.str.trim();
      if (!text) continue;
      const x = item.transform[4];
      const y = item.transform[5];
      let bucket = rowBuckets.find((b) => Math.abs(b.y - y) <= 6);
      if (!bucket) {
        bucket = { y, cells: [] };
        rowBuckets.push(bucket);
      }
      bucket.cells.push({ x, text });
    }

    // Sort top-to-bottom (higher Y first in PDF coordinates)
    rowBuckets.sort((a, b) => b.y - a.y);
    for (const b of rowBuckets) {
      b.cells.sort((a, c) => a.x - c.x);
      const line = b.cells.map((c) => c.text).join(' ').replace(/\s+/g, ' ').trim();
      allLines.push(line);
      fullText += line + '\n';
    }
  }

  // Detect month & year
  let detectedBulan: number | undefined;
  let detectedTahun: number | undefined;
  let detectedHariKerja: number | undefined;

  for (let m = 0; m < INDONESIAN_MONTHS.length; m++) {
    if (fullText.toLowerCase().includes(INDONESIAN_MONTHS[m].toLowerCase())) {
      detectedBulan = m + 1;
      break;
    }
  }
  const yearMatch = fullText.match(/\b(202\d|203\d)\b/);
  if (yearMatch) detectedTahun = parseInt(yearMatch[1], 10);

  const effMatch = fullText.match(/(\d{1,2})\s*Hari\s*Kerja\s*Efektif|Hari\s*Kerja\s*Efektif[:\s]*(\d{1,2})/i);
  if (effMatch) {
    detectedHariKerja = parseInt(effMatch[1] || effMatch[2], 10);
  }

  // Strategy 1: Card-block text format (e.g. "Nama : ... NIP : ... Status : ... Gol. Ruang : ... Jabatan : ... HADIR/TD/IJIN/SAKIT")
  if (/\bNama\s*:/i.test(fullText) && /\bJabatan\s*:/i.test(fullText)) {
    const cardMap = new Map<string, MonthlyRecapRow>();
    const blocks = fullText.split(/(?=\bNama\s*:)/i).filter((b) => /\bNama\s*:/i.test(b));
    for (let bi = 0; bi < blocks.length; bi++) {
      const blk = blocks[bi];
      const namaM = blk.match(/Nama\s*:\s*([^\n]+?)(?=\s+(?:HADIR|IJIN|IZIN|SAKIT|CUTI|TUGAS|TANPA|NIP\s*:)|\n|$)/i);
      const nipM = blk.match(/NIP\s*:\s*([^\n]+?)(?=\s+(?:Status\s*:|Gol\.?\s*Ruang\s*:|Jabatan\s*:)|\n|$)/i);
      const statusM = blk.match(/Status\s*:\s*([^\n]+?)(?=\s+(?:Gol\.?\s*Ruang\s*:|Jabatan\s*:)|\n|$)/i);
      const golM = blk.match(/Gol\.?\s*Ruang\s*:\s*([^\n]+?)(?=\s+(?:Jabatan\s*:)|\n|$)/i);
      const jabM = blk.match(/Jabatan\s*:\s*([^\n]+)/i);

      const nama = cleanCellStr(namaM?.[1] || '');
      if (!nama) continue;

      const key = nama.toLowerCase();
      if (!cardMap.has(key)) {
        const gol = cleanCellStr(golM?.[1] || '-') || '-';
        const statusHint = cleanCellStr(statusM?.[1] || '');
        cardMap.set(key, {
          id: `mrec_pdfcard_${Date.now()}_${bi}`,
          nama,
          nip: cleanCellStr(nipM?.[1] || '-') || '-',
          jabatan: cleanCellStr(jabM?.[1] || '-') || '-',
          golongan: gol,
          kategori: inferKategoriFromGolongan(gol, statusHint),
          h: 0,
          td: 0,
          i: 0,
          s: 0,
          tk: 0,
        });
      }
      const target = cardMap.get(key)!;
      if (/\bTUGAS\s+DINAS\b|\bTUGAS\s+BELAJAR\b|\b\(TD\)\b/i.test(blk)) target.td++;
      else if (/\bSAKIT\b|\b\(S\)\b/i.test(blk)) target.s++;
      else if (/\bIJIN\b|\bIZIN\b|\bCUTI\b|\b\(I\)\b|\b\(C\)\b/i.test(blk)) target.i++;
      else if (/\bTANPA\s+BERITA\b|\bTANPA\s+KETERANGAN\b|\bALPA\b|\b\(TB\)\b|\b\(TK\)\b/i.test(blk)) target.tk++;
      else target.h++;
    }

    const cardRows = Array.from(cardMap.values());
    if (cardRows.length > 0) {
      const maxTot = cardRows.reduce((m, r) => Math.max(m, r.h + r.td + r.i + r.s + r.tk), 0);
      return {
        rows: cardRows,
        detectedHariKerja: detectedHariKerja || (maxTot > 0 ? maxTot : defaultWorkDays),
        detectedBulan,
        detectedTahun,
        sourceSummary: `Berhasil membaca ${cardRows.length} pegawai dari format kartu laporan PDF.`,
      };
    }
  }

  // Strategy 2: Numbered summary table rows & daily grid rows
  const mergedLines: string[] = [];
  for (const rawLine of allLines) {
    const line = rawLine.trim();
    if (!line) continue;
    if (
      mergedLines.length > 0 &&
      /^\d{1,2}\s+/.test(mergedLines[mergedLines.length - 1]) &&
      !/^\d{1,2}\s+/.test(line) &&
      !/^(jumlah|rata-rata|catatan|sistem|halaman|daftar|no\s+nama|rincian|kurva|distribusi|berdasarkan)/i.test(line) &&
      /^\d{2,4}$/.test(line)
    ) {
      mergedLines[mergedLines.length - 1] = `${mergedLines[mergedLines.length - 1]} __NIPCONT__${line}`;
    } else {
      mergedLines.push(line);
    }
  }

  const rows: MonthlyRecapRow[] = [];
  const rowPattern =
    /^(\d{1,2})\s+(.+?)\s+(\d{1,2})\s+(\d{1,2})\s+(\d{1,2})\s+(\d{1,2})\s+(\d{1,2})(?:\s+(\d{1,2}))?(?:\s+[\d\s.,]+%?)?(?:\s+__NIPCONT__(\d{2,4}))?$/;

  for (let idx = 0; idx < mergedLines.length; idx++) {
    const line = mergedLines[idx];
    if (/jumlah|rata-rata|kebutuhan|rincian|daftar/i.test(line)) continue;

    // Check daily code row first (e.g. "1 Agusthinus Kese H H H H TD H H ...")
    const dailyMatch = line.match(/^(\d{1,2})\s+([A-Za-z.,'\s-]{3,}?)\s+((?:(?:H|TD|DL|I|S|TK|TB|A|C|L|-)\s+){6,}(?:H|TD|DL|I|S|TK|TB|A|C|L|-))(?:\s+.*)?$/i);
    if (dailyMatch) {
      const tokens = dailyMatch[3].trim().split(/\s+/);
      let h = 0, td = 0, iCnt = 0, sCnt = 0, tk = 0;
      for (const tok of tokens) {
        const c = classifyAttendanceCode(tok);
        if (c === 'h') h++;
        else if (c === 'td') td++;
        else if (c === 'i') iCnt++;
        else if (c === 's') sCnt++;
        else if (c === 'tk') tk++;
      }
      if (h + td + iCnt + sCnt + tk > 0) {
        rows.push({
          id: `mrec_pdfgrid_${Date.now()}_${idx}`,
          nama: dailyMatch[2].trim(),
          nip: '-',
          jabatan: '-',
          golongan: '-',
          kategori: 'PNS',
          h,
          td,
          i: iCnt,
          s: sCnt,
          tk,
        });
        continue;
      }
    }

    const match = line.match(rowPattern);
    if (!match) continue;

    const middle = match[2].trim();
    const h = parseInt(match[3], 10) || 0;
    const td = parseInt(match[4], 10) || 0;
    const iCnt = parseInt(match[5], 10) || 0;
    const sCnt = parseInt(match[6], 10) || 0;
    const tk = parseInt(match[7], 10) || 0;
    const nipCont = match[9] || '';

    let golongan = '-';
    let beforeGol = middle;
    const golMatch = middle.match(
      /\s+(IV\/[a-e]|III\/[a-d]|II\/[a-d]|I\/[a-d]|IX|VIII|VII|VI|X|XI|GTT|PTT|Honor|-)$/i
    );
    if (golMatch) {
      golongan = golMatch[1];
      beforeGol = middle.slice(0, golMatch.index).trim();
    }

    let nama = beforeGol;
    let nip = '-';
    let jabatan = '-';

    const nipMatch = beforeGol.match(/(\d[\d\s]{11,24}\d)/);
    if (nipMatch && nipMatch.index !== undefined) {
      nama = beforeGol.slice(0, nipMatch.index).trim();
      const rawDigits = (nipMatch[1] + nipCont).replace(/\s+/g, '');
      if (rawDigits.length === 18) {
        nip = `${rawDigits.slice(0, 8)} ${rawDigits.slice(8, 14)} ${rawDigits.slice(14, 15)} ${rawDigits.slice(15, 18)}`;
      } else {
        nip = `${nipMatch[1].replace(/\s+/g, ' ').trim()}${nipCont ? ' ' + nipCont : ''}`;
      }
      jabatan = beforeGol.slice(nipMatch.index + nipMatch[0].length).trim() || '-';
    } else {
      const dashIdx = beforeGol.indexOf(' - ');
      if (dashIdx > 0) {
        nama = beforeGol.slice(0, dashIdx).trim();
        nip = '-';
        jabatan = beforeGol.slice(dashIdx + 3).trim() || '-';
      }
    }

    if (!nama) continue;

    rows.push({
      id: `mrec_pdf_${Date.now()}_${idx}`,
      nama,
      nip,
      jabatan,
      golongan,
      kategori: inferKategoriFromGolongan(golongan),
      h,
      td,
      i: iCnt,
      s: sCnt,
      tk,
    });
  }

  if (rows.length === 0) {
    throw new Error(
      'Tidak ditemukan tabel data pegawai yang terbaca pada file PDF ini.'
    );
  }

  return {
    rows,
    detectedHariKerja: detectedHariKerja || defaultWorkDays,
    detectedBulan,
    detectedTahun,
    sourceSummary: `Berhasil membaca ${rows.length} data pegawai dari file PDF.`,
  };
};

/**
 * Detects Indonesian month (1-12) and 4-digit year from filename (e.g. "Rekapan_Absensi_untuk Bulan Oktober 2026.pdf")
 */
const detectPeriodFromText = (
  text: string
): { bulan?: number; tahun?: number } => {
  const lower = (text || '').toLowerCase();
  let bulan: number | undefined;
  for (let i = 0; i < INDONESIAN_MONTHS.length; i++) {
    if (lower.includes(INDONESIAN_MONTHS[i].toLowerCase())) {
      bulan = i + 1;
      break;
    }
  }
  const yearMatch = lower.match(/\b(202\d|203\d)\b/);
  const tahun = yearMatch ? parseInt(yearMatch[1], 10) : undefined;
  return { bulan, tahun };
};

const arrayBufferToBase64 = (buffer: ArrayBuffer): string => {
  const bytes = new Uint8Array(buffer);
  const chunkSize = 0x8000;
  let binary = '';
  for (let i = 0; i < bytes.length; i += chunkSize) {
    const chunk = bytes.subarray(i, i + chunkSize);
    binary += String.fromCharCode(...chunk);
  }
  return btoa(binary);
};

const normalizeKategori = (raw: unknown, golongan: string): PegawaiKategori => {
  const val = cleanCellStr(raw).toUpperCase();
  if (val === 'PNS' || val === 'ASN') return 'PNS';
  if (val === 'PPPK') return 'PPPK';
  if (val === 'GTT' || val === 'PTT' || val === 'HONOR') return 'GTT';
  if (val === 'LAINNYA') return 'Lainnya';
  return inferKategoriFromGolongan(golongan, val);
};

/**
 * Quickly extracts ordered lines of text from a PDF in the browser using pdfjs-dist.
 * Returns empty string for scanned/image-only PDFs.
 */
const extractRawPdfText = async (buffer: ArrayBuffer): Promise<string> => {
  try {
    const loadingTask = pdfjsLib.getDocument({ data: new Uint8Array(buffer.slice(0)) });
    const pdf = await loadingTask.promise;
    const lines: string[] = [];
    const maxPages = Math.min(pdf.numPages, 40);

    for (let p = 1; p <= maxPages; p++) {
      const page = await pdf.getPage(p);
      const content = await page.getTextContent();
      const items = content.items as Array<{ str: string; transform: number[] }>;
      const rowBuckets: { y: number; cells: { x: number; text: string }[] }[] = [];

      for (const item of items) {
        const text = item.str.trim();
        if (!text) continue;
        const x = item.transform[4];
        const y = item.transform[5];
        let bucket = rowBuckets.find((b) => Math.abs(b.y - y) <= 5);
        if (!bucket) {
          bucket = { y, cells: [] };
          rowBuckets.push(bucket);
        }
        bucket.cells.push({ x, text });
      }

      rowBuckets.sort((a, b) => b.y - a.y);
      lines.push(`--- Halaman ${p} ---`);
      for (const b of rowBuckets) {
        b.cells.sort((a, c) => a.x - c.x);
        lines.push(b.cells.map((c) => c.text).join('  '));
      }
    }
    return lines.join('\n').trim();
  } catch {
    return '';
  }
};

/**
 * Calls server-side multimodal PDF/Image parser (/api/parse-recap-document)
 * capable of reading ANY PDF table layout, daily 1-31 calendar grid, scanned PDF,
 * or compiled daily TimeMark attendance cards.
 */
const parseDocumentViaServerApi = async (
  file: File,
  buffer: ArrayBuffer,
  defaultWorkDays: number
): Promise<ParsedRecapResult> => {
  const ext = file.name.split('.').pop()?.toLowerCase() || '';
  const isPdf = ext === 'pdf';
  const mimeType =
    file.type ||
    (isPdf
      ? 'application/pdf'
      : ext === 'png'
      ? 'image/png'
      : ext === 'jpg' || ext === 'jpeg'
      ? 'image/jpeg'
      : 'application/pdf');

  // For PDFs: extract text locally first. If the PDF has rich selectable text (>=150 chars),
  // try fast text parsing first (~1-2s, works for large multi-page PDFs).
  // If the PDF is scanned/image-based OR text-only extraction finds 0 rows (e.g. hybrid PDF with text header + screenshot table),
  // automatically send full base64 PDF for native multimodal vision reading!
  let extractedText = '';
  let base64Data: string | undefined;

  if (isPdf) {
    extractedText = await extractRawPdfText(buffer);
    const nonHeaderChars = extractedText.replace(/---\s*Halaman\s*\d+\s*---/g, '').trim().length;
    if (nonHeaderChars < 150) {
      base64Data = arrayBufferToBase64(buffer);
    }
  } else {
    base64Data = arrayBufferToBase64(buffer);
  }

  const callServerApi = async (body: Record<string, unknown>) => {
    const res = await fetch('/api/parse-recap-document', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    const data = await res.json().catch(() => ({}));
    return { res, data };
  };

  let { res: response, data: payload } = await callServerApi({
    base64Data,
    extractedText: extractedText || undefined,
    mimeType,
    fileName: file.name,
    defaultWorkDays,
  });

  // Hybrid PDF fallback: if text-only pass returned 422 / 0 rows, retry with full binary PDF vision
  const noRowsFromTextOnly =
    isPdf &&
    !base64Data &&
    (!response.ok ? response.status === 422 || response.status === 502 : !Array.isArray(payload?.rows) || payload.rows.length === 0);

  if (noRowsFromTextOnly && buffer.byteLength <= 24 * 1024 * 1024) {
    base64Data = arrayBufferToBase64(buffer);
    const retry = await callServerApi({
      base64Data,
      extractedText: extractedText || undefined,
      mimeType,
      fileName: file.name,
      defaultWorkDays,
    });
    response = retry.res;
    payload = retry.data;
  }

  if (!response.ok) {
    throw new Error(
      payload?.error || `Gagal memproses file PDF (HTTP ${response.status}).`
    );
  }

  const rawRows: any[] = Array.isArray(payload?.rows) ? payload.rows : [];
  if (rawRows.length === 0) {
    throw new Error('Tidak ditemukan data pegawai pada dokumen yang diunggah.');
  }

  const rows: MonthlyRecapRow[] = rawRows
    .map((item, idx) => {
      const nama = cleanCellStr(item.nama);
      const golongan = cleanCellStr(item.golongan || '-') || '-';
      return {
        id: `mrec_doc_${Date.now()}_${idx}`,
        nama,
        nip: cleanCellStr(item.nip || '-') || '-',
        jabatan: cleanCellStr(item.jabatan || '-') || '-',
        golongan,
        kategori: normalizeKategori(item.kategori, golongan),
        h: parseIntSafe(item.h),
        td: parseIntSafe(item.td),
        i: parseIntSafe(item.i),
        s: parseIntSafe(item.s),
        tk: parseIntSafe(item.tk),
      };
    })
    .filter((r) => Boolean(r.nama));

  const namePeriod = detectPeriodFromText(file.name);
  const detectedBulan =
    typeof payload.bulan === 'number' && payload.bulan >= 1 && payload.bulan <= 12
      ? payload.bulan
      : namePeriod.bulan;
  const detectedTahun =
    typeof payload.tahun === 'number' && payload.tahun >= 2020 && payload.tahun <= 2040
      ? payload.tahun
      : namePeriod.tahun;

  const maxRowTotal = rows.reduce(
    (m, r) => Math.max(m, r.h + r.td + r.i + r.s + r.tk),
    0
  );
  const detectedHariKerja =
    typeof payload.hariKerjaEfektif === 'number' &&
    payload.hariKerjaEfektif >= 1 &&
    payload.hariKerjaEfektif <= 31
      ? payload.hariKerjaEfektif
      : maxRowTotal > 0
      ? maxRowTotal
      : defaultWorkDays;

  return {
    rows,
    detectedBulan,
    detectedTahun,
    detectedHariKerja,
    sourceSummary:
      cleanCellStr(payload.summary) ||
      `Berhasil membaca dan menghitung ${rows.length} data pegawai dari dokumen "${file.name}".`,
  };
};

/**
 * Main file upload entry point for "Upload Rekapan Absensi Bulanan"
 */
export const parseMonthlyRecapFile = async (
  file: File,
  defaultWorkDays: number
): Promise<ParsedRecapResult> => {
  const ext = file.name.split('.').pop()?.toLowerCase() || '';
  const buffer = await file.arrayBuffer();
  const namePeriod = detectPeriodFromText(file.name);

  if (ext === 'xlsx' || ext === 'xls' || ext === 'csv') {
    const res = parseSpreadsheetBuffer(buffer, defaultWorkDays);
    return {
      ...res,
      detectedBulan: res.detectedBulan || namePeriod.bulan,
      detectedTahun: res.detectedTahun || namePeriod.tahun,
    };
  }

  if (ext === 'pdf') {
    // Primary: Server-side multimodal PDF reader (handles ANY layout, scanned PDFs, daily 1-31 tables, TimeMark cards)
    try {
      return await parseDocumentViaServerApi(file, buffer, defaultWorkDays);
    } catch (serverErr: any) {
      // If server returned an explicit API/auth/quota message, surface it unless local parser succeeds cleanly
      try {
        const localRes = await parsePdfBuffer(buffer, defaultWorkDays);
        return {
          ...localRes,
          detectedBulan: localRes.detectedBulan || namePeriod.bulan,
          detectedTahun: localRes.detectedTahun || namePeriod.tahun,
        };
      } catch {
        throw serverErr;
      }
    }
  }

  if (ext === 'png' || ext === 'jpg' || ext === 'jpeg' || ext === 'webp') {
    return parseDocumentViaServerApi(file, buffer, defaultWorkDays);
  }

  if (ext === 'json') {
    const text = new TextDecoder().decode(buffer);
    const parsed = JSON.parse(text);
    const arr = Array.isArray(parsed) ? parsed : Array.isArray(parsed.rows) ? parsed.rows : [];
    const rows: MonthlyRecapRow[] = arr.map((item: any, idx: number) => {
      const golongan = cleanCellStr(item.golongan || item.gol || item.golRuang || '-');
      return {
        id: `mrec_json_${Date.now()}_${idx}`,
        nama: cleanCellStr(item.nama || item.name || `Pegawai ${idx + 1}`),
        nip: cleanCellStr(item.nip || '-'),
        jabatan: cleanCellStr(item.jabatan || item.tugas || '-'),
        golongan,
        kategori: item.kategori || inferKategoriFromGolongan(golongan, item.statusPegawai),
        h: parseIntSafe(item.h ?? item.hadir),
        td: parseIntSafe(item.td ?? item.tugasDinas),
        i: parseIntSafe(item.i ?? item.izin ?? item.ijin),
        s: parseIntSafe(item.s ?? item.sakit),
        tk: parseIntSafe(item.tk ?? item.tb ?? item.alpa),
      };
    });
    if (rows.length === 0) {
      throw new Error('File JSON tidak berisi data pegawai.');
    }
    return {
      rows,
      detectedBulan: namePeriod.bulan,
      detectedTahun: namePeriod.tahun,
      detectedHariKerja: parsed.hariKerjaEfektif || defaultWorkDays,
      sourceSummary: `Berhasil memuat ${rows.length} pegawai dari file JSON.`,
    };
  }

  throw new Error(
    'Format file tidak didukung. Gunakan file PDF (.pdf), Excel (.xlsx, .xls), CSV (.csv), Gambar (.png/.jpg), atau JSON (.json).'
  );
};

/**
 * Supports uploading 1 monthly file OR multiple daily/weekly files at once,
 * automatically aggregating H, TD, I, S, TK per employee across all uploaded files.
 */
export const parseMultipleMonthlyRecapFiles = async (
  files: File[],
  defaultWorkDays: number
): Promise<ParsedRecapResult> => {
  if (files.length === 1) {
    return parseMonthlyRecapFile(files[0], defaultWorkDays);
  }

  const mergedMap = new Map<string, MonthlyRecapRow>();
  let detectedBulan: number | undefined;
  let detectedTahun: number | undefined;
  let successFiles = 0;

  for (const file of files) {
    try {
      const res = await parseMonthlyRecapFile(file, defaultWorkDays);
      successFiles++;
      if (!detectedBulan && res.detectedBulan) detectedBulan = res.detectedBulan;
      if (!detectedTahun && res.detectedTahun) detectedTahun = res.detectedTahun;

      for (const row of res.rows) {
        const key = row.nama.trim().toLowerCase();
        if (!mergedMap.has(key)) {
          mergedMap.set(key, { ...row });
        } else {
          const existing = mergedMap.get(key)!;
          existing.h += row.h;
          existing.td += row.td;
          existing.i += row.i;
          existing.s += row.s;
          existing.tk += row.tk;
        }
      }
    } catch {
      // Continue parsing remaining files
    }
  }

  const mergedRows = Array.from(mergedMap.values());
  if (mergedRows.length === 0) {
    throw new Error('Tidak ada data pegawai yang dapat dibaca dari file yang diunggah.');
  }

  const maxTotal = mergedRows.reduce((m, r) => Math.max(m, r.h + r.td + r.i + r.s + r.tk), 0);

  return {
    rows: mergedRows,
    detectedBulan,
    detectedTahun,
    detectedHariKerja: maxTotal > 0 ? maxTotal : defaultWorkDays,
    sourceSummary: `Berhasil menggabungkan ${successFiles} file (${mergedRows.length} pegawai terhitung).`,
  };
};

/**
 * Builds monthly recap rows directly from LensaHadir's stored History records for the selected month/year
 */
export const buildMonthlyRowsFromHistory = (
  records: AttendanceRecord[],
  bulan: number,
  tahun: number
): MonthlyRecapRow[] => {
  const monthPrefix = `${tahun}-${String(bulan).padStart(2, '0')}`;
  const matching = records.filter((r) => r.tanggal && r.tanggal.startsWith(monthPrefix));
  const source = matching.length > 0 ? matching : records;

  const map = new Map<string, MonthlyRecapRow>();
  for (const rec of source) {
    const key = rec.nama.trim().toLowerCase();
    if (!map.has(key)) {
      const gol = rec.golRuang?.trim() || (rec.statusPegawai === 'Honor/GTT' ? 'GTT' : '-');
      map.set(key, {
        id: `mrec_hist_${rec.id}`,
        nama: rec.nama.trim(),
        nip: rec.nip?.trim() || '-',
        jabatan: rec.jabatan?.trim() || '-',
        golongan: gol,
        kategori: inferKategoriFromGolongan(gol, rec.statusPegawai),
        h: 0,
        td: 0,
        i: 0,
        s: 0,
        tk: 0,
      });
    }
    const row = map.get(key)!;
    const status = rec.statusKehadiran || 'Hadir (H)';
    if (status.startsWith('Hadir')) row.h++;
    else if (status.startsWith('Tugas Dinas') || status.startsWith('Tugas Belajar')) row.td++;
    else if (status.startsWith('Ijin') || status.startsWith('Cuti')) row.i++;
    else if (status.startsWith('Sakit')) row.s++;
    else row.tk++;
  }

  return Array.from(map.values());
};

/**
 * Sample 11-employee dataset matching the user's uploaded PDF example for instant testing
 */
export const getSampleMonthlyRows = (): MonthlyRecapRow[] => [
  {
    id: 'sample_1',
    nama: 'Jospia Haba Djingi, S.Pd.SD',
    nip: '19670614 200012 2 003',
    jabatan: 'Kepala Sekolah',
    golongan: 'IV/b',
    kategori: 'PNS',
    h: 25,
    td: 1,
    i: 0,
    s: 0,
    tk: 0,
  },
  {
    id: 'sample_2',
    nama: 'Dofiaranci Killok, S.Pd',
    nip: '19720418 200312 2 004',
    jabatan: 'Guru Kelas I',
    golongan: 'III/b',
    kategori: 'PNS',
    h: 26,
    td: 0,
    i: 0,
    s: 0,
    tk: 0,
  },
  {
    id: 'sample_3',
    nama: 'Obed Manggi, S.Pd',
    nip: '19661010 200701 1 037',
    jabatan: 'Guru Kelas III',
    golongan: 'III/b',
    kategori: 'PNS',
    h: 26,
    td: 0,
    i: 0,
    s: 0,
    tk: 0,
  },
  {
    id: 'sample_4',
    nama: 'Margaritha Djo Hau, S.Pd',
    nip: '19760312 201001 2 014',
    jabatan: 'Guru Kelas VI',
    golongan: 'III/b',
    kategori: 'PNS',
    h: 26,
    td: 0,
    i: 0,
    s: 0,
    tk: 0,
  },
  {
    id: 'sample_5',
    nama: 'Agusthinus Kese, S.Pd',
    nip: '19820805 201406 1 004',
    jabatan: 'Guru PJOK',
    golongan: 'III/b',
    kategori: 'PNS',
    h: 26,
    td: 0,
    i: 0,
    s: 0,
    tk: 0,
  },
  {
    id: 'sample_6',
    nama: 'Yakob Lomang, A.Ma.Pd',
    nip: '19801007 201406 1 006',
    jabatan: 'Tendik & Admin',
    golongan: 'II/b',
    kategori: 'PNS',
    h: 26,
    td: 0,
    i: 0,
    s: 0,
    tk: 0,
  },
  {
    id: 'sample_7',
    nama: 'Agrip Sugianto Sulla, S.Pd',
    nip: '19870822 201903 1 005',
    jabatan: 'Guru Kelas V',
    golongan: 'III/a',
    kategori: 'PNS',
    h: 26,
    td: 0,
    i: 0,
    s: 0,
    tk: 0,
  },
  {
    id: 'sample_8',
    nama: 'Agustina Tokael, S.Pd',
    nip: '19680812 202421 2 001',
    jabatan: 'Guru PAK Kelas I-V',
    golongan: 'IX',
    kategori: 'PPPK',
    h: 26,
    td: 0,
    i: 0,
    s: 0,
    tk: 0,
  },
  {
    id: 'sample_9',
    nama: 'Sarlota Beti, S.Pd',
    nip: '19911023 201903 2 017',
    jabatan: 'Guru Kelas IV',
    golongan: 'III/a',
    kategori: 'PNS',
    h: 26,
    td: 0,
    i: 0,
    s: 0,
    tk: 0,
  },
  {
    id: 'sample_10',
    nama: 'Trifena M. Manggi, S.Pd.',
    nip: '-',
    jabatan: 'Guru Kelas II',
    golongan: 'GTT',
    kategori: 'GTT',
    h: 26,
    td: 0,
    i: 0,
    s: 0,
    tk: 0,
  },
  {
    id: 'sample_11',
    nama: 'Winda Nenobesi, S.Pd',
    nip: '-',
    jabatan: 'Guru PAK VI & Mulok',
    golongan: 'GTT',
    kategori: 'GTT',
    h: 26,
    td: 0,
    i: 0,
    s: 0,
    tk: 0,
  },
];

/**
 * Generates and downloads a clean Excel (.xlsx) template for "Rekapan Absensi Bulanan"
 */
export const downloadMonthlyExcelTemplate = (bulan: number, tahun: number): void => {
  const monthName = INDONESIAN_MONTHS[bulan - 1] || 'Bulan';
  const sample = getSampleMonthlyRows();
  const data = [
    [`REKAPAN ABSENSI BULANAN - BULAN ${monthName.toUpperCase()} ${tahun}`],
    [],
    ['No', 'Nama Lengkap & Gelar', 'NIP', 'Tugas / Jabatan', 'Gol.', 'Status Pegawai', 'H', 'TD', 'I', 'S', 'TK'],
    ...sample.map((r, idx) => [
      idx + 1,
      r.nama,
      r.nip,
      r.jabatan,
      r.golongan,
      r.kategori,
      r.h,
      r.td,
      r.i,
      r.s,
      r.tk,
    ]),
  ];

  const ws = XLSX.utils.aoa_to_sheet(data);
  ws['!cols'] = [
    { wch: 5 },
    { wch: 30 },
    { wch: 24 },
    { wch: 22 },
    { wch: 8 },
    { wch: 14 },
    { wch: 6 },
    { wch: 6 },
    { wch: 6 },
    { wch: 6 },
    { wch: 6 },
  ];

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Rekap Bulanan');
  XLSX.writeFile(wb, `Template_Rekapan_Absensi_${monthName}_${tahun}.xlsx`);
};
