import { jsPDF } from 'jspdf';
import { AppSettings, DailyReportCardItem, DailyReportFooterSummary } from '../types/attendance';

export interface PaginatedReportPage {
  pageNumber: number;
  totalPages: number;
  items: DailyReportCardItem[];
  isFirstPage: boolean;
  isLastPage: boolean;
}

/**
 * Formats YYYY-MM-DD into full Indonesian date with weekday, e.g. "Jumat, 20 November 2026"
 */
export const formatIndonesianFullDate = (dateStr: string): string => {
  if (!dateStr) return '-';
  try {
    const [y, m, d] = dateStr.split('-').map(Number);
    if (!y || !m || !d) return dateStr;
    const dateObj = new Date(y, m - 1, d);
    return dateObj.toLocaleDateString('id-ID', {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    });
  } catch {
    return dateStr;
  }
};

/**
 * Formats YYYY-MM-DD into Indonesian date without weekday for signature line, e.g. "20 November 2026"
 */
export const formatIndonesianShortDate = (dateStr: string): string => {
  if (!dateStr) return '-';
  try {
    const [y, m, d] = dateStr.split('-').map(Number);
    if (!y || !m || !d) return dateStr;
    const dateObj = new Date(y, m - 1, d);
    return dateObj.toLocaleDateString('id-ID', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    });
  } catch {
    return dateStr;
  }
};

/**
 * Paginates uploaded daily report cards strictly 3 cards per A4 Portrait page
 * (Page 1: cards 1-3, Page 2: cards 4-6, Page 3: cards 7-9, etc.)
 * matching the official PDF template.
 */
export const paginateReportItems = (
  items: DailyReportCardItem[]
): PaginatedReportPage[] => {
  const validItems = items.filter((item) => Boolean(item.imageUrl));

  if (validItems.length === 0) {
    return [
      {
        pageNumber: 1,
        totalPages: 1,
        items: [],
        isFirstPage: true,
        isLastPage: true,
      },
    ];
  }

  const CARDS_PER_PAGE = 3;
  const chunks: DailyReportCardItem[][] = [];
  for (let i = 0; i < validItems.length; i += CARDS_PER_PAGE) {
    chunks.push(validItems.slice(i, i + CARDS_PER_PAGE));
  }

  const totalPages = chunks.length;
  return chunks.map((pageItems, idx) => ({
    pageNumber: idx + 1,
    totalPages,
    items: pageItems,
    isFirstPage: idx === 0,
    isLastPage: idx === totalPages - 1,
  }));
};

const loadImageSafe = (src: string): Promise<HTMLImageElement> => {
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = () => resolve(img);
    img.src = src;
  });
};

/**
 * Automatically detects and trims outer white margins / redundant individual card title & footer
 * from an uploaded LensaHadir PNG so every card renders as the clean blue-bordered table,
 * matching the exact PDF format where the blue number box sits inside the top-left of the table header.
 */
export const trimCardImageToTable = async (imageUrl: string): Promise<string> => {
  try {
    const img = await loadImageSafe(imageUrl);
    if (!img.width || !img.height) return imageUrl;

    const canvas = document.createElement('canvas');
    canvas.width = img.width;
    canvas.height = img.height;
    const ctx = canvas.getContext('2d');
    if (!ctx) return imageUrl;

    ctx.drawImage(img, 0, 0);
    const { data, width, height } = ctx.getImageData(0, 0, canvas.width, canvas.height);

    // Scan for the blue table frame / header pixels (#2e75b6 / #5b9bd5)
    let minX = width;
    let minY = height;
    let maxX = -1;
    let maxY = -1;

    const step = width > 1000 ? 2 : 1;
    for (let y = 0; y < height; y += step) {
      for (let x = 0; x < width; x += step) {
        const idx = (y * width + x) * 4;
        const r = data[idx];
        const g = data[idx + 1];
        const b = data[idx + 2];
        const a = data[idx + 3];

        // Match official table blue (#2e75b6 -> 46,117,182 | #5b9bd5 -> 91,155,213)
        if (a > 200 && b >= 145 && b - r >= 45 && g >= 80 && r <= 140) {
          if (x < minX) minX = x;
          if (y < minY) minY = y;
          if (x > maxX) maxX = x;
          if (y > maxY) maxY = y;
        }
      }
    }

    const boxW = maxX - minX;
    const boxH = maxY - minY;

    // Only crop if we detected a valid full table rectangle with meaningful outer margin
    const isValidTable = boxW > width * 0.45 && boxH > height * 0.35;
    const hasRedundantHeaderOrMargin =
      minY > height * 0.05 ||
      height - maxY > height * 0.05 ||
      minX > width * 0.02 ||
      width - maxX > width * 0.02;

    if (!isValidTable || !hasRedundantHeaderOrMargin) {
      return imageUrl;
    }

    const pad = 2;
    const cropX = Math.max(0, minX - pad);
    const cropY = Math.max(0, minY - pad);
    const cropW = Math.min(width - cropX, boxW + pad * 2 + step);
    const cropH = Math.min(height - cropY, boxH + pad * 2 + step);

    const outCanvas = document.createElement('canvas');
    outCanvas.width = cropW;
    outCanvas.height = cropH;
    const outCtx = outCanvas.getContext('2d');
    if (!outCtx) return imageUrl;

    outCtx.fillStyle = '#ffffff';
    outCtx.fillRect(0, 0, cropW, cropH);
    outCtx.drawImage(canvas, cropX, cropY, cropW, cropH, 0, 0, cropW, cropH);

    return outCanvas.toDataURL('image/png');
  } catch {
    return imageUrl;
  }
};

function wrapCenteredLines(
  ctx: CanvasRenderingContext2D,
  text: string,
  maxWidth: number
): string[] {
  const paragraphs = text.split(/\r?\n/);
  const lines: string[] = [];
  for (const para of paragraphs) {
    const words = para.trim().split(/\s+/).filter(Boolean);
    if (words.length === 0) continue;
    let current = words[0];
    for (let i = 1; i < words.length; i++) {
      const candidate = `${current} ${words[i]}`;
      if (ctx.measureText(candidate).width <= maxWidth) {
        current = candidate;
      } else {
        lines.push(current);
        current = words[i];
      }
    }
    lines.push(current);
  }
  return lines;
}

function wrapBreakAllLines(
  ctx: CanvasRenderingContext2D,
  text: string,
  maxWidth: number,
  maxLines = 2
): string[] {
  const clean = text.trim();
  if (!clean) return [];
  const lines: string[] = [];
  let current = '';

  for (let i = 0; i < clean.length; i++) {
    const ch = clean[i];
    const candidate = current + ch;
    if (ctx.measureText(candidate).width <= maxWidth) {
      current = candidate;
    } else {
      if (current) lines.push(current);
      if (lines.length >= maxLines) {
        const lastIdx = lines.length - 1;
        let truncated = lines[lastIdx];
        while (truncated.length > 3 && ctx.measureText(`${truncated}...`).width > maxWidth) {
          truncated = truncated.slice(0, -1);
        }
        lines[lastIdx] = `${truncated}...`;
        return lines;
      }
      current = ch;
    }
  }
  if (current) lines.push(current);
  return lines.slice(0, maxLines);
}

/**
 * Renders a single A4 Portrait page (1240 x 1754 px @ 150 DPI) of
 * "LAPORAN DISIPLIN JAM KERJA HARIAN" onto a Canvas element matching the uploaded PDF format:
 * - Page 1: Official Kop Instansi + thick blue Kop divider + underlined navy title + Meta + 3 Cards
 * - Page 2+: 3 Cards per page continuing sequentially
 * - Each card: White-bordered blue number box (#5b9bd5) tucked inside the top-left of the table header
 * - Last page: Left side Link Google Drive + Rekap Absensi Harian, Right side Kepala Sekolah signature block
 */
export const renderDailyReportPageToCanvas = async (
  page: PaginatedReportPage,
  reportDate: string,
  settings: AppSettings,
  footerSummary?: DailyReportFooterSummary
): Promise<HTMLCanvasElement | null> => {
  const canvas = document.createElement('canvas');
  const width = 1240;
  const height = 1754;
  canvas.width = width;
  canvas.height = height;

  const ctx = canvas.getContext('2d');
  if (!ctx) return null;

  const serifFont = '"Times New Roman", Times, Georgia, serif';
  const sansFont = '"Plus Jakarta Sans", -apple-system, BlinkMacSystemFont, sans-serif';
  const kopBlue = '#2e75b6';
  const titleNavy = '#1f4e79';
  const badgeBlue = '#5b9bd5';

  const marginX = 72;
  const contentW = width - marginX * 2; // 1096
  const footerSpace = 44;
  const bottomLimitY = height - footerSpace;

  // 1. Crisp White A4 Background
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, width, height);

  let cursorY = 56;

  // 2. KOP INSTANSI + JUDUL + META (Halaman 1)
  if (page.isFirstPage) {
    ctx.fillStyle = '#000000';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'top';

    // Pemerintah Daerah / Dinas (supports 1 or 2 lines via newline)
    if (settings.namaInstansi?.trim()) {
      ctx.font = `bold 24px ${serifFont}`;
      const instansiLines = wrapCenteredLines(
        ctx,
        settings.namaInstansi.trim().toUpperCase(),
        contentW
      );
      for (const line of instansiLines) {
        ctx.fillText(line, width / 2, cursorY);
        cursorY += 29;
      }
    }

    // Nama Satuan Pendidikan / Sekolah
    if (settings.subInstansi?.trim()) {
      ctx.font = `bold 25px ${serifFont}`;
      const subLines = wrapCenteredLines(
        ctx,
        settings.subInstansi.trim().toUpperCase(),
        contentW
      );
      for (const line of subLines) {
        ctx.fillText(line, width / 2, cursorY);
        cursorY += 30;
      }
    }

    // Alamat Instansi (italic)
    if (settings.alamatInstansi?.trim()) {
      ctx.font = `italic 19px ${serifFont}`;
      ctx.fillStyle = '#111827';
      const addrLines = wrapCenteredLines(ctx, settings.alamatInstansi.trim(), contentW);
      for (const line of addrLines) {
        ctx.fillText(line, width / 2, cursorY + 2);
        cursorY += 24;
      }
    }

    // Garis Biru Kop Tebal (#2e75b6) sesuai PDF
    cursorY += 8;
    ctx.fillStyle = kopBlue;
    ctx.fillRect(marginX - 10, cursorY, contentW + 20, 7);
    cursorY += 26;

    // Judul Laporan: LAPORAN DISIPLIN JAM KERJA HARIAN (biru tua bergaris bawah)
    const reportTitle = 'LAPORAN DISIPLIN JAM KERJA HARIAN';
    ctx.fillStyle = titleNavy;
    ctx.textAlign = 'center';
    ctx.font = `bold 24px ${serifFont}`;
    ctx.fillText(reportTitle, width / 2, cursorY);

    const titleMetrics = ctx.measureText(reportTitle);
    ctx.strokeStyle = titleNavy;
    ctx.lineWidth = 1.8;
    ctx.beginPath();
    ctx.moveTo(width / 2 - titleMetrics.width / 2, cursorY + 27);
    ctx.lineTo(width / 2 + titleMetrics.width / 2, cursorY + 27);
    ctx.stroke();

    cursorY += 42;

    // Metadata: Nama Satuan Pendidikan & Hari / Tanggal
    ctx.fillStyle = '#000000';
    ctx.textAlign = 'left';
    ctx.font = `22px ${serifFont}`;
    const labelX = marginX;
    const colonX = marginX + 270;
    const valX = colonX + 16;

    ctx.fillText('Nama Satuan Pendidikan', labelX, cursorY);
    ctx.fillText(':', colonX, cursorY);
    ctx.fillText(settings.subInstansi?.trim() || '-', valX, cursorY);
    cursorY += 28;

    ctx.fillText('Hari / Tanggal', labelX, cursorY);
    ctx.fillText(':', colonX, cursorY);
    ctx.fillText(formatIndonesianFullDate(reportDate), valX, cursorY);
    cursorY += 38;
  } else {
    // Halaman lanjutan: langsung mulai dengan margin atas bersih
    cursorY = 62;
  }

  // 3. Render up to 3 Cards on this A4 page
  const signatureH = page.isLastPage ? 295 : 0;
  const availableForCards = bottomLimitY - cursorY - signatureH;
  const cardCount = page.items.length;

  if (cardCount > 0) {
    const loadedImages = await Promise.all(
      page.items.map((item) => loadImageSafe(item.imageUrl))
    );

    const cardSpacing = page.isFirstPage && page.isLastPage && cardCount === 3 ? 14 : 22;
    const maxCardH = Math.min(
      420,
      Math.max(220, (availableForCards - cardSpacing * (cardCount - 1)) / cardCount)
    );

    for (let i = 0; i < cardCount; i++) {
      const item = page.items[i];
      const img = loadedImages[i];

      let drawW = contentW;
      let drawH = maxCardH;

      if (img.width > 0 && img.height > 0) {
        const ratio = img.width / img.height;
        drawW = contentW;
        drawH = drawW / ratio;
        if (drawH > maxCardH) {
          drawH = maxCardH;
          drawW = drawH * ratio;
        }
      }

      const cardX = marginX + (contentW - drawW) / 2;

      if (img.width > 0 && img.height > 0) {
        ctx.drawImage(img, cardX, cursorY, drawW, drawH);
      } else {
        ctx.strokeStyle = kopBlue;
        ctx.lineWidth = 2;
        ctx.strokeRect(cardX, cursorY, drawW, drawH);
        ctx.fillStyle = '#64748b';
        ctx.font = `bold 20px ${sansFont}`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('Kartu Laporan Harian', cardX + drawW / 2, cursorY + drawH / 2);
      }

      // Kotak Biru Nomor Urut dengan garis tepi putih tepat di sudut kiri atas dalam header tabel (sesuai PDF)
      const badgeW = Math.round(drawW * 0.058);
      const badgeH = Math.round(drawH * 0.135);
      const badgeX = cardX + Math.round(drawW * 0.008);
      const badgeY = cursorY + Math.round(drawH * 0.02);

      ctx.fillStyle = badgeBlue;
      ctx.fillRect(badgeX, badgeY, badgeW, badgeH);

      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2.4;
      ctx.strokeRect(badgeX, badgeY, badgeW, badgeH);

      ctx.fillStyle = '#ffffff';
      ctx.font = `bold ${Math.max(22, Math.round(badgeH * 0.56))}px ${serifFont}`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(String(item.orderNumber), badgeX + badgeW / 2, badgeY + badgeH / 2 + 1);

      cursorY += drawH + cardSpacing;
    }
  }

  // 4. Footer Halaman Terakhir:
  //    Kiri Bawah Tabel: Link Google Drive & Rekap Absensi Harian
  //    Kanan Bawah Tabel: Tanda Tangan Kepala Sekolah
  if (page.isLastPage) {
    const footerStartY = Math.min(cursorY + 10, bottomLimitY - 282);

    // --- KIRI: Link Google Drive + Rekap Absensi Harian ---
    const leftX = marginX;
    const leftMaxW = 635;
    let leftY = footerStartY;

    ctx.fillStyle = '#000000';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'top';

    ctx.font = `bold 18px ${serifFont}`;
    ctx.fillText('Link Google Drive :', leftX, leftY);
    leftY += 23;

    const rawDriveLink = footerSummary?.driveLink?.trim() || '';
    if (rawDriveLink) {
      ctx.fillStyle = '#1f4e79';
      ctx.font = `15.5px ${serifFont}`;
      const wrappedLink = wrapBreakAllLines(ctx, rawDriveLink, leftMaxW, 2);
      for (const line of wrappedLink) {
        ctx.fillText(line, leftX, leftY);
        leftY += 20;
      }
      leftY += 6;
    } else {
      ctx.fillStyle = '#334155';
      ctx.font = `17px ${serifFont}`;
      ctx.fillText('......................................................................', leftX, leftY);
      leftY += 27;
    }

    ctx.fillStyle = '#000000';
    ctx.font = `bold 18px ${serifFont}`;
    ctx.fillText('Rekap Absensi Harian :', leftX, leftY);
    leftY += 24;

    const formatCountVal = (val?: string) => {
      const trimmed = val?.trim();
      return trimmed && trimmed.length > 0 ? trimmed : '......';
    };

    const recapRows: Array<[string, string]> = [
      ['Jumlah Guru/Pegawai', formatCountVal(footerSummary?.jumlahGuruPegawai)],
      ['Jumlah Hadir (H)', formatCountVal(footerSummary?.hadir)],
      ['Jumlah Ijin (I)', formatCountVal(footerSummary?.ijin)],
      ['Jumlah Sakit (S)', formatCountVal(footerSummary?.sakit)],
      ['Jumlah Cuti (C)', formatCountVal(footerSummary?.cuti)],
      ['Jumlah Tugas Dinas (TD)', formatCountVal(footerSummary?.tugasDinas)],
      ['Jlh Tugas Belajar (TS)', formatCountVal(footerSummary?.tugasBelajar)],
      ['Jlh Tanpa Berita (TB)', formatCountVal(footerSummary?.tanpaBerita)],
    ];

    const recapColonX = leftX + 245;
    const recapValX = recapColonX + 14;
    ctx.font = `17.5px ${serifFont}`;
    for (const [label, countStr] of recapRows) {
      ctx.fillText(label, leftX, leftY);
      ctx.fillText(':', recapColonX, leftY);
      ctx.fillText(`${countStr} Orang`, recapValX, leftY);
      leftY += 22;
    }

    // --- KANAN: Tanda Tangan Kepala Sekolah ---
    const sigBlockW = 405;
    const sigX = width - marginX - sigBlockW;
    const sigY = footerStartY;

    ctx.fillStyle = '#000000';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'top';

    const kotaLabel = settings.kota?.trim() || 'Tempat';
    const shortDate = formatIndonesianShortDate(reportDate);

    ctx.font = `19.5px ${serifFont}`;
    ctx.fillText(`${kotaLabel}, ${shortDate}`, sigX, sigY);
    ctx.fillText(settings.jabatanPimpinan?.trim() || 'Kepala Sekolah', sigX, sigY + 25);

    const nameY = sigY + 122;
    const pimpinanName = settings.namaPimpinan?.trim() || '....................................';
    ctx.font = `bold 20.5px ${serifFont}`;
    ctx.fillText(pimpinanName, sigX, nameY);

    const nameMetrics = ctx.measureText(pimpinanName);
    ctx.strokeStyle = '#000000';
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.moveTo(sigX, nameY + 24);
    ctx.lineTo(sigX + nameMetrics.width, nameY + 24);
    ctx.stroke();

    ctx.font = `19.5px ${serifFont}`;
    ctx.fillText(`NIP. ${settings.nipPimpinan?.trim() || '-'}`, sigX, nameY + 30);
  }

  // 5. Nomor Halaman Ringkas (jika lebih dari 1 halaman)
  if (page.totalPages > 1) {
    ctx.fillStyle = '#64748b';
    ctx.font = `italic 14px ${serifFont}`;
    ctx.textAlign = 'right';
    ctx.textBaseline = 'middle';
    ctx.fillText(
      `Halaman ${page.pageNumber} dari ${page.totalPages}`,
      width - marginX,
      height - 22
    );
  }

  return canvas;
};

/**
 * Renders a single A4 page directly to a PNG Blob
 */
export const renderDailyReportPageToBlob = async (
  page: PaginatedReportPage,
  reportDate: string,
  settings: AppSettings,
  footerSummary?: DailyReportFooterSummary
): Promise<Blob | null> => {
  const canvas = await renderDailyReportPageToCanvas(page, reportDate, settings, footerSummary);
  if (!canvas) return null;
  return new Promise((resolve) => {
    canvas.toBlob((blob) => resolve(blob), 'image/png');
  });
};

/**
 * Generates a real multi-page A4 Portrait PDF file containing all paginated report pages
 * (3 cards per page + Kop Instansi on Page 1 + Bottom-left Drive Link & Daily Recap + Kepala Sekolah signature on the last page).
 */
export const renderDailyReportToPdfBlob = async (
  pages: PaginatedReportPage[],
  reportDate: string,
  settings: AppSettings,
  footerSummary?: DailyReportFooterSummary
): Promise<Blob | null> => {
  if (pages.length === 0) return null;

  const pdf = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
    compress: true,
  });

  for (let i = 0; i < pages.length; i++) {
    const canvas = await renderDailyReportPageToCanvas(
      pages[i],
      reportDate,
      settings,
      footerSummary
    );
    if (!canvas) continue;
    if (i > 0) {
      pdf.addPage('a4', 'portrait');
    }
    const imgData = canvas.toDataURL('image/jpeg', 0.95);
    pdf.addImage(imgData, 'JPEG', 0, 0, 210, 297, undefined, 'FAST');
  }

  return pdf.output('blob');
};
