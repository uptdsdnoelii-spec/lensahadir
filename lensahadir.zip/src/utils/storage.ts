import {
  AttendanceRecord,
  AppSettings,
  ManagedUser,
  AuthSession,
  AdminConfirmationContact,
  RecoveryNotification,
  AdminSubmissionRecord,
  AdminAccountProfile,
  AdminRegistrationRequest,
  DataLockConfig,
  HistoryLockDuration,
  SubmissionsLockDuration,
} from '../types/attendance';
import { createSampleTeacherPhoto } from './defaultImages';
import { loadFromVault, saveToVault } from './idbVault';

const STORAGE_KEYS = {
  RECORDS: 'lensahadir_records',
  SETTINGS: 'lensahadir_settings',
  AUTH: 'lensahadir_auth_session',
  USERS: 'lensahadir_managed_users',
  ADMIN_CONTACT: 'lensahadir_admin_confirmation_contact',
  RECOVERY_NOTIFS: 'lensahadir_recovery_notifications',
  ADMIN_SUBMISSIONS: 'lensahadir_admin_submissions',
  ADMIN_PROFILE: 'lensahadir_admin_profile',
  ADMIN_REGISTRATIONS: 'lensahadir_admin_registrations',
  DATA_LOCK_CONFIG: 'lensahadir_data_lock_config',
  DELETED_IDS: 'lensahadir_deleted_ids',
};

const safeSetLocalStorage = (key: string, value: unknown): void => {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // If localStorage hits ~5MB cap (e.g. 6 months of photos), full data remains safely in IndexedDB vault.
  }
};

export const ADMIN_DEFAULT_SESSION: AuthSession = {
  id: 'admin_default',
  username: 'admin',
  nama: 'Administrator Utama',
  role: 'Admin',
};

export const defaultSettings: AppSettings = {
  namaInstansi: 'PEMERINTAH DAERAH DINAS PENDIDIKAN',
  subInstansi: 'UPTD SATUAN PENDIDIKAN FORMAL NEGERI',
  alamatInstansi: 'Jl. Pendidikan No. 45, Kecamatan Sukamaju',
  namaPimpinan: 'Drs. H. Mulyadi, M.Pd.',
  nipPimpinan: '19720514 199802 1 003',
  jabatanPimpinan: 'Kepala Sekolah',
  kota: 'Jakarta',
  bingkaiWarna: 'navy',
};

export const getStoredSettings = (): AppSettings => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    if (!raw) return defaultSettings;
    return { ...defaultSettings, ...JSON.parse(raw) };
  } catch {
    return defaultSettings;
  }
};

export const saveStoredSettings = (settings: AppSettings): void => {
  try {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  } catch (e) {
    console.error('Failed to save settings:', e);
  }
};

export const getStoredRecords = (): AttendanceRecord[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.RECORDS);
    if (!raw) {
      // Seed with 1 initial sample record for quick demo
      const sampleDate = new Date().toISOString().split('T')[0];
      const sample: AttendanceRecord[] = [
        {
          id: `DOC_${Date.now() - 86400000}`,
          nama: 'Budi Santoso, S.Pd.',
          nip: '19850312 201001 1 018',
          golRuang: 'Penata Muda Tk. I / III/b',
          jabatan: 'Guru Matematika Ahli Pertama',
          statusPegawai: 'ASN',
          tanggal: sampleDate,
          statusKehadiran: 'Hadir (H)',
          catatan: 'Mengajar kelas VII A-D dan piket sekolah',
          fotoMasuk: createSampleTeacherPhoto('Budi Santoso, S.Pd.', 'masuk', 'Masuk'),
          fotoKeluar: createSampleTeacherPhoto('Budi Santoso, S.Pd.', 'keluar', 'Pulang'),
          createdAt: Date.now() - 86400000,
        },
      ];
      localStorage.setItem(STORAGE_KEYS.RECORDS, JSON.stringify(sample));
      return sample;
    }
    return JSON.parse(raw);
  } catch {
    return [];
  }
};

export const saveRecord = (
  record: AttendanceRecord,
  currentList?: AttendanceRecord[]
): AttendanceRecord[] => {
  const existing = Array.isArray(currentList) ? currentList : getStoredRecords();
  const updated = [record, ...existing.filter((r) => r.id !== record.id)];
  safeSetLocalStorage(STORAGE_KEYS.RECORDS, updated);
  void saveToVault(STORAGE_KEYS.RECORDS, updated);
  clearDeletedId('record', record.id);
  return updated;
};

export const deleteRecord = (
  id: string,
  currentList?: AttendanceRecord[]
): AttendanceRecord[] => {
  const existing = Array.isArray(currentList) ? currentList : getStoredRecords();
  const updated = existing.filter((r) => r.id !== id);
  safeSetLocalStorage(STORAGE_KEYS.RECORDS, updated);
  void saveToVault(STORAGE_KEYS.RECORDS, updated);
  markDeletedId('record', id);
  return updated;
};

export const defaultAdminProfile: AdminAccountProfile = {
  id: 'admin_default',
  nama: 'Administrator Utama',
  nip: '',
  jabatan: 'Administrator Utama Lembaga / Satuan Dinas',
  lembaga: defaultSettings.subInstansi || defaultSettings.namaInstansi,
  golRuang: '',
  email: '',
  noWa: '',
  username: 'admin',
  password: 'admin123',
};

export const getStoredAdminProfile = (): AdminAccountProfile => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.ADMIN_PROFILE);
    if (!raw) return defaultAdminProfile;
    const parsed = JSON.parse(raw);
    return {
      ...defaultAdminProfile,
      ...parsed,
      id: 'admin_default',
      username: String(parsed?.username || defaultAdminProfile.username),
      password: String(parsed?.password || defaultAdminProfile.password),
    };
  } catch {
    return defaultAdminProfile;
  }
};

export const saveAdminProfile = (
  profile: AdminAccountProfile
): AdminAccountProfile => {
  const sanitized: AdminAccountProfile = {
    ...defaultAdminProfile,
    ...profile,
    id: 'admin_default',
    updatedAt: Date.now(),
  };
  try {
    localStorage.setItem(STORAGE_KEYS.ADMIN_PROFILE, JSON.stringify(sanitized));
  } catch (e) {
    console.error('Failed to save admin profile:', e);
  }
  return sanitized;
};

export const buildAdminSessionFromProfile = (
  profile: AdminAccountProfile
): AuthSession => ({
  id: profile.id || 'admin_default',
  username: profile.username,
  nama: profile.nama || 'Administrator Utama',
  role: 'Admin',
  nip: profile.nip,
  golRuang: profile.golRuang,
  jabatan: profile.jabatan,
});

export const getStoredAuthSession = (): AuthSession | null => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.AUTH);
    if (!raw) return null;
    if (raw === 'true') {
      // Backward compatibility for legacy boolean session
      return buildAdminSessionFromProfile(getStoredAdminProfile());
    }
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === 'object' && parsed.role && parsed.username) {
      return parsed as AuthSession;
    }
    return null;
  } catch {
    return null;
  }
};

export const saveAuthSession = (session: AuthSession | null): void => {
  try {
    if (session) {
      localStorage.setItem(STORAGE_KEYS.AUTH, JSON.stringify(session));
    } else {
      localStorage.removeItem(STORAGE_KEYS.AUTH);
    }
  } catch {
    // Ignore error
  }
};

export const isAuthLoggedIn = (): boolean => {
  return Boolean(getStoredAuthSession());
};

export const setAuthLoggedIn = (val: boolean): void => {
  saveAuthSession(val ? ADMIN_DEFAULT_SESSION : null);
};

export const getStoredUsers = (): ManagedUser[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.USERS);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
};

export const saveManagedUser = (user: ManagedUser): ManagedUser[] => {
  try {
    const existing = getStoredUsers();
    const idx = existing.findIndex((u) => u.id === user.id);
    const updated =
      idx >= 0
        ? existing.map((u) =>
            u.id === user.id ? { ...user, profileUpdatedAt: Date.now() } : u
          )
        : [{ ...user, profileUpdatedAt: user.profileUpdatedAt || Date.now() }, ...existing];
    safeSetLocalStorage(STORAGE_KEYS.USERS, updated);
    void saveToVault(STORAGE_KEYS.USERS, updated);
    clearDeletedId('user', user.id);
    return updated;
  } catch (e) {
    console.error('Failed to save user:', e);
    return getStoredUsers();
  }
};

export const activateAllManagedUsers = (currentList?: ManagedUser[]): ManagedUser[] => {
  const existing = Array.isArray(currentList) ? currentList : getStoredUsers();
  const now = Date.now();
  const updated = existing.map((u) => ({
    ...u,
    aktif: true,
    profileUpdatedAt: now,
  }));
  safeSetLocalStorage(STORAGE_KEYS.USERS, updated);
  void saveToVault(STORAGE_KEYS.USERS, updated);
  return updated;
};

export const deleteManagedUser = (id: string, currentList?: ManagedUser[]): ManagedUser[] => {
  try {
    const existing = Array.isArray(currentList) ? currentList : getStoredUsers();
    const updated = existing.filter((u) => u.id !== id);
    safeSetLocalStorage(STORAGE_KEYS.USERS, updated);
    void saveToVault(STORAGE_KEYS.USERS, updated);
    markDeletedId('user', id);
    return updated;
  } catch (e) {
    console.error('Failed to delete user:', e);
    return getStoredUsers();
  }
};

export const getAdminConfirmationContact = (): AdminConfirmationContact => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.ADMIN_CONTACT);
    if (!raw) return { type: 'wa', value: '' };
    const parsed = JSON.parse(raw);
    if (parsed && (parsed.type === 'wa' || parsed.type === 'email')) {
      return { type: parsed.type, value: String(parsed.value || '') };
    }
    return { type: 'wa', value: '' };
  } catch {
    return { type: 'wa', value: '' };
  }
};

export const saveAdminConfirmationContact = (
  contact: AdminConfirmationContact
): void => {
  try {
    localStorage.setItem(STORAGE_KEYS.ADMIN_CONTACT, JSON.stringify(contact));
  } catch (e) {
    console.error('Failed to save admin contact:', e);
  }
};

export const getRecoveryNotifications = (): RecoveryNotification[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.RECOVERY_NOTIFS);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
};

export const addRecoveryNotification = (
  notif: RecoveryNotification
): RecoveryNotification[] => {
  try {
    const existing = getRecoveryNotifications();
    const updated = [notif, ...existing];
    localStorage.setItem(STORAGE_KEYS.RECOVERY_NOTIFS, JSON.stringify(updated));
    return updated;
  } catch (e) {
    console.error('Failed to save recovery notification:', e);
    return getRecoveryNotifications();
  }
};

export const markRecoveryNotificationDone = (
  id: string
): RecoveryNotification[] => {
  try {
    const existing = getRecoveryNotifications();
    const updated = existing.map((n) =>
      n.id === id ? { ...n, status: 'selesai' as const } : n
    );
    localStorage.setItem(STORAGE_KEYS.RECOVERY_NOTIFS, JSON.stringify(updated));
    return updated;
  } catch (e) {
    console.error('Failed to update notification:', e);
    return getRecoveryNotifications();
  }
};

export const deleteRecoveryNotification = (
  id: string
): RecoveryNotification[] => {
  try {
    const existing = getRecoveryNotifications();
    const updated = existing.filter((n) => n.id !== id);
    localStorage.setItem(STORAGE_KEYS.RECOVERY_NOTIFS, JSON.stringify(updated));
    return updated;
  } catch (e) {
    console.error('Failed to delete notification:', e);
    return getRecoveryNotifications();
  }
};

const INDONESIAN_DAY_NAMES = [
  'Minggu',
  'Senin',
  'Selasa',
  'Rabu',
  'Kamis',
  'Jumat',
  'Sabtu',
];

export const buildAdminSubmissionFromRecord = (
  record: AttendanceRecord,
  session: AuthSession
): AdminSubmissionRecord => {
  const parts = (record.tanggal || '').split('-').map((p) => parseInt(p, 10));
  const now = new Date();
  const tahun = parts.length === 3 && !Number.isNaN(parts[0]) ? parts[0] : now.getFullYear();
  const bulan = parts.length === 3 && !Number.isNaN(parts[1]) ? parts[1] : now.getMonth() + 1;
  const tanggalHari = parts.length === 3 && !Number.isNaN(parts[2]) ? parts[2] : now.getDate();
  const dt = new Date(tahun, bulan - 1, tanggalHari);
  const hari = INDONESIAN_DAY_NAMES[dt.getDay()] || 'Senin';

  return {
    id: `SUB_${session.id}_${record.tanggal}_${record.id}`,
    recordId: record.id,
    userId: session.id,
    username: session.username,
    nama: record.nama,
    nip: record.nip || '',
    golRuang: record.golRuang || '',
    jabatan: record.jabatan || '',
    statusPegawai: record.statusPegawai,
    tanggal: record.tanggal || `${tahun}-${String(bulan).padStart(2, '0')}-${String(tanggalHari).padStart(2, '0')}`,
    hari,
    tanggalHari,
    bulan,
    tahun,
    statusKehadiran: record.statusKehadiran,
    catatan: record.catatan || '',
    fotoMasuk: record.fotoMasuk,
    fotoKeluar: record.fotoKeluar,
    submittedAt: Date.now(),
  };
};

export const getAdminSubmissions = (): AdminSubmissionRecord[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.ADMIN_SUBMISSIONS);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
};

export const saveAdminSubmission = (
  submission: AdminSubmissionRecord,
  currentList?: AdminSubmissionRecord[]
): AdminSubmissionRecord[] => {
  const existing = Array.isArray(currentList) ? currentList : getAdminSubmissions();
  // Replace if same recordId OR same userId + same tanggal to prevent accidental duplicate on same day
  const filtered = existing.filter(
    (item) =>
      item.recordId !== submission.recordId &&
      !(item.userId === submission.userId && item.tanggal === submission.tanggal)
  );
  const updated = [submission, ...filtered];
  safeSetLocalStorage(STORAGE_KEYS.ADMIN_SUBMISSIONS, updated);
  void saveToVault(STORAGE_KEYS.ADMIN_SUBMISSIONS, updated);
  clearDeletedId('submission', submission.id);
  return updated;
};

export const deleteAdminSubmission = (
  id: string,
  currentList?: AdminSubmissionRecord[]
): AdminSubmissionRecord[] => {
  const existing = Array.isArray(currentList) ? currentList : getAdminSubmissions();
  const updated = existing.filter((item) => item.id !== id);
  safeSetLocalStorage(STORAGE_KEYS.ADMIN_SUBMISSIONS, updated);
  void saveToVault(STORAGE_KEYS.ADMIN_SUBMISSIONS, updated);
  markDeletedId('submission', id);
  return updated;
};

export const getAdminRegistrations = (): AdminRegistrationRequest[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.ADMIN_REGISTRATIONS);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
};

export const addAdminRegistration = (
  req: AdminRegistrationRequest
): AdminRegistrationRequest[] => {
  try {
    const existing = getAdminRegistrations();
    const updated = [req, ...existing];
    localStorage.setItem(
      STORAGE_KEYS.ADMIN_REGISTRATIONS,
      JSON.stringify(updated)
    );
    return updated;
  } catch (e) {
    console.error('Failed to save admin registration:', e);
    return getAdminRegistrations();
  }
};

export const markAdminRegistrationContacted = (
  id: string
): AdminRegistrationRequest[] => {
  try {
    const existing = getAdminRegistrations();
    const updated = existing.map((item) =>
      item.id === id ? { ...item, status: 'dihubungi' as const } : item
    );
    localStorage.setItem(
      STORAGE_KEYS.ADMIN_REGISTRATIONS,
      JSON.stringify(updated)
    );
    return updated;
  } catch (e) {
    console.error('Failed to update admin registration:', e);
    return getAdminRegistrations();
  }
};

export const deleteAdminRegistration = (
  id: string
): AdminRegistrationRequest[] => {
  try {
    const existing = getAdminRegistrations();
    const updated = existing.filter((item) => item.id !== id);
    localStorage.setItem(
      STORAGE_KEYS.ADMIN_REGISTRATIONS,
      JSON.stringify(updated)
    );
    return updated;
  } catch (e) {
    console.error('Failed to delete admin registration:', e);
    return getAdminRegistrations();
  }
};

export const defaultDataLockConfig: DataLockConfig = {
  adminDataLocked: false,
  adminDataLockedAt: null,
  historyLockMonths: 0,
  historyLockedAt: null,
  historyLockedUntil: null,
  submissionsLockMonths: 0,
  submissionsLockedAt: null,
  submissionsLockedUntil: null,
  retentionMonths: 6, // Maksimal 6 bulan (1 semester)
  updatedAt: 0,
};

export const computeLockUntil = (months: number, fromTs = Date.now()): number | null => {
  if (!months || months <= 0) return null;
  const d = new Date(fromTs);
  d.setMonth(d.getMonth() + months);
  return d.getTime();
};

export const getDataLockConfig = (): DataLockConfig => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.DATA_LOCK_CONFIG);
    if (!raw) return defaultDataLockConfig;
    return { ...defaultDataLockConfig, ...JSON.parse(raw) };
  } catch {
    return defaultDataLockConfig;
  }
};

export const saveDataLockConfig = (cfg: DataLockConfig): DataLockConfig => {
  const next: DataLockConfig = {
    ...defaultDataLockConfig,
    ...cfg,
    updatedAt: Date.now(),
  };
  safeSetLocalStorage(STORAGE_KEYS.DATA_LOCK_CONFIG, next);
  void saveToVault(STORAGE_KEYS.DATA_LOCK_CONFIG, next);
  return next;
};

export const buildUpdatedHistoryLock = (
  current: DataLockConfig,
  months: HistoryLockDuration
): DataLockConfig => {
  const now = Date.now();
  return saveDataLockConfig({
    ...current,
    historyLockMonths: months,
    historyLockedAt: months > 0 ? now : null,
    historyLockedUntil: months > 0 ? computeLockUntil(months, now) : null,
    updatedAt: now,
  });
};

export const buildUpdatedSubmissionsLock = (
  current: DataLockConfig,
  months: SubmissionsLockDuration,
  retentionMonths?: 1 | 3 | 6
): DataLockConfig => {
  const now = Date.now();
  const nextRetention: 1 | 3 | 6 =
    retentionMonths ||
    (months === 1 || months === 3 || months === 6 ? months : current.retentionMonths || 6);
  return saveDataLockConfig({
    ...current,
    submissionsLockMonths: months,
    submissionsLockedAt: months > 0 ? now : null,
    submissionsLockedUntil: months > 0 ? computeLockUntil(months, now) : null,
    retentionMonths: nextRetention,
    updatedAt: now,
  });
};

export const buildUpdatedAdminDataLock = (
  current: DataLockConfig,
  locked: boolean
): DataLockConfig => {
  const now = Date.now();
  return saveDataLockConfig({
    ...current,
    adminDataLocked: locked,
    adminDataLockedAt: locked ? now : null,
    updatedAt: now,
  });
};

export const isAdminDataLockedNow = (cfg: DataLockConfig): boolean => {
  return Boolean(cfg && cfg.adminDataLocked);
};

export const isHistoryLockedNow = (cfg: DataLockConfig): boolean => {
  if (!cfg || cfg.historyLockMonths === 0) return false;
  if (!cfg.historyLockedUntil) return true;
  return Date.now() <= cfg.historyLockedUntil;
};

export const isSubmissionsLockedNow = (cfg: DataLockConfig): boolean => {
  if (!cfg || cfg.submissionsLockMonths === 0) return false;
  if (!cfg.submissionsLockedUntil) return true;
  return Date.now() <= cfg.submissionsLockedUntil;
};

export interface DeletedIdsStore {
  recordIds: string[];
  submissionIds: string[];
  userIds: string[];
}

export const getDeletedIds = (): DeletedIdsStore => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.DELETED_IDS);
    if (!raw) return { recordIds: [], submissionIds: [], userIds: [] };
    const parsed = JSON.parse(raw);
    return {
      recordIds: Array.isArray(parsed?.recordIds) ? parsed.recordIds : [],
      submissionIds: Array.isArray(parsed?.submissionIds) ? parsed.submissionIds : [],
      userIds: Array.isArray(parsed?.userIds) ? parsed.userIds : [],
    };
  } catch {
    return { recordIds: [], submissionIds: [], userIds: [] };
  }
};

export const markDeletedId = (kind: 'record' | 'submission' | 'user', id: string): void => {
  if (!id) return;
  const store = getDeletedIds();
  if (kind === 'record') {
    store.recordIds = Array.from(new Set([...store.recordIds, id])).slice(-500);
  } else if (kind === 'submission') {
    store.submissionIds = Array.from(new Set([...store.submissionIds, id])).slice(-500);
  } else {
    store.userIds = Array.from(new Set([...store.userIds, id])).slice(-500);
  }
  safeSetLocalStorage(STORAGE_KEYS.DELETED_IDS, store);
};

export const clearDeletedId = (kind: 'record' | 'submission' | 'user', id: string): void => {
  if (!id) return;
  const store = getDeletedIds();
  if (kind === 'record') {
    store.recordIds = store.recordIds.filter((x) => x !== id);
  } else if (kind === 'submission') {
    store.submissionIds = store.submissionIds.filter((x) => x !== id);
  } else {
    store.userIds = store.userIds.filter((x) => x !== id);
  }
  safeSetLocalStorage(STORAGE_KEYS.DELETED_IDS, store);
};

export const hydrateFromDurableVault = async (): Promise<{
  users?: ManagedUser[];
  adminProfile?: AdminAccountProfile;
  records?: AttendanceRecord[];
  adminSubmissions?: AdminSubmissionRecord[];
  lockConfig?: DataLockConfig;
}> => {
  const [vaultUsers, vaultAdminProfile, vaultRecords, vaultSubmissions, vaultLock] =
    await Promise.all([
      loadFromVault<ManagedUser[]>(STORAGE_KEYS.USERS),
      loadFromVault<AdminAccountProfile>(STORAGE_KEYS.ADMIN_PROFILE),
      loadFromVault<AttendanceRecord[]>(STORAGE_KEYS.RECORDS),
      loadFromVault<AdminSubmissionRecord[]>(STORAGE_KEYS.ADMIN_SUBMISSIONS),
      loadFromVault<DataLockConfig>(STORAGE_KEYS.DATA_LOCK_CONFIG),
    ]);
  return {
    users: Array.isArray(vaultUsers) ? vaultUsers : undefined,
    adminProfile: vaultAdminProfile || undefined,
    records: Array.isArray(vaultRecords) ? vaultRecords : undefined,
    adminSubmissions: Array.isArray(vaultSubmissions) ? vaultSubmissions : undefined,
    lockConfig: vaultLock || undefined,
  };
};

export const replaceAllStoredData = (bundle: {
  settings?: AppSettings;
  adminProfile?: AdminAccountProfile;
  adminContact?: AdminConfirmationContact;
  lockConfig?: DataLockConfig;
  users?: ManagedUser[];
  records?: AttendanceRecord[];
  adminSubmissions?: AdminSubmissionRecord[];
  recoveryNotifications?: RecoveryNotification[];
  adminRegistrations?: AdminRegistrationRequest[];
}): void => {
  if (bundle.settings) {
    safeSetLocalStorage(STORAGE_KEYS.SETTINGS, { ...defaultSettings, ...bundle.settings });
  }
  if (bundle.adminProfile) {
    const mergedAdmin = {
      ...defaultAdminProfile,
      ...bundle.adminProfile,
    };
    safeSetLocalStorage(STORAGE_KEYS.ADMIN_PROFILE, mergedAdmin);
    void saveToVault(STORAGE_KEYS.ADMIN_PROFILE, mergedAdmin);
  }
  if (bundle.adminContact) {
    safeSetLocalStorage(STORAGE_KEYS.ADMIN_CONTACT, bundle.adminContact);
  }
  if (bundle.lockConfig) {
    const mergedLock = { ...defaultDataLockConfig, ...bundle.lockConfig };
    safeSetLocalStorage(STORAGE_KEYS.DATA_LOCK_CONFIG, mergedLock);
    void saveToVault(STORAGE_KEYS.DATA_LOCK_CONFIG, mergedLock);
  }
  if (Array.isArray(bundle.users)) {
    safeSetLocalStorage(STORAGE_KEYS.USERS, bundle.users);
    void saveToVault(STORAGE_KEYS.USERS, bundle.users);
  }
  if (Array.isArray(bundle.records)) {
    safeSetLocalStorage(STORAGE_KEYS.RECORDS, bundle.records);
    void saveToVault(STORAGE_KEYS.RECORDS, bundle.records);
  }
  if (Array.isArray(bundle.adminSubmissions)) {
    safeSetLocalStorage(STORAGE_KEYS.ADMIN_SUBMISSIONS, bundle.adminSubmissions);
    void saveToVault(STORAGE_KEYS.ADMIN_SUBMISSIONS, bundle.adminSubmissions);
  }
  if (Array.isArray(bundle.recoveryNotifications)) {
    safeSetLocalStorage(STORAGE_KEYS.RECOVERY_NOTIFS, bundle.recoveryNotifications);
  }
  if (Array.isArray(bundle.adminRegistrations)) {
    safeSetLocalStorage(STORAGE_KEYS.ADMIN_REGISTRATIONS, bundle.adminRegistrations);
  }
};


