import { AttendanceRecord, AppSettings } from '../types/attendance';

/**
 * Loads an image from a DataURL, Blob, or URL safely
 */
const loadImageSafe = (src: string): Promise<HTMLImageElement> => {
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = () => {
      resolve(img);
    };
    img.src = src;
  });
};

/**
 * Splits a paragraph into wrapped lines that fit within maxWidth
 */
function wrapTextLines(
  ctx: CanvasRenderingContext2D,
  text: string,
  maxWidth: number
): string[] {
  const paragraphs = text.split(/\r?\n/);
  const lines: string[] = [];

  for (const para of paragraphs) {
    const words = para.split(/\s+/).filter(Boolean);
    if (words.length === 0) {
      lines.push('');
      continue;
    }

    let currentLine = words[0];
    for (let i = 1; i < words.length; i++) {
      const testLine = currentLine + ' ' + words[i];
      if (ctx.measureText(testLine).width <= maxWidth) {
        currentLine = testLine;
      } else {
        lines.push(currentLine);
        currentLine = words[i];
      }
    }
    lines.push(currentLine);
  }

  return lines;
}

/**
 * Draws a crisp double line (two parallel lines with a tiny white gap)
 * to replicate the official blue double-border table style.
 */
function drawDoubleHorizontalLine(
  ctx: CanvasRenderingContext2D,
  x1: number,
  x2: number,
  y: number,
  color: string
) {
  ctx.save();
  ctx.strokeStyle = '#ffffff';
  ctx.lineWidth = 6;
  ctx.beginPath();
  ctx.moveTo(x1, y);
  ctx.lineTo(x2, y);
  ctx.stroke();

  ctx.strokeStyle = color;
  ctx.lineWidth = 1.8;
  ctx.beginPath();
  ctx.moveTo(x1, y - 2.2);
  ctx.lineTo(x2, y - 2.2);
  ctx.moveTo(x1, y + 2.2);
  ctx.lineTo(x2, y + 2.2);
  ctx.stroke();
  ctx.restore();
}

function drawDoubleVerticalLine(
  ctx: CanvasRenderingContext2D,
  x: number,
  y1: number,
  y2: number,
  color: string
) {
  ctx.save();
  ctx.strokeStyle = '#ffffff';
  ctx.lineWidth = 6;
  ctx.beginPath();
  ctx.moveTo(x, y1);
  ctx.lineTo(x, y2);
  ctx.stroke();

  ctx.strokeStyle = color;
  ctx.lineWidth = 1.8;
  ctx.beginPath();
  ctx.moveTo(x - 2.2, y1);
  ctx.lineTo(x - 2.2, y2);
  ctx.moveTo(x + 2.2, y1);
  ctx.lineTo(x + 2.2, y2);
  ctx.stroke();
  ctx.restore();
}

function drawDashedHorizontalLine(
  ctx: CanvasRenderingContext2D,
  x1: number,
  x2: number,
  y: number,
  color: string
) {
  ctx.save();
  ctx.strokeStyle = color;
  ctx.lineWidth = 1.8;
  ctx.setLineDash([7, 4]);
  ctx.beginPath();
  ctx.moveTo(x1, y);
  ctx.lineTo(x2, y);
  ctx.stroke();
  ctx.restore();
}

/**
 * Draws the Landscape Attendance Report Card directly onto a high-resolution 2D Canvas.
 * Matches the blue double-border Landscape tabular format and guarantees 100% reliable PNG download.
 */
export const renderAttendanceCardToBlob = async (
  record: AttendanceRecord,
  _settings: AppSettings
): Promise<Blob | null> => {
  const canvas = document.createElement('canvas');
  // High-resolution Landscape canvas (1600 x 800 px)
  const width = 1600;
  const height = 800;
  canvas.width = width;
  canvas.height = height;

  const ctx = canvas.getContext('2d');
  if (!ctx) return null;

  const serifFont = '"Times New Roman", Times, Georgia, serif';
  const sansFont = '"Plus Jakarta Sans", sans-serif';
  const headerBlue = '#5b9bd5';
  const borderBlue = '#2e75b6';
  const titleBlue = '#1f4e79';

  // 1. White Canvas Background
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, width, height);

  // Format Hari / Tanggal in Indonesian
  let formattedDate = record.tanggal;
  try {
    const [y, m, d] = record.tanggal.split('-').map(Number);
    const dateObj = new Date(y, m - 1, d);
    formattedDate = dateObj.toLocaleDateString('id-ID', {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    });
  } catch {
    // Keep raw date
  }

  // 2. Judul Kartu & Tanggal
  ctx.fillStyle = titleBlue;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.font = `bold 32px ${serifFont}`;
  ctx.fillText('KARTU LAPORAN ABSEN HARIAN', width / 2, 52);

  ctx.font = `22px ${serifFont}`;
  ctx.fillStyle = '#1e293b';
  ctx.fillText(`Hari / Tanggal : ${formattedDate}`, width / 2, 90);

  // 3. Landscape Table Geometry
  const tableLeft = 48;
  const tableTop = 122;

  const w1 = 200; // Label column (Nama, NIP, Status, Gol. Ruang, Jabatan)
  const w2 = 380; // Value column (: ...)
  const w3 = 346; // ABSEN MASUK
  const w4 = 346; // ABSEN PULANG
  const w5 = 232; // Ket. Kehadiran

  const x1 = tableLeft;
  const x2 = x1 + w1;
  const x3 = x2 + w2;
  const x4 = x3 + w3;
  const x5 = x4 + w4;
  const tableWidth = w1 + w2 + w3 + w4 + w5; // 1504

  const hHead1 = 54;
  const hHead2 = 46;
  const hHead = hHead1 + hHead2; // 100

  const bodyTop = tableTop + hHead; // 222
  const rowCount = 5;
  const rowHeight = 96;
  const bodyHeight = rowCount * rowHeight; // 480
  const tableBottom = bodyTop + bodyHeight; // 702

  // 4. Draw Header Backgrounds
  // Left header (Nama/NIP/Jabatan/Gol.Ruang/Status)
  ctx.fillStyle = headerBlue;
  ctx.fillRect(x1, tableTop, w1 + w2, hHead);

  // Middle top header (BUKTI DUKUNG (Foto TimeMark))
  ctx.fillStyle = headerBlue;
  ctx.fillRect(x3, tableTop, w3 + w4, hHead1);

  // Middle sub-headers (ABSEN MASUK | ABSEN PULANG) -> Clean White
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(x3, tableTop + hHead1, w3, hHead2);
  ctx.fillRect(x4, tableTop + hHead1, w4, hHead2);

  // Right header (Ket. Kehadiran)
  ctx.fillStyle = headerBlue;
  ctx.fillRect(x5, tableTop, w5, hHead);

  // 5. Draw Header Texts
  // White Bold headers on blue background
  ctx.fillStyle = '#ffffff';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.font = `bold 27px ${serifFont}`;
  ctx.fillText('Nama/NIP/Jabatan/', x1 + (w1 + w2) / 2, tableTop + hHead / 2 - 16);
  ctx.fillText('Gol.Ruang/Status', x1 + (w1 + w2) / 2, tableTop + hHead / 2 + 16);

  ctx.font = `bold 27px ${serifFont}`;
  ctx.fillText('BUKTI DUKUNG (Foto TimeMark)', x3 + (w3 + w4) / 2, tableTop + hHead1 / 2);

  ctx.font = `bold 27px ${serifFont}`;
  ctx.fillText('Ket.', x5 + w5 / 2, tableTop + hHead / 2 - 16);
  ctx.fillText('Kehadiran', x5 + w5 / 2, tableTop + hHead / 2 + 16);

  // Black Bold sub-headers on white background
  ctx.fillStyle = '#000000';
  ctx.font = `bold 25px ${serifFont}`;
  ctx.fillText('ABSEN MASUK', x3 + w3 / 2, tableTop + hHead1 + hHead2 / 2);
  ctx.fillText('ABSEN PULANG', x4 + w4 / 2, tableTop + hHead1 + hHead2 / 2);

  // 6. Draw Left 5 Data Rows (Bold labels, no vertical divider between label & value)
  const leftRows: { label: string; value: string; isBold?: boolean }[] = [
    { label: 'Nama', value: record.nama || '-', isBold: true },
    { label: 'NIP', value: record.nip || '-' },
    { label: 'Status', value: record.statusPegawai || '-' },
    { label: 'Gol. Ruang', value: record.golRuang || '-' },
    { label: 'Jabatan', value: record.jabatan || '-' },
  ];

  ctx.textAlign = 'left';
  ctx.textBaseline = 'top';
  ctx.fillStyle = '#000000';

  for (let i = 0; i < leftRows.length; i++) {
    const row = leftRows[i];
    const rowY = bodyTop + i * rowHeight;

    // Bold Label
    ctx.font = `bold 24px ${serifFont}`;
    ctx.fillText(row.label, x1 + 16, rowY + 16);

    // Value (preserve exact casing e.g. S.Pd)
    const colonStr = ': ';
    ctx.font = `24px ${serifFont}`;
    ctx.fillText(colonStr, x2 + 6, rowY + 16);
    const colonWidth = ctx.measureText(colonStr).width;

    ctx.font = `${row.isBold ? 'bold ' : ''}24px ${serifFont}`;
    const valueLines = wrapTextLines(ctx, row.value, w2 - 18 - colonWidth);
    const maxLines = 3;
    for (let l = 0; l < Math.min(valueLines.length, maxLines); l++) {
      ctx.fillText(valueLines[l], x2 + 6 + colonWidth, rowY + 16 + l * 28);
    }
  }

  // 7. Draw Photos (ABSEN MASUK & ABSEN PULANG) - Preserving Full TimeMark Watermarks
  const [imgMasuk, imgKeluar] = await Promise.all([
    loadImageSafe(record.fotoMasuk),
    loadImageSafe(record.fotoKeluar),
  ]);

  const photoPad = 14;
  const photoBoxW = w3 - photoPad * 2;
  const photoBoxH = bodyHeight - photoPad * 2;

  if (imgMasuk.width > 0 && imgMasuk.height > 0) {
    drawImageAspectContain(ctx, imgMasuk, x3 + photoPad, bodyTop + photoPad, photoBoxW, photoBoxH);
  } else {
    drawPlaceholderText(ctx, 'Foto Masuk', x3 + photoPad, bodyTop + photoPad, photoBoxW, photoBoxH);
  }

  if (imgKeluar.width > 0 && imgKeluar.height > 0) {
    drawImageAspectContain(ctx, imgKeluar, x4 + photoPad, bodyTop + photoPad, photoBoxW, photoBoxH);
  } else {
    drawPlaceholderText(ctx, 'Foto Pulang', x4 + photoPad, bodyTop + photoPad, photoBoxW, photoBoxH);
  }

  // 8. Draw Right Column (Ket. Kehadiran)
  const statusLabel = record.statusKehadiran || 'Hadir (H)';
  const hasCatatan = Boolean(
    record.catatan && record.catatan.trim() !== '' && record.catatan.trim() !== '-'
  );

  ctx.textAlign = 'left';
  ctx.textBaseline = 'top';
  ctx.fillStyle = '#000000';

  const ketPadX = 16;
  const ketMaxW = w5 - ketPadX * 2;
  let ketY = bodyTop + 16;

  // Bold Status Kehadiran
  ctx.font = `bold 24px ${serifFont}`;
  const statusLines = wrapTextLines(
    ctx,
    `${statusLabel}${hasCatatan ? ':' : ''}`,
    ketMaxW
  );
  for (const line of statusLines) {
    ctx.fillText(line, x5 + ketPadX, ketY);
    ketY += 30;
  }

  // Italic Keterangan / Catatan Tambahan
  if (hasCatatan) {
    ketY += 4;
    ctx.font = `italic 24px ${serifFont}`;
    const noteLines = wrapTextLines(ctx, record.catatan.trim(), ketMaxW);
    for (const line of noteLines) {
      if (ketY > bodyTop + bodyHeight - 28) break;
      ctx.fillText(line, x5 + ketPadX, ketY);
      ketY += 30;
    }
  }

  // 9. Draw Dashed Blue Horizontal Dividers for Left 5 Data Rows (no vertical line between label & value)
  for (let i = 1; i < rowCount; i++) {
    const y = bodyTop + i * rowHeight;
    drawDashedHorizontalLine(ctx, x1 + 4, x3 - 4, y, borderBlue);
  }

  // 10. Draw Double Blue Borders for Outer Frame & Major Structural Grid
  // Horizontal double lines
  drawDoubleHorizontalLine(ctx, x1, x1 + tableWidth, tableTop, borderBlue);
  drawDoubleHorizontalLine(ctx, x3, x5, tableTop + hHead1, borderBlue);
  drawDoubleHorizontalLine(ctx, x1, x1 + tableWidth, bodyTop, borderBlue);
  drawDoubleHorizontalLine(ctx, x1, x1 + tableWidth, tableBottom, borderBlue);

  // Vertical double lines
  drawDoubleVerticalLine(ctx, x1, tableTop, tableBottom, borderBlue);
  drawDoubleVerticalLine(ctx, x3, tableTop, tableBottom, borderBlue);
  drawDoubleVerticalLine(ctx, x4, tableTop + hHead1, tableBottom, borderBlue);
  drawDoubleVerticalLine(ctx, x5, tableTop, tableBottom, borderBlue);
  drawDoubleVerticalLine(ctx, x1 + tableWidth, tableTop, tableBottom, borderBlue);

  // 11. Footer Meta Ringkas
  const footerLineY = tableBottom + 24;
  ctx.strokeStyle = '#cbd5e1';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(tableLeft, footerLineY);
  ctx.lineTo(tableLeft + tableWidth, footerLineY);
  ctx.stroke();

  const printedTimestamp = new Date().toLocaleString('id-ID', {
    dateStyle: 'medium',
    timeStyle: 'medium',
  });

  ctx.textBaseline = 'top';
  ctx.font = `500 15px "JetBrains Mono", monospace`;
  ctx.fillStyle = '#64748b';
  ctx.textAlign = 'left';
  ctx.fillText(`ID_DOKUMEN: ${record.id || 'DOC_' + Date.now()}`, tableLeft, footerLineY + 14);

  ctx.textAlign = 'center';
  ctx.font = `italic 15px ${sansFont}`;
  ctx.fillStyle = '#94a3b8';
  ctx.fillText(
    '© 2026 Aplikasi Manajemen Absensi Digital by: yakob lomang blogger · LensaHadir',
    width / 2,
    footerLineY + 14
  );

  ctx.textAlign = 'right';
  ctx.font = `bold 15px "JetBrains Mono", monospace`;
  ctx.fillStyle = '#64748b';
  ctx.fillText(`DICETAK: ${printedTimestamp}`, tableLeft + tableWidth, footerLineY + 14);

  return new Promise((resolve) => {
    canvas.toBlob((blob) => {
      resolve(blob);
    }, 'image/png');
  });
};

/**
 * Draws an image fitted inside the target box preserving full TimeMark overlays without cropping
 */
function drawImageAspectContain(
  ctx: CanvasRenderingContext2D,
  img: HTMLImageElement,
  x: number,
  y: number,
  w: number,
  h: number
) {
  const imgRatio = img.width / img.height;
  const targetRatio = w / h;

  let drawW = w;
  let drawH = h;
  let offsetX = x;
  let offsetY = y;

  if (imgRatio > targetRatio) {
    drawW = w;
    drawH = w / imgRatio;
    offsetY = y + (h - drawH) / 2;
  } else {
    drawH = h;
    drawW = h * imgRatio;
    offsetX = x + (w - drawW) / 2;
  }

  ctx.drawImage(img, offsetX, offsetY, drawW, drawH);
}

function drawPlaceholderText(
  ctx: CanvasRenderingContext2D,
  label: string,
  x: number,
  y: number,
  w: number,
  h: number
) {
  ctx.fillStyle = '#64748b';
  ctx.font = 'bold 22px "Plus Jakarta Sans", sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(label, x + w / 2, y + h / 2);
}

/**
 * Initiates direct browser download to the user's PC Laptop Downloads folder
 */
export const triggerBrowserDownload = (blob: Blob, filename: string): void => {
  const blobUrl = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.style.display = 'none';
  link.href = blobUrl;
  link.setAttribute('download', filename);
  document.body.appendChild(link);

  link.click();

  setTimeout(() => {
    if (document.body.contains(link)) {
      document.body.removeChild(link);
    }
    URL.revokeObjectURL(blobUrl);
  }, 3000);
};
