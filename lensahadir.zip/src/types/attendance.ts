export type StatusPegawai = 'ASN' | 'PPPK' | 'PPPK Paruh Waktu' | 'Honor/GTT' | 'Tenaga Kontrak' | 'Penjaga Sekolah';

export type StatusKehadiran = 
  | 'Hadir (H)' 
  | 'Ijin (I)' 
  | 'Sakit (S)' 
  | 'Cuti (C)' 
  | 'Tugas Dinas (TD)' 
  | 'Tanpa Berita (TB)'
  | 'Tugas Belajar (TS)';

export interface AttendanceRecord {
  id: string;
  nama: string;
  nip: string;
  golRuang: string; // e.g. "Penata Tk. I / III/d", "IX", or "-"
  jabatan?: string;
  statusPegawai: StatusPegawai;
  tanggal: string; // YYYY-MM-DD
  statusKehadiran: StatusKehadiran;
  catatan: string;
  fotoMasuk: string; // Data URL or Image URL
  fotoKeluar: string; // Data URL or Image URL
  createdAt: number;
  jamMasuk?: string;
  jamKeluar?: string;
  lokasi?: string;
  ownerUserId?: string;
  ownerUsername?: string;
  sentToAdmin?: boolean;
  sentToAdminAt?: number;
}

export interface AppSettings {
  namaInstansi: string;
  subInstansi: string;
  alamatInstansi: string;
  namaPimpinan: string;
  nipPimpinan: string;
  jabatanPimpinan: string;
  kota: string;
  bingkaiWarna: 'navy' | 'emerald' | 'maroon';
}

export interface DailyReportCardItem {
  id: string;
  orderNumber: number;
  imageUrl: string;
  fileName?: string;
}

export interface DailyReportFooterSummary {
  driveLink: string;
  jumlahGuruPegawai: string;
  hadir: string;
  ijin: string;
  sakit: string;
  cuti: string;
  tugasDinas: string;
  tugasBelajar: string;
  tanpaBerita: string;
}

export type PegawaiKategori = 'PNS' | 'PPPK' | 'GTT' | 'Lainnya';

export interface MonthlyRecapRow {
  id: string;
  nama: string;
  nip: string;
  jabatan: string;
  golongan: string;
  kategori: PegawaiKategori;
  h: number;
  td: number;
  i: number;
  s: number;
  tk: number;
}

export interface WeeklyTrendPoint {
  label: string;
  present: number;
  td: number;
  absent: number;
}

export interface MonthlyRecapConfig {
  bulan: number; // 1 - 12
  tahun: number;
  hariKerjaEfektif: number;
  polaHariKerja: 'Senin–Sabtu (6 Hari Kerja)' | 'Senin–Jumat (5 Hari Kerja)';
  tanggalTtd: string; // YYYY-MM-DD
  catatanAdmin: string;
  logoKiri?: string;
  logoKanan?: string;
  customWeeklyTrend?: WeeklyTrendPoint[];
}

export type UserRole = 'Admin' | 'Guru/Pegawai' | 'Pimpinan';

export type AssignableUserRole = 'Guru/Pegawai' | 'Pimpinan';

export type ConfirmationContactType = 'wa' | 'email';

export interface AdminConfirmationContact {
  type: ConfirmationContactType;
  value: string;
}

export interface AdminAccountProfile {
  id: string;
  nama: string;
  nip: string;
  jabatan: string;
  lembaga: string;
  golRuang: string;
  email: string;
  noWa: string;
  username: string;
  password: string;
  updatedAt?: number;
}

export interface AdminRegistrationRequest {
  id: string;
  nama: string;
  nip: string;
  jabatan: string;
  lembaga: string;
  golRuang: string;
  noWa: string;
  email: string;
  username: string;
  password: string;
  status: 'menunggu' | 'dihubungi';
  createdAt: number;
}

export interface ManagedUser {
  id: string;
  nama: string;
  nip: string;
  golRuang: string;
  statusPegawai: StatusPegawai;
  jabatan: string;
  role: AssignableUserRole;
  username: string;
  password: string;
  konfirmasiTipe: ConfirmationContactType;
  konfirmasiAdmin: string;
  aktif: boolean;
  createdAt: number;
  profileUpdatedAt?: number;
  profileUpdatedBySelf?: boolean;
  linkedUid?: string;
}

export interface AuthSession {
  id: string;
  username: string;
  nama: string;
  role: UserRole;
  nip?: string;
  golRuang?: string;
  statusPegawai?: StatusPegawai;
  jabatan?: string;
}

export interface RecoveryNotification {
  id: string;
  namaPemohon: string;
  nipAtauInfo: string;
  matchedUserId?: string;
  matchedUsername?: string;
  matchedRole?: AssignableUserRole;
  jenisLupa: 'password' | 'username' | 'keduanya';
  catatan: string;
  saluranTujuan: ConfirmationContactType;
  kontakAdminTujuan: string;
  status: 'menunggu' | 'selesai';
  createdAt: number;
}

export interface AdminSubmissionRecord {
  id: string;
  recordId: string;
  userId: string;
  username: string;
  nama: string;
  nip: string;
  golRuang: string;
  jabatan: string;
  statusPegawai: StatusPegawai;
  tanggal: string; // YYYY-MM-DD
  hari: string; // e.g. "Senin"
  tanggalHari: number; // 1 - 31
  bulan: number; // 1 - 12
  tahun: number; // e.g. 2026
  statusKehadiran: StatusKehadiran;
  catatan: string;
  fotoMasuk: string;
  fotoKeluar: string;
  submittedAt: number;
}

export type HistoryLockDuration = 0 | 1 | 2 | 3; // 0 = Nonaktif, 1/2/3 bulan
export type SubmissionsLockDuration = 0 | 1 | 3 | 6; // 0 = Nonaktif, 1/3/6 bulan (1 semester)

export interface DataLockConfig {
  // Kunci Khusus Data Admin (Profil Admin, Kredensial Admin, Kop Instansi & Proteksi Hapus Akun)
  // Saat aktif, data Admin terkunci aman sementara seluruh akun user tetap aktif & dapat login di semua browser & HP
  adminDataLocked: boolean;
  adminDataLockedAt: number | null;
  // Kunci Riwayat Absensi: 1 bulan, 2 bulan, 3 bulan, atau Nonaktif (0)
  historyLockMonths: HistoryLockDuration;
  historyLockedAt: number | null;
  historyLockedUntil: number | null;
  // Kunci Data Absen Pengguna di Dashboard Admin: 1 bulan, 3 bulan, 6 bulan (1 semester), atau Nonaktif (0)
  submissionsLockMonths: SubmissionsLockDuration;
  submissionsLockedAt: number | null;
  submissionsLockedUntil: number | null;
  // Durasi penyimpanan maksimal data absen user (1, 3, atau 6 bulan / 1 semester)
  retentionMonths: 1 | 3 | 6;
  updatedAt: number;
}
