/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import html2canvas from 'html2canvas';
import confetti from 'canvas-confetti';
import {
  Camera,
  Upload,
  Printer,
  Download,
  Edit3,
  RotateCcw,
  Sparkles,
  Lock,
  LogOut,
  Settings,
  History,
  CheckCircle2,
  FileText,
  ShieldCheck,
  ChevronRight,
  User,
  Building2,
  X,
  FileSpreadsheet,
  BarChart3,
  LayoutDashboard,
  KeyRound,
  Shield,
  Briefcase,
  UserCog,
  Send,
  Home,
} from 'lucide-react';

import {
  AttendanceRecord,
  AppSettings,
  StatusPegawai,
  StatusKehadiran,
  DailyReportCardItem,
  MonthlyRecapRow,
  MonthlyRecapConfig,
  ManagedUser,
  AuthSession,
  AdminConfirmationContact,
  RecoveryNotification,
  AdminSubmissionRecord,
  AdminAccountProfile,
  AdminRegistrationRequest,
  DataLockConfig,
  HistoryLockDuration,
  SubmissionsLockDuration,
} from './types/attendance';
import {
  defaultFotoMasuk,
  defaultFotoKeluar,
  createSampleTeacherPhoto,
} from './utils/defaultImages';
import {
  getStoredSettings,
  saveStoredSettings,
  getStoredRecords,
  saveRecord,
  deleteRecord,
  getStoredAuthSession,
  saveAuthSession,
  getStoredUsers,
  saveManagedUser,
  activateAllManagedUsers,
  deleteManagedUser,
  getAdminConfirmationContact,
  saveAdminConfirmationContact,
  getRecoveryNotifications,
  addRecoveryNotification,
  markRecoveryNotificationDone,
  deleteRecoveryNotification,
  getAdminSubmissions,
  saveAdminSubmission,
  deleteAdminSubmission,
  buildAdminSubmissionFromRecord,
  getStoredAdminProfile,
  saveAdminProfile,
  buildAdminSessionFromProfile,
  getAdminRegistrations,
  addAdminRegistration,
  markAdminRegistrationContacted,
  deleteAdminRegistration,
  getDataLockConfig,
  buildUpdatedAdminDataLock,
  buildUpdatedHistoryLock,
  buildUpdatedSubmissionsLock,
  isAdminDataLockedNow,
  isHistoryLockedNow,
  isSubmissionsLockedNow,
  getDeletedIds,
  hydrateFromDurableVault,
  replaceAllStoredData,
} from './utils/storage';
import { PrintableCard } from './components/PrintableCard';
import { SettingsModal } from './components/SettingsModal';
import { HistoryDrawer } from './components/HistoryDrawer';
import { DailyDisciplineReport } from './components/DailyDisciplineReport';
import { MonthlyRecapReport } from './components/MonthlyRecapReport';
import { AdminDashboard } from './components/AdminDashboard';
import { UserDashboard } from './components/UserDashboard';
import { ForgotAccountModal } from './components/ForgotAccountModal';
import { UserProfileModal } from './components/UserProfileModal';
import { AdminProfileModal } from './components/AdminProfileModal';
import { HelpModal } from './components/HelpModal';
import { HomePage } from './components/HomePage';
import { AdminRegisterPage } from './components/AdminRegisterPage';
import { LeaderStatisticsPage } from './components/LeaderStatisticsPage';
import { renderAttendanceCardToBlob, triggerBrowserDownload } from './utils/cardCanvasRenderer';
import {
  getDaysInMonth,
  getDefaultEffectiveWorkDays,
  inferKategoriFromGolongan,
  INDONESIAN_MONTHS,
} from './utils/monthlyRecapParser';
import {
  compressPhotoDataUrl,
  exportBackupJsonFile,
  LensaHadirDataBundle,
  loginViaServer,
  mergeByIdNonDestructive,
  parseBackupJsonFile,
  pullSyncedData,
  pushSyncMutation,
  setAuthBearerToken,
} from './utils/dataSync';

export default function App() {
  // Navigation states: 'home' | 'login' | 'dashboard' | 'form' | 'result' | 'report' | 'monthly'
  const [currentUser, setCurrentUser] = useState<AuthSession | null>(() =>
    getStoredAuthSession()
  );
  const isLoggedIn = Boolean(currentUser);
  const isAdmin = currentUser?.role === 'Admin';
  const isPimpinan = currentUser?.role === 'Pimpinan';
  const isGuruPegawai = currentUser?.role === 'Guru/Pegawai';

  const [currentPage, setCurrentPage] = useState<
    | 'home'
    | 'login'
    | 'register'
    | 'dashboard'
    | 'form'
    | 'result'
    | 'report'
    | 'monthly'
    | 'statistics'
  >(() => {
    const existing = getStoredAuthSession();
    if (!existing) return 'home';
    return 'dashboard';
  });

  // Sync & Backup States
  const [isSyncingData, setIsSyncingData] = useState(false);

  // Primary Admin Profile, Managed Users (Guru/Pegawai & Pimpinan), Admin Confirmation Contact, Recovery Notifications, Admin Submissions & Admin Registrations
  const [adminProfile, setAdminProfile] = useState<AdminAccountProfile>(() =>
    getStoredAdminProfile()
  );
  const [users, setUsers] = useState<ManagedUser[]>(() => getStoredUsers());
  const [adminContact, setAdminContact] = useState<AdminConfirmationContact>(() =>
    getAdminConfirmationContact()
  );
  const [recoveryNotifications, setRecoveryNotifications] = useState<RecoveryNotification[]>(() =>
    getRecoveryNotifications()
  );
  const [adminSubmissions, setAdminSubmissions] = useState<AdminSubmissionRecord[]>(() =>
    getAdminSubmissions()
  );
  const [adminRegistrations, setAdminRegistrations] = useState<AdminRegistrationRequest[]>(() =>
    getAdminRegistrations()
  );

  const pendingRecoveryCount =
    recoveryNotifications.filter((n) => n.status === 'menunggu').length +
    adminRegistrations.filter((r) => r.status === 'menunggu').length;

  // Form Fields
  const [nama, setNama] = useState('');
  const [nip, setNip] = useState('');
  const [golRuang, setGolRuang] = useState('');
  const [jabatan, setJabatan] = useState('');
  const [statusPegawai, setStatusPegawai] = useState<StatusPegawai>('ASN');
  const [tanggal, setTanggal] = useState<string>(() => new Date().toISOString().split('T')[0]);
  const [statusKehadiran, setStatusKehadiran] = useState<StatusKehadiran>('Hadir (H)');
  const [catatan, setCatatan] = useState('');
  const [fotoMasuk, setFotoMasuk] = useState<string>(defaultFotoMasuk);
  const [fotoKeluar, setFotoKeluar] = useState<string>(defaultFotoKeluar);

  // Active Generated Record for Result View
  const [activeRecord, setActiveRecord] = useState<AttendanceRecord | null>(null);
  const [hasDownloadedActiveCard, setHasDownloadedActiveCard] = useState(false);

  // App Settings, Lock Config & History Records
  const [settings, setSettings] = useState<AppSettings>(() => getStoredSettings());
  const [records, setRecords] = useState<AttendanceRecord[]>(() => getStoredRecords());
  const [lockConfig, setLockConfig] = useState<DataLockConfig>(() => getDataLockConfig());

  // Refs synced with latest state so background sync merges non-destructively without stale closures
  const recordsRef = useRef<AttendanceRecord[]>(records);
  const submissionsRef = useRef<AdminSubmissionRecord[]>(adminSubmissions);
  const usersRef = useRef<ManagedUser[]>(users);
  const recoveryRef = useRef<RecoveryNotification[]>(recoveryNotifications);
  const registrationsRef = useRef<AdminRegistrationRequest[]>(adminRegistrations);
  const lockConfigRef = useRef<DataLockConfig>(lockConfig);
  const settingsRef = useRef<AppSettings>(settings);
  const adminProfileRef = useRef<AdminAccountProfile>(adminProfile);
  const adminContactRef = useRef<AdminConfirmationContact>(adminContact);

  recordsRef.current = records;
  submissionsRef.current = adminSubmissions;
  usersRef.current = users;
  recoveryRef.current = recoveryNotifications;
  registrationsRef.current = adminRegistrations;
  lockConfigRef.current = lockConfig;
  settingsRef.current = settings;
  adminProfileRef.current = adminProfile;
  adminContactRef.current = adminContact;

  // Daily Discipline Report (Rekapan Laporan Disiplin Jam Kerja Harian) state
  const [reportDate, setReportDate] = useState<string>(() => new Date().toISOString().split('T')[0]);
  const [reportItems, setReportItems] = useState<DailyReportCardItem[]>([
    { id: 'card_initial_1', orderNumber: 1, imageUrl: '' },
  ]);

  // Monthly Attendance Recap (Perhitungan Rekapitulasi Absensi Per Bulan) state
  const [monthlyRows, setMonthlyRows] = useState<MonthlyRecapRow[]>([]);
  const [monthlyConfig, setMonthlyConfig] = useState<MonthlyRecapConfig>(() => {
    const now = new Date();
    const b = now.getMonth() + 1;
    const t = now.getFullYear();
    const lastDay = getDaysInMonth(b, t);
    return {
      bulan: b,
      tahun: t,
      hariKerjaEfektif: getDefaultEffectiveWorkDays(b, t, true),
      polaHariKerja: 'Senin–Sabtu (6 Hari Kerja)',
      tanggalTtd: `${t}-${String(b).padStart(2, '0')}-${String(lastDay).padStart(2, '0')}`,
      catatanAdmin: '',
    };
  });

  // Modals
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [isForgotModalOpen, setIsForgotModalOpen] = useState(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [isAdminProfileOpen, setIsAdminProfileOpen] = useState(false);
  const [isHelpModalOpen, setIsHelpModalOpen] = useState(false);

  const currentManagedUser = currentUser
    ? users.find((u) => u.id === currentUser.id) || null
    : null;

  const visibleRecords =
    isGuruPegawai && currentUser
      ? records.filter(
          (r) =>
            r.ownerUserId === currentUser.id ||
            (r.ownerUsername &&
              r.ownerUsername.toLowerCase() === currentUser.username.toLowerCase()) ||
            r.nama.trim().toLowerCase() === currentUser.nama.trim().toLowerCase()
        )
      : records;

  const submittedRecordIds = new Set(adminSubmissions.map((s) => s.recordId));
  const isActiveRecordSentToAdmin = activeRecord
    ? Boolean(activeRecord.sentToAdmin || submittedRecordIds.has(activeRecord.id))
    : false;

  // Login inputs
  const [loginUser, setLoginUser] = useState('');
  const [loginPass, setLoginPass] = useState('');
  const [loginErrorMsg, setLoginErrorMsg] = useState('');

  // Notifications / Feedback
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadPreviewUrl, setDownloadPreviewUrl] = useState<string | null>(null);
  const [downloadFilename, setDownloadFilename] = useState<string>('');

  const fileInputMasukRef = useRef<HTMLInputElement>(null);
  const fileInputKeluarRef = useRef<HTMLInputElement>(null);
  const printableAreaRef = useRef<HTMLDivElement>(null);

  const applySessionIdentityToForm = (session: AuthSession) => {
    if (session.role !== 'Admin') {
      setNama(session.nama || '');
      setNip(session.nip || '');
      setGolRuang(session.golRuang || '');
      setJabatan(session.jabatan || '');
      if (session.statusPegawai) {
        setStatusPegawai(session.statusPegawai);
      }
    }
  };

  useEffect(() => {
    if (currentUser && currentUser.role !== 'Admin' && !nama) {
      applySessionIdentityToForm(currentUser);
    }
  }, [currentUser]);

  // Apply synced bundle (used by explicit Backup JSON restore)
  const applyBundleToAppState = (bundle: LensaHadirDataBundle) => {
    replaceAllStoredData(bundle);
    if (bundle.settings) setSettings(bundle.settings);
    if (bundle.adminProfile) setAdminProfile(bundle.adminProfile);
    if (bundle.adminContact) setAdminContact(bundle.adminContact);
    if (bundle.lockConfig) setLockConfig(bundle.lockConfig);
    if (Array.isArray(bundle.users)) setUsers(bundle.users);
    if (Array.isArray(bundle.records)) setRecords(bundle.records);
    if (Array.isArray(bundle.adminSubmissions)) setAdminSubmissions(bundle.adminSubmissions);
    if (Array.isArray(bundle.recoveryNotifications)) {
      setRecoveryNotifications(bundle.recoveryNotifications);
    }
    if (Array.isArray(bundle.adminRegistrations)) {
      setAdminRegistrations(bundle.adminRegistrations);
    }
  };

  // Durable IndexedDB Hydration + Non-Destructive Cross-Device Sync (/api/sync-data)
  // Prevents flickering/disappearing attendance items (e.g. 36 -> 0 -> 36) and supports full 6-month / 1-semester archives.
  useEffect(() => {
    let active = true;
    let vaultReady = false;

    const hydrateVault = async () => {
      try {
        const vault = await hydrateFromDurableVault();
        if (!active) return;

        const localDeleted = getDeletedIds();
        const deletedRecSet = new Set(localDeleted.recordIds);
        const deletedSubSet = new Set(localDeleted.submissionIds);

        if (vault.records && vault.records.length > 0) {
          const mergedRecs = mergeByIdNonDestructive(
            recordsRef.current,
            vault.records,
            deletedRecSet,
            (r) => r.sentToAdminAt || r.createdAt || 0
          ).merged;
          recordsRef.current = mergedRecs;
          setRecords(mergedRecs);
        }

        if (vault.adminSubmissions && vault.adminSubmissions.length > 0) {
          const mergedSubs = mergeByIdNonDestructive(
            submissionsRef.current,
            vault.adminSubmissions,
            deletedSubSet,
            (s) => s.submittedAt || 0
          ).merged;
          submissionsRef.current = mergedSubs;
          setAdminSubmissions(mergedSubs);
        }

        if (vault.users && vault.users.length > 0) {
          const deletedUserSet = new Set(localDeleted.userIds);
          const mergedUsers = mergeByIdNonDestructive(
            usersRef.current,
            vault.users,
            deletedUserSet,
            (u) => u.profileUpdatedAt || u.createdAt || 0
          ).merged;
          usersRef.current = mergedUsers;
          setUsers(mergedUsers);
        }

        if (
          vault.adminProfile &&
          (vault.adminProfile.updatedAt || 0) > (adminProfileRef.current.updatedAt || 0)
        ) {
          adminProfileRef.current = vault.adminProfile;
          setAdminProfile(vault.adminProfile);
        }

        if (
          vault.lockConfig &&
          (vault.lockConfig.updatedAt || 0) > (lockConfigRef.current.updatedAt || 0)
        ) {
          lockConfigRef.current = vault.lockConfig;
          setLockConfig(vault.lockConfig);
        }
      } finally {
        vaultReady = true;
      }
    };

    const syncFromServer = async () => {
      if (!vaultReady) return;
      const remote = await pullSyncedData();
      if (!active) return;

      const localDeleted = getDeletedIds();
      if (remote) {
        const deletedRecSet = new Set<string>([
          ...localDeleted.recordIds,
          ...(Array.isArray(remote.deletedRecordIds) ? remote.deletedRecordIds : []),
        ]);
        const deletedSubSet = new Set<string>([
          ...localDeleted.submissionIds,
          ...(Array.isArray(remote.deletedSubmissionIds) ? remote.deletedSubmissionIds : []),
        ]);
        const deletedUserSet = new Set<string>([
          ...localDeleted.userIds,
          ...(Array.isArray(remote.deletedUserIds) ? remote.deletedUserIds : []),
        ]);

        // Non-destructive union merge: existing users/records/submissions NEVER vanish or flicker
        const recMerge = mergeByIdNonDestructive(
          recordsRef.current,
          remote.records,
          deletedRecSet,
          (r) => r.sentToAdminAt || r.createdAt || 0
        );
        const subMerge = mergeByIdNonDestructive(
          submissionsRef.current,
          remote.adminSubmissions,
          deletedSubSet,
          (s) => s.submittedAt || 0
        );
        const userMerge = mergeByIdNonDestructive(
          usersRef.current,
          remote.users,
          deletedUserSet,
          (u) => u.profileUpdatedAt || u.createdAt || 0
        );
        const recovMerge = mergeByIdNonDestructive(
          recoveryRef.current,
          remote.recoveryNotifications,
          new Set<string>(),
          (n) => n.createdAt || 0
        );
        const regMerge = mergeByIdNonDestructive(
          registrationsRef.current,
          remote.adminRegistrations,
          new Set<string>(),
          (r) => r.createdAt || 0
        );

        const remoteLock = remote.lockConfig;
        const nextLock =
          remoteLock && (remoteLock.updatedAt || 0) >= (lockConfigRef.current.updatedAt || 0)
            ? remoteLock
            : lockConfigRef.current;

        const localAdminTs = adminProfileRef.current?.updatedAt || 0;
        const remoteAdminTs = remote.adminProfile?.updatedAt || 0;
        const nextAdminProfile =
          remote.adminProfile && remoteAdminTs >= localAdminTs
            ? remote.adminProfile
            : adminProfileRef.current;

        const mergedBundle: LensaHadirDataBundle = {
          version: 1,
          updatedAt: Math.max(remote.updatedAt || 0, Date.now()),
          settings: remote.settings || settingsRef.current,
          adminProfile: nextAdminProfile,
          adminContact: remote.adminContact || adminContactRef.current,
          lockConfig: nextLock,
          users: userMerge.merged,
          records: recMerge.merged,
          adminSubmissions: subMerge.merged,
          recoveryNotifications: recovMerge.merged,
          adminRegistrations: regMerge.merged,
          deletedRecordIds: Array.from(deletedRecSet),
          deletedSubmissionIds: Array.from(deletedSubSet),
          deletedUserIds: Array.from(deletedUserSet),
        };

        replaceAllStoredData(mergedBundle);
        if (mergedBundle.settings) {
          settingsRef.current = mergedBundle.settings;
          setSettings(mergedBundle.settings);
        }
        if (mergedBundle.adminProfile) {
          adminProfileRef.current = mergedBundle.adminProfile;
          setAdminProfile(mergedBundle.adminProfile);
        }
        if (mergedBundle.adminContact) {
          adminContactRef.current = mergedBundle.adminContact;
          setAdminContact(mergedBundle.adminContact);
        }
        lockConfigRef.current = nextLock;
        usersRef.current = userMerge.merged;
        recordsRef.current = recMerge.merged;
        submissionsRef.current = subMerge.merged;
        recoveryRef.current = recovMerge.merged;
        registrationsRef.current = regMerge.merged;
        setLockConfig(nextLock);
        setUsers(userMerge.merged);
        setRecords(recMerge.merged);
        setAdminSubmissions(subMerge.merged);
        setRecoveryNotifications(recovMerge.merged);
        setAdminRegistrations(regMerge.merged);

        // Push local-only users, submissions, records, Admin profile, or lock changes up so every browser & HP gets them immediately!
        const localLockNewer =
          (lockConfigRef.current.updatedAt || 0) > (remoteLock?.updatedAt || 0);
        const localAdminNewer = localAdminTs > remoteAdminTs;
        if (
          userMerge.localHadExtra ||
          recMerge.localHadExtra ||
          subMerge.localHadExtra ||
          localLockNewer ||
          localAdminNewer
        ) {
          await pushSyncMutation({
            type: 'full_replace',
            payload: mergedBundle,
          });
        }
      } else {
        // First time on fresh server: seed server if browser already has data
        const hasLocal =
          usersRef.current.length > 0 ||
          submissionsRef.current.length > 0 ||
          recordsRef.current.length > 0 ||
          Boolean(localStorage.getItem('lensahadir_settings')) ||
          Boolean(localStorage.getItem('lensahadir_admin_profile'));
        if (hasLocal) {
          await pushSyncMutation({
            type: 'full_replace',
            payload: {
              settings: settingsRef.current,
              adminProfile: adminProfileRef.current,
              adminContact: adminContactRef.current,
              lockConfig: lockConfigRef.current,
              users: usersRef.current,
              records: recordsRef.current,
              adminSubmissions: submissionsRef.current,
              recoveryNotifications: recoveryRef.current,
              adminRegistrations: registrationsRef.current,
              deletedRecordIds: localDeleted.recordIds,
              deletedSubmissionIds: localDeleted.submissionIds,
              deletedUserIds: localDeleted.userIds,
            },
          });
        }
      }
    };

    void hydrateVault().then(() => {
      if (active) void syncFromServer();
    });

    const interval = setInterval(() => {
      void syncFromServer();
    }, 25000);
    const onFocus = () => {
      void syncFromServer();
    };
    window.addEventListener('focus', onFocus);

    return () => {
      active = false;
      clearInterval(interval);
      window.removeEventListener('focus', onFocus);
    };
  }, []);

  // Toast Helper
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };

  // Multi-role Login handler:
  // Instant local match + fast cross-browser/HP server verification (/api/auth/login) so ANY active user
  // can log in from any browser or smartphone (even on a brand-new phone browser with empty cache).
  const handleLogin = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const cleanUser = loginUser.trim();
    if (!cleanUser || !loginPass) {
      setLoginErrorMsg('Masukkan Username dan Password terlebih dahulu.');
      return;
    }

    const completeSignIn = (session: AuthSession, welcomeMsg: string) => {
      setCurrentUser(session);
      saveAuthSession(session);
      if (session.role !== 'Admin') {
        applySessionIdentityToForm(session);
      }
      setLoginErrorMsg('');
      setLoginPass('');
      setCurrentPage('dashboard');
      showToast(welcomeMsg);
    };

    // 1. Instant local check for Admin
    const activeAdminUsername = (adminProfileRef.current.username || 'admin').trim();
    if (
      cleanUser.toLowerCase() === activeAdminUsername.toLowerCase() &&
      loginPass === adminProfileRef.current.password
    ) {
      const adminSession = buildAdminSessionFromProfile(adminProfileRef.current);
      completeSignIn(adminSession, `Berhasil masuk sebagai ${adminSession.nama}`);
      void loginViaServer(cleanUser, loginPass);
      return;
    }

    // 2. Instant local check for Managed Users (Guru/Pegawai & Pimpinan)
    const matchedLocal = usersRef.current.find(
      (u) => u.username.trim().toLowerCase() === cleanUser.toLowerCase() && u.password === loginPass
    );

    if (matchedLocal) {
      if (matchedLocal.aktif === false) {
        setLoginErrorMsg('Akun ini sedang dinonaktifkan oleh Admin. Silakan hubungi Admin instansi.');
        return;
      }
      const session: AuthSession = {
        id: matchedLocal.id,
        username: matchedLocal.username,
        nama: matchedLocal.nama,
        role: matchedLocal.role,
        nip: matchedLocal.nip,
        golRuang: matchedLocal.golRuang,
        statusPegawai: matchedLocal.statusPegawai,
        jabatan: matchedLocal.jabatan,
      };
      completeSignIn(session, `Selamat datang, ${matchedLocal.nama} (${matchedLocal.role})`);
      void loginViaServer(cleanUser, loginPass);
      return;
    }

    // 3. Cross-browser / Mobile HP verification against central server (/api/auth/login)
    const serverRes = await loginViaServer(cleanUser, loginPass);
    if (serverRes.ok) {
      const s = serverRes.session;
      completeSignIn(
        s,
        s.role === 'Admin'
          ? `Berhasil masuk sebagai ${s.nama}`
          : `Selamat datang, ${s.nama} (${s.role})`
      );
      // Refresh synced directory & attendance history in background
      void pullSyncedData().then((remote) => {
        if (!remote) return;
        if (remote.settings) setSettings(remote.settings);
        if (remote.adminProfile) setAdminProfile(remote.adminProfile);
        if (remote.adminContact) setAdminContact(remote.adminContact);
        if (remote.lockConfig) setLockConfig(remote.lockConfig);
        if (Array.isArray(remote.users)) setUsers(remote.users);
        if (Array.isArray(remote.records)) setRecords(remote.records);
        if (Array.isArray(remote.adminSubmissions)) setAdminSubmissions(remote.adminSubmissions);
      });
      return;
    }

    if (serverRes.code === 'INACTIVE') {
      setLoginErrorMsg(
        serverRes.error ||
          'Akun ini sedang dinonaktifkan oleh Admin. Silakan hubungi Admin instansi.'
      );
      return;
    }

    setLoginErrorMsg('Username atau Password salah! Periksa kembali data masuk Anda.');
  };

  const handleLogout = () => {
    setAuthBearerToken(null);
    setCurrentUser(null);
    saveAuthSession(null);
    setCurrentPage('home');
    setLoginUser('');
    setLoginPass('');
    setLoginErrorMsg('');
    showToast('Telah keluar dari sistem LensaHadir');
  };

  // User Management handlers (Admin-only, synced automatically for all browsers & HP)
  const handleSaveUser = async (user: ManagedUser) => {
    const stampedUser: ManagedUser = {
      ...user,
      profileUpdatedAt: Date.now(),
    };
    const updated = saveManagedUser(stampedUser);
    usersRef.current = updated;
    setUsers(updated);
    await pushSyncMutation({ type: 'save_user', payload: stampedUser });
  };

  const handleDeleteUser = async (id: string) => {
    if (isAdminDataLockedNow(lockConfigRef.current)) {
      showToast(
        'Kunci Data Admin sedang aktif. Buka Kunci Data Admin terlebih dahulu jika Admin ingin menghapus akun pengguna.'
      );
      return;
    }
    if (isSubmissionsLockedNow(lockConfigRef.current)) {
      showToast(
        'Gembok Data sedang aktif. Nonaktifkan Kunci terlebih dahulu jika Admin ingin menghapus akun pengguna.'
      );
      return;
    }
    const updated = deleteManagedUser(id, usersRef.current);
    usersRef.current = updated;
    setUsers(updated);
    await pushSyncMutation({ type: 'delete_user', id });
  };

  // Dedicated Kunci Data Admin Handler (Locks Admin Profile, Kop Instansi & Deletes while keeping all User accounts ACTIVE across all browsers & HP)
  const handleToggleAdminDataLock = async (locked: boolean) => {
    if (!isAdmin) return;
    const next = buildUpdatedAdminDataLock(lockConfigRef.current, locked);
    lockConfigRef.current = next;
    setLockConfig(next);
    await pushSyncMutation({ type: 'save_lock_config', payload: next });
    if (locked) {
      // Also ensure the central server has the latest Admin + Users snapshot immediately
      await pushSyncMutation({
        type: 'full_replace',
        payload: {
          settings: settingsRef.current,
          adminProfile: adminProfileRef.current,
          adminContact: adminContactRef.current,
          lockConfig: next,
          users: usersRef.current,
        },
      });
      showToast(
        'Kunci Data Admin AKTIF. Data Admin terkunci aman, sementara semua akun User tetap aktif & dapat login di semua browser termasuk HP.'
      );
    } else {
      showToast('Kunci Data Admin dinonaktifkan. Admin kini dapat mengubah Data Admin & Kop Instansi.');
    }
  };

  // Activate all user accounts and push them to central server so every Guru/Pegawai & Pimpinan can log in on any browser or HP immediately
  const handleActivateAllUsersForAllDevices = async () => {
    if (!isAdmin) return;
    const updated = activateAllManagedUsers(usersRef.current);
    usersRef.current = updated;
    setUsers(updated);
    await pushSyncMutation({
      type: 'full_replace',
      payload: {
        settings: settingsRef.current,
        adminProfile: adminProfileRef.current,
        adminContact: adminContactRef.current,
        lockConfig: lockConfigRef.current,
        users: updated,
      },
    });
    await pushSyncMutation({ type: 'activate_all_users' });
    showToast(
      `Semua ${updated.length} akun pengguna berstatus AKTIF & tersinkron untuk login di semua browser dan HP.`
    );
  };

  // Admin Full-Control Data Lock Handlers (Absensi Pengguna 1/3/6 Bulan & Riwayat 1/2/3 Bulan)
  const handleUpdateSubmissionsLock = async (months: SubmissionsLockDuration) => {
    if (!isAdmin) return;
    const next = buildUpdatedSubmissionsLock(lockConfigRef.current, months);
    lockConfigRef.current = next;
    setLockConfig(next);
    await pushSyncMutation({ type: 'save_lock_config', payload: next });
    if (months === 0) {
      showToast('Kunci Data & File Absensi Pengguna dinonaktifkan. Admin dapat mengelola/menghapus data.');
    } else if (months === 6) {
      showToast('Gembok Data & File Absensi Pengguna aktif selama 6 Bulan (1 Semester). Data aman terkunci.');
    } else {
      showToast(`Gembok Data & File Absensi Pengguna aktif selama ${months} Bulan. Data aman terkunci.`);
    }
  };

  const handleUpdateHistoryLock = async (months: HistoryLockDuration) => {
    if (!isAdmin) return;
    const next = buildUpdatedHistoryLock(lockConfigRef.current, months);
    lockConfigRef.current = next;
    setLockConfig(next);
    await pushSyncMutation({ type: 'save_lock_config', payload: next });
    if (months === 0) {
      showToast('Kunci Riwayat Absensi dinonaktifkan.');
    } else {
      showToast(`Kunci Riwayat Absensi aktif selama ${months} Bulan. Data riwayat aman terkunci.`);
    }
  };

  // Backup & Restore JSON handlers for data portability
  const handleExportBackup = () => {
    const filename = exportBackupJsonFile({
      version: 1,
      updatedAt: Date.now(),
      settings,
      adminProfile,
      adminContact,
      lockConfig,
      users,
      records,
      adminSubmissions,
      recoveryNotifications,
      adminRegistrations,
    });
    showToast(`Backup data berhasil diunduh: ${filename}`);
  };

  const handleImportBackup = async (file: File) => {
    setIsSyncingData(true);
    try {
      const parsed = await parseBackupJsonFile(file);
      if (!parsed.ok) {
        showToast(parsed.message);
        return;
      }
      applyBundleToAppState(parsed.data);
      await pushSyncMutation({ type: 'full_replace', payload: parsed.data });
      showToast(
        `Backup berhasil dipulihkan (${parsed.data.users?.length || 0} pengguna, ${parsed.data.records?.length || 0} riwayat) & disinkronkan.`
      );
    } finally {
      setIsSyncingData(false);
    }
  };

  const handleSaveAdminContact = async (contact: AdminConfirmationContact) => {
    if (isAdminDataLockedNow(lockConfigRef.current)) {
      showToast('Kunci Data Admin sedang aktif. Buka Kunci Data Admin terlebih dahulu untuk mengubah kontak konfirmasi.');
      return;
    }
    saveAdminConfirmationContact(contact);
    setAdminContact(contact);
    await pushSyncMutation({ type: 'save_admin_contact', payload: contact });
  };

  // Primary Admin Profile Update (Data Diri + Username + Password)
  const handleSaveAdminProfile = async (updatedProfile: AdminAccountProfile) => {
    if (isAdminDataLockedNow(lockConfigRef.current)) {
      showToast('Kunci Data Admin sedang aktif. Buka Kunci Data Admin terlebih dahulu untuk mengubah profil Admin.');
      return;
    }
    const saved = saveAdminProfile(updatedProfile);
    adminProfileRef.current = saved;
    setAdminProfile(saved);
    if (isAdmin) {
      const updatedSession = buildAdminSessionFromProfile(saved);
      setCurrentUser(updatedSession);
      saveAuthSession(updatedSession);
    }
    let nextContact = adminContact;
    if (!adminContact.value) {
      if (saved.noWa) {
        nextContact = { type: 'wa', value: saved.noWa };
        saveAdminConfirmationContact(nextContact);
        setAdminContact(nextContact);
        await pushSyncMutation({ type: 'save_admin_contact', payload: nextContact });
      } else if (saved.email) {
        nextContact = { type: 'email', value: saved.email };
        saveAdminConfirmationContact(nextContact);
        setAdminContact(nextContact);
        await pushSyncMutation({ type: 'save_admin_contact', payload: nextContact });
      }
    }
    await pushSyncMutation({ type: 'save_admin_profile', payload: saved });
    showToast('Pengaturan Data Admin berhasil disimpan & disinkronkan');
  };

  const handleAddRecoveryNotification = async (notif: RecoveryNotification) => {
    const updated = addRecoveryNotification(notif);
    setRecoveryNotifications(updated);
    await pushSyncMutation({ type: 'save_recovery', payload: notif });
  };

  const handleMarkNotificationDone = async (id: string) => {
    const updated = markRecoveryNotificationDone(id);
    setRecoveryNotifications(updated);
    await pushSyncMutation({ type: 'mark_recovery_done', id });
  };

  const handleDeleteNotification = async (id: string) => {
    const updated = deleteRecoveryNotification(id);
    setRecoveryNotifications(updated);
    await pushSyncMutation({ type: 'delete_recovery', id });
  };

  // Admin Registration Requests (1 Sekolah / Satuan Dinas)
  const handleAddAdminRegistration = async (req: AdminRegistrationRequest) => {
    const updated = addAdminRegistration(req);
    setAdminRegistrations(updated);
    await pushSyncMutation({ type: 'save_registration', payload: req });
  };

  const handleMarkRegistrationContacted = async (id: string) => {
    const updated = markAdminRegistrationContacted(id);
    setAdminRegistrations(updated);
    await pushSyncMutation({ type: 'mark_registration_contacted', id });
  };

  const handleDeleteRegistration = async (id: string) => {
    const updated = deleteAdminRegistration(id);
    setAdminRegistrations(updated);
    await pushSyncMutation({ type: 'delete_registration', id });
  };

  // Guru/Pegawai & Pimpinan Self-Profile Update ("Pengaturan Data Diri") -> Auto-saved to Admin
  const handleSaveSelfProfile = async (updatedUser: ManagedUser) => {
    const syncedUser: ManagedUser = {
      ...updatedUser,
      profileUpdatedAt: updatedUser.profileUpdatedAt || Date.now(),
      profileUpdatedBySelf: true,
    };
    const updatedList = saveManagedUser(syncedUser);
    setUsers(updatedList);
    const updatedSession: AuthSession = {
      id: syncedUser.id,
      username: syncedUser.username,
      nama: syncedUser.nama,
      role: syncedUser.role,
      nip: syncedUser.nip,
      golRuang: syncedUser.golRuang,
      statusPegawai: syncedUser.statusPegawai,
      jabatan: syncedUser.jabatan,
    };
    setCurrentUser(updatedSession);
    saveAuthSession(updatedSession);
    applySessionIdentityToForm(updatedSession);
    await pushSyncMutation({ type: 'save_user', payload: syncedUser });
    showToast('Data Diri berhasil disimpan & otomatis tersinkron ke akun Admin');
  };

  // Save attendance card to Admin account (organized by User, Day, Month, Year)
  const handleSendRecordToAdmin = async (record: AttendanceRecord) => {
    if (!currentUser) return;
    const compressedMasuk = await compressPhotoDataUrl(record.fotoMasuk);
    const compressedKeluar = await compressPhotoDataUrl(record.fotoKeluar);
    const enrichedRecord: AttendanceRecord = {
      ...record,
      fotoMasuk: compressedMasuk,
      fotoKeluar: compressedKeluar,
      ownerUserId: record.ownerUserId || currentUser.id,
      ownerUsername: record.ownerUsername || currentUser.username,
      sentToAdmin: true,
      sentToAdminAt: Date.now(),
    };
    const submission = buildAdminSubmissionFromRecord(enrichedRecord, currentUser);
    const updatedSubs = saveAdminSubmission(submission, submissionsRef.current);
    submissionsRef.current = updatedSubs;
    setAdminSubmissions(updatedSubs);

    const updatedRecs = saveRecord(enrichedRecord, recordsRef.current);
    recordsRef.current = updatedRecs;
    setRecords(updatedRecs);
    if (activeRecord && activeRecord.id === record.id) {
      setActiveRecord(enrichedRecord);
    }

    await pushSyncMutation({ type: 'save_record', payload: enrichedRecord });
    await pushSyncMutation({ type: 'save_submission', payload: submission });

    const monthName = INDONESIAN_MONTHS[submission.bulan - 1] || '';
    showToast(
      `Absensi ${submission.hari}, ${String(submission.tanggalHari).padStart(2, '0')} ${monthName} ${submission.tahun} tersimpan ke akun Admin`
    );
  };

  const handleSendAllRecordsToAdmin = async (recs: AttendanceRecord[]) => {
    if (!currentUser || recs.length === 0) return;
    let latestSubs = submissionsRef.current;
    let latestRecs = recordsRef.current;
    for (const rec of recs) {
      const compressedMasuk = await compressPhotoDataUrl(rec.fotoMasuk);
      const compressedKeluar = await compressPhotoDataUrl(rec.fotoKeluar);
      const enriched: AttendanceRecord = {
        ...rec,
        fotoMasuk: compressedMasuk,
        fotoKeluar: compressedKeluar,
        ownerUserId: rec.ownerUserId || currentUser.id,
        ownerUsername: rec.ownerUsername || currentUser.username,
        sentToAdmin: true,
        sentToAdminAt: Date.now(),
      };
      const sub = buildAdminSubmissionFromRecord(enriched, currentUser);
      latestSubs = saveAdminSubmission(sub, latestSubs);
      latestRecs = saveRecord(enriched, latestRecs);
      await pushSyncMutation({ type: 'save_record', payload: enriched });
      await pushSyncMutation({ type: 'save_submission', payload: sub });
    }
    submissionsRef.current = latestSubs;
    recordsRef.current = latestRecs;
    setAdminSubmissions(latestSubs);
    setRecords(latestRecs);
    showToast(`${recs.length} riwayat absensi berhasil disimpan ke akun Admin`);
  };

  // Admin Dashboard handlers for received submissions
  const handleOpenSubmissionCard = (sub: AdminSubmissionRecord) => {
    const rec: AttendanceRecord = {
      id: sub.recordId,
      nama: sub.nama,
      nip: sub.nip,
      golRuang: sub.golRuang,
      jabatan: sub.jabatan,
      statusPegawai: sub.statusPegawai,
      tanggal: sub.tanggal,
      statusKehadiran: sub.statusKehadiran,
      catatan: sub.catatan,
      fotoMasuk: sub.fotoMasuk,
      fotoKeluar: sub.fotoKeluar,
      createdAt: sub.submittedAt,
      ownerUserId: sub.userId,
      ownerUsername: sub.username,
      sentToAdmin: true,
      sentToAdminAt: sub.submittedAt,
    };
    setActiveRecord(rec);
    setHasDownloadedActiveCard(false);
    setCurrentPage('result');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDeleteSubmission = async (id: string) => {
    if (!isAdmin) return;
    if (isSubmissionsLockedNow(lockConfigRef.current)) {
      showToast(
        'Data & file absensi pengguna sedang terkunci. Klik "Nonaktifkan Kunci" terlebih dahulu jika Admin ingin menghapus.'
      );
      return;
    }
    const updated = deleteAdminSubmission(id, submissionsRef.current);
    submissionsRef.current = updated;
    setAdminSubmissions(updated);
    await pushSyncMutation({ type: 'delete_submission', id });
  };

  const handleImportSubmissionsToMonthly = (
    subs: AdminSubmissionRecord[],
    bulan: number,
    tahun: number
  ) => {
    const map = new Map<string, MonthlyRecapRow>();
    for (const s of subs) {
      const key = s.userId || s.nama.trim().toLowerCase();
      if (!map.has(key)) {
        const gol = s.golRuang?.trim() || (s.statusPegawai === 'Honor/GTT' ? 'GTT' : '-');
        map.set(key, {
          id: `mrec_sub_${s.userId}_${bulan}_${tahun}`,
          nama: s.nama.trim(),
          nip: s.nip?.trim() || '-',
          jabatan: s.jabatan?.trim() || '-',
          golongan: gol,
          kategori: inferKategoriFromGolongan(gol, s.statusPegawai),
          h: 0,
          td: 0,
          i: 0,
          s: 0,
          tk: 0,
        });
      }
      const row = map.get(key)!;
      const st = s.statusKehadiran || 'Hadir (H)';
      if (st.startsWith('Hadir')) row.h++;
      else if (st.startsWith('Tugas Dinas') || st.startsWith('Tugas Belajar')) row.td++;
      else if (st.startsWith('Ijin') || st.startsWith('Cuti')) row.i++;
      else if (st.startsWith('Sakit')) row.s++;
      else row.tk++;
    }

    const groupedRows = Array.from(map.values());
    const lastDay = getDaysInMonth(bulan, tahun);
    setMonthlyRows(groupedRows);
    setMonthlyConfig((prev) => ({
      ...prev,
      bulan,
      tahun,
      hariKerjaEfektif: getDefaultEffectiveWorkDays(bulan, tahun, true),
      tanggalTtd: `${tahun}-${String(bulan).padStart(2, '0')}-${String(lastDay).padStart(2, '0')}`,
      customWeeklyTrend: undefined,
    }));
    setCurrentPage('monthly');
    showToast(
      `${groupedRows.length} pegawai (${INDONESIAN_MONTHS[bulan - 1]} ${tahun}) ditarik ke Rekap Bulanan`
    );
  };

  // File Upload Handlers
  const handleFileUpload = (
    e: React.ChangeEvent<HTMLInputElement>,
    type: 'masuk' | 'keluar'
  ) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const result = event.target?.result as string;
        if (type === 'masuk') {
          setFotoMasuk(result);
        } else {
          setFotoKeluar(result);
        }
        showToast(`Foto ${type === 'masuk' ? 'Masuk' : 'Keluar'} berhasil diunggah`);
      };
      reader.readAsDataURL(file);
    }
  };

  // Reset form matching script
  const handleResetForm = () => {
    if (currentUser && currentUser.role !== 'Admin') {
      applySessionIdentityToForm(currentUser);
    } else {
      setNama('');
      setNip('');
      setGolRuang('');
      setJabatan('');
      setStatusPegawai('ASN');
    }
    setTanggal(new Date().toISOString().split('T')[0]);
    setStatusKehadiran('Hadir (H)');
    setCatatan('');
    setFotoMasuk(defaultFotoMasuk);
    setFotoKeluar(defaultFotoKeluar);
    if (fileInputMasukRef.current) fileInputMasukRef.current.value = '';
    if (fileInputKeluarRef.current) fileInputKeluarRef.current.value = '';
    window.scrollTo({ top: 0, behavior: 'smooth' });
    showToast('Formulir berhasil direset');
  };

  // Populate sample data for instant testing
  const handleLoadSampleData = () => {
    const today = new Date().toISOString().split('T')[0];
    const sampleNama = 'Dra. Hj. Siti Rahmawati, M.Pd.';
    setNama(sampleNama);
    setNip('19780825 200501 2 006');
    setGolRuang('Pembina / IV/a');
    setJabatan('Guru Bahasa Indonesia & Wali Kelas');
    setStatusPegawai('ASN');
    setTanggal(today);
    setStatusKehadiran('Hadir (H)');
    setCatatan('Masuk dan Pulang Seperti Biasa.');
    setFotoMasuk(createSampleTeacherPhoto(sampleNama, 'masuk', 'Masuk'));
    setFotoKeluar(createSampleTeacherPhoto(sampleNama, 'keluar', 'Pulang'));
    showToast('Contoh data guru berhasil dimuat');
  };

  // Generate Attendance Document
  const handleGenerateDocument = () => {
    if (!nama.trim()) {
      alert('Nama Lengkap tidak boleh kosong.');
      return;
    }

    const newRecord: AttendanceRecord = {
      id: `DOC_${Date.now()}`,
      nama: nama.trim(),
      nip: nip.trim(),
      golRuang: golRuang.trim(),
      jabatan: jabatan.trim(),
      statusPegawai,
      tanggal,
      statusKehadiran,
      catatan: catatan.trim(),
      fotoMasuk,
      fotoKeluar,
      createdAt: Date.now(),
      ownerUserId: currentUser?.id,
      ownerUsername: currentUser?.username,
    };

    setActiveRecord(newRecord);
    setHasDownloadedActiveCard(false);
    setCurrentPage('result');
    window.scrollTo({ top: 0, behavior: 'smooth' });

    // Celebration confetti
    try {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.7 },
      });
    } catch {
      // Ignore if confetti fails
    }
  };

  // Save current record to localStorage + server sync
  const handleSaveToHistory = async () => {
    if (!activeRecord) return;
    const compressedMasuk = await compressPhotoDataUrl(activeRecord.fotoMasuk);
    const compressedKeluar = await compressPhotoDataUrl(activeRecord.fotoKeluar);
    const recordToSave: AttendanceRecord = {
      ...activeRecord,
      fotoMasuk: compressedMasuk,
      fotoKeluar: compressedKeluar,
      ownerUserId: activeRecord.ownerUserId || currentUser?.id,
      ownerUsername: activeRecord.ownerUsername || currentUser?.username,
    };
    const updated = saveRecord(recordToSave, recordsRef.current);
    recordsRef.current = updated;
    setRecords(updated);
    setActiveRecord(recordToSave);
    await pushSyncMutation({ type: 'save_record', payload: recordToSave });
    showToast('Kartu absensi berhasil disimpan ke Riwayat');
  };

  // Guard opening Kop Instansi modal while Kunci Data Admin is active
  const handleOpenKopSettings = () => {
    if (isAdminDataLockedNow(lockConfigRef.current)) {
      showToast('Kunci Data Admin sedang aktif. Nonaktifkan Kunci Data Admin terlebih dahulu untuk mengubah Kop Instansi.');
      return;
    }
    setIsSettingsOpen(true);
  };

  // Save updated settings to localStorage + server sync
  const handleSaveSettings = async (newSettings: AppSettings) => {
    if (isAdminDataLockedNow(lockConfigRef.current)) {
      showToast('Kunci Data Admin sedang aktif. Buka Kunci Data Admin terlebih dahulu untuk mengubah Kop Instansi.');
      return;
    }
    setSettings(newSettings);
    saveStoredSettings(newSettings);
    await pushSyncMutation({ type: 'save_settings', payload: newSettings });
    showToast('Pengaturan Kop Instansi berhasil disimpan');
  };

  // Download card as high-res PNG (Direct Canvas Rendering & Automatic PC Download)
  const handleDownloadAsImage = async () => {
    if (!activeRecord) return;
    setIsDownloading(true);

    const cleanName = (activeRecord.nama || 'PEGAWAI')
      .replace(/\s+/g, '_')
      .replace(/[^A-Za-z0-9_]/g, '')
      .toUpperCase();
    const dateStr = activeRecord.tanggal || 'TANGGAL';
    const filename = `KARTU_ABSENSI_${cleanName}_${dateStr}.png`;
    setDownloadFilename(filename);

    try {
      // 1. Render card directly to high-res PNG Blob via Native Canvas 2D
      let blob = await renderAttendanceCardToBlob(activeRecord, settings);

      // 2. Fallback to html2canvas if needed
      if (!blob && printableAreaRef.current) {
        const canvas = await html2canvas(printableAreaRef.current, {
          scale: 2,
          useCORS: true,
          allowTaint: true,
          backgroundColor: '#ffffff',
          logging: false,
        });
        blob = await new Promise((resolve) => canvas.toBlob(resolve, 'image/png'));
      }

      if (blob) {
        // Trigger automatic download directly into PC/Laptop's Downloads folder
        triggerBrowserDownload(blob, filename);

        // Also set preview URL so user can view or save manually if needed
        const objectUrl = URL.createObjectURL(blob);
        setDownloadPreviewUrl(objectUrl);
        setHasDownloadedActiveCard(true);

        showToast(`Kartu berhasil diunduh ke folder Unduhan: ${filename}`);
      } else {
        throw new Error('Gagal menghasilkan file gambar.');
      }
    } catch (err: any) {
      console.error('Download error:', err);
      // Fallback preview
      if (printableAreaRef.current) {
        try {
          const canvas = await html2canvas(printableAreaRef.current, { scale: 2 });
          setDownloadPreviewUrl(canvas.toDataURL('image/png'));
        } catch {
          // ignore
        }
      }
      alert('Gagal mengunduh otomatis. Silakan klik tombol Simpan pada jendela pratinjau.');
    } finally {
      setIsDownloading(false);
    }
  };

  // Open photo from history
  const handleSelectHistoryRecord = (rec: AttendanceRecord) => {
    setActiveRecord(rec);
    setNama(rec.nama);
    setNip(rec.nip);
    setGolRuang(rec.golRuang || '');
    setJabatan(rec.jabatan || '');
    setStatusPegawai(rec.statusPegawai);
    setTanggal(rec.tanggal);
    setStatusKehadiran(rec.statusKehadiran);
    setCatatan(rec.catatan);
    setFotoMasuk(rec.fotoMasuk);
    setFotoKeluar(rec.fotoKeluar);
    setHasDownloadedActiveCard(false);
    setCurrentPage('result');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDeleteHistoryRecord = async (id: string) => {
    if (isHistoryLockedNow(lockConfigRef.current)) {
      showToast(
        'Riwayat absensi sedang dikunci oleh Admin. Nonaktifkan Kunci Riwayat terlebih dahulu untuk menghapus.'
      );
      return;
    }
    const updated = deleteRecord(id, recordsRef.current);
    recordsRef.current = updated;
    setRecords(updated);
    await pushSyncMutation({ type: 'delete_record', id });
    showToast('Kartu absensi dihapus dari riwayat');
  };

  const navigateToHomeSection = (sectionId?: string) => {
    setCurrentPage('home');
    setTimeout(() => {
      if (sectionId) {
        const el = document.getElementById(sectionId);
        if (el) {
          el.scrollIntoView({ behavior: 'smooth', block: 'start' });
          return;
        }
      }
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }, 40);
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col justify-between">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-5 right-5 z-50 flex items-center gap-2 rounded-xl bg-slate-900 px-4 py-3 text-xs sm:text-sm font-semibold text-white shadow-2xl border border-slate-700 animate-slideDown">
          <CheckCircle2 className="h-4 w-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Bar Contract (Visible across application) */}
      <header className="no-print sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-8">
          {/* Zone 1: Brand Wordmark */}
          <button
            type="button"
            onClick={() => navigateToHomeSection()}
            className="flex items-center gap-2.5 cursor-pointer select-none whitespace-nowrap shrink-0 group text-left"
          >
            <div className="h-9 w-9 rounded-xl bg-indigo-700 flex items-center justify-center text-white group-hover:bg-indigo-800 transition-colors">
              <Camera className="h-5 w-5" />
            </div>
            <span className="text-lg font-extrabold tracking-tight text-slate-900 group-hover:text-indigo-700 transition-colors">
              LensaHadir
            </span>
          </button>

          {/* Zone 2: Navigation Links */}
          <nav className="hidden md:flex items-center gap-4 lg:gap-5 text-xs lg:text-[13px] font-medium text-slate-600">
            {isLoggedIn ? (
              <>
                <button
                  onClick={() => navigateToHomeSection()}
                  className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
                    currentPage === 'home' ? 'text-indigo-700 font-bold' : ''
                  }`}
                >
                  <Home className="h-3.5 w-3.5 text-slate-400" />
                  Home
                </button>
                <button
                  onClick={() => setCurrentPage('dashboard')}
                  className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
                    currentPage === 'dashboard' ? 'text-indigo-700 font-bold' : ''
                  }`}
                >
                  <LayoutDashboard className="h-3.5 w-3.5 text-slate-400" />
                  Dashboard
                  {isAdmin && pendingRecoveryCount > 0 && (
                    <span className="px-1.5 py-0.5 rounded-md bg-rose-600 text-white text-[10px] font-black leading-none">
                      {pendingRecoveryCount}
                    </span>
                  )}
                </button>
                <button
                  onClick={() => setCurrentPage('form')}
                  className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 ${
                    currentPage === 'form' || currentPage === 'result'
                      ? 'text-indigo-700 font-bold'
                      : ''
                  }`}
                >
                  Form Absensi
                </button>
                {isAdmin && (
                  <>
                    <button
                      onClick={() => setCurrentPage('report')}
                      className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
                        currentPage === 'report' ? 'text-indigo-700 font-bold' : ''
                      }`}
                    >
                      <FileSpreadsheet className="h-3.5 w-3.5 text-slate-400" />
                      Laporan Disiplin
                    </button>
                    <button
                      onClick={() => setCurrentPage('monthly')}
                      className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
                        currentPage === 'monthly' ? 'text-indigo-700 font-bold' : ''
                      }`}
                    >
                      <BarChart3 className="h-3.5 w-3.5 text-slate-400" />
                      Rekap Bulanan
                    </button>
                  </>
                )}
                {isPimpinan && (
                  <button
                    onClick={() => setCurrentPage('statistics')}
                    className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
                      currentPage === 'statistics' ? 'text-indigo-700 font-bold' : ''
                    }`}
                  >
                    <BarChart3 className="h-3.5 w-3.5 text-slate-400" />
                    Statistik Absensi
                  </button>
                )}
                <button
                  onClick={() => setIsHistoryOpen(true)}
                  className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 cursor-pointer"
                >
                  <History className="h-3.5 w-3.5 text-slate-400" />
                  Riwayat ({visibleRecords.length})
                  {isHistoryLockedNow(lockConfig) && (
                    <Lock
                      className="h-3 w-3 text-amber-600"
                      aria-label="Riwayat terkunci"
                    />
                  )}
                </button>
                {!isAdmin && (
                  <button
                    onClick={() => setIsProfileModalOpen(true)}
                    className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5"
                  >
                    <UserCog className="h-3.5 w-3.5 text-slate-400" />
                    Pengaturan Data Diri
                  </button>
                )}
                {isAdmin && (
                  <button
                    onClick={handleOpenKopSettings}
                    className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5"
                    title={
                      isAdminDataLockedNow(lockConfig)
                        ? 'Terkunci oleh Kunci Data Admin'
                        : 'Pengaturan Kop Instansi'
                    }
                  >
                    <Settings className="h-3.5 w-3.5 text-slate-400" />
                    Kop Instansi
                    {isAdminDataLockedNow(lockConfig) && (
                      <Lock
                        className="h-3 w-3 text-amber-600"
                        aria-label="Data Admin terkunci"
                      />
                    )}
                  </button>
                )}
              </>
            ) : (
              <>
                <button
                  onClick={() => navigateToHomeSection('tentang')}
                  className={`hover:text-slate-900 hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0 ${
                    currentPage === 'home' ? 'text-slate-900 font-semibold' : ''
                  }`}
                >
                  Beranda
                </button>
                <button
                  onClick={() => navigateToHomeSection('regulasi')}
                  className="hover:text-slate-900 hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0"
                >
                  Dasar Regulasi
                </button>
                <button
                  onClick={() => navigateToHomeSection('fitur')}
                  className="hover:text-slate-900 hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0"
                >
                  Fitur
                </button>
                <button
                  onClick={() => navigateToHomeSection('pembuat')}
                  className="hover:text-slate-900 hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0"
                >
                  Pembuat
                </button>
              </>
            )}
          </nav>

          {/* Zone 3: Primary Action */}
          <div className="flex items-center gap-2 shrink-0">
            {isLoggedIn && currentUser ? (
              <>
                <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-100 border border-slate-200 text-[11px] font-bold text-slate-700">
                  {currentUser.role === 'Admin' ? (
                    <Shield className="h-3.5 w-3.5 text-indigo-600" />
                  ) : currentUser.role === 'Pimpinan' ? (
                    <Briefcase className="h-3.5 w-3.5 text-amber-600" />
                  ) : (
                    <User className="h-3.5 w-3.5 text-emerald-600" />
                  )}
                  <span className="max-w-[110px] truncate">{currentUser.role}</span>
                </div>
                <button
                  onClick={handleLogout}
                  className="flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-rose-700 bg-rose-50 hover:bg-rose-100 rounded-xl transition-colors whitespace-nowrap shrink-0"
                  title="Keluar dari sesi"
                >
                  <LogOut className="h-3.5 w-3.5" />
                  <span className="hidden sm:inline">Keluar</span>
                </button>
              </>
            ) : (
              <button
                onClick={() => setCurrentPage('login')}
                className="flex items-center gap-2 px-4 py-2 text-xs font-bold text-white bg-indigo-700 hover:bg-indigo-800 rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Lock className="h-3.5 w-3.5" />
                Masuk Login
              </button>
            )}
          </div>
        </div>

        {/* Compact Mobile Navigation Strip (visible on < md when logged in) */}
        {isLoggedIn && (
          <div className="md:hidden border-t border-slate-100 bg-slate-50/90 px-3 py-2 flex items-center gap-1.5 overflow-x-auto">
            <button
              onClick={() => navigateToHomeSection()}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap shrink-0 flex items-center gap-1 transition ${
                currentPage === 'home'
                  ? 'bg-indigo-600 text-white'
                  : 'bg-white text-slate-600 border border-slate-200'
              }`}
            >
              <Home className="h-3.5 w-3.5" />
              Home
            </button>
            <button
              onClick={() => setCurrentPage('dashboard')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap shrink-0 flex items-center gap-1 transition ${
                currentPage === 'dashboard'
                  ? 'bg-indigo-600 text-white'
                  : 'bg-white text-slate-600 border border-slate-200'
              }`}
            >
              <LayoutDashboard className="h-3.5 w-3.5" />
              Dashboard
              {isAdmin && pendingRecoveryCount > 0 && (
                <span className="ml-0.5 px-1.5 py-0.2 rounded bg-rose-600 text-white text-[10px] font-black">
                  {pendingRecoveryCount}
                </span>
              )}
            </button>
            <button
              onClick={() => setCurrentPage('form')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap shrink-0 transition ${
                currentPage === 'form' || currentPage === 'result'
                  ? 'bg-indigo-600 text-white'
                  : 'bg-white text-slate-600 border border-slate-200'
              }`}
            >
              Form Absensi
            </button>
            {isAdmin && (
              <>
                <button
                  onClick={() => setCurrentPage('report')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap shrink-0 flex items-center gap-1 transition ${
                    currentPage === 'report'
                      ? 'bg-indigo-600 text-white'
                      : 'bg-white text-slate-600 border border-slate-200'
                  }`}
                >
                  <FileSpreadsheet className="h-3.5 w-3.5" />
                  Laporan Disiplin
                </button>
                <button
                  onClick={() => setCurrentPage('monthly')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap shrink-0 flex items-center gap-1 transition ${
                    currentPage === 'monthly'
                      ? 'bg-indigo-600 text-white'
                      : 'bg-white text-slate-600 border border-slate-200'
                  }`}
                >
                  <BarChart3 className="h-3.5 w-3.5" />
                  Rekap Bulanan
                </button>
              </>
            )}
            {isPimpinan && (
              <button
                onClick={() => setCurrentPage('statistics')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap shrink-0 flex items-center gap-1 transition ${
                  currentPage === 'statistics'
                    ? 'bg-indigo-600 text-white'
                    : 'bg-white text-slate-600 border border-slate-200'
                }`}
              >
                <BarChart3 className="h-3.5 w-3.5" />
                Statistik Absensi
              </button>
            )}
            <button
              onClick={() => setIsHistoryOpen(true)}
              className="px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap shrink-0 bg-white text-slate-600 border border-slate-200 flex items-center gap-1"
            >
              <History className="h-3.5 w-3.5" />
              Riwayat ({visibleRecords.length})
            </button>
            {!isAdmin && (
              <button
                onClick={() => setIsProfileModalOpen(true)}
                className="px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap shrink-0 bg-white text-slate-600 border border-slate-200 flex items-center gap-1"
              >
                <UserCog className="h-3.5 w-3.5" />
                Pengaturan Data Diri
              </button>
            )}
            {isAdmin && (
              <button
                onClick={handleOpenKopSettings}
                className="px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap shrink-0 bg-white text-slate-600 border border-slate-200 flex items-center gap-1"
              >
                <Settings className="h-3.5 w-3.5" />
                Kop Instansi
                {isAdminDataLockedNow(lockConfig) && (
                  <Lock className="h-3 w-3 text-amber-600" aria-label="Data Admin terkunci" />
                )}
              </button>
            )}
          </div>
        )}
      </header>

      {/* Main Container */}
      <main className="flex-1 w-full max-w-6xl mx-auto px-4 sm:px-6 py-6 sm:py-10">
        {/* ========================================================= */}
        {/* HALAMAN 1: HOME (Beranda Informasi Aplikasi & Regulasi)   */}
        {/* ========================================================= */}
        {currentPage === 'home' && (
          <HomePage
            settings={settings}
            isLoggedIn={isLoggedIn}
            canViewRecentHistory={isAdmin || isPimpinan}
            recordsCount={records.length}
            onGoToLogin={() => {
              setCurrentPage('login');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onGoToDashboard={() => {
              setCurrentPage('dashboard');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onOpenHistory={() => setIsHistoryOpen(true)}
            onOpenHelp={() => setIsHelpModalOpen(true)}
          />
        )}

        {/* ========================================================= */}
        {/* HALAMAN 2: LOGIN SISTEM (LANGSUNG & SIMPEL) */}
        {/* ========================================================= */}
        {currentPage === 'login' && (
          <div className="max-w-md mx-auto bg-white shadow-2xl rounded-3xl p-8 border border-slate-200 animate-fadeIn">
            <div className="text-center mb-6">
              <div className="inline-flex p-3 rounded-2xl bg-indigo-50 text-indigo-600 mb-3">
                <Lock className="h-7 w-7" />
              </div>
              <h2 className="text-2xl font-black text-indigo-800 uppercase tracking-wide">
                Login Sistem
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Portal Absensi Digital LensaHadir • Admin, Pimpinan &amp; Pegawai
              </p>
            </div>

            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label
                  className={`block text-xs font-bold mb-1.5 ${
                    loginErrorMsg ? 'text-rose-600' : 'text-slate-700'
                  }`}
                >
                  Username
                </label>
                <input
                  type="text"
                  value={loginUser}
                  onChange={(e) => {
                    setLoginUser(e.target.value);
                    setLoginErrorMsg('');
                  }}
                  className={`w-full p-3.5 rounded-xl outline-none text-sm font-medium transition ${
                    loginErrorMsg
                      ? 'border-2 border-rose-500 bg-rose-50/50 text-rose-900 focus:ring-2 focus:ring-rose-500 focus:border-rose-500'
                      : 'border border-slate-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500'
                  }`}
                  placeholder="Masukkan username Anda"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label
                    className={`block text-xs font-bold ${
                      loginErrorMsg ? 'text-rose-600' : 'text-slate-700'
                    }`}
                  >
                    Password
                  </label>
                  <button
                    type="button"
                    onClick={() => setIsForgotModalOpen(true)}
                    className="text-[11px] font-bold text-indigo-600 hover:text-indigo-800 hover:underline flex items-center gap-1"
                  >
                    <KeyRound className="h-3 w-3" />
                    Lupa Username / Password?
                  </button>
                </div>
                <input
                  type="password"
                  value={loginPass}
                  onChange={(e) => {
                    setLoginPass(e.target.value);
                    setLoginErrorMsg('');
                  }}
                  className={`w-full p-3.5 rounded-xl outline-none text-sm font-medium transition ${
                    loginErrorMsg
                      ? 'border-2 border-rose-500 bg-rose-50/50 text-rose-900 focus:ring-2 focus:ring-rose-500 focus:border-rose-500'
                      : 'border border-slate-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500'
                  }`}
                  placeholder="Masukkan password Anda"
                />
              </div>

              {loginErrorMsg && (
                <div className="p-3 rounded-xl bg-rose-600 text-white text-xs font-bold text-center shadow-sm">
                  {loginErrorMsg}
                </div>
              )}

              <button
                type="submit"
                className={`w-full py-4 rounded-xl font-black text-sm uppercase tracking-wider shadow-lg transition transform active:scale-98 cursor-pointer ${
                  loginErrorMsg
                    ? 'bg-rose-600 hover:bg-rose-700 text-white shadow-rose-600/30'
                    : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-indigo-600/30'
                }`}
              >
                MASUK SEKARANG
              </button>

              {/* Belum punya akun -> Daftar / Registrasi (Khusus Role Admin 1 Sekolah / Dinas) */}
              <div className="pt-4 mt-2 border-t border-slate-200 space-y-2.5">
                <div className="text-center">
                  <p className="text-xs font-bold text-slate-700">
                    Belum punya akun Administrator Sekolah / Dinas?
                  </p>
                  <p className="text-[11px] text-slate-500 mt-0.5 leading-relaxed">
                    Registrasi hanya untuk <b>Role Admin (1 Sekolah / Lembaga / Satuan Dinas)</b>.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    setCurrentPage('register');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black uppercase tracking-wide flex items-center justify-center gap-2 shadow-sm transition cursor-pointer"
                >
                  <ShieldCheck className="h-4 w-4" />
                  Daftar / Registrasi Admin
                </button>

                <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-[11px] text-slate-600 leading-relaxed">
                  <b className="text-slate-800">Pengguna selain Admin (Guru/Pegawai &amp; Pimpinan):</b>{' '}
                  Masuk langsung menggunakan Username &amp; Password dari Admin instansi Anda. Apabila lupa akun, gunakan menu{' '}
                  <button
                    type="button"
                    onClick={() => setIsForgotModalOpen(true)}
                    className="font-bold text-indigo-700 hover:underline cursor-pointer"
                  >
                    Lupa Username / Password?
                  </button>
                  .
                </div>
              </div>
            </form>
          </div>
        )}

        {/* ========================================================= */}
        {/* HALAMAN 2A: FORMULIR DAFTAR / REGISTRASI ADMIN            */}
        {/* ========================================================= */}
        {currentPage === 'register' && (
          <AdminRegisterPage
            onBackToLogin={() => {
              setCurrentPage('login');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onSubmitRegistration={handleAddAdminRegistration}
            showToast={showToast}
          />
        )}

        {/* ========================================================= */}
        {/* HALAMAN 2B: DASHBOARD KHUSUS ADMIN (Tambah Pengguna)      */}
        {/* ========================================================= */}
        {currentPage === 'dashboard' && isAdmin && (
          <AdminDashboard
            settings={settings}
            adminProfile={adminProfile}
            users={users}
            adminContact={adminContact}
            recoveryNotifications={recoveryNotifications}
            adminSubmissions={adminSubmissions}
            adminRegistrations={adminRegistrations}
            recordsCount={records.length}
            onSaveUser={handleSaveUser}
            onDeleteUser={handleDeleteUser}
            onSaveAdminContact={handleSaveAdminContact}
            onMarkNotificationDone={handleMarkNotificationDone}
            onDeleteNotification={handleDeleteNotification}
            onMarkRegistrationContacted={handleMarkRegistrationContacted}
            onDeleteRegistration={handleDeleteRegistration}
            onOpenSubmissionCard={handleOpenSubmissionCard}
            onDeleteSubmission={handleDeleteSubmission}
            onImportSubmissionsToMonthly={handleImportSubmissionsToMonthly}
            onNavigate={(page) => setCurrentPage(page)}
            onOpenSettings={() => setIsSettingsOpen(true)}
            onOpenAdminProfile={() => setIsAdminProfileOpen(true)}
            onOpenHelp={() => setIsHelpModalOpen(true)}
            showToast={showToast}
            lockConfig={lockConfig}
            onToggleAdminDataLock={handleToggleAdminDataLock}
            onActivateAllUsersForAllDevices={handleActivateAllUsersForAllDevices}
            onUpdateSubmissionsLock={handleUpdateSubmissionsLock}
            onUpdateHistoryLock={handleUpdateHistoryLock}
            onExportBackup={handleExportBackup}
            onImportBackup={handleImportBackup}
            isSyncingData={isSyncingData}
          />
        )}

        {/* ========================================================= */}
        {/* HALAMAN 2C: DASHBOARD AKUN PENGGUNA (Guru/Pegawai & Pimpinan) */}
        {/* ========================================================= */}
        {currentPage === 'dashboard' && !isAdmin && currentUser && (
          <UserDashboard
            currentUser={currentUser}
            managedUser={currentManagedUser}
            settings={settings}
            records={visibleRecords}
            submittedRecordIds={submittedRecordIds}
            isPimpinan={isPimpinan}
            isGuruPegawai={isGuruPegawai}
            onNavigate={(page) => setCurrentPage(page)}
            onOpenHistory={() => setIsHistoryOpen(true)}
            onOpenProfile={() => setIsProfileModalOpen(true)}
            onOpenHelp={() => setIsHelpModalOpen(true)}
            onSelectRecord={handleSelectHistoryRecord}
          />
        )}

        {/* ========================================================= */}
        {/* HALAMAN 2D: STATISTIK ABSENSI KHUSUS PIMPINAN             */}
        {/* ========================================================= */}
        {currentPage === 'statistics' && isPimpinan && (
          <LeaderStatisticsPage
            settings={settings}
            records={records}
            adminSubmissions={adminSubmissions}
            onSelectRecord={handleSelectHistoryRecord}
            onGoToForm={() => setCurrentPage('form')}
          />
        )}

        {/* ========================================================= */}
        {/* HALAMAN 3: FORM INPUT ABSENSI                             */}
        {/* ========================================================= */}
        {currentPage === 'form' && (
          <div className="max-w-5xl mx-auto bg-white shadow-xl rounded-2xl overflow-hidden border border-slate-200 animate-fadeIn">
            {/* Header Banner */}
            <div className="bg-indigo-800 p-5 text-white flex flex-col sm:flex-row justify-between items-center gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-white/10 rounded-lg">
                  <FileText className="h-5 w-5 text-indigo-200" />
                </div>
                <div>
                  <h1 className="text-base sm:text-lg font-black uppercase tracking-tight">
                    Form Absensi Guru / Pegawai
                  </h1>
                  <p className="text-xs text-indigo-200">
                    {settings.subInstansi || settings.namaInstansi}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {!isAdmin ? (
                  <button
                    type="button"
                    onClick={() => setIsProfileModalOpen(true)}
                    className="bg-white/15 hover:bg-white/25 text-white px-3.5 py-2 rounded-lg flex items-center gap-1.5 text-xs font-bold transition"
                    title="Perbarui data identitas diri Anda"
                  >
                    <UserCog className="h-4 w-4 text-emerald-300" />
                    Pengaturan Data Diri
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={handleLoadSampleData}
                    className="bg-white/10 hover:bg-white/20 text-white px-3 py-1.5 rounded-lg flex items-center gap-1.5 text-xs font-bold transition"
                    title="Isi form dengan data contoh untuk uji coba instan"
                  >
                    <Sparkles className="h-3.5 w-3.5 text-amber-300" />
                    Isi Contoh Cepat
                  </button>
                )}
                {isAdmin && (
                  <button
                    type="button"
                    onClick={() => setIsSettingsOpen(true)}
                    className="bg-white/10 hover:bg-white/20 text-white p-2 rounded-lg transition"
                    title="Pengaturan Kop Instansi"
                  >
                    <Settings className="h-4 w-4" />
                  </button>
                )}
              </div>
            </div>

            {/* Konten Form Input */}
            <div className="p-6 sm:p-8 space-y-6">
              {/* Data Pegawai Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 flex items-center gap-1">
                    <User className="h-3.5 w-3.5 text-indigo-600" />
                    Nama Lengkap <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={nama}
                    onChange={(e) => setNama(e.target.value)}
                    className="block w-full rounded-xl border border-slate-300 p-3 text-base font-semibold text-slate-900 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
                    placeholder="Nama Guru / Pegawai"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700">
                    NIP / ID Pegawai (Opsional)
                  </label>
                  <input
                    type="text"
                    value={nip}
                    onChange={(e) => setNip(e.target.value)}
                    className="block w-full rounded-xl border border-slate-300 p-3 text-base font-mono text-slate-900 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
                    placeholder="Nomor Induk Pegawai"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700">
                    Gol. Ruang
                  </label>
                  <input
                    type="text"
                    value={golRuang}
                    onChange={(e) => setGolRuang(e.target.value)}
                    className="block w-full rounded-xl border border-slate-300 p-3 text-base font-semibold text-slate-900 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
                    placeholder="Isi Gol. Ruang (contoh: IV/a, III/b, dll.)"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700">Status Pegawai</label>
                  <select
                    value={statusPegawai}
                    onChange={(e) => setStatusPegawai(e.target.value as StatusPegawai)}
                    className="block w-full rounded-xl border border-slate-300 p-3 text-base font-bold bg-white text-slate-800 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
                  >
                    <option value="ASN">ASN (PNS)</option>
                    <option value="PPPK">PPPK</option>
                    <option value="PPPK Paruh Waktu">PPPK Paruh Waktu</option>
                    <option value="Honor/GTT">Honor/GTT</option>
                    <option value="Tenaga Kontrak">Tenaga Kontrak</option>
                    <option value="Penjaga Sekolah">Penjaga Sekolah</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700">
                    Jabatan / Unit Tugas (Opsional)
                  </label>
                  <input
                    type="text"
                    value={jabatan}
                    onChange={(e) => setJabatan(e.target.value)}
                    className="block w-full rounded-xl border border-slate-300 p-3 text-base text-slate-900 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
                    placeholder="Contoh: Guru Kelas / Wali Kelas"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700">Hari / Tanggal</label>
                  <input
                    type="date"
                    value={tanggal}
                    onChange={(e) => setTanggal(e.target.value)}
                    className="block w-full rounded-xl border border-slate-300 p-3 text-base font-medium text-slate-800 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700">Status Kehadiran</label>
                  <select
                    value={statusKehadiran}
                    onChange={(e) => setStatusKehadiran(e.target.value as StatusKehadiran)}
                    className="block w-full rounded-xl border border-slate-300 p-3 text-base font-extrabold text-indigo-700 bg-white focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
                  >
                    <option value="Hadir (H)">Hadir (H)</option>
                    <option value="Ijin (I)">Ijin (I)</option>
                    <option value="Sakit (S)">Sakit (S)</option>
                    <option value="Cuti (C)">Cuti (C)</option>
                    <option value="Tugas Dinas (TD)">Tugas Dinas (TD)</option>
                    <option value="Tanpa Berita (TB)">Tanpa Berita (TB)</option>
                    <option value="Tugas Belajar (TS)">Tugas Belajar (TS)</option>
                  </select>
                </div>

                <div className="space-y-1.5 md:col-span-2 lg:col-span-2">
                  <label className="text-xs font-bold text-slate-700">Keterangan / Catatan Tambahan</label>
                  <input
                    type="text"
                    value={catatan}
                    onChange={(e) => setCatatan(e.target.value)}
                    placeholder="Contoh: Masuk dan Pulang Seperti Biasa, atau keterangan tugas/izin/sakit..."
                    className="block w-full rounded-xl border border-slate-300 p-3 text-base text-slate-800 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
                  />
                </div>
              </div>

              {/* Unggah & Ambil Foto Masuk & Pulang */}
              <div className="pt-6 border-t border-slate-200">
                <div className="mb-4 text-center">
                  <h3 className="text-sm font-black text-slate-900 uppercase tracking-wider">
                    Upload Foto TimeMark
                  </h3>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {/* Foto Masuk */}
                  <div className="space-y-3 bg-slate-50 p-4 rounded-2xl border border-slate-200">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-black text-indigo-900 uppercase tracking-wide flex items-center gap-1.5">
                        <div className="h-2 w-2 rounded-full bg-blue-600" />
                        Foto Masuk
                      </label>
                      {fotoMasuk !== defaultFotoMasuk && (
                        <button
                          type="button"
                          onClick={() => setFotoMasuk(defaultFotoMasuk)}
                          className="text-[10px] font-bold text-rose-600 hover:underline"
                        >
                          Hapus Foto
                        </button>
                      )}
                    </div>

                    <div 
                      onClick={() => fileInputMasukRef.current?.click()}
                      className="overflow-hidden rounded-xl border-2 border-dashed border-slate-300 hover:border-indigo-400 bg-white relative aspect-[3/4] cursor-pointer group transition-colors"
                      title="Klik untuk memilih foto dari galeri/perangkat"
                    >
                      <img
                        src={fotoMasuk}
                        alt="Preview Foto Masuk"
                        className="w-full h-full object-cover group-hover:opacity-95 transition-opacity"
                      />
                      <div className="absolute inset-0 bg-indigo-900/10 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
                        <span className="bg-slate-900/75 text-white text-[11px] font-bold px-3 py-1.5 rounded-lg flex items-center gap-1.5">
                          <Upload className="h-3.5 w-3.5" />
                          Ganti Foto
                        </span>
                      </div>
                    </div>

                    <input
                      type="file"
                      accept="image/*"
                      ref={fileInputMasukRef}
                      onChange={(e) => handleFileUpload(e, 'masuk')}
                      className="hidden"
                    />

                    <div className="pt-1">
                      <button
                        type="button"
                        onClick={() => fileInputMasukRef.current?.click()}
                        className="w-full py-2.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-sm transition"
                      >
                        <Upload className="h-4 w-4" />
                        Unggah Foto Masuk (TimeMark)
                      </button>
                    </div>
                  </div>

                  {/* Foto Keluar */}
                  <div className="space-y-3 bg-slate-50 p-4 rounded-2xl border border-slate-200">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-black text-indigo-900 uppercase tracking-wide flex items-center gap-1.5">
                        <div className="h-2 w-2 rounded-full bg-emerald-600" />
                        Foto Keluar / Pulang
                      </label>
                      {fotoKeluar !== defaultFotoKeluar && (
                        <button
                          type="button"
                          onClick={() => setFotoKeluar(defaultFotoKeluar)}
                          className="text-[10px] font-bold text-rose-600 hover:underline"
                        >
                          Hapus Foto
                        </button>
                      )}
                    </div>

                    <div 
                      onClick={() => fileInputKeluarRef.current?.click()}
                      className="overflow-hidden rounded-xl border-2 border-dashed border-slate-300 hover:border-emerald-400 bg-white relative aspect-[3/4] cursor-pointer group transition-colors"
                      title="Klik untuk memilih foto dari galeri/perangkat"
                    >
                      <img
                        src={fotoKeluar}
                        alt="Preview Foto Keluar"
                        className="w-full h-full object-cover group-hover:opacity-95 transition-opacity"
                      />
                      <div className="absolute inset-0 bg-emerald-900/10 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
                        <span className="bg-slate-900/75 text-white text-[11px] font-bold px-3 py-1.5 rounded-lg flex items-center gap-1.5">
                          <Upload className="h-3.5 w-3.5" />
                          Ganti Foto
                        </span>
                      </div>
                    </div>

                    <input
                      type="file"
                      accept="image/*"
                      ref={fileInputKeluarRef}
                      onChange={(e) => handleFileUpload(e, 'keluar')}
                      className="hidden"
                    />

                    <div className="pt-1">
                      <button
                        type="button"
                        onClick={() => fileInputKeluarRef.current?.click()}
                        className="w-full py-2.5 px-4 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-sm transition"
                      >
                        <Upload className="h-4 w-4" />
                        Unggah Foto Pulang (TimeMark)
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Bottom Action Buttons matching script behavior */}
              <div className="pt-6 border-t border-slate-200 flex flex-col sm:flex-row justify-center gap-4">
                <button
                  type="button"
                  onClick={handleResetForm}
                  className="bg-slate-200 hover:bg-slate-300 text-slate-700 px-10 py-4 rounded-full font-black text-base transition-all transform hover:scale-102 active:scale-98 flex items-center justify-center gap-2"
                >
                  <RotateCcw className="h-4 w-4" />
                  RESET FORM
                </button>
                <button
                  type="button"
                  onClick={handleGenerateDocument}
                  className="bg-indigo-600 hover:bg-indigo-700 text-white px-12 py-4 rounded-full font-black text-base shadow-xl shadow-indigo-600/30 transition-all transform hover:scale-102 active:scale-98 flex items-center justify-center gap-2"
                >
                  <Printer className="h-5 w-5" />
                  CETAK KARTU
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================= */}
        {/* HALAMAN 4: HASIL KARTU ABSENSI RESMI (Result Screen)       */}
        {/* ========================================================= */}
        {currentPage === 'result' && activeRecord && (
          <div className="space-y-6 animate-fadeIn">
            {/* Action Bar (no-print) */}
            <div className="no-print p-4 bg-white border border-slate-200 rounded-2xl shadow-sm flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setCurrentPage('form')}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-700 px-4 py-2.5 rounded-xl font-bold text-xs flex items-center gap-1.5 transition"
                >
                  <Edit3 className="h-4 w-4" />
                  Edit Data
                </button>
                <button
                  onClick={() => {
                    handleResetForm();
                    setCurrentPage('form');
                  }}
                  className="text-xs font-semibold text-slate-500 hover:text-slate-800 px-3 py-2 transition"
                >
                  + Buat Baru
                </button>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={handleSaveToHistory}
                  className="bg-slate-800 hover:bg-slate-900 text-white px-4 py-2.5 rounded-xl font-bold text-xs flex items-center gap-1.5 transition shadow-sm"
                  title="Simpan kartu ini ke riwayat lokal"
                >
                  <History className="h-4 w-4 text-amber-400" />
                  Simpan Riwayat
                </button>

                <button
                  onClick={handleDownloadAsImage}
                  disabled={isDownloading}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white px-5 py-2.5 rounded-xl font-bold text-xs flex items-center gap-1.5 transition shadow-sm disabled:opacity-50"
                >
                  <Download className="h-4 w-4" />
                  {isDownloading ? 'Memproses...' : 'Unduh Foto PNG'}
                </button>

                {isGuruPegawai && (
                  <button
                    type="button"
                    onClick={() => handleSendRecordToAdmin(activeRecord)}
                    className={`px-5 py-2.5 rounded-xl font-bold text-xs flex items-center gap-1.5 transition shadow-sm ${
                      isActiveRecordSentToAdmin
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-300 hover:bg-emerald-100'
                        : hasDownloadedActiveCard
                        ? 'bg-indigo-600 hover:bg-indigo-700 text-white ring-2 ring-indigo-300 ring-offset-1'
                        : 'bg-indigo-600 hover:bg-indigo-700 text-white'
                    }`}
                  >
                    {isActiveRecordSentToAdmin ? (
                      <>
                        <CheckCircle2 className="h-4 w-4" />
                        Tersimpan di Admin
                      </>
                    ) : (
                      <>
                        <Send className="h-4 w-4" />
                        Simpan ke Admin
                      </>
                    )}
                  </button>
                )}
              </div>
            </div>

            {/* Post-Download Guided Callout for Guru/Pegawai -> Simpan ke Admin */}
            {isGuruPegawai && hasDownloadedActiveCard && !isActiveRecordSentToAdmin && (
              <div className="no-print p-4 rounded-2xl bg-indigo-50 border-2 border-indigo-300 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 animate-fadeIn">
                <div className="flex items-start gap-3">
                  <div className="p-2 rounded-xl bg-indigo-600 text-white shrink-0">
                    <Send className="h-4 w-4" />
                  </div>
                  <div>
                    <h3 className="text-xs sm:text-sm font-black text-indigo-950">
                      Foto Kartu Berhasil Diunduh — Lanjutkan Simpan ke Admin
                    </h3>
                    <p className="text-[11px] sm:text-xs text-indigo-800/90 mt-0.5">
                      Klik tombol <b>Simpan ke Admin</b> agar data absensi Anda tersimpan otomatis di akun Admin sesuai hari, bulan, dan tahun.
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => handleSendRecordToAdmin(activeRecord)}
                  className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs flex items-center gap-2 shadow-md transition shrink-0"
                >
                  <Send className="h-4 w-4" />
                  Simpan ke Admin
                </button>
              </div>
            )}

            {/* Printable Document Container */}
            <PrintableCard
              ref={printableAreaRef}
              record={activeRecord}
              settings={settings}
            />
          </div>
        )}

        {/* ========================================================= */}
        {/* HALAMAN 5: LAPORAN DISIPLIN JAM KERJA HARIAN (ADMIN ONLY) */}
        {/* ========================================================= */}
        {currentPage === 'report' && isAdmin && (
          <DailyDisciplineReport
            settings={settings}
            records={records}
            adminSubmissions={adminSubmissions}
            items={reportItems}
            setItems={setReportItems}
            reportDate={reportDate}
            setReportDate={setReportDate}
            onOpenSettings={() => setIsSettingsOpen(true)}
            showToast={showToast}
          />
        )}

        {/* ========================================================= */}
        {/* HALAMAN 6: PERHITUNGAN REKAPITULASI ABSENSI PER BULAN     */}
        {/* ========================================================= */}
        {currentPage === 'monthly' && isAdmin && (
          <MonthlyRecapReport
            settings={settings}
            records={records}
            rows={monthlyRows}
            setRows={setMonthlyRows}
            config={monthlyConfig}
            setConfig={setMonthlyConfig}
            onOpenSettings={() => setIsSettingsOpen(true)}
            showToast={showToast}
          />
        )}
      </main>

      {/* Settings Modal (Admin only) */}
      <SettingsModal
        isOpen={isSettingsOpen && isAdmin}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onSave={handleSaveSettings}
      />

      {/* History Drawer */}
      <HistoryDrawer
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        records={visibleRecords}
        onSelectRecord={handleSelectHistoryRecord}
        onDeleteRecord={handleDeleteHistoryRecord}
        isAdmin={isAdmin}
        isGuruPegawai={isGuruPegawai}
        submittedRecordIds={submittedRecordIds}
        onSendToAdmin={handleSendRecordToAdmin}
        onSendAllToAdmin={handleSendAllRecordsToAdmin}
        lockConfig={lockConfig}
        onUpdateHistoryLock={handleUpdateHistoryLock}
      />

      {/* User Self-Profile Modal ("Pengaturan Data Diri" untuk pengguna selain Admin) */}
      <UserProfileModal
        isOpen={isProfileModalOpen && !isAdmin}
        onClose={() => setIsProfileModalOpen(false)}
        user={currentManagedUser}
        onSaveProfile={handleSaveSelfProfile}
      />

      {/* Primary Administrator Profile Modal ("Pengaturan Data Admin" — data diri, username & password) */}
      <AdminProfileModal
        isOpen={isAdminProfileOpen && isAdmin}
        onClose={() => setIsAdminProfileOpen(false)}
        adminProfile={adminProfile}
        settings={settings}
        existingUsers={users}
        onSaveAdminProfile={handleSaveAdminProfile}
      />

      {/* Forgot Username / Password Modal (Sends confirmation notice to Admin Dashboard & WA/Email) */}
      <ForgotAccountModal
        isOpen={isForgotModalOpen}
        onClose={() => setIsForgotModalOpen(false)}
        users={users}
        adminContact={adminContact}
        settings={settings}
        onSubmitNotification={handleAddRecoveryNotification}
        showToast={showToast}
      />

      {/* Help Modal — Tanya Admin via WhatsApp Channel + Balasan Otomatis */}
      <HelpModal
        isOpen={isHelpModalOpen}
        onClose={() => setIsHelpModalOpen(false)}
        senderName={currentUser?.nama}
        showToast={showToast}
      />

      {/* Modal Preview & Unduh Foto PNG (Fail-Proof Modal + Tombol Simpan ke Admin) */}
      {downloadPreviewUrl && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-xs animate-fadeIn">
          <div className="relative w-full max-w-4xl overflow-hidden rounded-2xl bg-white shadow-2xl border border-slate-200 flex flex-col max-h-[90vh]">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-slate-100 bg-slate-50 px-5 py-3.5">
              <div className="flex items-center gap-2">
                <div className="rounded-lg bg-emerald-600 p-1.5 text-white">
                  <Download className="h-4 w-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">
                    Foto Kartu Absensi Berhasil Diunduh
                  </h3>
                  <p className="text-[11px] text-slate-500 font-mono">
                    {downloadFilename}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setDownloadPreviewUrl(null)}
                className="rounded-lg p-1 text-slate-400 hover:bg-slate-200 hover:text-slate-700 transition"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Image Preview */}
            <div className="flex-1 overflow-auto p-4 bg-slate-100 flex items-center justify-center">
              <img
                src={downloadPreviewUrl}
                alt="Kartu Absensi PNG"
                className="max-h-[60vh] w-auto rounded-lg shadow-md border border-slate-300 object-contain bg-white"
              />
            </div>

            {/* Modal Actions */}
            <div className="border-t border-slate-200 bg-white p-4 flex flex-col sm:flex-row items-center justify-between gap-3">
              <p className="text-[11px] text-slate-500 text-center sm:text-left">
                {isGuruPegawai
                  ? 'Setelah file PNG terunduh, klik "Simpan ke Admin" agar absensi Anda langsung tersimpan otomatis di akun Admin.'
                  : 'Jika unduhan otomatis tidak berjalan, klik Simpan File PNG atau klik kanan pada gambar lalu pilih Simpan Gambar.'}
              </p>
              <div className="flex flex-wrap items-center justify-center gap-2 shrink-0">
                <a
                  href={downloadPreviewUrl}
                  download={downloadFilename}
                  className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-2 shadow-sm transition"
                >
                  <Download className="h-4 w-4" />
                  Simpan File PNG
                </a>
                {isGuruPegawai && activeRecord && (
                  <button
                    type="button"
                    onClick={() => {
                      handleSendRecordToAdmin(activeRecord);
                      setDownloadPreviewUrl(null);
                    }}
                    className={`px-5 py-2.5 rounded-xl font-black text-xs flex items-center gap-2 shadow-md transition ${
                      isActiveRecordSentToAdmin
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-300 hover:bg-emerald-100'
                        : 'bg-indigo-600 hover:bg-indigo-700 text-white'
                    }`}
                  >
                    {isActiveRecordSentToAdmin ? (
                      <>
                        <CheckCircle2 className="h-4 w-4" />
                        Sudah Tersimpan di Admin
                      </>
                    ) : (
                      <>
                        <Send className="h-4 w-4" />
                        Simpan ke Admin
                      </>
                    )}
                  </button>
                )}
                <button
                  onClick={() => setDownloadPreviewUrl(null)}
                  className="px-4 py-2.5 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-100 font-bold text-xs transition"
                >
                  Tutup
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* App Footer */}
      <footer className="no-print mt-12 border-t border-slate-200 bg-white py-6">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-900">LensaHadir</span>
            <span aria-hidden="true">·</span>
            <span>Sistem Presensi Foto TimeMark &amp; Laporan Disiplin</span>
          </div>
          <div className="text-slate-500">
            © 2026 Dikembangkan oleh <span className="font-semibold text-slate-700">Y. Lomang</span> (Blogger &amp; Penggiat Pendidikan Sekolah)
          </div>
        </div>
      </footer>
    </div>
  );
}
