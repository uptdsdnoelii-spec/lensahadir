import React, { useState, useEffect } from 'react';
import { AppSettings } from '../types/attendance';
import { Settings, Save, X, RotateCcw } from 'lucide-react';
import { defaultSettings } from '../utils/storage';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  onSave: (settings: AppSettings) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onSave,
}) => {
  const [formData, setFormData] = useState<AppSettings>(settings);

  useEffect(() => {
    if (isOpen) {
      setFormData(settings);
    }
  }, [isOpen, settings]);

  if (!isOpen) return null;

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
    onClose();
  };

  const handleResetDefault = () => {
    setFormData(defaultSettings);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
      <div className="relative w-full max-w-xl overflow-hidden rounded-2xl bg-white shadow-2xl border border-slate-200">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 bg-slate-50 px-6 py-4">
          <div className="flex items-center gap-2.5">
            <div className="rounded-lg bg-indigo-600 p-2 text-white">
              <Settings className="h-4 w-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">Pengaturan Kop & Instansi</h2>
              <p className="text-xs text-slate-500">Digunakan otomatis untuk Kop Laporan, Nama Satuan Pendidikan, & Tanda Tangan Kepala Sekolah</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-200 hover:text-slate-700 transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Nama Pemerintah Daerah &amp; Dinas (Kop Baris Atas — bisa 2 baris tekan Enter)
            </label>
            <textarea
              rows={2}
              name="namaInstansi"
              value={formData.namaInstansi}
              onChange={handleChange}
              placeholder={"PEMERINTAH KABUPATEN KUPANG\nDINAS PENDIDIKAN KEPEMUDAAN DAN OLAHRAGA"}
              className="w-full rounded-xl border border-slate-300 p-3 text-sm font-semibold focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none resize-none"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Nama Satuan Pendidikan / Sekolah (Kop Baris 2)
            </label>
            <input
              type="text"
              name="subInstansi"
              value={formData.subInstansi}
              onChange={handleChange}
              placeholder="Contoh: UPTD SD NEGERI OELII"
              className="w-full rounded-xl border border-slate-300 p-3 text-sm font-semibold focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Alamat Instansi / Sekolah
            </label>
            <input
              type="text"
              name="alamatInstansi"
              value={formData.alamatInstansi}
              onChange={handleChange}
              placeholder="Contoh: Jl. Pendidikan No. 45, Kec. Kupang Barat"
              className="w-full rounded-xl border border-slate-300 p-3 text-sm focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Nama Kepala Sekolah / Pimpinan
              </label>
              <input
                type="text"
                name="namaPimpinan"
                value={formData.namaPimpinan}
                onChange={handleChange}
                placeholder="Contoh: Drs. H. Mulyadi, M.Pd."
                className="w-full rounded-xl border border-slate-300 p-3 text-sm focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                NIP Kepala Sekolah / Pimpinan
              </label>
              <input
                type="text"
                name="nipPimpinan"
                value={formData.nipPimpinan}
                onChange={handleChange}
                placeholder="Contoh: 19720514 199802 1 003"
                className="w-full rounded-xl border border-slate-300 p-3 text-sm font-mono focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Jabatan Penandatangan
              </label>
              <input
                type="text"
                name="jabatanPimpinan"
                value={formData.jabatanPimpinan}
                onChange={handleChange}
                placeholder="Contoh: Kepala Sekolah"
                className="w-full rounded-xl border border-slate-300 p-3 text-sm focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Kota / Lokasi Tanda Tangan
              </label>
              <input
                type="text"
                name="kota"
                value={formData.kota}
                onChange={handleChange}
                placeholder="Contoh: Kupang"
                className="w-full rounded-xl border border-slate-300 p-3 text-sm focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
              />
            </div>
          </div>

          {/* Footer Actions */}
          <div className="pt-4 border-t border-slate-200 flex items-center justify-between gap-3">
            <button
              type="button"
              onClick={handleResetDefault}
              className="flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-slate-800 transition"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              Kembalikan Standar
            </button>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 transition"
              >
                Batal
              </button>
              <button
                type="submit"
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-md transition"
              >
                <Save className="h-4 w-4" />
                Simpan Perubahan
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
