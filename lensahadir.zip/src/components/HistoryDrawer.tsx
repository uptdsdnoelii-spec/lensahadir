import React, { useState } from 'react';
import {
  AttendanceRecord,
  DataLockConfig,
  HistoryLockDuration,
} from '../types/attendance';
import { isHistoryLockedNow } from '../utils/storage';
import {
  X,
  Search,
  Calendar,
  Trash2,
  Eye,
  UserCheck,
  Send,
  CheckCircle2,
  Lock,
  LockOpen,
  ShieldCheck,
} from 'lucide-react';

interface HistoryDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  records: AttendanceRecord[];
  onSelectRecord: (record: AttendanceRecord) => void;
  onDeleteRecord: (id: string) => void;
  isAdmin?: boolean;
  isGuruPegawai?: boolean;
  submittedRecordIds?: Set<string>;
  onSendToAdmin?: (record: AttendanceRecord) => void;
  onSendAllToAdmin?: (records: AttendanceRecord[]) => void;
  lockConfig?: DataLockConfig;
  onUpdateHistoryLock?: (months: HistoryLockDuration) => void;
}

const formatLockDate = (ts: number | null | undefined): string => {
  if (!ts) return '';
  try {
    return new Date(ts).toLocaleDateString('id-ID', {
      day: '2-digit',
      month: 'long',
      year: 'numeric',
    });
  } catch {
    return '';
  }
};

export const HistoryDrawer: React.FC<HistoryDrawerProps> = ({
  isOpen,
  onClose,
  records,
  onSelectRecord,
  onDeleteRecord,
  isAdmin = false,
  isGuruPegawai = false,
  submittedRecordIds,
  onSendToAdmin,
  onSendAllToAdmin,
  lockConfig,
  onUpdateHistoryLock,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [showLockMenu, setShowLockMenu] = useState(false);

  if (!isOpen) return null;

  const historyLocked = lockConfig ? isHistoryLockedNow(lockConfig) : false;
  const activeLockMonths = historyLocked ? lockConfig?.historyLockMonths || 0 : 0;
  const lockedUntilLabel = formatLockDate(lockConfig?.historyLockedUntil);

  const isRecordSent = (rec: AttendanceRecord): boolean => {
    return Boolean(rec.sentToAdmin || submittedRecordIds?.has(rec.id));
  };

  const unsentRecords = isGuruPegawai
    ? records.filter((r) => !isRecordSent(r))
    : [];

  const filteredRecords = records.filter((r) => {
    const matchSearch =
      r.nama.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (r.nip && r.nip.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (r.tanggal && r.tanggal.includes(searchTerm));
    const matchStatus = filterStatus === 'all' || r.statusKehadiran === filterStatus;
    return matchSearch && matchStatus;
  });

  const handleSelectHistoryLock = (months: HistoryLockDuration) => {
    if (!onUpdateHistoryLock) return;
    onUpdateHistoryLock(months);
    setConfirmDeleteId(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs animate-fadeIn">
      <div className="relative w-full max-w-4xl overflow-hidden rounded-2xl bg-white shadow-2xl border border-slate-200 flex flex-col max-h-[88vh]">
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between border-b border-slate-100 bg-slate-50 px-6 py-4 gap-3">
          <div className="flex items-center gap-2.5">
            <div className="rounded-lg bg-indigo-600 p-2 text-white">
              <UserCheck className="h-5 w-5" />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-base font-bold text-slate-900">
                  {isGuruPegawai
                    ? 'Riwayat Absensi Saya'
                    : 'Riwayat Kartu Absensi Tersimpan'}
                </h2>
                {historyLocked && (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-100 border border-amber-300 text-amber-900 text-[10px] font-black uppercase">
                    <Lock className="h-3 w-3" />
                    Terkunci {activeLockMonths} Bulan
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-500">
                Total {records.length} kartu absensi tersimpan
                {isGuruPegawai &&
                  ` • ${records.length - unsentRecords.length} tersimpan di Admin`}
                {lockConfig && ` • Masa simpan aktif hingga ${lockConfig.retentionMonths} bulan`}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Tombol Kunci Riwayat (Hak Penuh Admin) */}
            {isAdmin && onUpdateHistoryLock && (
              <button
                type="button"
                onClick={() => setShowLockMenu((prev) => !prev)}
                className={`px-3.5 py-2 rounded-xl text-xs font-black flex items-center gap-1.5 shadow-xs border transition cursor-pointer ${
                  historyLocked
                    ? 'bg-amber-500 hover:bg-amber-600 text-white border-amber-600'
                    : 'bg-slate-900 hover:bg-slate-800 text-white border-slate-900'
                }`}
              >
                {historyLocked ? (
                  <>
                    <Lock className="h-3.5 w-3.5" />
                    Kunci Riwayat ({activeLockMonths} Bln)
                  </>
                ) : (
                  <>
                    <LockOpen className="h-3.5 w-3.5" />
                    Kunci Riwayat
                  </>
                )}
              </button>
            )}

            {isGuruPegawai && onSendAllToAdmin && unsentRecords.length > 0 && (
              <button
                type="button"
                onClick={() => onSendAllToAdmin(unsentRecords)}
                className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-sm transition cursor-pointer"
              >
                <Send className="h-3.5 w-3.5" />
                Simpan Semua ke Admin ({unsentRecords.length})
              </button>
            )}
            <button
              onClick={onClose}
              className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-200 hover:text-slate-700 transition cursor-pointer"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Panel Pengaturan Kunci Riwayat (Khusus Admin: 1 Bulan, 2 Bulan, 3 Bulan, Nonaktifkan Kunci) */}
        {isAdmin && onUpdateHistoryLock && showLockMenu && (
          <div className="px-6 py-4 bg-amber-50/80 border-b border-amber-200 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-start gap-2.5">
                <ShieldCheck className="h-5 w-5 text-amber-700 shrink-0 mt-0.5" />
                <div>
                  <h3 className="text-xs font-black uppercase tracking-wider text-amber-950">
                    Pengaturan Kunci Riwayat Absensi (Hak Penuh Admin)
                  </h3>
                  <p className="text-[11px] text-amber-900/80 mt-0.5 leading-relaxed">
                    Saat kunci diaktifkan, seluruh kartu absensi di riwayat tidak dapat terhapus atau hilang (penambahan kartu baru tetap masuk). Pilih durasi kunci atau nonaktifkan kapan saja:
                  </p>
                </div>
              </div>
              {historyLocked && lockedUntilLabel && (
                <span className="text-[11px] font-bold text-amber-900 bg-white/80 border border-amber-300 px-2.5 py-1 rounded-lg shrink-0">
                  Aktif s.d. {lockedUntilLabel}
                </span>
              )}
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {([1, 2, 3] as const).map((months) => {
                const isActive = historyLocked && activeLockMonths === months;
                return (
                  <button
                    key={months}
                    type="button"
                    onClick={() => handleSelectHistoryLock(months)}
                    className={`px-3.5 py-2 rounded-xl text-xs font-black flex items-center gap-1.5 border transition cursor-pointer ${
                      isActive
                        ? 'bg-amber-600 text-white border-amber-700 shadow-sm'
                        : 'bg-white hover:bg-amber-100 text-amber-950 border-amber-300'
                    }`}
                  >
                    <Lock className="h-3.5 w-3.5" />
                    Kunci {months} Bulan
                  </button>
                );
              })}

              <button
                type="button"
                onClick={() => handleSelectHistoryLock(0)}
                className={`px-3.5 py-2 rounded-xl text-xs font-black flex items-center gap-1.5 border transition cursor-pointer ${
                  !historyLocked
                    ? 'bg-slate-800 text-white border-slate-900 shadow-sm'
                    : 'bg-white hover:bg-rose-50 text-rose-700 border-rose-300'
                }`}
              >
                <LockOpen className="h-3.5 w-3.5" />
                Nonaktifkan Kunci
              </button>
            </div>
          </div>
        )}

        {/* Info Banner Kunci untuk Non-Admin (Guru/Pegawai & Pimpinan) */}
        {!isAdmin && historyLocked && (
          <div className="px-6 py-2.5 bg-amber-50 border-b border-amber-200 flex items-center gap-2 text-xs text-amber-900">
            <Lock className="h-4 w-4 text-amber-700 shrink-0" />
            <span>
              <b>Riwayat Terkunci oleh Admin ({activeLockMonths} Bulan)</b>
              {lockedUntilLabel ? ` sampai ${lockedUntilLabel}` : ''}. Data absensi tersimpan aman dan tidak dapat dihapus.
            </span>
          </div>
        )}

        {/* Search & Filter Toolbar */}
        <div className="p-4 border-b border-slate-100 bg-white flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
            <input
              type="text"
              placeholder="Cari berdasarkan nama, NIP, atau tanggal (YYYY-MM-DD)..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-4 py-2 text-xs sm:text-sm rounded-xl border border-slate-200 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
            />
          </div>
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-3 py-2 text-xs sm:text-sm rounded-xl border border-slate-200 bg-white font-medium text-slate-700 outline-none"
          >
            <option value="all">Semua Status Kehadiran</option>
            <option value="Hadir (H)">Hadir (H)</option>
            <option value="Ijin (I)">Ijin (I)</option>
            <option value="Sakit (S)">Sakit (S)</option>
            <option value="Cuti (C)">Cuti (C)</option>
            <option value="Tugas Dinas (TD)">Tugas Dinas (TD)</option>
            <option value="Tanpa Berita (TB)">Tanpa Berita (TB)</option>
            <option value="Tugas Belajar (TS)">Tugas Belajar (TS)</option>
          </select>
        </div>

        {/* Content List */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-3">
          {filteredRecords.length === 0 ? (
            <div className="py-12 text-center text-slate-400">
              <Calendar className="mx-auto h-12 w-12 text-slate-300 mb-2" />
              <p className="text-sm font-semibold text-slate-600">Tidak ada riwayat absensi ditemukan</p>
              <p className="text-xs text-slate-400 mt-1">
                Kartu absensi yang dicetak dan disimpan akan muncul di sini.
              </p>
            </div>
          ) : (
            filteredRecords.map((item) => {
              const sent = isRecordSent(item);
              return (
                <div
                  key={item.id}
                  className="group flex flex-col sm:flex-row items-start sm:items-center justify-between p-4 rounded-xl border border-slate-200 hover:border-indigo-300 hover:bg-indigo-50/20 transition-all gap-4"
                >
                  <div className="flex items-center gap-4">
                    {/* Miniature Photos */}
                    <div className="flex -space-x-3 overflow-hidden shrink-0">
                      <img
                        src={item.fotoMasuk}
                        alt="Masuk"
                        className="inline-block h-12 w-12 rounded-lg object-cover ring-2 ring-white border border-slate-200"
                      />
                      <img
                        src={item.fotoKeluar}
                        alt="Keluar"
                        className="inline-block h-12 w-12 rounded-lg object-cover ring-2 ring-white border border-slate-200"
                      />
                    </div>

                    <div>
                      <div className="flex flex-wrap items-center gap-2">
                        <h4 className="text-sm font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">
                          {item.nama}
                        </h4>
                        <span className="text-[11px] font-semibold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded">
                          {item.statusPegawai}
                        </span>
                        {isGuruPegawai && sent && (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded">
                            <CheckCircle2 className="h-3 w-3" />
                            Tersimpan di Admin
                          </span>
                        )}
                      </div>
                      <div className="flex flex-wrap items-center gap-x-2 text-xs text-slate-500 mt-0.5">
                        <span>NIP: {item.nip || '-'}</span>
                        {item.golRuang && (
                          <>
                            <span>•</span>
                            <span>Gol: {item.golRuang}</span>
                          </>
                        )}
                        <span>•</span>
                        <span>Tanggal: {item.tanggal}</span>
                        <span>•</span>
                        <span className="font-semibold text-slate-700">
                          Status: {item.statusKehadiran}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 self-end sm:self-center">
                    {isGuruPegawai && onSendToAdmin && (
                      <button
                        type="button"
                        onClick={() => onSendToAdmin(item)}
                        className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
                          sent
                            ? 'text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200'
                            : 'text-white bg-emerald-600 hover:bg-emerald-700 shadow-xs'
                        }`}
                        title={
                          sent
                            ? 'Perbarui data absensi ini ke akun Admin'
                            : 'Simpan otomatis ke akun Admin sesuai hari, bulan, dan tahun'
                        }
                      >
                        {sent ? (
                          <>
                            <CheckCircle2 className="h-3.5 w-3.5" />
                            Kirim Ulang ke Admin
                          </>
                        ) : (
                          <>
                            <Send className="h-3.5 w-3.5" />
                            Simpan ke Admin
                          </>
                        )}
                      </button>
                    )}

                    <button
                      onClick={() => {
                        onSelectRecord(item);
                        onClose();
                      }}
                      className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 rounded-lg transition-colors cursor-pointer"
                    >
                      <Eye className="h-3.5 w-3.5" />
                      Buka Kartu
                    </button>

                    {historyLocked ? (
                      <button
                        type="button"
                        onClick={() => {
                          if (isAdmin) setShowLockMenu(true);
                        }}
                        disabled={!isAdmin}
                        className={`inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-[11px] font-bold border transition ${
                          isAdmin
                            ? 'bg-amber-50 hover:bg-amber-100 text-amber-800 border-amber-200 cursor-pointer'
                            : 'bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed'
                        }`}
                        title={
                          isAdmin
                            ? 'Riwayat terkunci. Klik untuk membuka pengaturan Kunci Riwayat.'
                            : 'Riwayat sedang dikunci oleh Admin'
                        }
                      >
                        <Lock className="h-3.5 w-3.5" />
                        Terkunci
                      </button>
                    ) : confirmDeleteId === item.id ? (
                      <div className="flex items-center gap-1.5 bg-rose-50 px-2 py-1 rounded-lg border border-rose-200">
                        <span className="text-[11px] font-bold text-rose-700">Hapus?</span>
                        <button
                          onClick={() => {
                            onDeleteRecord(item.id);
                            setConfirmDeleteId(null);
                          }}
                          className="px-2 py-0.5 bg-rose-600 hover:bg-rose-700 text-white rounded text-[11px] font-bold transition cursor-pointer"
                        >
                          Ya
                        </button>
                        <button
                          onClick={() => setConfirmDeleteId(null)}
                          className="px-2 py-0.5 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded text-[11px] font-bold transition cursor-pointer"
                        >
                          Batal
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => setConfirmDeleteId(item.id)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-colors cursor-pointer"
                        title="Hapus Dari Riwayat"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-slate-100 bg-slate-50 px-6 py-3 flex items-center justify-between gap-2">
          {isGuruPegawai ? (
            <p className="text-[11px] text-slate-500">
              Klik <b>Simpan ke Admin</b> agar absensi Anda tersimpan otomatis di akun Admin per hari, bulan, dan tahun.
            </p>
          ) : (
            <p className="text-[11px] text-slate-500">
              {historyLocked
                ? `Kunci Riwayat aktif (${activeLockMonths} Bulan). Klik tombol Kunci Riwayat di atas untuk mengubah atau menonaktifkan.`
                : 'Admin dapat mengunci riwayat selama 1, 2, atau 3 bulan melalui tombol Kunci Riwayat di atas.'}
            </p>
          )}
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-bold text-slate-600 hover:text-slate-900 transition shrink-0 cursor-pointer"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
