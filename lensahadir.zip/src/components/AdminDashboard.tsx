import React, { useState, useMemo } from 'react';
import {
  UserPlus,
  Users,
  Shield,
  Briefcase,
  Search,
  Edit3,
  Trash2,
  Eye,
  EyeOff,
  KeyRound,
  Mail,
  MessageCircle,
  Bell,
  CheckCircle2,
  X,
  Copy,
  RefreshCw,
  FileText,
  FileSpreadsheet,
  BarChart3,
  Settings,
  AlertCircle,
  User,
  Lock,
  LockOpen,
  Check,
  CalendarDays,
  FolderOpen,
  HelpCircle,
  ShieldCheck,
  ExternalLink,
  Building2,
  Download,
  Upload,
  Code2,
  Smartphone,
} from 'lucide-react';
import {
  AppSettings,
  ManagedUser,
  StatusPegawai,
  AssignableUserRole,
  ConfirmationContactType,
  AdminConfirmationContact,
  RecoveryNotification,
  AdminSubmissionRecord,
  AdminAccountProfile,
  AdminRegistrationRequest,
  DataLockConfig,
  SubmissionsLockDuration,
  HistoryLockDuration,
} from '../types/attendance';
import { INDONESIAN_MONTHS } from '../utils/monthlyRecapParser';
import {
  isAdminDataLockedNow,
  isHistoryLockedNow,
  isSubmissionsLockedNow,
} from '../utils/storage';
import { REGISTRATION_AUTO_REPLY } from './AdminRegisterPage';
import { BlogspotEmbedModal } from './BlogspotEmbedModal';

interface AdminDashboardProps {
  settings: AppSettings;
  adminProfile: AdminAccountProfile;
  users: ManagedUser[];
  adminContact: AdminConfirmationContact;
  recoveryNotifications: RecoveryNotification[];
  adminSubmissions: AdminSubmissionRecord[];
  adminRegistrations: AdminRegistrationRequest[];
  recordsCount: number;
  onSaveUser: (user: ManagedUser) => void;
  onDeleteUser: (id: string) => void;
  onSaveAdminContact: (contact: AdminConfirmationContact) => void;
  onMarkNotificationDone: (id: string) => void;
  onDeleteNotification: (id: string) => void;
  onMarkRegistrationContacted: (id: string) => void;
  onDeleteRegistration: (id: string) => void;
  onOpenSubmissionCard: (sub: AdminSubmissionRecord) => void;
  onDeleteSubmission: (id: string) => void;
  onImportSubmissionsToMonthly: (
    subs: AdminSubmissionRecord[],
    bulan: number,
    tahun: number
  ) => void;
  onNavigate: (page: 'form' | 'report' | 'monthly') => void;
  onOpenSettings: () => void;
  onOpenAdminProfile: () => void;
  onOpenHelp: () => void;
  showToast: (msg: string) => void;
  lockConfig: DataLockConfig;
  onToggleAdminDataLock: (locked: boolean) => void;
  onActivateAllUsersForAllDevices: () => void;
  onUpdateSubmissionsLock: (months: SubmissionsLockDuration) => void;
  onUpdateHistoryLock: (months: HistoryLockDuration) => void;
  onExportBackup?: () => void;
  onImportBackup?: (file: File) => void;
  isSyncingData?: boolean;
}

const STATUS_PEGAWAI_OPTIONS: { value: StatusPegawai; label: string }[] = [
  { value: 'ASN', label: 'ASN (PNS)' },
  { value: 'PPPK', label: 'PPPK' },
  { value: 'PPPK Paruh Waktu', label: 'PPPK Paruh Waktu' },
  { value: 'Honor/GTT', label: 'Honor/GTT' },
  { value: 'Tenaga Kontrak', label: 'Tenaga Kontrak' },
  { value: 'Penjaga Sekolah', label: 'Penjaga Sekolah' },
];

const formatWaNumber = (raw: string): string => {
  const digits = raw.replace(/[^0-9]/g, '');
  if (!digits) return '';
  if (digits.startsWith('0')) return `62${digits.slice(1)}`;
  if (digits.startsWith('62')) return digits;
  return `62${digits}`;
};

const formatDateTimeId = (ts: number): string => {
  try {
    return new Date(ts).toLocaleString('id-ID', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return '';
  }
};

const formatLockDateId = (ts: number | null | undefined): string => {
  if (!ts) return '';
  try {
    return new Date(ts).toLocaleDateString('id-ID', {
      day: '2-digit',
      month: 'long',
      year: 'numeric',
    });
  } catch {
    return '';
  }
};

const generateRandomPassword = (): string => {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
  let result = '';
  for (let i = 0; i < 8; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
};

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  settings,
  adminProfile,
  users,
  adminContact,
  recoveryNotifications,
  adminSubmissions,
  adminRegistrations,
  recordsCount,
  onSaveUser,
  onDeleteUser,
  onSaveAdminContact,
  onMarkNotificationDone,
  onDeleteNotification,
  onMarkRegistrationContacted,
  onDeleteRegistration,
  onOpenSubmissionCard,
  onDeleteSubmission,
  onImportSubmissionsToMonthly,
  onNavigate,
  onOpenSettings,
  onOpenAdminProfile,
  onOpenHelp,
  showToast,
  lockConfig,
  onToggleAdminDataLock,
  onActivateAllUsersForAllDevices,
  onUpdateSubmissionsLock,
  onUpdateHistoryLock,
  onExportBackup,
  onImportBackup,
  isSyncingData = false,
}) => {
  // Search & Filter
  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState<'ALL' | AssignableUserRole>('ALL');
  const [activeTab, setActiveTab] = useState<
    'users' | 'submissions' | 'notifications' | 'registrations'
  >('users');

  // Master Data Lock Quick Panel toggle & Blogspot HTML Embed Modal
  const [showMasterLockPanel, setShowMasterLockPanel] = useState(false);
  const [isBlogspotModalOpen, setIsBlogspotModalOpen] = useState(false);

  const adminDataLocked = isAdminDataLockedNow(lockConfig);
  const submissionsLocked = isSubmissionsLockedNow(lockConfig);
  const historyLocked = isHistoryLockedNow(lockConfig);
  const anyLockActive = adminDataLocked || submissionsLocked || historyLocked;
  const submissionsLockedUntilLabel = formatLockDateId(lockConfig.submissionsLockedUntil);
  const historyLockedUntilLabel = formatLockDateId(lockConfig.historyLockedUntil);
  const activeUsersCount = users.filter((u) => u.aktif !== false).length;
  const inactiveUsersCount = users.length - activeUsersCount;

  // Submissions (Absensi Pengguna per Hari / Bulan / Tahun) filters
  const [subUserFilter, setSubUserFilter] = useState<string>('ALL');
  const [subYearFilter, setSubYearFilter] = useState<string>('ALL');
  const [subMonthFilter, setSubMonthFilter] = useState<string>('ALL');
  const [subDateFilter, setSubDateFilter] = useState<string>('');
  const [confirmDeleteSubId, setConfirmDeleteSubId] = useState<string | null>(null);

  // Password visibility map per user row
  const [visiblePasswords, setVisiblePasswords] = useState<Record<string, boolean>>({});
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  // Admin default confirmation contact inline editor
  const [editingContact, setEditingContact] = useState(false);
  const [contactTypeDraft, setContactTypeDraft] = useState<ConfirmationContactType>(
    adminContact.type
  );
  const [contactValueDraft, setContactValueDraft] = useState(adminContact.value);
  const [contactError, setContactError] = useState('');

  // Add / Edit User Modal state
  const [isUserModalOpen, setIsUserModalOpen] = useState(false);
  const [editingUserId, setEditingUserId] = useState<string | null>(null);
  const [nama, setNama] = useState('');
  const [nip, setNip] = useState('');
  const [golRuang, setGolRuang] = useState('');
  const [statusPegawai, setStatusPegawai] = useState<StatusPegawai>('ASN');
  const [jabatan, setJabatan] = useState('');
  const [role, setRole] = useState<AssignableUserRole>('Guru/Pegawai');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showModalPassword, setShowModalPassword] = useState(false);
  const [konfirmasiTipe, setKonfirmasiTipe] = useState<ConfirmationContactType>(
    adminContact.type
  );
  const [konfirmasiAdmin, setKonfirmasiAdmin] = useState(adminContact.value);
  const [aktif, setAktif] = useState(true);
  const [formError, setFormError] = useState('');

  const guruCount = useMemo(
    () => users.filter((u) => u.role === 'Guru/Pegawai').length,
    [users]
  );
  const pimpinanCount = useMemo(
    () => users.filter((u) => u.role === 'Pimpinan').length,
    [users]
  );
  const pendingNotifsCount = useMemo(
    () => recoveryNotifications.filter((n) => n.status === 'menunggu').length,
    [recoveryNotifications]
  );
  const pendingRegistrationsCount = useMemo(
    () => adminRegistrations.filter((r) => r.status === 'menunggu').length,
    [adminRegistrations]
  );

  const filteredUsers = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return users.filter((u) => {
      if (roleFilter !== 'ALL' && u.role !== roleFilter) return false;
      if (!q) return true;
      return (
        u.nama.toLowerCase().includes(q) ||
        u.username.toLowerCase().includes(q) ||
        u.nip.toLowerCase().includes(q) ||
        u.jabatan.toLowerCase().includes(q)
      );
    });
  }, [users, searchQuery, roleFilter]);

  // Distinct available years and users in adminSubmissions
  const submissionYears = useMemo(() => {
    const set = new Set<number>();
    adminSubmissions.forEach((s) => set.add(s.tahun));
    return Array.from(set).sort((a, b) => b - a);
  }, [adminSubmissions]);

  const submissionUserOptions = useMemo(() => {
    const map = new Map<string, string>();
    adminSubmissions.forEach((s) => {
      const key = s.userId || s.nama.toLowerCase();
      if (!map.has(key)) map.set(key, s.nama);
    });
    return Array.from(map.entries())
      .map(([id, nama]) => ({ id, nama }))
      .sort((a, b) => a.nama.localeCompare(b.nama, 'id-ID', { sensitivity: 'base' }));
  }, [adminSubmissions]);

  const filteredSubmissions = useMemo(() => {
    return adminSubmissions
      .filter((s) => {
        const key = s.userId || s.nama.toLowerCase();
        if (subUserFilter !== 'ALL' && key !== subUserFilter) return false;
        if (subYearFilter !== 'ALL' && String(s.tahun) !== subYearFilter) return false;
        if (subMonthFilter !== 'ALL' && String(s.bulan) !== subMonthFilter) return false;
        if (subDateFilter && s.tanggal !== subDateFilter) return false;
        return true;
      })
      .sort((a, b) => b.tanggal.localeCompare(a.tanggal) || b.submittedAt - a.submittedAt);
  }, [adminSubmissions, subUserFilter, subYearFilter, subMonthFilter, subDateFilter]);

  // Group filtered submissions: Per Pengguna -> Tahun & Bulan -> Hari/Tanggal
  const groupedSubmissions = useMemo(() => {
    type MonthBucket = {
      key: string;
      tahun: number;
      bulan: number;
      label: string;
      items: AdminSubmissionRecord[];
    };
    type UserGroup = {
      userKey: string;
      nama: string;
      nip: string;
      jabatan: string;
      golRuang: string;
      statusPegawai: StatusPegawai;
      total: number;
      counts: { h: number; td: number; i: number; s: number; tk: number };
      months: MonthBucket[];
    };

    const userMap = new Map<string, UserGroup>();

    for (const sub of filteredSubmissions) {
      const userKey = sub.userId || sub.nama.toLowerCase();
      if (!userMap.has(userKey)) {
        userMap.set(userKey, {
          userKey,
          nama: sub.nama,
          nip: sub.nip,
          jabatan: sub.jabatan,
          golRuang: sub.golRuang,
          statusPegawai: sub.statusPegawai,
          total: 0,
          counts: { h: 0, td: 0, i: 0, s: 0, tk: 0 },
          months: [],
        });
      }
      const grp = userMap.get(userKey)!;
      grp.total++;
      const st = sub.statusKehadiran || 'Hadir (H)';
      if (st.startsWith('Hadir')) grp.counts.h++;
      else if (st.startsWith('Tugas Dinas') || st.startsWith('Tugas Belajar')) grp.counts.td++;
      else if (st.startsWith('Ijin') || st.startsWith('Cuti')) grp.counts.i++;
      else if (st.startsWith('Sakit')) grp.counts.s++;
      else grp.counts.tk++;

      const mKey = `${sub.tahun}-${String(sub.bulan).padStart(2, '0')}`;
      let mBucket = grp.months.find((m) => m.key === mKey);
      if (!mBucket) {
        mBucket = {
          key: mKey,
          tahun: sub.tahun,
          bulan: sub.bulan,
          label: `${INDONESIAN_MONTHS[sub.bulan - 1] || 'Bulan'} ${sub.tahun}`,
          items: [],
        };
        grp.months.push(mBucket);
      }
      mBucket.items.push(sub);
    }

    const result = Array.from(userMap.values()).sort((a, b) =>
      a.nama.localeCompare(b.nama, 'id-ID', { sensitivity: 'base' })
    );
    for (const grp of result) {
      grp.months.sort((a, b) => b.key.localeCompare(a.key));
      for (const m of grp.months) {
        m.items.sort((a, b) => b.tanggal.localeCompare(a.tanggal));
      }
    }
    return result;
  }, [filteredSubmissions]);

  const openAddUserModal = () => {
    setEditingUserId(null);
    setNama('');
    setNip('');
    setGolRuang('');
    setStatusPegawai('ASN');
    setJabatan('');
    setRole('Guru/Pegawai');
    setUsername('');
    setPassword('');
    setShowModalPassword(false);
    setKonfirmasiTipe(adminContact.type || 'wa');
    setKonfirmasiAdmin(adminContact.value || '');
    setAktif(true);
    setFormError('');
    setIsUserModalOpen(true);
  };

  const openEditUserModal = (user: ManagedUser) => {
    setEditingUserId(user.id);
    setNama(user.nama);
    setNip(user.nip);
    setGolRuang(user.golRuang);
    setStatusPegawai(user.statusPegawai);
    setJabatan(user.jabatan);
    setRole(user.role);
    setUsername(user.username);
    setPassword(user.password);
    setShowModalPassword(true);
    setKonfirmasiTipe(user.konfirmasiTipe || adminContact.type || 'wa');
    setKonfirmasiAdmin(user.konfirmasiAdmin || adminContact.value || '');
    setAktif(user.aktif !== false);
    setFormError('');
    setIsUserModalOpen(true);
  };

  const validateConfirmationContact = (
    type: ConfirmationContactType,
    val: string
  ): string | null => {
    const trimmed = val.trim();
    if (!trimmed) {
      return type === 'email'
        ? 'Email Konfirmasi Admin wajib diisi (pilih salah satu: Email atau Nomor WA).'
        : 'Nomor WA Konfirmasi Admin wajib diisi (pilih salah satu: Nomor WA atau Email).';
    }
    if (type === 'email') {
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmed)) {
        return 'Format Email Konfirmasi Admin tidak valid (contoh: admin@sekolah.sch.id).';
      }
    } else {
      const digits = trimmed.replace(/[^0-9]/g, '');
      if (digits.length < 9 || digits.length > 15) {
        return 'Nomor WA Konfirmasi Admin harus berupa angka yang valid (9–15 digit, contoh: 081234567890).';
      }
    }
    return null;
  };

  const handleSubmitUser = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    const cleanNama = nama.trim();
    const cleanUsername = username.trim().replace(/\s+/g, '');
    const cleanPassword = password.trim();
    const cleanKonfirmasi = konfirmasiAdmin.trim();

    if (!cleanNama) {
      setFormError('Nama Lengkap wajib diisi.');
      return;
    }
    if (!cleanUsername || cleanUsername.length < 3) {
      setFormError('Username wajib diisi minimal 3 karakter (tanpa spasi).');
      return;
    }
    if (
      cleanUsername.toLowerCase() ===
      (adminProfile.username || 'admin').toLowerCase()
    ) {
      setFormError(
        `Username "${cleanUsername}" sudah digunakan oleh akun Administrator utama.`
      );
      return;
    }
    const duplicate = users.find(
      (u) =>
        u.username.toLowerCase() === cleanUsername.toLowerCase() &&
        u.id !== editingUserId
    );
    if (duplicate) {
      setFormError(`Username "${cleanUsername}" sudah digunakan oleh ${duplicate.nama}.`);
      return;
    }
    if (!cleanPassword || cleanPassword.length < 4) {
      setFormError('Password wajib diisi minimal 4 karakter.');
      return;
    }

    const contactErr = validateConfirmationContact(konfirmasiTipe, cleanKonfirmasi);
    if (contactErr) {
      setFormError(contactErr);
      return;
    }

    const existingUser = editingUserId
      ? users.find((u) => u.id === editingUserId)
      : undefined;

    const newUser: ManagedUser = {
      id: editingUserId || `USR_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      nama: cleanNama,
      nip: nip.trim(),
      golRuang: golRuang.trim(),
      statusPegawai,
      jabatan: jabatan.trim(),
      role,
      username: cleanUsername,
      password: cleanPassword,
      konfirmasiTipe,
      konfirmasiAdmin: cleanKonfirmasi,
      aktif,
      createdAt: existingUser?.createdAt || Date.now(),
    };

    onSaveUser(newUser);
    // Keep default Admin confirmation contact synced with the latest saved confirmation contact
    onSaveAdminContact({ type: konfirmasiTipe, value: cleanKonfirmasi });
    setContactTypeDraft(konfirmasiTipe);
    setContactValueDraft(cleanKonfirmasi);

    setIsUserModalOpen(false);
    showToast(
      editingUserId
        ? `Data pengguna "${cleanNama}" berhasil diperbarui`
        : `Pengguna "${cleanNama}" (${role}) berhasil ditambahkan`
    );
  };

  const handleSaveAdminContactInline = (e: React.FormEvent) => {
    e.preventDefault();
    setContactError('');
    const err = validateConfirmationContact(contactTypeDraft, contactValueDraft);
    if (err) {
      setContactError(err);
      return;
    }
    onSaveAdminContact({
      type: contactTypeDraft,
      value: contactValueDraft.trim(),
    });
    setEditingContact(false);
    showToast(
      `Kontak konfirmasi Admin (${contactTypeDraft === 'wa' ? 'Nomor WA' : 'Email'}) disimpan`
    );
  };

  const handleCopyCredentials = (user: ManagedUser) => {
    const text = `Info Akun Login LensaHadir\nNama: ${user.nama}\nRole: ${user.role}\nUsername: ${user.username}\nPassword: ${user.password}`;
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text).then(() => {
        showToast(`Info login ${user.nama} disalin ke clipboard`);
      });
    }
  };

  const handleToggleActive = (user: ManagedUser) => {
    onSaveUser({ ...user, aktif: !user.aktif });
    showToast(
      `Akun ${user.nama} ${!user.aktif ? 'diaktifkan kembali' : 'dinonaktifkan sementara'}`
    );
  };

  const handleAutoFillUsernameFromName = () => {
    if (!nama.trim()) return;
    // Take first name + last name without academic titles
    const withoutTitle = nama
      .split(',')[0]
      .replace(/^(Drs\.|Dra\.|Dr\.|Hj\.|H\.|Ir\.|Prof\.)\s*/gi, '')
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9\s]/g, '')
      .split(/\s+/)
      .slice(0, 2)
      .join('.');
    if (withoutTitle) {
      setUsername(withoutTitle);
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Executive Admin Banner */}
      <div className="bg-gradient-to-br from-indigo-900 via-indigo-800 to-slate-900 rounded-2xl p-6 sm:p-7 text-white shadow-xl border border-indigo-700/50">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-indigo-200 bg-white/10 px-2.5 py-1 rounded-md">
              <Shield className="h-3.5 w-3.5 text-emerald-300" />
              Dashboard Khusus Administrator
            </div>
            <h1 className="text-xl sm:text-2xl font-black tracking-tight">
              Manajemen Pengguna & Kendali Sistem
            </h1>
            <p className="text-xs sm:text-sm text-indigo-200/90">
              {adminProfile.lembaga || settings.subInstansi || settings.namaInstansi}
            </p>
            <div className="flex flex-wrap items-center gap-x-3 gap-y-1 pt-0.5 text-[11px] text-indigo-200/90">
              <span className="font-bold text-white">
                {adminProfile.nama || 'Administrator Utama'}
              </span>
              <span>•</span>
              <span>{adminProfile.jabatan || 'Administrator Utama Lembaga / Satuan Dinas'}</span>
              <span>•</span>
              <span className="font-mono text-emerald-300 font-semibold">
                @{adminProfile.username}
              </span>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              onClick={() => onToggleAdminDataLock(!adminDataLocked)}
              className={`font-black text-xs px-4 py-3 rounded-xl border transition flex items-center gap-1.5 shadow-md cursor-pointer ${
                adminDataLocked
                  ? 'bg-emerald-400 hover:bg-emerald-300 text-slate-950 border-emerald-200'
                  : 'bg-white/15 hover:bg-white/25 text-white border-white/30'
              }`}
              title={
                adminDataLocked
                  ? 'Data Admin sedang terkunci aman. Semua akun User tetap aktif dan dapat login di semua browser & HP. Klik untuk membuka kunci.'
                  : 'Aktifkan Kunci Khusus Data Admin (Profil Admin, Kop Instansi & Hapus Akun terkunci, sementara seluruh akun User tetap aktif di semua browser & HP)'
              }
            >
              {adminDataLocked ? (
                <>
                  <Lock className="h-4 w-4" />
                  <span>Data Admin Terkunci</span>
                </>
              ) : (
                <>
                  <LockOpen className="h-4 w-4 text-emerald-300" />
                  <span>Kunci Data Admin</span>
                </>
              )}
            </button>
            <button
              type="button"
              onClick={() => setShowMasterLockPanel((prev) => !prev)}
              className={`font-black text-xs px-4 py-3 rounded-xl border transition flex items-center gap-1.5 shadow-md cursor-pointer ${
                anyLockActive
                  ? 'bg-amber-400 hover:bg-amber-300 text-slate-950 border-amber-300'
                  : 'bg-amber-500/20 hover:bg-amber-500/35 text-amber-100 border-amber-300/50'
              }`}
              title="Gembok / Kunci seluruh data & file absensi pengguna agar aman dan tidak hilang tanpa sengaja"
            >
              {anyLockActive ? (
                <>
                  <Lock className="h-4 w-4" />
                  <span>
                    Gembok Aktif
                    {submissionsLocked
                      ? ` (${lockConfig.submissionsLockMonths} Bln)`
                      : historyLocked
                      ? ` (Riwayat ${lockConfig.historyLockMonths} Bln)`
                      : adminDataLocked
                      ? ' (Admin)'
                      : ''}
                  </span>
                </>
              ) : (
                <>
                  <LockOpen className="h-4 w-4 text-amber-300" />
                  <span>Gembok / Kunci Data</span>
                </>
              )}
            </button>
            <button
              type="button"
              onClick={openAddUserModal}
              className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs sm:text-sm px-5 py-3 rounded-xl shadow-lg shadow-emerald-950/30 transition flex items-center gap-2 cursor-pointer"
            >
              <UserPlus className="h-4 w-4" />
              Tambah Pengguna
            </button>
            <button
              type="button"
              onClick={() => {
                if (adminDataLocked) {
                  showToast(
                    'Kunci Data Admin sedang aktif. Klik tombol "Data Admin Terkunci" untuk membuka kunci terlebih dahulu jika ingin mengubah data Admin.'
                  );
                  return;
                }
                onOpenAdminProfile();
              }}
              className={`border font-bold text-xs px-4 py-3 rounded-xl transition flex items-center gap-1.5 cursor-pointer ${
                adminDataLocked
                  ? 'bg-white/10 border-white/20 text-indigo-200 hover:bg-white/15'
                  : 'bg-amber-400/20 hover:bg-amber-400/30 border-amber-300/40 text-white'
              }`}
              title={
                adminDataLocked
                  ? 'Data Admin terkunci. Buka Kunci Data Admin terlebih dahulu untuk mengubah.'
                  : 'Ubah data diri, username, dan password Administrator Utama'
              }
            >
              {adminDataLocked ? (
                <Lock className="h-3.5 w-3.5 text-emerald-300" />
              ) : (
                <ShieldCheck className="h-4 w-4 text-amber-300" />
              )}
              Pengaturan Data Admin
            </button>
            <button
              type="button"
              onClick={() => {
                if (adminDataLocked) {
                  showToast(
                    'Kunci Data Admin sedang aktif. Buka Kunci Data Admin terlebih dahulu jika ingin mengubah Kop Instansi.'
                  );
                  return;
                }
                onOpenSettings();
              }}
              className={`font-bold text-xs px-4 py-3 rounded-xl transition flex items-center gap-1.5 cursor-pointer ${
                adminDataLocked
                  ? 'bg-white/10 text-indigo-200 border border-white/15 hover:bg-white/15'
                  : 'bg-white/10 hover:bg-white/20 text-white'
              }`}
              title={
                adminDataLocked
                  ? 'Kop Instansi terkunci oleh Kunci Data Admin'
                  : 'Ubah Kop Instansi & Logo'
              }
            >
              {adminDataLocked ? (
                <Lock className="h-3.5 w-3.5 text-emerald-300" />
              ) : (
                <Settings className="h-4 w-4" />
              )}
              Kop Instansi
            </button>
            <button
              type="button"
              onClick={onOpenHelp}
              className="bg-sky-500/20 hover:bg-sky-500/35 border border-sky-300/40 text-white font-bold text-xs px-4 py-3 rounded-xl transition flex items-center gap-1.5 cursor-pointer"
              title="Tanya Admin melalui Saluran Bantuan"
            >
              <HelpCircle className="h-4 w-4 text-sky-200" />
              Help
            </button>
          </div>
        </div>

        {/* Panel Gembok / Kunci Data Admin & File Absensi Pengguna (Hak Penuh Admin) */}
        {showMasterLockPanel && (
          <div className="mt-5 rounded-2xl bg-slate-950/60 border border-amber-400/40 p-4 sm:p-5 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-start gap-2.5">
                <div className="p-2 rounded-xl bg-amber-400/20 text-amber-300 shrink-0">
                  {anyLockActive ? <Lock className="h-5 w-5" /> : <LockOpen className="h-5 w-5" />}
                </div>
                <div>
                  <h2 className="text-sm font-black text-white flex flex-wrap items-center gap-2">
                    Gembok / Kunci Data Admin &amp; File Absensi Pengguna (Hak Penuh Admin)
                  </h2>
                  <p className="text-xs text-indigo-100/90 mt-0.5 leading-relaxed">
                    Kunci Data Admin menjaga profil, password Admin, Kop Instansi, serta mencegah penghapusan akun — <b>sementara semua akun pengguna tetap AKTIF dan dapat login dari browser mana saja termasuk HP/Gadget</b>.
                  </p>
                </div>
              </div>
              <div className="flex flex-wrap items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => {
                    onToggleAdminDataLock(true);
                    onUpdateSubmissionsLock(6);
                    onUpdateHistoryLock(3);
                    setConfirmDeleteId(null);
                    setConfirmDeleteSubId(null);
                  }}
                  className="px-3.5 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-black flex items-center gap-1.5 transition cursor-pointer"
                >
                  <Lock className="h-3.5 w-3.5" />
                  Kunci Semua Maksimal
                </button>
                {anyLockActive && (
                  <button
                    type="button"
                    onClick={() => {
                      onToggleAdminDataLock(false);
                      onUpdateSubmissionsLock(0);
                      onUpdateHistoryLock(0);
                    }}
                    className="px-3 py-2 rounded-xl bg-white/10 hover:bg-rose-500/30 border border-rose-300/40 text-rose-100 text-xs font-bold flex items-center gap-1.5 transition cursor-pointer"
                  >
                    <LockOpen className="h-3.5 w-3.5" />
                    Buka Semua
                  </button>
                )}
              </div>
            </div>

            {/* Kartu Khusus: Kunci Data Admin (User Tetap Aktif di Semua Browser & HP) */}
            <div className="rounded-xl bg-emerald-500/15 border border-emerald-300/35 p-3.5 flex flex-col lg:flex-row lg:items-center justify-between gap-3">
              <div className="space-y-0.5">
                <p className="text-xs font-black text-white flex items-center gap-1.5">
                  <ShieldCheck className="h-4 w-4 text-emerald-300" />
                  Kunci Khusus Data Admin (Akun User Tetap Aktif Login di Semua Browser &amp; HP)
                </p>
                <p className="text-[11px] text-emerald-100/90 leading-relaxed">
                  {adminDataLocked
                    ? `Data Admin, Kop Instansi & daftar akun terkunci aman. Sebanyak ${activeUsersCount} dari ${users.length} akun pengguna aktif dan siap login di browser HP maupun laptop.`
                    : `Aktifkan untuk mengunci Data Admin & Kop Instansi agar tidak berubah, sambil membiarkan ${activeUsersCount} akun pengguna tetap aktif dan bisa login di semua browser termasuk HP.`}
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => onToggleAdminDataLock(!adminDataLocked)}
                  className={`px-3.5 py-2 rounded-xl text-xs font-black flex items-center gap-1.5 border transition cursor-pointer ${
                    adminDataLocked
                      ? 'bg-emerald-400 hover:bg-emerald-300 text-slate-950 border-emerald-200'
                      : 'bg-white text-slate-900 hover:bg-emerald-50 border-white'
                  }`}
                >
                  {adminDataLocked ? (
                    <>
                      <LockOpen className="h-3.5 w-3.5" />
                      Buka Kunci Data Admin
                    </>
                  ) : (
                    <>
                      <Lock className="h-3.5 w-3.5" />
                      Kunci Data Admin
                    </>
                  )}
                </button>
                <button
                  type="button"
                  onClick={onActivateAllUsersForAllDevices}
                  className="px-3.5 py-2 rounded-xl bg-indigo-500 hover:bg-indigo-400 text-white text-xs font-black flex items-center gap-1.5 shadow-xs transition cursor-pointer"
                  title="Pastikan semua akun user berstatus Aktif dan langsung tersinkron ke server agar bisa login dari browser apa saja termasuk HP"
                >
                  <Smartphone className="h-3.5 w-3.5" />
                  Aktifkan &amp; Sinkron Semua User (HP/Browser)
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
              {/* Kunci Data & File Absensi Pengguna (Maks. 6 Bulan / 1 Semester) */}
              <div className="rounded-xl bg-white/10 border border-white/15 p-3.5 space-y-2.5">
                <div className="flex items-center justify-between gap-2">
                  <div>
                    <p className="text-xs font-black text-white flex items-center gap-1.5">
                      <Lock className="h-3.5 w-3.5 text-amber-300" />
                      Kunci Absensi Pengguna &amp; File Masuk
                    </p>
                    <p className="text-[11px] text-indigo-200">
                      Masa simpan maks. 6 bulan (1 semester) •{' '}
                      {submissionsLocked
                        ? `Terkunci ${lockConfig.submissionsLockMonths} Bln${submissionsLockedUntilLabel ? ` s.d. ${submissionsLockedUntilLabel}` : ''}`
                        : 'Kunci belum aktif'}
                    </p>
                  </div>
                </div>
                <div className="flex flex-wrap items-center gap-1.5">
                  {([1, 3, 6] as const).map((m) => {
                    const active = submissionsLocked && lockConfig.submissionsLockMonths === m;
                    return (
                      <button
                        key={m}
                        type="button"
                        onClick={() => {
                          onUpdateSubmissionsLock(m);
                          setConfirmDeleteId(null);
                          setConfirmDeleteSubId(null);
                        }}
                        className={`px-3 py-1.5 rounded-lg text-[11px] font-black flex items-center gap-1 border transition cursor-pointer ${
                          active
                            ? 'bg-amber-400 text-slate-950 border-amber-300'
                            : 'bg-white/10 hover:bg-white/20 text-white border-white/20'
                        }`}
                      >
                        <Lock className="h-3 w-3" />
                        {m === 6 ? '6 Bln (1 Semester)' : `${m} Bulan`}
                      </button>
                    );
                  })}
                  <button
                    type="button"
                    onClick={() => onUpdateSubmissionsLock(0)}
                    className={`px-3 py-1.5 rounded-lg text-[11px] font-black flex items-center gap-1 border transition cursor-pointer ${
                      !submissionsLocked
                        ? 'bg-slate-200 text-slate-900 border-white'
                        : 'bg-rose-500/20 hover:bg-rose-500/35 text-rose-100 border-rose-300/40'
                    }`}
                  >
                    <LockOpen className="h-3 w-3" />
                    Nonaktifkan
                  </button>
                </div>
              </div>

              {/* Kunci Riwayat Absensi (1, 2, 3 Bulan) */}
              <div className="rounded-xl bg-white/10 border border-white/15 p-3.5 space-y-2.5">
                <div className="flex items-center justify-between gap-2">
                  <div>
                    <p className="text-xs font-black text-white flex items-center gap-1.5">
                      <Lock className="h-3.5 w-3.5 text-amber-300" />
                      Kunci Riwayat Kartu Absensi
                    </p>
                    <p className="text-[11px] text-indigo-200">
                      Pilihan durasi 1, 2, atau 3 bulan •{' '}
                      {historyLocked
                        ? `Terkunci ${lockConfig.historyLockMonths} Bln${historyLockedUntilLabel ? ` s.d. ${historyLockedUntilLabel}` : ''}`
                        : 'Kunci belum aktif'}
                    </p>
                  </div>
                </div>
                <div className="flex flex-wrap items-center gap-1.5">
                  {([1, 2, 3] as const).map((m) => {
                    const active = historyLocked && lockConfig.historyLockMonths === m;
                    return (
                      <button
                        key={m}
                        type="button"
                        onClick={() => onUpdateHistoryLock(m)}
                        className={`px-3 py-1.5 rounded-lg text-[11px] font-black flex items-center gap-1 border transition cursor-pointer ${
                          active
                            ? 'bg-amber-400 text-slate-950 border-amber-300'
                            : 'bg-white/10 hover:bg-white/20 text-white border-white/20'
                        }`}
                      >
                        <Lock className="h-3 w-3" />
                        {m} Bulan
                      </button>
                    );
                  })}
                  <button
                    type="button"
                    onClick={() => onUpdateHistoryLock(0)}
                    className={`px-3 py-1.5 rounded-lg text-[11px] font-black flex items-center gap-1 border transition cursor-pointer ${
                      !historyLocked
                        ? 'bg-slate-200 text-slate-900 border-white'
                        : 'bg-rose-500/20 hover:bg-rose-500/35 text-rose-100 border-rose-300/40'
                    }`}
                  >
                    <LockOpen className="h-3 w-3" />
                    Nonaktifkan
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Pasang di Tema Blogspot / Domain Khusus & Cadangan Data Bar */}
        <div className="mt-5 rounded-xl bg-white/10 border border-white/15 px-4 py-3 flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          <div className="text-xs text-indigo-100 leading-relaxed">
            <span className="font-black text-white">Domain Khusus Blogspot &amp; Cadangan Data:</span>{' '}
            Salin atau unduh file Tema Blogspot HTML (.xml/.html) untuk dipasang langsung pada domain khusus Blogspot Anda, serta unduh/pulihkan backup data kapan saja.
          </div>
          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setIsBlogspotModalOpen(true)}
              className="px-3.5 py-2 rounded-xl bg-orange-500 hover:bg-orange-400 text-white text-xs font-black flex items-center gap-1.5 shadow-sm transition cursor-pointer"
              title="Lihat, salin, atau unduh file Tema Blogspot (Edit HTML / .xml) untuk dipasang langsung di Blogger"
            >
              <Code2 className="h-3.5 w-3.5" />
              Tema Blogspot HTML &amp; Unduh
            </button>
            {onExportBackup && (
              <button
                type="button"
                onClick={onExportBackup}
                className="px-3.5 py-2 rounded-xl bg-emerald-400 hover:bg-emerald-300 text-slate-950 text-xs font-black flex items-center gap-1.5 shadow-sm transition cursor-pointer"
              >
                <Download className="h-3.5 w-3.5" />
                Unduh Backup (.json)
              </button>
            )}
            {onImportBackup && (
              <label className="px-3.5 py-2 rounded-xl bg-white/15 hover:bg-white/25 border border-white/25 text-white text-xs font-bold flex items-center gap-1.5 transition cursor-pointer">
                <Upload className="h-3.5 w-3.5 text-amber-300" />
                <span>{isSyncingData ? 'Memulihkan...' : 'Impor Backup (.json)'}</span>
                <input
                  type="file"
                  accept="application/json,.json"
                  disabled={isSyncingData}
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      onImportBackup(file);
                    }
                    e.target.value = '';
                  }}
                />
              </label>
            )}
          </div>
        </div>

        {/* Summary KPI Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mt-6">
          <div className="bg-white/10 backdrop-blur-xs rounded-xl p-4 border border-white/10">
            <p className="text-[11px] font-semibold text-indigo-200 uppercase tracking-wider">
              Total Pengguna
            </p>
            <p className="text-2xl font-black mt-1">{users.length}</p>
            <p className="text-[11px] text-indigo-200/80 mt-0.5">Selain akun Admin</p>
          </div>
          <div className="bg-white/10 backdrop-blur-xs rounded-xl p-4 border border-white/10">
            <p className="text-[11px] font-semibold text-indigo-200 uppercase tracking-wider">
              Role Guru/Pegawai
            </p>
            <p className="text-2xl font-black mt-1 text-sky-300">{guruCount}</p>
            <p className="text-[11px] text-indigo-200/80 mt-0.5">Akses Form Absensi</p>
          </div>
          <div className="bg-white/10 backdrop-blur-xs rounded-xl p-4 border border-white/10">
            <p className="text-[11px] font-semibold text-indigo-200 uppercase tracking-wider">
              Role Pimpinan
            </p>
            <p className="text-2xl font-black mt-1 text-amber-300">{pimpinanCount}</p>
            <p className="text-[11px] text-indigo-200/80 mt-0.5">Akses Statistik &amp; Disiplin</p>
          </div>
          <button
            type="button"
            onClick={() => setActiveTab('notifications')}
            className="text-left bg-white/10 hover:bg-white/15 backdrop-blur-xs rounded-xl p-4 border border-white/10 transition"
          >
            <p className="text-[11px] font-semibold text-indigo-200 uppercase tracking-wider flex items-center justify-between">
              <span>Konfirmasi Lupa Akun</span>
              {pendingNotifsCount > 0 && (
                <span className="h-2.5 w-2.5 rounded-full bg-rose-400 animate-pulse" />
              )}
            </p>
            <p className="text-2xl font-black mt-1 text-rose-300">
              {pendingNotifsCount}
            </p>
            <p className="text-[11px] text-indigo-200/80 mt-0.5">
              {pendingNotifsCount > 0 ? 'Menunggu tindak lanjut' : 'Semua terkonfirmasi'}
            </p>
          </button>
        </div>
      </div>

      {/* Quick Shortcuts + Admin Confirmation Contact Card */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Quick Module Shortcuts */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 shadow-sm p-5">
          <h2 className="text-xs font-black uppercase tracking-wider text-slate-500 mb-3">
            Akses Cepat Modul LensaHadir
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <button
              type="button"
              onClick={() => onNavigate('form')}
              className="flex items-center gap-3 p-3.5 rounded-xl border border-slate-200 hover:border-indigo-400 hover:bg-indigo-50/40 transition text-left group"
            >
              <div className="p-2.5 rounded-xl bg-indigo-50 text-indigo-600 group-hover:bg-indigo-600 group-hover:text-white transition">
                <FileText className="h-5 w-5" />
              </div>
              <div>
                <div className="text-xs font-black text-slate-800">Form Absensi</div>
                <div className="text-[11px] text-slate-500">{recordsCount} kartu tersimpan</div>
              </div>
            </button>

            <button
              type="button"
              onClick={() => onNavigate('report')}
              className="flex items-center gap-3 p-3.5 rounded-xl border border-slate-200 hover:border-indigo-400 hover:bg-indigo-50/40 transition text-left group"
            >
              <div className="p-2.5 rounded-xl bg-sky-50 text-sky-600 group-hover:bg-sky-600 group-hover:text-white transition">
                <FileSpreadsheet className="h-5 w-5" />
              </div>
              <div>
                <div className="text-xs font-black text-slate-800">Laporan Disiplin</div>
                <div className="text-[11px] text-slate-500">Rekap harian A4</div>
              </div>
            </button>

            <button
              type="button"
              onClick={() => onNavigate('monthly')}
              className="flex items-center gap-3 p-3.5 rounded-xl border border-slate-200 hover:border-indigo-400 hover:bg-indigo-50/40 transition text-left group"
            >
              <div className="p-2.5 rounded-xl bg-emerald-50 text-emerald-600 group-hover:bg-emerald-600 group-hover:text-white transition">
                <BarChart3 className="h-5 w-5" />
              </div>
              <div>
                <div className="text-xs font-black text-slate-800">Rekap Bulanan</div>
                <div className="text-[11px] text-slate-500">Hitung & ekspor PDF</div>
              </div>
            </button>
          </div>
        </div>

        {/* Admin Confirmation Contact (Email OR WA — salah satu saja) */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between gap-2 mb-2">
              <h2 className="text-xs font-black uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                <Bell className="h-3.5 w-3.5 text-indigo-600" />
                Kontak Konfirmasi Admin
              </h2>
              {!editingContact && (
                <button
                  type="button"
                  onClick={() => {
                    setContactTypeDraft(adminContact.type || 'wa');
                    setContactValueDraft(adminContact.value || '');
                    setContactError('');
                    setEditingContact(true);
                  }}
                  className="text-[11px] font-bold text-indigo-600 hover:underline"
                >
                  Ubah
                </button>
              )}
            </div>

            {!editingContact ? (
              <div className="space-y-2">
                {adminContact.value ? (
                  <div className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-50 border border-slate-200">
                    {adminContact.type === 'wa' ? (
                      <div className="p-2 rounded-lg bg-emerald-100 text-emerald-700 shrink-0">
                        <MessageCircle className="h-4 w-4" />
                      </div>
                    ) : (
                      <div className="p-2 rounded-lg bg-indigo-100 text-indigo-700 shrink-0">
                        <Mail className="h-4 w-4" />
                      </div>
                    )}
                    <div className="min-w-0">
                      <div className="text-[10px] font-bold uppercase text-slate-400">
                        {adminContact.type === 'wa' ? 'Nomor WA Admin' : 'Email Admin'}
                      </div>
                      <div className="text-xs font-bold text-slate-800 truncate">
                        {adminContact.value}
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-800 text-xs">
                    Belum diatur. Isi <b>Nomor WA</b> atau <b>Email Admin</b> (salah satu saja) untuk menerima pemberitahuan lupa username/password.
                  </div>
                )}
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  Menerima konfirmasi pemberitahuan apabila Guru/Pegawai atau Pimpinan lupa username/password.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSaveAdminContactInline} className="space-y-2.5">
                <div className="grid grid-cols-2 gap-1.5 bg-slate-100 p-1 rounded-lg">
                  <button
                    type="button"
                    onClick={() => {
                      setContactTypeDraft('wa');
                      setContactError('');
                    }}
                    className={`py-1.5 rounded-md text-[11px] font-bold flex items-center justify-center gap-1 transition ${
                      contactTypeDraft === 'wa'
                        ? 'bg-white text-emerald-700 shadow-xs'
                        : 'text-slate-500 hover:text-slate-700'
                    }`}
                  >
                    <MessageCircle className="h-3.5 w-3.5" />
                    Nomor WA
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setContactTypeDraft('email');
                      setContactError('');
                    }}
                    className={`py-1.5 rounded-md text-[11px] font-bold flex items-center justify-center gap-1 transition ${
                      contactTypeDraft === 'email'
                        ? 'bg-white text-indigo-700 shadow-xs'
                        : 'text-slate-500 hover:text-slate-700'
                    }`}
                  >
                    <Mail className="h-3.5 w-3.5" />
                    Email
                  </button>
                </div>

                <input
                  type={contactTypeDraft === 'email' ? 'email' : 'tel'}
                  value={contactValueDraft}
                  onChange={(e) => {
                    setContactValueDraft(e.target.value);
                    setContactError('');
                  }}
                  placeholder={
                    contactTypeDraft === 'wa'
                      ? 'Contoh: 081234567890'
                      : 'Contoh: admin@sekolah.sch.id'
                  }
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs font-medium focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
                />

                {contactError && (
                  <p className="text-[11px] font-semibold text-rose-600">{contactError}</p>
                )}

                <div className="flex items-center gap-2">
                  <button
                    type="submit"
                    className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white py-1.5 rounded-lg text-xs font-bold transition"
                  >
                    Simpan
                  </button>
                  <button
                    type="button"
                    onClick={() => setEditingContact(false)}
                    className="px-3 py-1.5 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 text-xs font-bold transition"
                  >
                    Batal
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>

      {/* Main Content Card with Tabs: Daftar Pengguna & Pemberitahuan Lupa Akun */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        {/* Section Header + Tabs */}
        <div className="border-b border-slate-200 px-5 py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50/70">
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => setActiveTab('users')}
              className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition ${
                activeTab === 'users'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              <Users className="h-4 w-4" />
              Daftar Pengguna ({users.length})
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('submissions')}
              className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition cursor-pointer ${
                activeTab === 'submissions'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              <CalendarDays className="h-4 w-4" />
              Absensi Pengguna ({adminSubmissions.length})
              {submissionsLocked && (
                <span
                  className={`inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-md text-[10px] font-black ${
                    activeTab === 'submissions'
                      ? 'bg-amber-400 text-slate-950'
                      : 'bg-amber-100 text-amber-900 border border-amber-300'
                  }`}
                  title={`Data terkunci ${lockConfig.submissionsLockMonths} bulan`}
                >
                  <Lock className="h-2.5 w-2.5" />
                  {lockConfig.submissionsLockMonths}B
                </span>
              )}
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('notifications')}
              className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition ${
                activeTab === 'notifications'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              <Bell className="h-4 w-4" />
              Notifikasi Lupa Akun
              {pendingNotifsCount > 0 && (
                <span
                  className={`px-1.5 py-0.5 rounded-md text-[10px] font-black ${
                    activeTab === 'notifications'
                      ? 'bg-white text-indigo-700'
                      : 'bg-rose-600 text-white'
                  }`}
                >
                  {pendingNotifsCount}
                </span>
              )}
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('registrations')}
              className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition ${
                activeTab === 'registrations'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              <Building2 className="h-4 w-4" />
              Pendaftaran Admin
              {pendingRegistrationsCount > 0 && (
                <span
                  className={`px-1.5 py-0.5 rounded-md text-[10px] font-black ${
                    activeTab === 'registrations'
                      ? 'bg-white text-indigo-700'
                      : 'bg-emerald-600 text-white'
                  }`}
                >
                  {pendingRegistrationsCount}
                </span>
              )}
            </button>
          </div>

          {activeTab === 'users' && (
            <button
              type="button"
              onClick={openAddUserModal}
              className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm transition"
            >
              <UserPlus className="h-4 w-4" />
              Tambah Pengguna
            </button>
          )}
        </div>

        {/* TAB 1: DAFTAR PENGGUNA */}
        {activeTab === 'users' && (
          <div className="p-5 space-y-4">
            {/* Bar Status Kunci Data Admin & Login Lintas Browser / HP */}
            <div
              className={`rounded-2xl border p-4 flex flex-col lg:flex-row lg:items-center justify-between gap-3 ${
                adminDataLocked
                  ? 'bg-emerald-50/80 border-emerald-200'
                  : 'bg-indigo-50/60 border-indigo-200'
              }`}
            >
              <div className="flex items-start gap-3">
                <div
                  className={`p-2 rounded-xl shrink-0 ${
                    adminDataLocked
                      ? 'bg-emerald-600 text-white'
                      : 'bg-indigo-600 text-white'
                  }`}
                >
                  <Smartphone className="h-5 w-5" />
                </div>
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="text-xs sm:text-sm font-black text-slate-900">
                      Login Pengguna Aktif di Semua Browser &amp; HP ({activeUsersCount}/{users.length} Aktif)
                    </h3>
                    <span
                      className={`px-2 py-0.5 rounded-md text-[10px] font-black uppercase ${
                        adminDataLocked
                          ? 'bg-emerald-600 text-white'
                          : 'bg-slate-200 text-slate-700'
                      }`}
                    >
                      {adminDataLocked ? 'DATA ADMIN TERKUNCI' : 'DATA ADMIN BELUM DIKUNCI'}
                    </span>
                  </div>
                  <p className="text-[11px] sm:text-xs text-slate-600 mt-0.5 leading-relaxed">
                    Seluruh akun pengguna yang berstatus <b>Aktif</b> otomatis disinkronkan ke server sehingga Guru/Pegawai &amp; Pimpinan dapat langsung login dari <b>browser mana saja termasuk HP/Gadget</b>, meskipun <b>Kunci Data Admin</b> diaktifkan.
                    {inactiveUsersCount > 0 && (
                      <span className="text-amber-700 font-bold">
                        {' '}
                        (Ada {inactiveUsersCount} akun berstatus Off — klik tombol di samping untuk mengaktifkan semua).
                      </span>
                    )}
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => onToggleAdminDataLock(!adminDataLocked)}
                  className={`px-3.5 py-2 rounded-xl text-xs font-black flex items-center gap-1.5 border transition cursor-pointer ${
                    adminDataLocked
                      ? 'bg-emerald-600 hover:bg-emerald-700 text-white border-emerald-700 shadow-xs'
                      : 'bg-white hover:bg-slate-100 text-slate-800 border-slate-300'
                  }`}
                >
                  {adminDataLocked ? (
                    <>
                      <Lock className="h-3.5 w-3.5" />
                      Buka Kunci Data Admin
                    </>
                  ) : (
                    <>
                      <LockOpen className="h-3.5 w-3.5 text-emerald-700" />
                      Kunci Data Admin
                    </>
                  )}
                </button>
                <button
                  type="button"
                  onClick={onActivateAllUsersForAllDevices}
                  className="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black flex items-center gap-1.5 shadow-xs transition cursor-pointer"
                >
                  <RefreshCw className="h-3.5 w-3.5" />
                  Aktifkan &amp; Sinkron Semua User
                </button>
              </div>
            </div>

            {/* Search & Role Filter */}
            <div className="flex flex-col sm:flex-row gap-3 justify-between">
              <div className="relative flex-1 max-w-md">
                <Search className="h-4 w-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Cari nama, NIP, jabatan, atau username..."
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 text-xs sm:text-sm focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
                />
              </div>

              <div className="flex items-center gap-1.5">
                {(['ALL', 'Guru/Pegawai', 'Pimpinan'] as const).map((rf) => (
                  <button
                    key={rf}
                    type="button"
                    onClick={() => setRoleFilter(rf)}
                    className={`px-3.5 py-2 rounded-xl text-xs font-bold transition ${
                      roleFilter === rf
                        ? 'bg-slate-900 text-white'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {rf === 'ALL' ? 'Semua Role' : rf}
                  </button>
                ))}
              </div>
            </div>

            {/* Users Table or Empty State */}
            {filteredUsers.length === 0 ? (
              <div className="border-2 border-dashed border-slate-200 rounded-2xl p-10 text-center space-y-3">
                <div className="inline-flex p-3 rounded-2xl bg-indigo-50 text-indigo-600">
                  <Users className="h-7 w-7" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-slate-800">
                    {users.length === 0
                      ? 'Belum Ada Pengguna Terdaftar'
                      : 'Tidak Ada Pengguna yang Cocok'}
                  </h3>
                  <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto">
                    {users.length === 0
                      ? 'Tambahkan akun untuk Guru/Pegawai atau Pimpinan agar mereka dapat masuk menggunakan Username dan Password masing-masing.'
                      : 'Coba ubah kata kunci pencarian atau filter role.'}
                  </p>
                </div>
                {users.length === 0 && (
                  <button
                    type="button"
                    onClick={openAddUserModal}
                    className="inline-flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-xl text-xs font-bold shadow-sm transition"
                  >
                    <UserPlus className="h-4 w-4" />
                    Tambah Pengguna Pertama
                  </button>
                )}
              </div>
            ) : (
              <div className="overflow-x-auto rounded-xl border border-slate-200">
                <table className="w-full text-left border-collapse min-w-[820px]">
                  <thead>
                    <tr className="bg-slate-100 text-[11px] font-black uppercase tracking-wider text-slate-600 border-b border-slate-200">
                      <th className="py-3 px-3.5 w-10 text-center">No</th>
                      <th className="py-3 px-3.5">Identitas Pegawai</th>
                      <th className="py-3 px-3.5">Status / Gol / Jabatan</th>
                      <th className="py-3 px-3.5">Role</th>
                      <th className="py-3 px-3.5">Akun Login</th>
                      <th className="py-3 px-3.5">Konfirmasi Admin</th>
                      <th className="py-3 px-3.5 text-right">Aksi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-xs">
                    {filteredUsers.map((u, idx) => {
                      const isPassVisible = Boolean(visiblePasswords[u.id]);
                      return (
                        <tr
                          key={u.id}
                          className={`hover:bg-slate-50/80 transition ${
                            !u.aktif ? 'opacity-60 bg-slate-50' : ''
                          }`}
                        >
                          <td className="py-3 px-3.5 text-center font-bold text-slate-500">
                            {idx + 1}
                          </td>
                          <td className="py-3 px-3.5">
                            <div className="font-bold text-slate-900 text-sm">{u.nama}</div>
                            <div className="font-mono text-[11px] text-slate-500 mt-0.5">
                              NIP: {u.nip || '-'}
                            </div>
                            {u.profileUpdatedBySelf && u.profileUpdatedAt && (
                              <div className="inline-flex items-center gap-1 mt-1 px-2 py-0.5 rounded bg-emerald-50 border border-emerald-200 text-[10px] font-bold text-emerald-700">
                                <CheckCircle2 className="h-3 w-3" />
                                Data Diri Diperbarui • {formatDateTimeId(u.profileUpdatedAt)}
                              </div>
                            )}
                          </td>
                          <td className="py-3 px-3.5">
                            <div className="font-semibold text-slate-800">
                              {u.statusPegawai}
                              {u.golRuang ? ` • ${u.golRuang}` : ''}
                            </div>
                            <div className="text-[11px] text-slate-500 mt-0.5">
                              {u.jabatan || '-'}
                            </div>
                          </td>
                          <td className="py-3 px-3.5">
                            <span
                              className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-extrabold ${
                                u.role === 'Pimpinan'
                                  ? 'bg-amber-100 text-amber-800 border border-amber-200'
                                  : 'bg-indigo-100 text-indigo-800 border border-indigo-200'
                              }`}
                            >
                              {u.role === 'Pimpinan' ? (
                                <Briefcase className="h-3 w-3" />
                              ) : (
                                <User className="h-3 w-3" />
                              )}
                              {u.role}
                            </span>
                            {!u.aktif && (
                              <div className="text-[10px] font-bold text-rose-600 mt-1">
                                Nonaktif
                              </div>
                            )}
                          </td>
                          <td className="py-3 px-3.5">
                            <div className="font-mono text-xs font-bold text-slate-800">
                              {u.username}
                            </div>
                            <div className="flex items-center gap-1.5 mt-0.5">
                              <span className="font-mono text-[11px] text-slate-500">
                                {isPassVisible ? u.password : '••••••••'}
                              </span>
                              <button
                                type="button"
                                onClick={() =>
                                  setVisiblePasswords((prev) => ({
                                    ...prev,
                                    [u.id]: !prev[u.id],
                                  }))
                                }
                                className="text-slate-400 hover:text-indigo-600"
                                title={isPassVisible ? 'Sembunyikan password' : 'Lihat password'}
                              >
                                {isPassVisible ? (
                                  <EyeOff className="h-3.5 w-3.5" />
                                ) : (
                                  <Eye className="h-3.5 w-3.5" />
                                )}
                              </button>
                            </div>
                          </td>
                          <td className="py-3 px-3.5">
                            <div className="inline-flex items-center gap-1.5 text-[11px] font-semibold text-slate-700 bg-slate-100 px-2.5 py-1 rounded-lg">
                              {u.konfirmasiTipe === 'wa' ? (
                                <MessageCircle className="h-3.5 w-3.5 text-emerald-600 shrink-0" />
                              ) : (
                                <Mail className="h-3.5 w-3.5 text-indigo-600 shrink-0" />
                              )}
                              <span className="max-w-[140px] truncate">{u.konfirmasiAdmin}</span>
                            </div>
                          </td>
                          <td className="py-3 px-3.5">
                            <div className="flex items-center justify-end gap-1">
                              <button
                                type="button"
                                onClick={() => handleCopyCredentials(u)}
                                className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 hover:text-indigo-600 transition"
                                title="Salin Username & Password"
                              >
                                <Copy className="h-4 w-4" />
                              </button>
                              <button
                                type="button"
                                onClick={() => openEditUserModal(u)}
                                className="p-1.5 rounded-lg text-slate-500 hover:bg-indigo-50 hover:text-indigo-600 transition"
                                title="Edit Pengguna / Reset Password"
                              >
                                <Edit3 className="h-4 w-4" />
                              </button>
                              <button
                                type="button"
                                onClick={() => handleToggleActive(u)}
                                className={`px-2 py-1 rounded-lg text-[10px] font-bold transition ${
                                  u.aktif
                                    ? 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
                                    : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
                                }`}
                                title={u.aktif ? 'Nonaktifkan akun' : 'Aktifkan akun'}
                              >
                                {u.aktif ? 'Aktif' : 'Off'}
                              </button>
                              {submissionsLocked || adminDataLocked ? (
                                <button
                                  type="button"
                                  onClick={() => {
                                    setShowMasterLockPanel(true);
                                    showToast(
                                      adminDataLocked
                                        ? 'Kunci Data Admin sedang aktif. Buka Kunci Data Admin terlebih dahulu jika Admin ingin menghapus akun pengguna.'
                                        : 'Gembok Data sedang aktif. Nonaktifkan Kunci terlebih dahulu jika Admin ingin menghapus akun pengguna.'
                                    );
                                  }}
                                  className="p-1.5 rounded-lg bg-amber-50 text-amber-700 border border-amber-200 hover:bg-amber-100 transition cursor-pointer"
                                  title="Data pengguna dilindungi Kunci Data Admin / Gembok Kunci. Klik untuk mengatur kunci."
                                >
                                  <Lock className="h-3.5 w-3.5" />
                                </button>
                              ) : confirmDeleteId === u.id ? (
                                <div className="flex items-center gap-1 bg-rose-50 px-1.5 py-0.5 rounded-lg border border-rose-200">
                                  <button
                                    type="button"
                                    onClick={() => {
                                      onDeleteUser(u.id);
                                      setConfirmDeleteId(null);
                                      showToast(`Pengguna "${u.nama}" dihapus`);
                                    }}
                                    className="text-[10px] font-black text-rose-700 hover:underline px-1 cursor-pointer"
                                  >
                                    Hapus
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => setConfirmDeleteId(null)}
                                    className="text-[10px] font-bold text-slate-500 px-1 cursor-pointer"
                                  >
                                    Batal
                                  </button>
                                </div>
                              ) : (
                                <button
                                  type="button"
                                  onClick={() => setConfirmDeleteId(u.id)}
                                  className="p-1.5 rounded-lg text-slate-400 hover:bg-rose-50 hover:text-rose-600 transition cursor-pointer"
                                  title="Hapus Pengguna"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {/* TAB 2: ABSENSI PENGGUNA (TERSIMPAN OTOMATIS PER PENGGUNA, HARI, BULAN, TAHUN) */}
        {activeTab === 'submissions' && (
          <div className="p-5 space-y-5">
            {/* Panel Gembok / Kunci Data Absensi & Masa Simpan (Hak Penuh Admin: 1, 3, 6 Bulan / 1 Semester) */}
            <div
              className={`rounded-2xl border p-4 space-y-3 transition ${
                submissionsLocked
                  ? 'bg-amber-50/90 border-amber-300'
                  : 'bg-slate-50 border-slate-200'
              }`}
            >
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
                <div className="flex items-start gap-3">
                  <div
                    className={`p-2.5 rounded-xl shrink-0 ${
                      submissionsLocked
                        ? 'bg-amber-500 text-white shadow-sm'
                        : 'bg-slate-800 text-amber-300'
                    }`}
                  >
                    {submissionsLocked ? (
                      <Lock className="h-5 w-5" />
                    ) : (
                      <LockOpen className="h-5 w-5" />
                    )}
                  </div>
                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="text-xs sm:text-sm font-black uppercase tracking-wider text-slate-900">
                        Kunci Data &amp; File Absensi Pengguna (Maks. 6 Bulan / 1 Semester)
                      </h3>
                      <span
                        className={`px-2 py-0.5 rounded-md text-[10px] font-black uppercase ${
                          submissionsLocked
                            ? 'bg-amber-600 text-white'
                            : 'bg-slate-200 text-slate-700'
                        }`}
                      >
                        {submissionsLocked
                          ? `TERKUNCI ${lockConfig.submissionsLockMonths} BULAN`
                          : 'BELUM DIKUNCI'}
                      </span>
                    </div>
                    <p className="text-[11px] sm:text-xs text-slate-600 mt-0.5 leading-relaxed">
                      {submissionsLocked ? (
                        <>
                          Total <b>{adminSubmissions.length} file absensi</b> terkunci aman
                          {submissionsLockedUntilLabel
                            ? ` sampai ${submissionsLockedUntilLabel}`
                            : ''}
                          . Jumlah tidak dapat berkurang atau terhapus tanpa sengaja — hanya bertambah saat pengguna mengirim absen baru. Admin memegang kendali penuh untuk membuka kunci.
                        </>
                      ) : (
                        <>
                          Aktifkan gembok kunci untuk menjaga <b>{adminSubmissions.length} file absensi</b> yang masuk agar tidak hilang atau terhapus tanpa sengaja. Masa simpan mendukung penuh hingga <b>6 bulan (1 semester)</b>.
                        </>
                      )}
                    </p>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-1.5 shrink-0">
                  {([1, 3, 6] as const).map((months) => {
                    const isActive =
                      submissionsLocked && lockConfig.submissionsLockMonths === months;
                    return (
                      <button
                        key={months}
                        type="button"
                        onClick={() => {
                          onUpdateSubmissionsLock(months);
                          setConfirmDeleteSubId(null);
                        }}
                        className={`px-3 py-2 rounded-xl text-xs font-black flex items-center gap-1.5 border transition cursor-pointer ${
                          isActive
                            ? 'bg-amber-600 text-white border-amber-700 shadow-sm'
                            : 'bg-white hover:bg-amber-100 text-slate-800 border-amber-300'
                        }`}
                      >
                        <Lock className="h-3.5 w-3.5" />
                        {months === 6 ? 'Kunci 6 Bln (1 Semester)' : `Kunci ${months} Bulan`}
                      </button>
                    );
                  })}

                  <button
                    type="button"
                    onClick={() => onUpdateSubmissionsLock(0)}
                    className={`px-3 py-2 rounded-xl text-xs font-black flex items-center gap-1.5 border transition cursor-pointer ${
                      !submissionsLocked
                        ? 'bg-slate-900 text-white border-slate-900 shadow-sm'
                        : 'bg-white hover:bg-rose-50 text-rose-700 border-rose-300'
                    }`}
                  >
                    <LockOpen className="h-3.5 w-3.5" />
                    Nonaktifkan Kunci
                  </button>
                </div>
              </div>
            </div>

            {/* Filter Toolbar */}
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <h3 className="text-xs font-black uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                    <FolderOpen className="h-4 w-4 text-indigo-600" />
                    Arsip Absensi Kiriman Guru/Pegawai (Urut Nama A–Z • Filter Tanggal • Bulan • Tahun)
                  </h3>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Total <b>{adminSubmissions.length}</b> data absensi tersimpan permanen (kapasitas aktif hingga {lockConfig.retentionMonths} bulan). Ditampilkan <b>{filteredSubmissions.length}</b> sesuai filter.
                  </p>
                </div>
                {filteredSubmissions.length > 0 && (
                  <button
                    type="button"
                    onClick={() => {
                      const targetBulan =
                        subMonthFilter !== 'ALL'
                          ? parseInt(subMonthFilter, 10)
                          : filteredSubmissions[0].bulan;
                      const targetTahun =
                        subYearFilter !== 'ALL'
                          ? parseInt(subYearFilter, 10)
                          : filteredSubmissions[0].tahun;
                      const matchingMonthSubs = filteredSubmissions.filter(
                        (s) => s.bulan === targetBulan && s.tahun === targetTahun
                      );
                      onImportSubmissionsToMonthly(
                        matchingMonthSubs.length > 0 ? matchingMonthSubs : filteredSubmissions,
                        targetBulan,
                        targetTahun
                      );
                    }}
                    className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm transition shrink-0"
                  >
                    <BarChart3 className="h-3.5 w-3.5" />
                    Tarik ke Rekap Bulanan
                  </button>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                <select
                  value={subUserFilter}
                  onChange={(e) => setSubUserFilter(e.target.value)}
                  className="px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs font-semibold text-slate-800 outline-none focus:border-indigo-600"
                >
                  <option value="ALL">Semua Pengguna ({submissionUserOptions.length})</option>
                  {submissionUserOptions.map((opt) => (
                    <option key={opt.id} value={opt.id}>
                      {opt.nama}
                    </option>
                  ))}
                </select>

                <select
                  value={subMonthFilter}
                  onChange={(e) => setSubMonthFilter(e.target.value)}
                  className="px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs font-semibold text-slate-800 outline-none focus:border-indigo-600"
                >
                  <option value="ALL">Semua Bulan</option>
                  {INDONESIAN_MONTHS.map((m, i) => (
                    <option key={m} value={String(i + 1)}>
                      {m}
                    </option>
                  ))}
                </select>

                <select
                  value={subYearFilter}
                  onChange={(e) => setSubYearFilter(e.target.value)}
                  className="px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs font-semibold text-slate-800 outline-none focus:border-indigo-600"
                >
                  <option value="ALL">Semua Tahun</option>
                  {submissionYears.map((yr) => (
                    <option key={yr} value={String(yr)}>
                      Tahun {yr}
                    </option>
                  ))}
                </select>

                <div className="flex items-center gap-1.5">
                  <input
                    type="date"
                    value={subDateFilter}
                    onChange={(e) => setSubDateFilter(e.target.value)}
                    className="flex-1 px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs font-semibold text-slate-800 outline-none focus:border-indigo-600"
                    title="Filter berdasarkan hari/tanggal tertentu"
                  />
                  {(subUserFilter !== 'ALL' ||
                    subMonthFilter !== 'ALL' ||
                    subYearFilter !== 'ALL' ||
                    subDateFilter) && (
                    <button
                      type="button"
                      onClick={() => {
                        setSubUserFilter('ALL');
                        setSubMonthFilter('ALL');
                        setSubYearFilter('ALL');
                        setSubDateFilter('');
                      }}
                      className="px-2.5 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-700 text-[11px] font-bold transition"
                      title="Reset semua filter"
                    >
                      Reset
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* Grouped Cards per User -> Month/Year -> Day */}
            {groupedSubmissions.length === 0 ? (
              <div className="border-2 border-dashed border-slate-200 rounded-2xl p-10 text-center space-y-2">
                <CalendarDays className="h-8 w-8 text-slate-300 mx-auto" />
                <h3 className="text-sm font-black text-slate-800">
                  {adminSubmissions.length === 0
                    ? 'Belum Ada Absensi yang Dikirim ke Admin'
                    : 'Tidak Ada Data Absensi Sesuai Filter'}
                </h3>
                <p className="text-xs text-slate-500 max-w-md mx-auto">
                  {adminSubmissions.length === 0
                    ? 'Saat Guru/Pegawai menekan tombol "Simpan ke Admin" dari halaman Cetak Kartu atau menu Riwayat, data absensi akan tersimpan otomatis di sini per pengguna, hari, bulan, dan tahun.'
                    : 'Ubah filter pengguna, bulan, tahun, atau tanggal untuk melihat data lainnya.'}
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {groupedSubmissions.map((grp) => (
                  <div
                    key={grp.userKey}
                    className="rounded-2xl border border-slate-200 overflow-hidden bg-white shadow-xs"
                  >
                    {/* User Group Header */}
                    <div className="bg-indigo-50/70 border-b border-indigo-100 px-5 py-3.5 flex flex-col md:flex-row md:items-center justify-between gap-3">
                      <div>
                        <div className="flex flex-wrap items-center gap-2">
                          <h4 className="text-sm font-black text-slate-900">{grp.nama}</h4>
                          <span className="px-2 py-0.5 rounded-md bg-indigo-600 text-white text-[10px] font-bold">
                            {grp.statusPegawai}
                          </span>
                          {grp.golRuang && (
                            <span className="px-2 py-0.5 rounded-md bg-white border border-indigo-200 text-indigo-800 text-[10px] font-bold">
                              Gol: {grp.golRuang}
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-slate-600 mt-0.5">
                          NIP: <span className="font-mono">{grp.nip || '-'}</span> •{' '}
                          {grp.jabatan || '-'}
                        </p>
                      </div>

                      {/* Quick Attendance Tally for this User */}
                      <div className="flex flex-wrap items-center gap-1.5 text-[11px] font-black">
                        <span className="px-2.5 py-1 rounded-lg bg-emerald-100 text-emerald-800">
                          H: {grp.counts.h}
                        </span>
                        <span className="px-2.5 py-1 rounded-lg bg-sky-100 text-sky-800">
                          TD: {grp.counts.td}
                        </span>
                        <span className="px-2.5 py-1 rounded-lg bg-amber-100 text-amber-800">
                          I: {grp.counts.i}
                        </span>
                        <span className="px-2.5 py-1 rounded-lg bg-orange-100 text-orange-800">
                          S: {grp.counts.s}
                        </span>
                        <span className="px-2.5 py-1 rounded-lg bg-rose-100 text-rose-800">
                          TK: {grp.counts.tk}
                        </span>
                        <span className="px-2.5 py-1 rounded-lg bg-slate-900 text-white">
                          Total: {grp.total} hari
                        </span>
                      </div>
                    </div>

                    {/* Month & Year Sub-groups */}
                    <div className="divide-y divide-slate-100">
                      {grp.months.map((mBucket) => (
                        <div key={mBucket.key} className="p-4 space-y-2.5">
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-black uppercase tracking-wider text-indigo-700 flex items-center gap-1.5">
                              <CalendarDays className="h-3.5 w-3.5" />
                              {mBucket.label}
                            </span>
                            <span className="text-[11px] font-bold text-slate-500">
                              {mBucket.items.length} hari tercatat
                            </span>
                          </div>

                          <div className="space-y-2">
                            {mBucket.items.map((sub) => (
                              <div
                                key={sub.id}
                                className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3 rounded-xl bg-slate-50 border border-slate-200/80 hover:border-indigo-300 transition"
                              >
                                <div className="flex items-center gap-3">
                                  <div className="flex -space-x-2.5 shrink-0">
                                    <img
                                      src={sub.fotoMasuk}
                                      alt="Masuk"
                                      className="h-11 w-11 rounded-lg object-cover ring-2 ring-white border border-slate-200"
                                    />
                                    <img
                                      src={sub.fotoKeluar}
                                      alt="Pulang"
                                      className="h-11 w-11 rounded-lg object-cover ring-2 ring-white border border-slate-200"
                                    />
                                  </div>
                                  <div>
                                    <div className="flex flex-wrap items-center gap-2">
                                      <span className="text-xs font-black text-slate-900">
                                        {sub.hari}, {String(sub.tanggalHari).padStart(2, '0')}{' '}
                                        {INDONESIAN_MONTHS[sub.bulan - 1]} {sub.tahun}
                                      </span>
                                      <span className="px-2 py-0.5 rounded-md text-[10px] font-black bg-indigo-100 text-indigo-800">
                                        {sub.statusKehadiran}
                                      </span>
                                    </div>
                                    <div className="text-[11px] text-slate-500 mt-0.5">
                                      {sub.catatan || 'Tidak ada catatan tambahan'} • Dikirim{' '}
                                      {formatDateTimeId(sub.submittedAt)}
                                    </div>
                                  </div>
                                </div>

                                <div className="flex items-center gap-2 self-end sm:self-center">
                                  <button
                                    type="button"
                                    onClick={() => onOpenSubmissionCard(sub)}
                                    className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold flex items-center gap-1.5 transition"
                                  >
                                    <Eye className="h-3.5 w-3.5" />
                                    Buka Kartu
                                  </button>
                                  {submissionsLocked ? (
                                    <button
                                      type="button"
                                      onClick={() =>
                                        showToast(
                                          `File absensi ini sedang terkunci (${lockConfig.submissionsLockMonths} Bulan). Klik "Nonaktifkan Kunci" di bagian atas jika Admin ingin menghapus.`
                                        )
                                      }
                                      className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 text-[11px] font-bold transition cursor-pointer"
                                      title="Data & file absensi terkunci. Nonaktifkan kunci terlebih dahulu untuk menghapus."
                                    >
                                      <Lock className="h-3.5 w-3.5" />
                                      Terkunci
                                    </button>
                                  ) : confirmDeleteSubId === sub.id ? (
                                    <div className="flex items-center gap-1 bg-rose-50 px-2 py-1 rounded-lg border border-rose-200">
                                      <button
                                        type="button"
                                        onClick={() => {
                                          onDeleteSubmission(sub.id);
                                          setConfirmDeleteSubId(null);
                                          showToast('Data absensi dihapus dari arsip Admin');
                                        }}
                                        className="text-[10px] font-black text-rose-700 px-1 cursor-pointer"
                                      >
                                        Hapus
                                      </button>
                                      <button
                                        type="button"
                                        onClick={() => setConfirmDeleteSubId(null)}
                                        className="text-[10px] font-bold text-slate-500 px-1 cursor-pointer"
                                      >
                                        Batal
                                      </button>
                                    </div>
                                  ) : (
                                    <button
                                      type="button"
                                      onClick={() => setConfirmDeleteSubId(sub.id)}
                                      className="p-1.5 rounded-lg text-slate-400 hover:bg-rose-50 hover:text-rose-600 transition cursor-pointer"
                                      title="Hapus dari arsip Admin"
                                    >
                                      <Trash2 className="h-4 w-4" />
                                    </button>
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 3: PEMBERITAHUAN KONFIRMASI LUPA USERNAME / PASSWORD */}
        {activeTab === 'notifications' && (
          <div className="p-5 space-y-4">
            <div className="p-3.5 rounded-xl bg-indigo-50 border border-indigo-200 text-xs text-indigo-900 flex items-start gap-2.5">
              <Bell className="h-4 w-4 text-indigo-600 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold">Pusat Pemberitahuan Lupa Username / Password:</span>{' '}
                Setiap permintaan bantuan lupa akun dari Guru/Pegawai atau Pimpinan di halaman Login akan tercatat otomatis di sini sekaligus diarahkan ke{' '}
                <b>
                  {adminContact.value
                    ? `${adminContact.type === 'wa' ? 'Nomor WA' : 'Email'} Admin (${adminContact.value})`
                    : 'Email / Nomor WA Konfirmasi Admin'}
                </b>
                .
              </div>
            </div>

            {recoveryNotifications.length === 0 ? (
              <div className="border-2 border-dashed border-slate-200 rounded-2xl p-10 text-center space-y-2">
                <CheckCircle2 className="h-8 w-8 text-emerald-500 mx-auto" />
                <h3 className="text-sm font-black text-slate-800">
                  Belum Ada Permintaan Lupa Username / Password
                </h3>
                <p className="text-xs text-slate-500 max-w-md mx-auto">
                  Jika ada Guru/Pegawai atau Pimpinan yang menekan &quot;Lupa Username / Password?&quot; saat login, pemberitahuannya akan muncul di sini.
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {recoveryNotifications.map((notif) => {
                  const matchedUser = notif.matchedUserId
                    ? users.find((u) => u.id === notif.matchedUserId)
                    : undefined;
                  const jenisLabel =
                    notif.jenisLupa === 'password'
                      ? 'Lupa Password'
                      : notif.jenisLupa === 'username'
                      ? 'Lupa Username'
                      : 'Lupa Username & Password';

                  return (
                    <div
                      key={notif.id}
                      className={`p-4 rounded-xl border transition flex flex-col md:flex-row md:items-center justify-between gap-4 ${
                        notif.status === 'menunggu'
                          ? 'bg-amber-50/60 border-amber-200'
                          : 'bg-slate-50 border-slate-200 opacity-80'
                      }`}
                    >
                      <div className="space-y-1.5">
                        <div className="flex flex-wrap items-center gap-2">
                          <span
                            className={`px-2 py-0.5 rounded-md text-[10px] font-black uppercase ${
                              notif.status === 'menunggu'
                                ? 'bg-rose-600 text-white'
                                : 'bg-emerald-600 text-white'
                            }`}
                          >
                            {notif.status === 'menunggu' ? 'Menunggu Konfirmasi' : 'Selesai'}
                          </span>
                          <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-indigo-100 text-indigo-800">
                            {jenisLabel}
                          </span>
                          <span className="text-[11px] text-slate-500">
                            {formatDateTimeId(notif.createdAt)}
                          </span>
                        </div>

                        <div className="text-sm font-black text-slate-900">
                          {notif.namaPemohon}
                          {notif.matchedRole && (
                            <span className="ml-2 text-[11px] font-bold text-slate-500">
                              ({notif.matchedRole})
                            </span>
                          )}
                        </div>

                        {notif.nipAtauInfo && (
                          <div className="text-xs text-slate-600">
                            NIP / Info: <span className="font-mono">{notif.nipAtauInfo}</span>
                          </div>
                        )}
                        {notif.catatan && (
                          <div className="text-xs text-slate-600 italic">
                            &ldquo;{notif.catatan}&rdquo;
                          </div>
                        )}

                        <div className="text-[11px] text-slate-500 flex items-center gap-1.5 pt-0.5">
                          {notif.saluranTujuan === 'wa' ? (
                            <MessageCircle className="h-3.5 w-3.5 text-emerald-600" />
                          ) : (
                            <Mail className="h-3.5 w-3.5 text-indigo-600" />
                          )}
                          <span>
                            Tujuan Konfirmasi:{' '}
                            <strong className="text-slate-700">
                              {notif.kontakAdminTujuan || 'Dashboard Admin'}
                            </strong>
                          </span>
                        </div>
                      </div>

                      <div className="flex flex-wrap items-center gap-2 shrink-0">
                        {matchedUser && (
                          <>
                            <button
                              type="button"
                              onClick={() => openEditUserModal(matchedUser)}
                              className="px-3 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold flex items-center gap-1.5 transition"
                            >
                              <KeyRound className="h-3.5 w-3.5" />
                              Reset / Edit Akun
                            </button>
                            <button
                              type="button"
                              onClick={() => handleCopyCredentials(matchedUser)}
                              className="px-3 py-2 rounded-lg bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 text-xs font-bold flex items-center gap-1.5 transition"
                            >
                              <Copy className="h-3.5 w-3.5" />
                              Salin Login
                            </button>
                          </>
                        )}
                        {notif.status === 'menunggu' && (
                          <button
                            type="button"
                            onClick={() => {
                              onMarkNotificationDone(notif.id);
                              showToast('Pemberitahuan ditandai selesai');
                            }}
                            className="px-3 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 transition"
                          >
                            <Check className="h-3.5 w-3.5" />
                            Selesai
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => {
                            onDeleteNotification(notif.id);
                            showToast('Notifikasi dihapus');
                          }}
                          className="p-2 rounded-lg text-slate-400 hover:bg-rose-50 hover:text-rose-600 transition"
                          title="Hapus notifikasi"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* TAB 4: PENDAFTARAN CALON ADMIN (1 SEKOLAH / DINAS) + BALAS WA OTOMATIS */}
        {activeTab === 'registrations' && (
          <div className="p-5 space-y-4">
            <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-950 flex items-start gap-2.5">
              <MessageCircle className="h-4 w-4 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold">Daftar Pendaftaran Calon Admin Sekolah / Satuan Dinas:</span>{' '}
                Klik tombol <b>Balas ke WA Calon User</b> untuk langsung mengirim pesan konfirmasi otomatis:{' '}
                <span className="italic font-semibold">
                  &ldquo;{REGISTRATION_AUTO_REPLY}&rdquo;
                </span>
              </div>
            </div>

            {adminRegistrations.length === 0 ? (
              <div className="border-2 border-dashed border-slate-200 rounded-2xl p-10 text-center space-y-2">
                <Building2 className="h-8 w-8 text-slate-400 mx-auto" />
                <h3 className="text-sm font-black text-slate-800">
                  Belum Ada Pendaftaran Calon Admin Masuk
                </h3>
                <p className="text-xs text-slate-500 max-w-md mx-auto">
                  Apabila ada calon Admin sekolah atau satuan dinas mendaftar melalui tombol Registrasi di halaman Login, datanya akan tercatat otomatis di sini.
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {adminRegistrations.map((reg) => {
                  const waReplyHref = `https://wa.me/${formatWaNumber(
                    reg.noWa
                  )}?text=${encodeURIComponent(REGISTRATION_AUTO_REPLY)}`;

                  return (
                    <div
                      key={reg.id}
                      className={`p-4 rounded-xl border transition flex flex-col lg:flex-row lg:items-center justify-between gap-4 ${
                        reg.status === 'menunggu'
                          ? 'bg-emerald-50/40 border-emerald-200'
                          : 'bg-slate-50 border-slate-200 opacity-85'
                      }`}
                    >
                      <div className="space-y-1.5 min-w-0">
                        <div className="flex flex-wrap items-center gap-2">
                          <span
                            className={`px-2 py-0.5 rounded-md text-[10px] font-black uppercase ${
                              reg.status === 'menunggu'
                                ? 'bg-amber-500 text-white'
                                : 'bg-emerald-600 text-white'
                            }`}
                          >
                            {reg.status === 'menunggu'
                              ? 'Menunggu Balasan WA'
                              : 'Sudah Dihubungi'}
                          </span>
                          <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-indigo-100 text-indigo-800">
                            Calon Admin Sekolah / Dinas
                          </span>
                          <span className="text-[11px] text-slate-500">
                            {formatDateTimeId(reg.createdAt)}
                          </span>
                        </div>

                        <div className="text-sm font-black text-slate-900">
                          {reg.nama}{' '}
                          <span className="font-semibold text-indigo-700">
                            — {reg.lembaga}
                          </span>
                        </div>

                        <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-600">
                          {reg.nip && (
                            <span className="font-mono">NIP: {reg.nip}</span>
                          )}
                          <span>Jabatan: {reg.jabatan || '-'}</span>
                          {reg.golRuang && <span>Gol: {reg.golRuang}</span>}
                          <span className="font-semibold text-emerald-700">
                            WA: {reg.noWa}
                          </span>
                          {reg.email && <span>Email: {reg.email}</span>}
                          <span className="font-mono text-slate-700">
                            Usulan User: @{reg.username}
                          </span>
                        </div>
                      </div>

                      <div className="flex flex-wrap items-center gap-2 shrink-0">
                        <a
                          href={waReplyHref}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={() => {
                            if (reg.status === 'menunggu') {
                              onMarkRegistrationContacted(reg.id);
                            }
                            showToast(
                              `Membuka WA ${reg.nama} dengan pesan konfirmasi otomatis`
                            );
                          }}
                          className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black flex items-center gap-1.5 shadow-sm transition whitespace-nowrap"
                        >
                          <MessageCircle className="h-3.5 w-3.5" />
                          Balas ke WA Calon User
                          <ExternalLink className="h-3 w-3" />
                        </a>

                        <button
                          type="button"
                          onClick={() => {
                            if (navigator.clipboard) {
                              navigator.clipboard
                                .writeText(REGISTRATION_AUTO_REPLY)
                                .then(() => {
                                  showToast(
                                    'Pesan konfirmasi otomatis disalin ke clipboard'
                                  );
                                });
                            }
                          }}
                          className="px-3 py-2 rounded-xl bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 text-xs font-bold flex items-center gap-1.5 transition"
                        >
                          <Copy className="h-3.5 w-3.5" />
                          Salin Balasan
                        </button>

                        {reg.status === 'menunggu' && (
                          <button
                            type="button"
                            onClick={() => {
                              onMarkRegistrationContacted(reg.id);
                              showToast('Pendaftaran ditandai sudah dihubungi');
                            }}
                            className="px-3 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold flex items-center gap-1.5 transition"
                          >
                            <Check className="h-3.5 w-3.5" />
                            Selesai
                          </button>
                        )}

                        <button
                          type="button"
                          onClick={() => {
                            onDeleteRegistration(reg.id);
                            showToast('Data pendaftaran dihapus');
                          }}
                          className="p-2 rounded-xl text-slate-400 hover:bg-rose-50 hover:text-rose-600 transition"
                          title="Hapus data pendaftaran"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>

      {/* ================================================================= */}
      {/* MODAL TAMBAH / EDIT PENGGUNA (Format Form Absensi + Login + WA/Email) */}
      {/* ================================================================= */}
      {isUserModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 p-4 backdrop-blur-xs animate-fadeIn">
          <div className="relative w-full max-w-3xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
            {/* Modal Header */}
            <div className="bg-indigo-800 px-6 py-4 text-white flex items-center justify-between shrink-0">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-xl bg-white/15">
                  <UserPlus className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h3 className="text-base font-black uppercase tracking-tight">
                    {editingUserId ? 'Edit Data Pengguna' : 'Tambah Pengguna Baru'}
                  </h3>
                  <p className="text-[11px] text-indigo-200">
                    Format mengikuti Form Absensi • Role khusus Guru/Pegawai &amp; Pimpinan
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsUserModalOpen(false)}
                className="p-1.5 rounded-lg text-indigo-200 hover:bg-white/15 hover:text-white transition"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Modal Body */}
            <form onSubmit={handleSubmitUser} className="overflow-y-auto p-6 space-y-6">
              {formError && (
                <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold flex items-center gap-2">
                  <AlertCircle className="h-4 w-4 shrink-0" />
                  <span>{formError}</span>
                </div>
              )}

              {/* BAGIAN 1: DATA PEGAWAI (Sesuai Format Form Absensi, tanpa Status Kehadiran, Hari/Tanggal, Catatan) */}
              <div className="space-y-4">
                <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
                  <span className="h-6 w-6 rounded-lg bg-indigo-100 text-indigo-700 text-xs font-black flex items-center justify-center">
                    1
                  </span>
                  <h4 className="text-xs font-black uppercase tracking-wider text-slate-700">
                    Data Identitas Pengguna (Format Form Absensi)
                  </h4>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1.5 md:col-span-2">
                    <label className="text-xs font-bold text-slate-700 flex items-center gap-1">
                      <User className="h-3.5 w-3.5 text-indigo-600" />
                      Nama Lengkap <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={nama}
                      onChange={(e) => setNama(e.target.value)}
                      onBlur={() => {
                        if (!username.trim() && nama.trim()) {
                          handleAutoFillUsernameFromName();
                        }
                      }}
                      className="block w-full rounded-xl border border-slate-300 p-3 text-sm font-semibold text-slate-900 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
                      placeholder="Nama Guru / Pegawai / Pimpinan (contoh: Agusthinus Kese, S.Pd.Gr)"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-700">
                      NIP / ID Pegawai (Opsional)
                    </label>
                    <input
                      type="text"
                      value={nip}
                      onChange={(e) => setNip(e.target.value)}
                      className="block w-full rounded-xl border border-slate-300 p-3 text-sm font-mono text-slate-900 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
                      placeholder="Nomor Induk Pegawai"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-700">Gol. Ruang</label>
                    <input
                      type="text"
                      value={golRuang}
                      onChange={(e) => setGolRuang(e.target.value)}
                      className="block w-full rounded-xl border border-slate-300 p-3 text-sm font-semibold text-slate-900 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
                      placeholder="Isi Gol. Ruang (contoh: IV/a, III/b, dll.)"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-700">Status Pegawai</label>
                    <select
                      value={statusPegawai}
                      onChange={(e) => setStatusPegawai(e.target.value as StatusPegawai)}
                      className="block w-full rounded-xl border border-slate-300 p-3 text-sm font-bold bg-white text-slate-800 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
                    >
                      {STATUS_PEGAWAI_OPTIONS.map((opt) => (
                        <option key={opt.value} value={opt.value}>
                          {opt.label}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-700">
                      Jabatan / Unit Tugas (Opsional)
                    </label>
                    <input
                      type="text"
                      value={jabatan}
                      onChange={(e) => setJabatan(e.target.value)}
                      className="block w-full rounded-xl border border-slate-300 p-3 text-sm text-slate-900 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
                      placeholder="Contoh: Guru Kelas / Kepala Sekolah"
                    />
                  </div>
                </div>
              </div>

              {/* BAGIAN 2: ROLE (HANYA 2 PILIHAN) & DATA LOGIN */}
              <div className="space-y-4">
                <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
                  <span className="h-6 w-6 rounded-lg bg-indigo-100 text-indigo-700 text-xs font-black flex items-center justify-center">
                    2
                  </span>
                  <h4 className="text-xs font-black uppercase tracking-wider text-slate-700">
                    Role Pengguna &amp; Data Login
                  </h4>
                </div>

                {/* Role Selector — STRICTLY ONLY 2 OPTIONS: Guru/Pegawai & Pimpinan */}
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-700">
                    Pilih Role Pengguna <span className="text-rose-500">*</span>
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() => setRole('Guru/Pegawai')}
                      className={`p-3.5 rounded-xl border-2 text-left transition flex items-start gap-3 ${
                        role === 'Guru/Pegawai'
                          ? 'border-indigo-600 bg-indigo-50/70'
                          : 'border-slate-200 hover:border-slate-300 bg-white'
                      }`}
                    >
                      <div
                        className={`p-2 rounded-lg shrink-0 ${
                          role === 'Guru/Pegawai'
                            ? 'bg-indigo-600 text-white'
                            : 'bg-slate-100 text-slate-500'
                        }`}
                      >
                        <User className="h-4 w-4" />
                      </div>
                      <div>
                        <div className="text-sm font-black text-slate-900">Guru/Pegawai</div>
                        <div className="text-[11px] text-slate-500 mt-0.5">
                          Mengisi Form Absensi harian, cetak kartu &amp; riwayat pribadi.
                        </div>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setRole('Pimpinan')}
                      className={`p-3.5 rounded-xl border-2 text-left transition flex items-start gap-3 ${
                        role === 'Pimpinan'
                          ? 'border-amber-500 bg-amber-50/70'
                          : 'border-slate-200 hover:border-slate-300 bg-white'
                      }`}
                    >
                      <div
                        className={`p-2 rounded-lg shrink-0 ${
                          role === 'Pimpinan'
                            ? 'bg-amber-500 text-white'
                            : 'bg-slate-100 text-slate-500'
                        }`}
                      >
                        <Briefcase className="h-4 w-4" />
                      </div>
                      <div>
                        <div className="text-sm font-black text-slate-900">Pimpinan</div>
                        <div className="text-[11px] text-slate-500 mt-0.5">
                          Akses Form Absensi, Laporan Disiplin Harian &amp; Rekap Bulanan.
                        </div>
                      </div>
                    </button>
                  </div>
                </div>

                {/* Username & Password */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-bold text-slate-700 flex items-center gap-1">
                        <Lock className="h-3.5 w-3.5 text-indigo-600" />
                        Username <span className="text-rose-500">*</span>
                      </label>
                      {nama.trim() && (
                        <button
                          type="button"
                          onClick={handleAutoFillUsernameFromName}
                          className="text-[10px] font-bold text-indigo-600 hover:underline"
                        >
                          Saran dari nama
                        </button>
                      )}
                    </div>
                    <input
                      type="text"
                      value={username}
                      onChange={(e) => setUsername(e.target.value.replace(/\s+/g, ''))}
                      className="block w-full rounded-xl border border-slate-300 p-3 text-sm font-mono font-semibold text-slate-900 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
                      placeholder="Contoh: agusthinus.kese"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-bold text-slate-700 flex items-center gap-1">
                        <KeyRound className="h-3.5 w-3.5 text-indigo-600" />
                        Password <span className="text-rose-500">*</span>
                      </label>
                      <button
                        type="button"
                        onClick={() => {
                          setPassword(generateRandomPassword());
                          setShowModalPassword(true);
                        }}
                        className="text-[10px] font-bold text-indigo-600 hover:underline flex items-center gap-1"
                      >
                        <RefreshCw className="h-3 w-3" />
                        Buat Acak
                      </button>
                    </div>
                    <div className="relative">
                      <input
                        type={showModalPassword ? 'text' : 'password'}
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="block w-full rounded-xl border border-slate-300 p-3 pr-10 text-sm font-mono font-semibold text-slate-900 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
                        placeholder="Minimal 4 karakter"
                      />
                      <button
                        type="button"
                        onClick={() => setShowModalPassword((v) => !v)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700"
                      >
                        {showModalPassword ? (
                          <EyeOff className="h-4 w-4" />
                        ) : (
                          <Eye className="h-4 w-4" />
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* BAGIAN 3: EMAIL / NOMOR WA KONFIRMASI ADMIN (PILIH SALAH SATU SAJA) */}
              <div className="space-y-3 bg-slate-50 p-4 rounded-2xl border border-slate-200">
                <div className="flex items-center gap-2">
                  <span className="h-6 w-6 rounded-lg bg-emerald-100 text-emerald-700 text-xs font-black flex items-center justify-center">
                    3
                  </span>
                  <div>
                    <h4 className="text-xs font-black uppercase tracking-wider text-slate-800">
                      Email / Nomor WA Konfirmasi Admin (Pilih Salah Satu Saja)
                    </h4>
                    <p className="text-[11px] text-slate-500">
                      Berfungsi menerima konfirmasi pemberitahuan apabila pengguna lupa password atau username.
                    </p>
                  </div>
                </div>

                {/* Toggle: Nomor WA vs Email (strictly one active) */}
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      if (konfirmasiTipe !== 'wa') {
                        setKonfirmasiTipe('wa');
                        setKonfirmasiAdmin(
                          adminContact.type === 'wa' ? adminContact.value : ''
                        );
                      }
                    }}
                    className={`py-2.5 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-2 transition ${
                      konfirmasiTipe === 'wa'
                        ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                        : 'bg-white text-slate-600 border-slate-300 hover:bg-slate-100'
                    }`}
                  >
                    <MessageCircle className="h-4 w-4" />
                    Nomor WA Admin
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      if (konfirmasiTipe !== 'email') {
                        setKonfirmasiTipe('email');
                        setKonfirmasiAdmin(
                          adminContact.type === 'email' ? adminContact.value : ''
                        );
                      }
                    }}
                    className={`py-2.5 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-2 transition ${
                      konfirmasiTipe === 'email'
                        ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                        : 'bg-white text-slate-600 border-slate-300 hover:bg-slate-100'
                    }`}
                  >
                    <Mail className="h-4 w-4" />
                    Email Admin
                  </button>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700">
                    {konfirmasiTipe === 'wa'
                      ? 'Nomor WA Konfirmasi Admin'
                      : 'Email Konfirmasi Admin'}{' '}
                    <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type={konfirmasiTipe === 'email' ? 'email' : 'tel'}
                    value={konfirmasiAdmin}
                    onChange={(e) => setKonfirmasiAdmin(e.target.value)}
                    placeholder={
                      konfirmasiTipe === 'wa'
                        ? 'Contoh: 081234567890 (WA Admin penerima pemberitahuan)'
                        : 'Contoh: admin@sekolah.sch.id (Email Admin penerima pemberitahuan)'
                    }
                    className="block w-full rounded-xl border border-slate-300 bg-white p-3 text-sm font-medium text-slate-900 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
                  />
                  {konfirmasiTipe === 'wa' && konfirmasiAdmin.trim() && (
                    <p className="text-[11px] text-emerald-700 font-medium">
                      Tautan konfirmasi WA: wa.me/{formatWaNumber(konfirmasiAdmin)}
                    </p>
                  )}
                </div>
              </div>

              {/* Modal Footer Buttons */}
              <div className="pt-2 border-t border-slate-200 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsUserModalOpen(false)}
                  className="px-5 py-2.5 rounded-xl border border-slate-300 text-slate-600 hover:bg-slate-100 font-bold text-xs transition"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs shadow-md shadow-indigo-600/20 transition flex items-center gap-2"
                >
                  <CheckCircle2 className="h-4 w-4" />
                  {editingUserId ? 'Simpan Perubahan' : 'Simpan Pengguna'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      {/* Modal Kode Skrip HTML & Unduh untuk Blogspot / Blogger */}
      <BlogspotEmbedModal
        isOpen={isBlogspotModalOpen}
        onClose={() => setIsBlogspotModalOpen(false)}
        settings={settings}
        showToast={showToast}
      />
    </div>
  );
};
