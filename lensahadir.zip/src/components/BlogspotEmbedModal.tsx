import React, { useState, useMemo } from 'react';
import {
  X,
  Code2,
  Copy,
  Check,
  Download,
  Globe,
  FileCode2,
  Layout,
  AlertCircle,
  AlertTriangle,
  ExternalLink,
  CheckCircle2,
} from 'lucide-react';
import { AppSettings } from '../types/attendance';

interface BlogspotEmbedModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  showToast: (msg: string) => void;
}

type EmbedMode = 'theme' | 'page';

const escapeXmlAttr = (str: string): string =>
  str
    .replace(/&/g, '&amp;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');

const DEFAULT_PLACEHOLDER_URL = 'https://URL-SERVER-APLIKASI-ANDA.run.app';

const isPrivatePreviewUrl = (url: string): boolean => {
  const lower = url.trim().toLowerCase();
  return (
    lower.includes('ais-dev-') ||
    lower.includes('ais-pre-') ||
    lower.includes('localhost') ||
    lower.includes('127.0.0.1')
  );
};

const isBlogspotSelfUrl = (url: string): boolean => {
  const lower = url.trim().toLowerCase();
  return lower.includes('.blogspot.') || lower.includes('blogger.com');
};

const sanitizeAppUrl = (raw: string): string => {
  const trimmed = raw.trim();
  if (!trimmed) return DEFAULT_PLACEHOLDER_URL;
  if (/^https?:\/\//i.test(trimmed)) {
    return trimmed.replace(/\/+$/, '');
  }
  if (/^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(trimmed)) {
    return DEFAULT_PLACEHOLDER_URL;
  }
  return `https://${trimmed.replace(/^\/+/, '').replace(/\/+$/, '')}`;
};

const detectDefaultAppUrl = (): string => {
  if (typeof window === 'undefined') return '';
  const origin = window.location.origin || '';
  if (origin && !isPrivatePreviewUrl(origin) && !isBlogspotSelfUrl(origin)) {
    return origin;
  }
  return '';
};

export const BlogspotEmbedModal: React.FC<BlogspotEmbedModalProps> = ({
  isOpen,
  onClose,
  settings,
  showToast,
}) => {
  const [appUrl, setAppUrl] = useState<string>(() => detectDefaultAppUrl());
  const [embedTitle, setEmbedTitle] = useState<string>(
    () => `LensaHadir — ${settings.subInstansi || settings.namaInstansi || 'Absensi Digital'}`
  );
  const [embedMode, setEmbedMode] = useState<EmbedMode>('theme');
  const [frameHeight, setFrameHeight] = useState<string>('920px');
  const [copied, setCopied] = useState(false);

  const hasPrivateUrlError = useMemo(() => isPrivatePreviewUrl(appUrl), [appUrl]);
  const hasBlogspotSelfError = useMemo(() => isBlogspotSelfUrl(appUrl), [appUrl]);
  const isUrlEmpty = !appUrl.trim();
  const isUrlReady = !isUrlEmpty && !hasPrivateUrlError && !hasBlogspotSelfError;

  const safeUrl = useMemo(() => sanitizeAppUrl(appUrl), [appUrl]);
  const safeTitle = useMemo(
    () => escapeXmlAttr(embedTitle.trim() || 'LensaHadir — Sistem Absensi Digital'),
    [embedTitle]
  );
  const escapedUrl = useMemo(() => escapeXmlAttr(safeUrl), [safeUrl]);

  const htmlCode = useMemo(() => {
    if (embedMode === 'theme') {
      return `<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE html>
<html b:css='false' b:defaultwidgetversion='2' b:js='false' b:layoutsVersion='3' expr:dir='data:blog.languageDirection' xmlns='http://www.w3.org/1999/xhtml' xmlns:b='http://www.google.com/2005/gml/b' xmlns:data='http://www.google.com/2005/gml/data' xmlns:expr='http://www.google.com/2005/gml/expr'>
<head>
  <meta charset='UTF-8'/>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=5.0' name='viewport'/>
  <meta content='no-referrer-when-downgrade' name='referrer'/>
  <title>${safeTitle}</title>
  <meta content='${safeTitle} — Aplikasi Absensi Digital Guru dan Pegawai' name='description'/>
  <link href='${escapedUrl}/assets/aistudio/yakang_blogger_ikon_ba9a3c56.jpg' rel='icon' type='image/jpeg'/>
  <link href='${escapedUrl}/assets/aistudio/yakang_blogger_ikon_ba9a3c56.jpg' rel='apple-touch-icon'/>
  <b:skin><![CDATA[
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }
    html, body {
      width: 100%;
      height: 100%;
      overflow: hidden;
      background: #f8fafc;
      font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    }
    #lensahadir-theme-shell {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      width: 100vw;
      height: 100vh;
      height: 100dvh;
      background: #f8fafc;
      z-index: 99999;
    }
    #lensahadir-theme-loader {
      position: absolute;
      inset: 0;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 10px;
      padding: 24px;
      text-align: center;
      background: linear-gradient(135deg, #1e1b4b 0%, #312e81 100%);
      color: #ffffff;
      z-index: 4;
      transition: opacity 0.3s ease;
    }
    .lh-spinner {
      width: 40px;
      height: 40px;
      border: 4px solid rgba(255,255,255,0.22);
      border-top-color: #34d399;
      border-radius: 50%;
      animation: lhSpin 0.8s linear infinite;
    }
    @keyframes lhSpin {
      to { transform: rotate(360deg); }
    }
    .lh-title {
      font-size: 16px;
      font-weight: 800;
      letter-spacing: 0.2px;
    }
    .lh-sub {
      font-size: 12px;
      color: #c7d2fe;
      max-width: 380px;
      line-height: 1.5;
    }
    .lh-fallback-btn {
      margin-top: 8px;
      display: inline-block;
      background: #10b981;
      color: #022c22;
      text-decoration: none;
      font-size: 12px;
      font-weight: 800;
      padding: 10px 18px;
      border-radius: 10px;
    }
    #lensahadir-theme-frame {
      position: relative;
      z-index: 2;
      width: 100%;
      height: 100%;
      border: 0;
      display: block;
      background: #f8fafc;
    }
    .blogger-hidden-section {
      display: none !important;
      visibility: hidden !important;
      height: 0 !important;
      overflow: hidden !important;
    }
  ]]></b:skin>
</head>
<body>
  <!-- Wadah Aplikasi LensaHadir Layar Penuh untuk Blogspot / Domain Khusus -->
  <div id='lensahadir-theme-shell'>
    <div id='lensahadir-theme-loader'>
      <div class='lh-spinner' id='lh-spinner-el'/>
      <div class='lh-title' id='lh-status-title'>${safeTitle}</div>
      <div class='lh-sub' id='lh-status-desc'>Sedang memuat aplikasi absensi digital. Mohon tunggu sebentar...</div>
      <a class='lh-fallback-btn' href='${escapedUrl}' rel='noopener noreferrer' target='_top'>Buka Langsung Aplikasi</a>
    </div>
    <iframe allow='camera; microphone; fullscreen; clipboard-read; clipboard-write; geolocation' allowfullscreen='allowfullscreen' id='lensahadir-theme-frame' referrerpolicy='no-referrer-when-downgrade' src='${escapedUrl}' title='${safeTitle}'/>
  </div>

  <!-- Wajib ada minimal satu b:section agar Tema Blogger valid disimpan -->
  <div class='blogger-hidden-section'>
    <b:section id='lensahadir-blogger-core' showaddelement='no'/>
  </div>

  <script type='text/javascript'>
  //<![CDATA[
    (function() {
      var frame = document.getElementById('lensahadir-theme-frame');
      var loader = document.getElementById('lensahadir-theme-loader');
      var titleEl = document.getElementById('lh-status-title');
      var descEl = document.getElementById('lh-status-desc');
      var spinEl = document.getElementById('lh-spinner-el');
      if (!frame || !loader) return;

      try {
        var target = new URL(frame.getAttribute('src'), window.location.href);
        if (target.hostname === window.location.hostname || target.hostname.indexOf('blogspot.') !== -1) {
          if (spinEl) spinEl.style.display = 'none';
          if (titleEl) titleEl.textContent = 'URL Server Aplikasi Belum Diisi dengan Benar';
          if (descEl) {
            descEl.textContent = 'Tema Blogspot tidak bisa memuat alamat Blogspot itu sendiri. Ganti src iframe di Tema Edit HTML dengan URL publik hasil Deploy aplikasi LensaHadir (misal: https://...run.app atau https://...vercel.app).';
          }
          frame.removeAttribute('src');
          return;
        }
      } catch (e) {}

      frame.addEventListener('load', function() {
        loader.style.opacity = '0';
        setTimeout(function() {
          loader.style.display = 'none';
        }, 300);
      });
    })();
  //]]>
  </script>
</body>
</html>`;
    }

    return `<!-- ============================================================ -->
<!-- LENSAHADIR — KODE SKRIP HTML UNTUK HALAMAN / POST BLOGSPOT   -->
<!-- Cara pasang: Blogger > Halaman/Postingan > Tampilan HTML </> -->
<!-- ============================================================ -->
<div id="lensahadir-embed-root" style="width:100%;max-width:1280px;margin:0 auto;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;">
  <div style="display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:10px;background:#1e1b4b;color:#ffffff;padding:12px 16px;border-radius:14px 14px 0 0;border:1px solid #312e81;border-bottom:none;">
    <div style="display:flex;align-items:center;gap:10px;">
      <span style="display:inline-block;width:10px;height:10px;border-radius:999px;background:#34d399;"></span>
      <strong style="font-size:14px;letter-spacing:0.2px;">${safeTitle}</strong>
    </div>
    <div style="display:flex;flex-wrap:wrap;align-items:center;gap:8px;">
      <button
        type="button"
        onclick="(function(){var el=document.getElementById('lensahadir-embed-box');if(el&&el.requestFullscreen){el.requestFullscreen();}else{window.open('${escapedUrl}','_blank','noopener');}})()"
        style="background:#4f46e5;color:#ffffff;border:none;border-radius:8px;padding:7px 12px;font-size:12px;font-weight:700;cursor:pointer;"
      >
        &#x26F6; Layar Penuh
      </button>
      <a
        href="${escapedUrl}"
        target="_blank"
        rel="noopener noreferrer"
        style="background:#10b981;color:#022c22;text-decoration:none;border-radius:8px;padding:7px 12px;font-size:12px;font-weight:800;"
      >
        Buka di Tab Baru &#x2197;
      </a>
    </div>
  </div>

  <div id="lensahadir-embed-box" style="position:relative;width:100%;height:${escapeXmlAttr(frameHeight)};min-height:82vh;background:#f8fafc;border:1px solid #cbd5e1;border-radius:0 0 14px 14px;overflow:hidden;box-shadow:0 12px 30px rgba(15,23,42,0.12);">
    <div id="lensahadir-loader" style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;background:#f8fafc;color:#334155;font-size:13px;font-weight:700;z-index:2;">
      <span>Memuat Aplikasi LensaHadir...</span>
      <span style="font-size:11px;font-weight:500;color:#64748b;">Jika tampilan tidak muncul, klik tombol &ldquo;Buka di Tab Baru&rdquo; di atas.</span>
    </div>
    <iframe
      src="${escapedUrl}"
      title="${safeTitle}"
      onload="var l=document.getElementById('lensahadir-loader');if(l)l.style.display='none';"
      style="position:relative;z-index:3;width:100%;height:100%;border:0;display:block;background:#ffffff;"
      allow="camera; microphone; fullscreen; clipboard-read; clipboard-write; geolocation"
      allowfullscreen="allowfullscreen"
      referrerpolicy="no-referrer-when-downgrade"
    ></iframe>
  </div>
</div>`;
  }, [embedMode, escapedUrl, safeTitle, frameHeight]);

  if (!isOpen) return null;

  const validateBeforeExport = (): boolean => {
    if (hasBlogspotSelfError) {
      showToast(
        'Jangan masukkan alamat Blogspot sendiri! Masukkan URL Publik hasil Deploy aplikasi (contoh: https://...run.app atau https://...vercel.app).'
      );
      return false;
    }
    if (hasPrivateUrlError) {
      showToast(
        'Error 403 dicegah: Jangan gunakan URL pratinjau (ais-dev / ais-pre). Deploy dulu aplikasi untuk mendapatkan URL publik!'
      );
      return false;
    }
    if (isUrlEmpty) {
      showToast('Masukkan URL Publik hasil Deploy aplikasi terlebih dahulu sebelum mengunduh.');
      return false;
    }
    return true;
  };

  const handleCopyCode = async () => {
    if (!validateBeforeExport()) return;
    try {
      await navigator.clipboard.writeText(htmlCode);
      setCopied(true);
      showToast(
        embedMode === 'theme'
          ? 'Kode Tema Blogspot HTML berhasil disalin ke clipboard'
          : 'Kode HTML Halaman Blogspot berhasil disalin ke clipboard'
      );
      setTimeout(() => setCopied(false), 2500);
    } catch {
      const textarea = document.createElement('textarea');
      textarea.value = htmlCode;
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand('copy');
      document.body.removeChild(textarea);
      setCopied(true);
      showToast('Kode Blogspot berhasil disalin');
      setTimeout(() => setCopied(false), 2500);
    }
  };

  const triggerDownload = (filename: string, mimeType: string) => {
    if (!validateBeforeExport()) return;
    const blob = new Blob([htmlCode], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    showToast(`File berhasil diunduh: ${filename}`);
  };

  const handleDownloadThemeXml = () => {
    triggerDownload('TEMA_BLOGSPOT_LENSAHADIR.xml', 'application/xml;charset=utf-8');
  };

  const handleDownloadHtml = () => {
    const filename =
      embedMode === 'theme'
        ? 'TEMA_BLOGSPOT_LENSAHADIR.html'
        : 'SKRIP_HALAMAN_BLOGSPOT_LENSAHADIR.html';
    triggerDownload(filename, 'text/html;charset=utf-8');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/65 p-4 backdrop-blur-xs animate-fadeIn">
      <div className="relative w-full max-w-4xl max-h-[92vh] overflow-hidden rounded-2xl bg-white shadow-2xl border border-slate-200 flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between gap-3 border-b border-slate-200 bg-gradient-to-r from-orange-600 via-amber-600 to-indigo-800 px-6 py-4 text-white">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-white/15">
              <Code2 className="h-5 w-5 text-white" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black tracking-tight">
                Tema Blogspot HTML &amp; Domain Khusus Blogspot
              </h2>
              <p className="text-xs text-amber-100">
                Kode XML/HTML valid untuk Blogger → Tema → Edit HTML / Pulihkan (.xml) — Bebas 403 &amp; Bebas Layar Kosong
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1.5 text-white/80 hover:bg-white/15 hover:text-white transition cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-5">
          {/* Peringatan Anti Error 403 & Anti Loop Blogspot */}
          <div className="rounded-xl bg-rose-50 border border-rose-200 p-4 space-y-1.5 text-xs text-rose-950">
            <p className="font-black flex items-center gap-1.5 text-rose-800">
              <AlertTriangle className="h-4 w-4 text-rose-600 shrink-0" />
              2 Jenis URL yang TIDAK BOLEH dimasukkan ke kolom bawah (Agar Blogspot Tidak Kosong / Error 403):
            </p>
            <ul className="list-disc list-inside space-y-1 text-rose-900/90 leading-relaxed">
              <li>
                <b>Jangan masukkan alamat Blogspot sendiri</b> (misal <span className="font-mono font-bold bg-rose-100 px-1 rounded">https://lensahadir.blogspot.com</span>), karena Blogspot akan mencoba membuka dirinya sendiri dan hasilnya blank/tidak bisa dibuka.
              </li>
              <li>
                <b>Jangan masukkan link pratinjau editor</b> (berawalan <span className="font-mono font-bold bg-rose-100 px-1 rounded">ais-dev-</span> atau <span className="font-mono font-bold bg-rose-100 px-1 rounded">ais-pre-</span>), karena link tersebut privat dan diblokir Google dengan <b>Error 403</b>.
              </li>
              <li>
                <b>Yang BENAR:</b> Masukkan <b>URL Publik hasil Deploy</b> aplikasi LensaHadir (klik tombol <b>Deploy ke Cloud Run</b> di pojok kanan atas editor → dapatkan alamat publik <span className="font-mono font-bold bg-emerald-100 text-emerald-900 px-1 rounded">https://nama-app-xxxx.a.run.app</span>, atau hasil deploy dari <b>Vercel / Cloudflare Pages</b>).
              </li>
            </ul>
          </div>

          {/* Panduan Singkat sesuai Mode */}
          <div className="rounded-xl bg-amber-50 border border-amber-200 p-4 space-y-1.5 text-xs text-amber-950">
            <p className="font-black flex items-center gap-1.5">
              <Globe className="h-4 w-4 text-amber-700" />
              {embedMode === 'theme'
                ? 'Cara Kerja Domain Blogspot + Server Aplikasi LensaHadir:'
                : 'Cara Pasang di Halaman / Postingan Blogspot:'}
            </p>
            {embedMode === 'theme' ? (
              <ol className="list-decimal list-inside space-y-1 text-amber-900/90 leading-relaxed">
                <li>
                  <b>Deploy Aplikasi LensaHadir</b> sekali saja (klik tombol <b>Deploy</b> di kanan atas untuk dapat alamat server publik <span className="font-mono font-bold">https://...a.run.app</span> yang bisa dibuka di mode penyamaran tanpa login Google).
                </li>
                <li>
                  Tempel <b>URL Server Publik</b> tersebut di kolom bawah ini → klik <b>Unduh Tema Blogspot (.xml)</b>.
                </li>
                <li>
                  Buka <b>Blogger.com → Tema → panah (▾) di samping Sesuaikan → Pulihkan → Upload file .xml</b>.
                </li>
                <li>
                  Atur <b>Tema → ▾ → Setelan seluler → Desktop</b>, lalu sambungkan domain khusus Anda di <b>Setelan → Memublikasikan → Domain kustom</b>. Pengunjung tetap membuka alamat Blogspot/Domain Khusus Anda, sementara aplikasi berjalan mulus di dalamnya!
                </li>
              </ol>
            ) : (
              <ol className="list-decimal list-inside space-y-1 text-amber-900/90 leading-relaxed">
                <li>
                  Tempel <b>URL Server Publik hasil Deploy</b> aplikasi Anda pada kolom URL di bawah ini.
                </li>
                <li>
                  Klik <b>Salin Kode HTML</b> atau <b>Unduh File (.html)</b>.
                </li>
                <li>
                  Buka <b>Blogger.com → Halaman → Halaman Baru → Tampilan HTML (&lt;/&gt;)</b> → tempel kodenya → <b>Publikasikan</b>.
                </li>
              </ol>
            )}
          </div>

          {/* Form Pengaturan URL & Judul */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-black text-slate-700 flex items-center justify-between gap-2">
                <span>URL Server Publik Aplikasi LensaHadir</span>
                <div className="flex items-center gap-2">
                  {typeof window !== 'undefined' &&
                    !isPrivatePreviewUrl(window.location.origin) &&
                    !isBlogspotSelfUrl(window.location.origin) && (
                      <button
                        type="button"
                        onClick={() => setAppUrl(window.location.origin)}
                        className="text-[11px] font-bold text-indigo-600 hover:underline cursor-pointer"
                      >
                        Gunakan URL Ini
                      </button>
                    )}
                  {isUrlReady && (
                    <a
                      href={safeUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[11px] font-bold text-emerald-700 hover:underline flex items-center gap-0.5"
                    >
                      Uji URL
                      <ExternalLink className="h-3 w-3" />
                    </a>
                  )}
                </div>
              </label>
              <input
                type="url"
                value={appUrl}
                onChange={(e) => setAppUrl(e.target.value)}
                placeholder="https://lensahadir-xxxx.a.run.app"
                className={`w-full rounded-xl border px-3.5 py-2.5 text-xs sm:text-sm font-mono outline-none transition ${
                  hasPrivateUrlError || hasBlogspotSelfError
                    ? 'border-rose-500 bg-rose-50 text-rose-900 focus:border-rose-600 focus:ring-1 focus:ring-rose-500'
                    : isUrlReady
                    ? 'border-emerald-500 bg-emerald-50/40 text-slate-900 focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600'
                    : 'border-slate-300 text-slate-900 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600'
                }`}
              />
              {hasBlogspotSelfError ? (
                <p className="text-[11px] text-rose-700 flex items-start gap-1.5 font-bold">
                  <AlertTriangle className="h-3.5 w-3.5 shrink-0 mt-0.5" />
                  <span>
                    Ini adalah alamat <b>Blogspot Anda sendiri</b>! Tema Blogspot tidak boleh memuat alamat Blogspot sendiri (menyebabkan situs tidak bisa terbuka/blank). Masukkan URL publik hasil <b>Deploy</b> aplikasi (contoh: <span className="font-mono">https://...a.run.app</span> atau <span className="font-mono">https://...vercel.app</span>).
                  </span>
                </p>
              ) : hasPrivateUrlError ? (
                <p className="text-[11px] text-rose-700 flex items-start gap-1.5 font-bold">
                  <AlertTriangle className="h-3.5 w-3.5 shrink-0 mt-0.5" />
                  <span>
                    URL ini berawalan <span className="font-mono">ais-dev / ais-pre</span> (privat) sehingga akan memunculkan <b>Error 403</b> di Blogspot! Ganti dengan URL publik hasil tombol <b>Deploy</b>.
                  </span>
                </p>
              ) : isUrlEmpty ? (
                <p className="text-[11px] text-amber-700 flex items-center gap-1 font-semibold">
                  <AlertCircle className="h-3.5 w-3.5 shrink-0" />
                  Masukkan URL Server Publik hasil Deploy (bukan link <span className="font-mono">blogspot.com</span> atau <span className="font-mono">ais-dev/ais-pre</span>).
                </p>
              ) : (
                <p className="text-[11px] text-emerald-700 flex items-center gap-1 font-bold">
                  <CheckCircle2 className="h-3.5 w-3.5 shrink-0" />
                  Format URL server publik valid! Klik &ldquo;Uji URL&rdquo; untuk memastikan langsung terbuka tanpa login Google.
                </p>
              )}
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-black text-slate-700">
                Judul Situs / Tab Browser Blogspot
              </label>
              <input
                type="text"
                value={embedTitle}
                onChange={(e) => setEmbedTitle(e.target.value)}
                placeholder="LensaHadir — Absensi Digital"
                className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-xs sm:text-sm text-slate-900 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
              />
            </div>
          </div>

          {/* Pilihan Mode: Tema Blogspot HTML vs Halaman/Postingan */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => setEmbedMode('theme')}
                className={`px-4 py-2.5 rounded-xl text-xs font-black flex items-center gap-2 border transition cursor-pointer ${
                  embedMode === 'theme'
                    ? 'bg-orange-600 text-white border-orange-700 shadow-sm'
                    : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                }`}
              >
                <FileCode2 className="h-4 w-4" />
                Tema Blogspot (Edit HTML / .xml)
              </button>
              <button
                type="button"
                onClick={() => setEmbedMode('page')}
                className={`px-4 py-2.5 rounded-xl text-xs font-black flex items-center gap-2 border transition cursor-pointer ${
                  embedMode === 'page'
                    ? 'bg-indigo-600 text-white border-indigo-700 shadow-sm'
                    : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                }`}
              >
                <Layout className="h-4 w-4" />
                Halaman / Postingan Blogspot
              </button>
            </div>

            {embedMode === 'page' && (
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-600">Tinggi Frame:</span>
                <select
                  value={frameHeight}
                  onChange={(e) => setFrameHeight(e.target.value)}
                  className="px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs font-bold text-slate-800 outline-none focus:border-indigo-600"
                >
                  <option value="820px">820px (Standar)</option>
                  <option value="920px">920px (Direkomendasikan)</option>
                  <option value="1050px">1050px (Tinggi)</option>
                  <option value="92vh">92vh (Otomatis Layar)</option>
                </select>
              </div>
            )}
          </div>

          {/* Code Preview Box */}
          <div className="rounded-2xl border border-slate-800 bg-slate-950 overflow-hidden shadow-lg">
            <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-2.5 bg-slate-900 border-b border-slate-800">
              <span className="text-[11px] font-mono font-bold text-emerald-400">
                {embedMode === 'theme'
                  ? 'TEMA_BLOGSPOT_LENSAHADIR.xml (Valid Edit HTML)'
                  : 'SKRIP_HALAMAN_BLOGSPOT_LENSAHADIR.html'}
              </span>
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={handleCopyCode}
                  className={`px-3 py-1.5 rounded-lg text-white text-xs font-black flex items-center gap-1.5 transition cursor-pointer ${
                    isUrlReady
                      ? 'bg-indigo-600 hover:bg-indigo-500'
                      : 'bg-slate-700 hover:bg-slate-600 opacity-80'
                  }`}
                >
                  {copied ? (
                    <>
                      <Check className="h-3.5 w-3.5 text-emerald-300" />
                      Tersalin!
                    </>
                  ) : (
                    <>
                      <Copy className="h-3.5 w-3.5" />
                      {embedMode === 'theme' ? 'Salin Kode Tema HTML' : 'Salin Kode HTML'}
                    </>
                  )}
                </button>
                {embedMode === 'theme' && (
                  <button
                    type="button"
                    onClick={handleDownloadThemeXml}
                    className={`px-3 py-1.5 rounded-lg text-white text-xs font-black flex items-center gap-1.5 transition cursor-pointer ${
                      isUrlReady
                        ? 'bg-orange-500 hover:bg-orange-400'
                        : 'bg-slate-700 hover:bg-slate-600 opacity-80'
                    }`}
                  >
                    <Download className="h-3.5 w-3.5" />
                    Unduh Tema (.xml)
                  </button>
                )}
                <button
                  type="button"
                  onClick={handleDownloadHtml}
                  className={`px-3 py-1.5 rounded-lg text-xs font-black flex items-center gap-1.5 transition cursor-pointer ${
                    isUrlReady
                      ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950'
                      : 'bg-slate-700 hover:bg-slate-600 text-white opacity-80'
                  }`}
                >
                  <Download className="h-3.5 w-3.5" />
                  Unduh (.html)
                </button>
              </div>
            </div>
            <pre className="p-4 text-[11px] sm:text-xs font-mono text-slate-100 overflow-x-auto max-h-72 leading-relaxed select-all">
              <code>{htmlCode}</code>
            </pre>
          </div>
        </div>

        {/* Footer */}
        <div className="border-t border-slate-200 bg-slate-50 px-6 py-3.5 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-[11px] text-slate-600">
            <ExternalLink className="h-3.5 w-3.5 text-indigo-600 shrink-0" />
            <span>
              Dilengkapi pengaman anti-loop &amp; anti-403 agar domain Blogspot Anda tampil penuh dengan lancar.
            </span>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {embedMode === 'theme' && (
              <button
                type="button"
                onClick={handleDownloadThemeXml}
                className="px-4 py-2 rounded-xl bg-orange-600 hover:bg-orange-700 text-white text-xs font-black flex items-center gap-1.5 shadow-sm transition cursor-pointer"
              >
                <Download className="h-4 w-4" />
                Unduh Tema Blogspot (.xml)
              </button>
            )}
            <button
              type="button"
              onClick={handleDownloadHtml}
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black flex items-center gap-1.5 shadow-sm transition cursor-pointer"
            >
              <Download className="h-4 w-4" />
              Unduh File (.html)
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-bold transition cursor-pointer"
            >
              Tutup
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
