import React, { useState, useEffect } from 'react';
import {
  X,
  ShieldCheck,
  User,
  Building2,
  KeyRound,
  Lock,
  Eye,
  EyeOff,
  Save,
  AlertCircle,
  MessageCircle,
  Mail,
  CheckCircle2,
  RefreshCw,
} from 'lucide-react';
import {
  AdminAccountProfile,
  AppSettings,
  ManagedUser,
} from '../types/attendance';

interface AdminProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  adminProfile: AdminAccountProfile;
  settings: AppSettings;
  existingUsers: ManagedUser[];
  onSaveAdminProfile: (profile: AdminAccountProfile) => void;
}

const formatDateTimeId = (ts?: number): string => {
  if (!ts) return '';
  try {
    return new Date(ts).toLocaleString('id-ID', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return '';
  }
};

export const AdminProfileModal: React.FC<AdminProfileModalProps> = ({
  isOpen,
  onClose,
  adminProfile,
  settings,
  existingUsers,
  onSaveAdminProfile,
}) => {
  const [nama, setNama] = useState('');
  const [nip, setNip] = useState('');
  const [golRuang, setGolRuang] = useState('');
  const [jabatan, setJabatan] = useState('');
  const [lembaga, setLembaga] = useState('');
  const [noWa, setNoWa] = useState('');
  const [email, setEmail] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (isOpen) {
      setNama(adminProfile.nama || '');
      setNip(adminProfile.nip || '');
      setGolRuang(adminProfile.golRuang || '');
      setJabatan(
        adminProfile.jabatan || 'Administrator Utama Lembaga / Satuan Dinas'
      );
      setLembaga(
        adminProfile.lembaga ||
          settings.subInstansi ||
          settings.namaInstansi ||
          ''
      );
      setNoWa(adminProfile.noWa || '');
      setEmail(adminProfile.email || '');
      setUsername(adminProfile.username || 'admin');
      setPassword(adminProfile.password || 'admin123');
      setShowPassword(false);
      setError('');
    }
  }, [isOpen, adminProfile, settings]);

  if (!isOpen) return null;

  const handleSyncFromKop = () => {
    const combined = [settings.subInstansi, settings.namaInstansi]
      .filter((s) => Boolean(s && s.trim()))
      .join(' — ');
    if (combined) {
      setLembaga(combined);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const cleanNama = nama.trim();
    const cleanUsername = username.trim().replace(/\s+/g, '');
    const cleanPassword = password.trim();
    const cleanEmail = email.trim();
    const cleanWa = noWa.trim();

    if (!cleanNama) {
      setError('Nama Lengkap Administrator Utama wajib diisi.');
      return;
    }

    if (!cleanUsername || cleanUsername.length < 3) {
      setError('Username Admin wajib diisi minimal 3 karakter tanpa spasi.');
      return;
    }

    const collidingUser = existingUsers.find(
      (u) => u.username.toLowerCase() === cleanUsername.toLowerCase()
    );
    if (collidingUser) {
      setError(
        `Username "${cleanUsername}" sedang digunakan oleh pengguna ${collidingUser.nama}. Gunakan username lain.`
      );
      return;
    }

    if (!cleanPassword || cleanPassword.length < 4) {
      setError('Password Admin wajib diisi minimal 4 karakter.');
      return;
    }

    if (cleanEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
      setError('Format Email Admin tidak valid (contoh: admin@dinas.go.id).');
      return;
    }

    if (cleanWa) {
      const digits = cleanWa.replace(/[^0-9]/g, '');
      if (digits.length < 9 || digits.length > 15) {
        setError('Nomor WA Admin harus berupa angka valid (9–15 digit).');
        return;
      }
    }

    onSaveAdminProfile({
      id: 'admin_default',
      nama: cleanNama,
      nip: nip.trim(),
      golRuang: golRuang.trim(),
      jabatan:
        jabatan.trim() || 'Administrator Utama Lembaga / Satuan Dinas',
      lembaga:
        lembaga.trim() || settings.subInstansi || settings.namaInstansi || '',
      noWa: cleanWa,
      email: cleanEmail,
      username: cleanUsername,
      password: cleanPassword,
      updatedAt: Date.now(),
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 p-4 backdrop-blur-xs animate-fadeIn">
      <div className="w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-indigo-900 px-6 py-4 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-white/15">
              <ShieldCheck className="h-5 w-5 text-emerald-300" />
            </div>
            <div>
              <h3 className="text-base font-black uppercase tracking-tight">
                Pengaturan Data Admin
              </h3>
              <p className="text-[11px] text-indigo-200">
                Administrator Utama Lembaga / Satuan Dinas — Data Diri, Username &amp; Password
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-indigo-200 hover:bg-white/15 hover:text-white transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="overflow-y-auto p-6 space-y-5">
          {error && (
            <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold flex items-center gap-2">
              <AlertCircle className="h-4 w-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {adminProfile.updatedAt && (
            <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-[11px] font-semibold flex items-center justify-between gap-2">
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600 shrink-0" />
                Data Administrator Utama tersimpan
              </span>
              <span className="text-[10px] font-bold text-emerald-700">
                Diperbarui: {formatDateTimeId(adminProfile.updatedAt)}
              </span>
            </div>
          )}

          {/* Section 1: Data Diri Administrator Utama */}
          <div className="space-y-4">
            <div className="text-xs font-black uppercase tracking-wider text-indigo-700 flex items-center gap-1.5 border-b border-slate-100 pb-2">
              <User className="h-4 w-4" />
              1. Data Diri Administrator Utama Lembaga / Satuan Dinas
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700">
                  Nama Lengkap Admin <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  value={nama}
                  onChange={(e) => setNama(e.target.value)}
                  placeholder="Nama Lengkap Administrator Utama"
                  className="block w-full rounded-xl border border-slate-300 p-2.5 text-sm font-semibold text-slate-900 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700">
                  NIP / ID Administrator (Opsional)
                </label>
                <input
                  type="text"
                  value={nip}
                  onChange={(e) => setNip(e.target.value)}
                  placeholder="Nomor Induk Pegawai / ID Admin"
                  className="block w-full rounded-xl border border-slate-300 p-2.5 text-sm font-mono text-slate-900 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700">
                  Jabatan Administrator
                </label>
                <input
                  type="text"
                  value={jabatan}
                  onChange={(e) => setJabatan(e.target.value)}
                  placeholder="Contoh: Administrator Utama / Operator Dinas"
                  className="block w-full rounded-xl border border-slate-300 p-2.5 text-sm text-slate-900 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700">
                  Gol. Ruang (Opsional)
                </label>
                <input
                  type="text"
                  value={golRuang}
                  onChange={(e) => setGolRuang(e.target.value)}
                  placeholder="Contoh: Penata / III/c"
                  className="block w-full rounded-xl border border-slate-300 p-2.5 text-sm font-semibold text-slate-900 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
                />
              </div>

              <div className="space-y-1.5 md:col-span-2">
                <div className="flex items-center justify-between gap-2">
                  <label className="text-xs font-bold text-slate-700 flex items-center gap-1">
                    <Building2 className="h-3.5 w-3.5 text-indigo-600" />
                    Nama Lembaga / Satuan Dinas
                  </label>
                  <button
                    type="button"
                    onClick={handleSyncFromKop}
                    className="text-[11px] font-bold text-indigo-600 hover:underline flex items-center gap-1"
                  >
                    <RefreshCw className="h-3 w-3" />
                    Ambil dari Kop Instansi
                  </button>
                </div>
                <input
                  type="text"
                  value={lembaga}
                  onChange={(e) => setLembaga(e.target.value)}
                  placeholder="Contoh: Dinas Pendidikan / UPTD SD Negeri..."
                  className="block w-full rounded-xl border border-slate-300 p-2.5 text-sm font-semibold text-slate-900 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 flex items-center gap-1">
                  <MessageCircle className="h-3.5 w-3.5 text-emerald-600" />
                  Nomor WA Admin (Opsional)
                </label>
                <input
                  type="tel"
                  value={noWa}
                  onChange={(e) => setNoWa(e.target.value)}
                  placeholder="Contoh: 081234567890"
                  className="block w-full rounded-xl border border-slate-300 p-2.5 text-sm font-medium text-slate-900 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 flex items-center gap-1">
                  <Mail className="h-3.5 w-3.5 text-indigo-600" />
                  Email Admin (Opsional)
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Contoh: admin@lembaga.go.id"
                  className="block w-full rounded-xl border border-slate-300 p-2.5 text-sm font-medium text-slate-900 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Username & Password Admin (Dapat Diubah Sewaktu-Waktu) */}
          <div className="space-y-4 pt-2 border-t border-slate-200">
            <div className="text-xs font-black uppercase tracking-wider text-indigo-700 flex items-center gap-1.5 border-b border-slate-100 pb-2">
              <KeyRound className="h-4 w-4" />
              2. Akun Login Administrator (Dapat Diubah Sewaktu-Waktu)
            </div>

            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 flex items-center gap-1">
                    <User className="h-3.5 w-3.5 text-indigo-600" />
                    Username Admin <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value.replace(/\s+/g, ''))}
                    placeholder="Masukkan username admin"
                    className="block w-full rounded-xl border border-slate-300 bg-white p-2.5 text-sm font-mono font-bold text-slate-900 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 flex items-center gap-1">
                    <Lock className="h-3.5 w-3.5 text-indigo-600" />
                    Password Admin <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Minimal 4 karakter"
                      className="block w-full rounded-xl border border-slate-300 bg-white p-2.5 pr-10 text-sm font-mono font-bold text-slate-900 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword((prev) => !prev)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-indigo-600"
                      title={showPassword ? 'Sembunyikan password' : 'Tampilkan password'}
                    >
                      {showPassword ? (
                        <EyeOff className="h-4 w-4" />
                      ) : (
                        <Eye className="h-4 w-4" />
                      )}
                    </button>
                  </div>
                </div>
              </div>

              <p className="text-[11px] text-slate-600 leading-relaxed">
                Perubahan <b>Username</b> dan <b>Password</b> Administrator Utama dapat dilakukan sewaktu-waktu dan langsung berlaku pada saat login berikutnya.
              </p>
            </div>
          </div>

          {/* Footer Actions */}
          <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-100 text-xs font-bold transition"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black uppercase tracking-wide flex items-center gap-2 shadow-md shadow-indigo-600/20 transition"
            >
              <Save className="h-4 w-4" />
              Simpan Data Admin
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
