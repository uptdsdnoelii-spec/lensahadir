import React, { forwardRef } from 'react';
import { AttendanceRecord, AppSettings } from '../types/attendance';

interface PrintableCardProps {
  record: AttendanceRecord;
  settings: AppSettings;
}

export const PrintableCard = forwardRef<HTMLDivElement, PrintableCardProps>(
  ({ record }, ref) => {
    // Format date in Indonesian
    const formatIndonesianDate = (dateStr: string) => {
      try {
        const [y, m, d] = dateStr.split('-').map(Number);
        const dateObj = new Date(y, m - 1, d);
        return dateObj.toLocaleDateString('id-ID', {
          weekday: 'long',
          day: 'numeric',
          month: 'long',
          year: 'numeric',
        });
      } catch {
        return dateStr;
      }
    };

    const formattedDate = formatIndonesianDate(record.tanggal);
    const printedTimestamp = new Date().toLocaleString('id-ID', {
      dateStyle: 'medium',
      timeStyle: 'medium',
    });

    const statusLabel = record.statusKehadiran || 'Hadir (H)';
    const hasCatatan = Boolean(
      record.catatan && record.catatan.trim() !== '' && record.catatan.trim() !== '-'
    );

    const headerBlue = '#5b9bd5';
    const borderBlue = '#2e75b6';
    const doubleBlueBorder = `3px double ${borderBlue}`;
    const dashedBlueBorder = `1.5px dashed ${borderBlue}`;

    return (
      <div className="w-full overflow-x-auto pb-2">
        <div
          ref={ref}
          id="printableArea"
          className="w-[1040px] max-w-none mx-auto bg-white p-7 border border-slate-200 shadow-md text-black select-text"
          style={{
            backgroundColor: '#ffffff',
            fontFamily: '"Times New Roman", Times, Georgia, serif',
          }}
        >
          {/* Judul Kartu & Tanggal */}
          <div className="text-center mb-4">
            <h1
              className="text-[22px] font-bold uppercase tracking-wide leading-tight"
              style={{ color: '#1f4e79' }}
            >
              Kartu Laporan Absen Harian
            </h1>
            <p className="text-[15px] text-slate-700 mt-1">
              Hari / Tanggal : <span className="font-bold text-black">{formattedDate}</span>
            </p>
          </div>

          {/* Tabel Landscape Berwarna sesuai Template Terbaru */}
          <table
            className="w-full border-collapse text-black table-fixed"
            style={{ border: doubleBlueBorder }}
          >
            <colgroup>
              <col style={{ width: '13.5%' }} />
              <col style={{ width: '25%' }} />
              <col style={{ width: '23%' }} />
              <col style={{ width: '23%' }} />
              <col style={{ width: '15.5%' }} />
            </colgroup>

            <thead>
              {/* Header Baris 1 */}
              <tr>
                <th
                  colSpan={2}
                  rowSpan={2}
                  className="px-3 py-2.5 text-center align-middle font-bold text-white text-[18px] leading-snug"
                  style={{
                    backgroundColor: headerBlue,
                    border: doubleBlueBorder,
                  }}
                >
                  <div>Nama/NIP/Jabatan/</div>
                  <div>Gol.Ruang/Status</div>
                </th>
                <th
                  colSpan={2}
                  className="px-3 py-2 text-center align-middle font-bold text-white text-[18px]"
                  style={{
                    backgroundColor: headerBlue,
                    border: doubleBlueBorder,
                  }}
                >
                  BUKTI DUKUNG (Foto TimeMark)
                </th>
                <th
                  rowSpan={2}
                  className="px-2 py-2.5 text-center align-middle font-bold text-white text-[18px] leading-snug"
                  style={{
                    backgroundColor: headerBlue,
                    border: doubleBlueBorder,
                  }}
                >
                  <div>Ket.</div>
                  <div>Kehadiran</div>
                </th>
              </tr>

              {/* Header Baris 2 */}
              <tr>
                <th
                  className="px-2 py-1.5 text-center align-middle font-bold text-black text-[17px] tracking-wide uppercase bg-white"
                  style={{ border: doubleBlueBorder }}
                >
                  ABSEN MASUK
                </th>
                <th
                  className="px-2 py-1.5 text-center align-middle font-bold text-black text-[17px] tracking-wide uppercase bg-white"
                  style={{ border: doubleBlueBorder }}
                >
                  ABSEN PULANG
                </th>
              </tr>
            </thead>

            <tbody>
              {/* Baris 1: Nama + Foto Masuk + Foto Pulang + Ket. Kehadiran */}
              <tr>
                <td
                  className="px-2.5 py-2 align-top text-[16px] font-bold text-black"
                  style={{
                    borderLeft: doubleBlueBorder,
                    borderTop: doubleBlueBorder,
                    borderBottom: dashedBlueBorder,
                    borderRight: 'none',
                  }}
                >
                  Nama
                </td>
                <td
                  className="px-2.5 py-2 align-top text-[16px] text-black break-words"
                  style={{
                    borderTop: doubleBlueBorder,
                    borderRight: doubleBlueBorder,
                    borderBottom: dashedBlueBorder,
                    borderLeft: 'none',
                  }}
                >
                  <span>: </span>
                  <span className="font-bold">{record.nama || '-'}</span>
                </td>

                {/* Foto Absen Masuk (rowSpan 5) */}
                <td
                  rowSpan={5}
                  className="p-2 align-middle text-center bg-white"
                  style={{ border: doubleBlueBorder }}
                >
                  <div className="w-full h-[300px] flex items-center justify-center overflow-hidden bg-white">
                    <img
                      src={record.fotoMasuk}
                      alt="Absen Masuk"
                      className="max-w-full max-h-full w-auto h-auto object-contain"
                    />
                  </div>
                </td>

                {/* Foto Absen Pulang (rowSpan 5) */}
                <td
                  rowSpan={5}
                  className="p-2 align-middle text-center bg-white"
                  style={{ border: doubleBlueBorder }}
                >
                  <div className="w-full h-[300px] flex items-center justify-center overflow-hidden bg-white">
                    <img
                      src={record.fotoKeluar}
                      alt="Absen Pulang"
                      className="max-w-full max-h-full w-auto h-auto object-contain"
                    />
                  </div>
                </td>

                {/* Ket. Kehadiran (rowSpan 5) */}
                <td
                  rowSpan={5}
                  className="px-3 py-2 align-top text-[16px] leading-snug text-black break-words bg-white"
                  style={{ border: doubleBlueBorder }}
                >
                  <div className="font-bold">
                    {statusLabel}
                    {hasCatatan ? ':' : ''}
                  </div>
                  {hasCatatan && (
                    <div className="italic mt-1 whitespace-pre-wrap">
                      {record.catatan}
                    </div>
                  )}
                </td>
              </tr>

              {/* Baris 2: NIP */}
              <tr>
                <td
                  className="px-2.5 py-2 align-top text-[16px] font-bold text-black"
                  style={{
                    borderLeft: doubleBlueBorder,
                    borderTop: dashedBlueBorder,
                    borderBottom: dashedBlueBorder,
                    borderRight: 'none',
                  }}
                >
                  NIP
                </td>
                <td
                  className="px-2.5 py-2 align-top text-[16px] text-black break-words"
                  style={{
                    borderRight: doubleBlueBorder,
                    borderTop: dashedBlueBorder,
                    borderBottom: dashedBlueBorder,
                    borderLeft: 'none',
                  }}
                >
                  : {record.nip || '-'}
                </td>
              </tr>

              {/* Baris 3: Status */}
              <tr>
                <td
                  className="px-2.5 py-2 align-top text-[16px] font-bold text-black"
                  style={{
                    borderLeft: doubleBlueBorder,
                    borderTop: dashedBlueBorder,
                    borderBottom: dashedBlueBorder,
                    borderRight: 'none',
                  }}
                >
                  Status
                </td>
                <td
                  className="px-2.5 py-2 align-top text-[16px] text-black break-words"
                  style={{
                    borderRight: doubleBlueBorder,
                    borderTop: dashedBlueBorder,
                    borderBottom: dashedBlueBorder,
                    borderLeft: 'none',
                  }}
                >
                  : {record.statusPegawai || '-'}
                </td>
              </tr>

              {/* Baris 4: Gol. Ruang */}
              <tr>
                <td
                  className="px-2.5 py-2 align-top text-[16px] font-bold text-black"
                  style={{
                    borderLeft: doubleBlueBorder,
                    borderTop: dashedBlueBorder,
                    borderBottom: dashedBlueBorder,
                    borderRight: 'none',
                  }}
                >
                  Gol. Ruang
                </td>
                <td
                  className="px-2.5 py-2 align-top text-[16px] text-black break-words"
                  style={{
                    borderRight: doubleBlueBorder,
                    borderTop: dashedBlueBorder,
                    borderBottom: dashedBlueBorder,
                    borderLeft: 'none',
                  }}
                >
                  : {record.golRuang || '-'}
                </td>
              </tr>

              {/* Baris 5: Jabatan */}
              <tr>
                <td
                  className="px-2.5 py-2 align-top text-[16px] font-bold text-black"
                  style={{
                    borderLeft: doubleBlueBorder,
                    borderTop: dashedBlueBorder,
                    borderBottom: doubleBlueBorder,
                    borderRight: 'none',
                  }}
                >
                  Jabatan
                </td>
                <td
                  className="px-2.5 py-2 align-top text-[16px] text-black break-words"
                  style={{
                    borderRight: doubleBlueBorder,
                    borderTop: dashedBlueBorder,
                    borderBottom: doubleBlueBorder,
                    borderLeft: 'none',
                  }}
                >
                  : {record.jabatan || '-'}
                </td>
              </tr>
            </tbody>
          </table>

          {/* Footer Meta Ringkas */}
          <div
            className="mt-4 pt-2 border-t border-slate-200 flex justify-between items-center text-[11px] text-slate-500"
            style={{ fontFamily: '"Plus Jakarta Sans", sans-serif' }}
          >
            <p className="font-mono">
              ID_DOKUMEN: {record.id || `DOC_${Date.now()}`}
            </p>
            <p className="italic text-slate-400">
              © 2026 Aplikasi Manajemen Absensi Digital by: yakob lomang blogger · LensaHadir
            </p>
            <p className="font-mono font-semibold uppercase">
              DICETAK: {printedTimestamp}
            </p>
          </div>
        </div>
      </div>
    );
  }
);

PrintableCard.displayName = 'PrintableCard';
