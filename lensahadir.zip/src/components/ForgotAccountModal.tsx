import React, { useState } from 'react';
import {
  X,
  KeyRound,
  MessageCircle,
  Mail,
  CheckCircle2,
  Copy,
  Send,
  AlertCircle,
} from 'lucide-react';
import {
  ManagedUser,
  AdminConfirmationContact,
  RecoveryNotification,
  AppSettings,
} from '../types/attendance';

interface ForgotAccountModalProps {
  isOpen: boolean;
  onClose: () => void;
  users: ManagedUser[];
  adminContact: AdminConfirmationContact;
  settings: AppSettings;
  onSubmitNotification: (notif: RecoveryNotification) => void;
  showToast: (msg: string) => void;
}

const formatWaNumber = (raw: string): string => {
  const digits = raw.replace(/[^0-9]/g, '');
  if (!digits) return '';
  if (digits.startsWith('0')) return `62${digits.slice(1)}`;
  if (digits.startsWith('62')) return digits;
  return `62${digits}`;
};

export const ForgotAccountModal: React.FC<ForgotAccountModalProps> = ({
  isOpen,
  onClose,
  users,
  adminContact,
  settings,
  onSubmitNotification,
  showToast,
}) => {
  const [namaPemohon, setNamaPemohon] = useState('');
  const [nipAtauInfo, setNipAtauInfo] = useState('');
  const [jenisLupa, setJenisLupa] = useState<'password' | 'username' | 'keduanya'>('password');
  const [catatan, setCatatan] = useState('');
  const [error, setError] = useState('');
  const [submittedNotif, setSubmittedNotif] = useState<RecoveryNotification | null>(null);

  if (!isOpen) return null;

  const handleClose = () => {
    setSubmittedNotif(null);
    setError('');
    setNamaPemohon('');
    setNipAtauInfo('');
    setCatatan('');
    onClose();
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const cleanNama = namaPemohon.trim();
    if (!cleanNama) {
      setError('Silakan masukkan Nama Lengkap Anda.');
      return;
    }

    // Try to match user by name, NIP, or username
    const qName = cleanNama.toLowerCase();
    const qInfo = nipAtauInfo.trim().toLowerCase();
    const matched = users.find(
      (u) =>
        u.nama.toLowerCase().includes(qName) ||
        qName.includes(u.nama.toLowerCase()) ||
        (qInfo &&
          ((u.nip && u.nip.toLowerCase().includes(qInfo)) ||
            u.username.toLowerCase() === qInfo))
    );

    const saluranTujuan = matched?.konfirmasiTipe || adminContact.type || 'wa';
    const kontakAdminTujuan = matched?.konfirmasiAdmin || adminContact.value || '';

    const notif: RecoveryNotification = {
      id: `REC_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`,
      namaPemohon: cleanNama,
      nipAtauInfo: nipAtauInfo.trim(),
      matchedUserId: matched?.id,
      matchedUsername: matched?.username,
      matchedRole: matched?.role,
      jenisLupa,
      catatan: catatan.trim(),
      saluranTujuan,
      kontakAdminTujuan,
      status: 'menunggu',
      createdAt: Date.now(),
    };

    onSubmitNotification(notif);
    setSubmittedNotif(notif);
    showToast('Pemberitahuan lupa akun telah dikirim ke Admin');
  };

  const buildConfirmationMessage = (notif: RecoveryNotification): string => {
    const jenisText =
      notif.jenisLupa === 'password'
        ? 'Lupa Password'
        : notif.jenisLupa === 'username'
        ? 'Lupa Username'
        : 'Lupa Username & Password';
    const instansi = settings.subInstansi || settings.namaInstansi || 'LensaHadir';
    return [
      `Halo Admin ${instansi},`,
      `Mohon bantuan konfirmasi akun LensaHadir:`,
      `- Nama: ${notif.namaPemohon}`,
      notif.nipAtauInfo ? `- NIP / Info: ${notif.nipAtauInfo}` : null,
      `- Kendala: ${jenisText}`,
      notif.catatan ? `- Catatan: ${notif.catatan}` : null,
      `Terima kasih.`,
    ]
      .filter(Boolean)
      .join('\n');
  };

  const handleCopyMessage = () => {
    if (!submittedNotif) return;
    const msg = buildConfirmationMessage(submittedNotif);
    if (navigator.clipboard) {
      navigator.clipboard.writeText(msg).then(() => {
        showToast('Pesan konfirmasi disalin ke clipboard');
      });
    }
  };

  const waHref =
    submittedNotif &&
    submittedNotif.saluranTujuan === 'wa' &&
    submittedNotif.kontakAdminTujuan
      ? `https://wa.me/${formatWaNumber(submittedNotif.kontakAdminTujuan)}?text=${encodeURIComponent(
          buildConfirmationMessage(submittedNotif)
        )}`
      : null;

  const mailHref =
    submittedNotif &&
    submittedNotif.saluranTujuan === 'email' &&
    submittedNotif.kontakAdminTujuan
      ? `mailto:${submittedNotif.kontakAdminTujuan}?subject=${encodeURIComponent(
          `Konfirmasi Lupa Akun LensaHadir - ${submittedNotif.namaPemohon}`
        )}&body=${encodeURIComponent(buildConfirmationMessage(submittedNotif))}`
      : null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 p-4 backdrop-blur-xs animate-fadeIn">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
        {/* Header */}
        <div className="bg-indigo-800 px-5 py-4 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-white/15">
              <KeyRound className="h-4 w-4" />
            </div>
            <div>
              <h3 className="text-sm font-black uppercase tracking-wide">
                Lupa Username / Password
              </h3>
              <p className="text-[11px] text-indigo-200">
                Konfirmasi pemberitahuan ke Admin
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={handleClose}
            className="p-1 rounded-lg text-indigo-200 hover:bg-white/15 hover:text-white transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Body */}
        {!submittedNotif ? (
          <form onSubmit={handleSubmit} className="p-5 space-y-4">
            <p className="text-xs text-slate-600 leading-relaxed">
              Kirim pemberitahuan konfirmasi ke Admin agar Username atau Password Anda dapat dibantu cek/reset.
            </p>

            {error && (
              <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold flex items-center gap-2">
                <AlertCircle className="h-4 w-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700">Jenis Kendala</label>
              <div className="grid grid-cols-3 gap-1.5">
                {[
                  { id: 'password', label: 'Lupa Password' },
                  { id: 'username', label: 'Lupa Username' },
                  { id: 'keduanya', label: 'Keduanya' },
                ].map((opt) => (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() =>
                      setJenisLupa(opt.id as 'password' | 'username' | 'keduanya')
                    }
                    className={`py-2 px-2 rounded-xl text-[11px] font-bold border transition ${
                      jenisLupa === opt.id
                        ? 'bg-indigo-600 text-white border-indigo-600'
                        : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700">
                Nama Lengkap Anda <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                value={namaPemohon}
                onChange={(e) => {
                  setNamaPemohon(e.target.value);
                  setError('');
                }}
                placeholder="Masukkan nama lengkap sesuai akun"
                className="w-full p-3 rounded-xl border border-slate-300 text-sm font-medium focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700">
                NIP / Jabatan / Username yang Diingat (Opsional)
              </label>
              <input
                type="text"
                value={nipAtauInfo}
                onChange={(e) => setNipAtauInfo(e.target.value)}
                placeholder="Contoh: 19820805... atau Guru PJOK"
                className="w-full p-3 rounded-xl border border-slate-300 text-sm focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700">
                Catatan Tambahan (Opsional)
              </label>
              <input
                type="text"
                value={catatan}
                onChange={(e) => setCatatan(e.target.value)}
                placeholder="Contoh: Mohon bantu reset password saya"
                className="w-full p-3 rounded-xl border border-slate-300 text-sm focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
              />
            </div>

            <div className="pt-2 flex items-center gap-2">
              <button
                type="button"
                onClick={handleClose}
                className="px-4 py-3 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 text-xs font-bold transition"
              >
                Batal
              </button>
              <button
                type="submit"
                className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white py-3 rounded-xl text-xs font-black uppercase tracking-wide flex items-center justify-center gap-2 shadow-md transition"
              >
                <Send className="h-3.5 w-3.5" />
                Kirim Konfirmasi ke Admin
              </button>
            </div>
          </form>
        ) : (
          <div className="p-5 space-y-4">
            <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 space-y-1.5">
              <div className="flex items-center gap-2 font-black text-sm text-emerald-800">
                <CheckCircle2 className="h-5 w-5 text-emerald-600 shrink-0" />
                Pemberitahuan Tercatat ke Dashboard Admin
              </div>
              <p className="text-xs text-emerald-800/90 leading-relaxed">
                Permintaan bantuan atas nama <b>{submittedNotif.namaPemohon}</b> sudah masuk ke kotak pemberitahuan Admin.
              </p>
            </div>

            {submittedNotif.kontakAdminTujuan ? (
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
                <div className="flex items-center gap-2.5">
                  {submittedNotif.saluranTujuan === 'wa' ? (
                    <div className="p-2 rounded-lg bg-emerald-100 text-emerald-700">
                      <MessageCircle className="h-4 w-4" />
                    </div>
                  ) : (
                    <div className="p-2 rounded-lg bg-indigo-100 text-indigo-700">
                      <Mail className="h-4 w-4" />
                    </div>
                  )}
                  <div>
                    <div className="text-[10px] font-bold uppercase text-slate-400">
                      {submittedNotif.saluranTujuan === 'wa'
                        ? 'Nomor WA Konfirmasi Admin'
                        : 'Email Konfirmasi Admin'}
                    </div>
                    <div className="text-sm font-black text-slate-900">
                      {submittedNotif.kontakAdminTujuan}
                    </div>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row gap-2">
                  {waHref && (
                    <a
                      href={waHref}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white py-2.5 px-4 rounded-xl text-xs font-black flex items-center justify-center gap-2 transition"
                    >
                      <MessageCircle className="h-4 w-4" />
                      Kirim ke WA Admin
                    </a>
                  )}
                  {mailHref && (
                    <a
                      href={mailHref}
                      className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white py-2.5 px-4 rounded-xl text-xs font-black flex items-center justify-center gap-2 transition"
                    >
                      <Mail className="h-4 w-4" />
                      Kirim ke Email Admin
                    </a>
                  )}
                  <button
                    type="button"
                    onClick={handleCopyMessage}
                    className="px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white hover:bg-slate-100 text-slate-700 text-xs font-bold flex items-center justify-center gap-1.5 transition"
                  >
                    <Copy className="h-3.5 w-3.5" />
                    Salin Pesan
                  </button>
                </div>
              </div>
            ) : (
              <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-800">
                Pemberitahuan sudah tampil di <b>Dashboard Admin</b>. Hubungi Admin sekolah Anda secara langsung jika diperlukan.
              </div>
            )}

            <button
              type="button"
              onClick={handleClose}
              className="w-full py-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition"
            >
              Kembali ke Halaman Login
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
