import React, { useState, useEffect } from 'react';
import {
  X,
  UserCog,
  User,
  CheckCircle2,
  AlertCircle,
  ShieldCheck,
  Lock,
} from 'lucide-react';
import { ManagedUser, StatusPegawai } from '../types/attendance';

interface UserProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: ManagedUser | null;
  onSaveProfile: (updatedUser: ManagedUser) => void;
}

const STATUS_PEGAWAI_OPTIONS: { value: StatusPegawai; label: string }[] = [
  { value: 'ASN', label: 'ASN (PNS)' },
  { value: 'PPPK', label: 'PPPK' },
  { value: 'PPPK Paruh Waktu', label: 'PPPK Paruh Waktu' },
  { value: 'Honor/GTT', label: 'Honor/GTT' },
  { value: 'Tenaga Kontrak', label: 'Tenaga Kontrak' },
  { value: 'Penjaga Sekolah', label: 'Penjaga Sekolah' },
];

export const UserProfileModal: React.FC<UserProfileModalProps> = ({
  isOpen,
  onClose,
  user,
  onSaveProfile,
}) => {
  const [nama, setNama] = useState('');
  const [nip, setNip] = useState('');
  const [golRuang, setGolRuang] = useState('');
  const [statusPegawai, setStatusPegawai] = useState<StatusPegawai>('ASN');
  const [jabatan, setJabatan] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    if (isOpen && user) {
      setNama(user.nama || '');
      setNip(user.nip || '');
      setGolRuang(user.golRuang || '');
      setStatusPegawai(user.statusPegawai || 'ASN');
      setJabatan(user.jabatan || '');
      setError('');
    }
  }, [isOpen, user]);

  if (!isOpen || !user) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const cleanNama = nama.trim();
    if (!cleanNama) {
      setError('Nama Lengkap wajib diisi.');
      return;
    }

    // Preserve admin-only login credentials and confirmation contact unchanged,
    // and mark timestamp so Admin sees automatic synchronization in Dashboard
    onSaveProfile({
      ...user,
      nama: cleanNama,
      nip: nip.trim(),
      golRuang: golRuang.trim(),
      statusPegawai,
      jabatan: jabatan.trim(),
      profileUpdatedAt: Date.now(),
      profileUpdatedBySelf: true,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 p-4 backdrop-blur-xs animate-fadeIn">
      <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-indigo-800 px-6 py-4 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-white/15">
              <UserCog className="h-5 w-5 text-white" />
            </div>
            <div>
              <h3 className="text-base font-black uppercase tracking-tight">
                Pengaturan Data Diri
              </h3>
              <p className="text-[11px] text-indigo-200">
                Perbarui data identitas pegawai Anda untuk pengisian Form Absensi otomatis
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-indigo-200 hover:bg-white/15 hover:text-white transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Form Body — Identitas Pegawai saja (Username, Password & Kontak Konfirmasi hanya otoritas Admin) */}
        <form onSubmit={handleSubmit} className="overflow-y-auto p-6 space-y-5">
          {error && (
            <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold flex items-center gap-2">
              <AlertCircle className="h-4 w-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Read-only Role Banner */}
          <div className="p-3 rounded-xl bg-indigo-50 border border-indigo-200 flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs font-bold text-indigo-900">
              <ShieldCheck className="h-4 w-4 text-indigo-600" />
              <span>Role Akun Anda</span>
            </div>
            <span className="px-3 py-1 rounded-lg bg-indigo-600 text-white text-xs font-black">
              {user.role}
            </span>
          </div>

          {/* Data Identitas Pegawai (Format Form Absensi) */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1.5 md:col-span-2">
              <label className="text-xs font-bold text-slate-700 flex items-center gap-1">
                <User className="h-3.5 w-3.5 text-indigo-600" />
                Nama Lengkap <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                value={nama}
                onChange={(e) => setNama(e.target.value)}
                className="block w-full rounded-xl border border-slate-300 p-3 text-sm font-semibold text-slate-900 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
                placeholder="Nama Lengkap beserta gelar (contoh: Agusthinus Kese, S.Pd.Gr)"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700">
                NIP / ID Pegawai (Opsional)
              </label>
              <input
                type="text"
                value={nip}
                onChange={(e) => setNip(e.target.value)}
                className="block w-full rounded-xl border border-slate-300 p-3 text-sm font-mono text-slate-900 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
                placeholder="Nomor Induk Pegawai"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700">Gol. Ruang</label>
              <input
                type="text"
                value={golRuang}
                onChange={(e) => setGolRuang(e.target.value)}
                className="block w-full rounded-xl border border-slate-300 p-3 text-sm font-semibold text-slate-900 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
                placeholder="Isi Gol. Ruang (contoh: IV/a, III/b, dll.)"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700">Status Pegawai</label>
              <select
                value={statusPegawai}
                onChange={(e) => setStatusPegawai(e.target.value as StatusPegawai)}
                className="block w-full rounded-xl border border-slate-300 p-3 text-sm font-bold bg-white text-slate-800 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
              >
                {STATUS_PEGAWAI_OPTIONS.map((opt) => (
                  <option key={opt.value} value={opt.value}>
                    {opt.label}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700">
                Jabatan / Unit Tugas (Opsional)
              </label>
              <input
                type="text"
                value={jabatan}
                onChange={(e) => setJabatan(e.target.value)}
                className="block w-full rounded-xl border border-slate-300 p-3 text-sm text-slate-900 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
                placeholder="Contoh: Guru Kelas / Guru PJOK"
              />
            </div>
          </div>

          {/* Admin-only authority notice */}
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-[11px] text-slate-600 flex items-start gap-2.5">
            <Lock className="h-4 w-4 text-slate-400 shrink-0 mt-0.5" />
            <span>
              Pengaturan <b>Username</b>, <b>Password</b>, dan <b>Email / Nomor WA Konfirmasi</b> merupakan hak otoritas <b>Admin</b>. Hubungi Admin apabila ingin mengubah data login Anda.
            </span>
          </div>

          {/* Actions */}
          <div className="pt-2 border-t border-slate-200 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 rounded-xl border border-slate-300 text-slate-600 hover:bg-slate-100 font-bold text-xs transition"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs shadow-md shadow-indigo-600/20 transition flex items-center gap-2"
            >
              <CheckCircle2 className="h-4 w-4" />
              Simpan Data Diri
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
