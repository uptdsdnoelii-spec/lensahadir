import React, { useState } from 'react';
import {
  X,
  HardDrive,
  ExternalLink,
  CheckCircle2,
  Copy,
  Check,
  FileDown,
  FolderOpen,
  Info,
} from 'lucide-react';

export const ADMIN_GOOGLE_DRIVE_FOLDER_URL =
  'https://drive.google.com/drive/folders/1ZaOyiBVg62GFTCm5fC10w5mXjkvHznrI?usp=drive_link';

interface SaveToDriveModalProps {
  isOpen: boolean;
  onClose: () => void;
  reportTitle: string;
  filename: string;
  onRedownload?: () => void;
  isRedownloading?: boolean;
}

export const SaveToDriveModal: React.FC<SaveToDriveModalProps> = ({
  isOpen,
  onClose,
  reportTitle,
  filename,
  onRedownload,
  isRedownloading = false,
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleCopyFolderUrl = async () => {
    try {
      await navigator.clipboard.writeText(ADMIN_GOOGLE_DRIVE_FOLDER_URL);
      setCopied(true);
      setTimeout(() => setCopied(false), 2200);
    } catch {
      setCopied(false);
    }
  };

  return (
    <div className="no-print fixed inset-0 z-50 flex items-center justify-center bg-slate-950/65 p-4 backdrop-blur-xs animate-fadeIn">
      <div className="w-full max-w-lg rounded-2xl bg-white shadow-2xl border border-slate-200 overflow-hidden">
        {/* Header */}
        <div className="bg-slate-900 px-5 py-4 text-white flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-xl bg-emerald-500/20 border border-emerald-400/30 text-emerald-300 flex items-center justify-center shrink-0">
              <HardDrive className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-sm font-black tracking-tight">
                Simpan ke Folder Google Drive
              </h3>
              <p className="text-[11px] text-slate-300 mt-0.5">{reportTitle}</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-300 hover:bg-white/10 hover:text-white transition"
            aria-label="Tutup"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 space-y-4">
          {/* Downloaded File Confirmation */}
          <div className="rounded-xl bg-emerald-50 border border-emerald-200 p-3.5 flex items-start gap-3">
            <CheckCircle2 className="h-5 w-5 text-emerald-600 shrink-0 mt-0.5" />
            <div className="min-w-0">
              <p className="text-xs font-bold text-emerald-900">
                File PDF berhasil diunduh ke perangkat Anda
              </p>
              <p className="text-[11px] text-emerald-800 font-mono break-all mt-1">
                {filename}
              </p>
            </div>
          </div>

          {/* Transparent Explanation */}
          <div className="rounded-xl bg-slate-50 border border-slate-200 p-3.5 flex items-start gap-2.5 text-xs text-slate-600 leading-relaxed">
            <Info className="h-4 w-4 text-indigo-600 shrink-0 mt-0.5" />
            <div>
              Integrasi unggah otomatis Google Drive tidak diaktifkan. Silakan klik tombol{' '}
              <b className="text-slate-900">Buka Folder Google Drive Tujuan</b> di bawah ini, lalu
              unggah (tarik/drop) file PDF yang baru saja diunduh ke dalam folder tersebut.
            </div>
          </div>

          {/* Target Folder Link Box */}
          <div className="space-y-1.5">
            <label className="text-[11px] font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
              <FolderOpen className="h-3.5 w-3.5 text-indigo-600" />
              Link Folder Google Drive Tujuan
            </label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                readOnly
                value={ADMIN_GOOGLE_DRIVE_FOLDER_URL}
                className="flex-1 rounded-xl border border-slate-300 bg-slate-50 px-3 py-2 text-[11px] font-mono text-slate-700 focus:outline-none"
              />
              <button
                type="button"
                onClick={handleCopyFolderUrl}
                className="px-3 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-100 text-slate-700 text-xs font-bold flex items-center gap-1.5 shrink-0 transition"
              >
                {copied ? (
                  <>
                    <Check className="h-3.5 w-3.5 text-emerald-600" />
                    Tersalin
                  </>
                ) : (
                  <>
                    <Copy className="h-3.5 w-3.5" />
                    Salin
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="bg-slate-50 border-t border-slate-200 px-5 py-3.5 flex flex-wrap items-center justify-between gap-2">
          {onRedownload ? (
            <button
              type="button"
              onClick={onRedownload}
              disabled={isRedownloading}
              className="px-3.5 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-100 text-slate-700 text-xs font-bold flex items-center gap-1.5 transition disabled:opacity-50"
            >
              <FileDown className="h-3.5 w-3.5" />
              {isRedownloading ? 'Mengunduh...' : 'Unduh Ulang PDF'}
            </button>
          ) : (
            <div />
          )}

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-100 text-slate-600 text-xs font-bold transition"
            >
              Tutup
            </button>
            <a
              href={ADMIN_GOOGLE_DRIVE_FOLDER_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black flex items-center gap-1.5 shadow-sm transition"
            >
              <ExternalLink className="h-3.5 w-3.5" />
              Buka Folder Google Drive Tujuan
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
