import React from 'react';
import { AlertTriangle, RotateCcw } from 'lucide-react';

interface ErrorBoundaryState {
  hasError: boolean;
  errorMessage: string;
}

export class ErrorBoundary extends React.Component<
  { children: React.ReactNode },
  ErrorBoundaryState
> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, errorMessage: '' };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return {
      hasError: true,
      errorMessage: error?.message || 'Terjadi kesalahan sistem.',
    };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo) {
    console.error('LensaHadir ErrorBoundary caught:', error, info);
  }

  render() {
    if (this.state.hasError) {
      const friendlyMsg =
        'Terjadi kendala sementara pada aplikasi. Silakan muat ulang halaman untuk melanjutkan.';

      return (
        <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
          <div className="max-w-md w-full bg-white rounded-3xl border border-slate-200 shadow-xl p-7 text-center space-y-4">
            <div className="mx-auto h-12 w-12 rounded-2xl bg-rose-50 border border-rose-200 text-rose-600 flex items-center justify-center">
              <AlertTriangle className="h-6 w-6" />
            </div>
            <h2 className="text-lg font-black text-slate-900">
              Terjadi Kendala Aplikasi
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              {friendlyMsg}
            </p>
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="w-full py-3 px-5 rounded-xl bg-indigo-700 hover:bg-indigo-800 text-white text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 transition"
            >
              <RotateCcw className="h-4 w-4" />
              Muat Ulang Aplikasi
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
