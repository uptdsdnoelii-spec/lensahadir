import React, { useState, useRef } from 'react';
import {
  Upload,
  FileDown,
  Printer,
  Download,
  Settings,
  BarChart3,
  Edit3,
  Eye,
  Plus,
  Trash2,
  FileSpreadsheet,
  Sparkles,
  History,
  CheckCircle2,
  AlertCircle,
  RotateCcw,
  Image as ImageIcon,
  HardDrive,
} from 'lucide-react';
import {
  AppSettings,
  AttendanceRecord,
  MonthlyRecapConfig,
  MonthlyRecapRow,
  PegawaiKategori,
} from '../types/attendance';
import {
  buildMonthlyRowsFromHistory,
  computeMonthlyStats,
  downloadMonthlyExcelTemplate,
  getDaysInMonth,
  getDefaultEffectiveWorkDays,
  getSampleMonthlyRows,
  INDONESIAN_MONTHS,
  inferKategoriFromGolongan,
  parseMultipleMonthlyRecapFiles,
} from '../utils/monthlyRecapParser';
import {
  DEFAULT_LOGO_KANAN,
  DEFAULT_LOGO_KIRI,
  getDefaultAdminNotes,
  paginateMonthlyRows,
  renderMonthlyRecapPageToPngBlob,
  renderMonthlyRecapToPdfBlob,
} from '../utils/monthlyRecapPdfRenderer';
import { triggerBrowserDownload } from '../utils/cardCanvasRenderer';
import { formatIndonesianShortDate } from '../utils/dailyReportCanvasRenderer';
import { SaveToDriveModal } from './SaveToDriveModal';

interface MonthlyRecapReportProps {
  settings: AppSettings;
  records: AttendanceRecord[];
  rows: MonthlyRecapRow[];
  setRows: React.Dispatch<React.SetStateAction<MonthlyRecapRow[]>>;
  config: MonthlyRecapConfig;
  setConfig: React.Dispatch<React.SetStateAction<MonthlyRecapConfig>>;
  onOpenSettings: () => void;
  showToast: (msg: string) => void;
}

export const MonthlyRecapReport: React.FC<MonthlyRecapReportProps> = ({
  settings,
  records,
  rows,
  setRows,
  config,
  setConfig,
  onOpenSettings,
  showToast,
}) => {
  const [activeTab, setActiveTab] = useState<'editor' | 'preview'>('editor');
  const [isParsing, setIsParsing] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [uploadStatus, setUploadStatus] = useState<{
    type: 'success' | 'error';
    message: string;
    fileName?: string;
  } | null>(null);
  const [isExportingPdf, setIsExportingPdf] = useState(false);
  const [isExportingPng, setIsExportingPng] = useState(false);
  const [isSavingDrive, setIsSavingDrive] = useState(false);
  const [driveModalInfo, setDriveModalInfo] = useState<{ filename: string } | null>(null);
  const [confirmClear, setConfirmClear] = useState(false);

  const fileUploadRef = useRef<HTMLInputElement>(null);
  const logoKiriRef = useRef<HTMLInputElement>(null);
  const logoKananRef = useRef<HTMLInputElement>(null);

  const monthName = INDONESIAN_MONTHS[config.bulan - 1] || 'Bulan';
  const stats = computeMonthlyStats(
    rows,
    config.hariKerjaEfektif,
    config.bulan,
    config.tahun,
    config.customWeeklyTrend
  );
  const pages = paginateMonthlyRows(rows);
  const adminNotesList = getDefaultAdminNotes(config, stats);

  // Helper to update month/year and auto-sync effective days & signature date
  const handleChangePeriod = (
    nextBulan: number,
    nextTahun: number,
    nextPola: MonthlyRecapConfig['polaHariKerja'] = config.polaHariKerja
  ) => {
    const isSixDays = nextPola.includes('6 Hari');
    const effDays = getDefaultEffectiveWorkDays(nextBulan, nextTahun, isSixDays);
    const lastDay = getDaysInMonth(nextBulan, nextTahun);
    const ttdDate = `${nextTahun}-${String(nextBulan).padStart(2, '0')}-${String(lastDay).padStart(2, '0')}`;
    setConfig((prev) => ({
      ...prev,
      bulan: nextBulan,
      tahun: nextTahun,
      polaHariKerja: nextPola,
      hariKerjaEfektif: effDays,
      tanggalTtd: ttdDate,
      customWeeklyTrend: undefined,
    }));
  };

  // Handle "Upload Rekapan Absensi Bulanan" (supports 1 monthly file or multiple files at once)
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []) as File[];
    if (files.length === 0) return;
    setIsParsing(true);
    setUploadStatus(null);
    try {
      const result = await parseMultipleMonthlyRecapFiles(files, config.hariKerjaEfektif);
      setRows(result.rows);
      setConfig((prev) => {
        const b = result.detectedBulan || prev.bulan;
        const t = result.detectedTahun || prev.tahun;
        const lastDay = getDaysInMonth(b, t);
        const autoTtd =
          result.detectedBulan || result.detectedTahun
            ? `${t}-${String(b).padStart(2, '0')}-${String(lastDay).padStart(2, '0')}`
            : prev.tanggalTtd;
        return {
          ...prev,
          bulan: b,
          tahun: t,
          hariKerjaEfektif: result.detectedHariKerja || prev.hariKerjaEfektif,
          tanggalTtd: autoTtd,
          customWeeklyTrend: result.weeklyTrend,
        };
      });
      const labelName =
        files.length === 1 ? files[0].name : `${files.length} file terpilih`;
      setUploadStatus({
        type: 'success',
        message: `${result.sourceSummary} Klik "Generate Laporan Perhitungan Rekapitulasi Absensi" untuk menyusun laporan PDF A4.`,
        fileName: labelName,
      });
      showToast(`Data "${labelName}" berhasil dibaca (${result.rows.length} pegawai)`);
    } catch (err: any) {
      const msg = err?.message || 'Gagal membaca file rekapan bulanan.';
      setUploadStatus({ type: 'error', message: msg, fileName: files[0]?.name });
      showToast(msg);
    } finally {
      setIsParsing(false);
      e.target.value = '';
    }
  };

  const handleLogoUpload = (
    e: React.ChangeEvent<HTMLInputElement>,
    side: 'kiri' | 'kanan'
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const dataUrl = ev.target?.result as string;
      setConfig((prev) =>
        side === 'kiri' ? { ...prev, logoKiri: dataUrl } : { ...prev, logoKanan: dataUrl }
      );
      showToast(`Logo ${side === 'kiri' ? 'Kiri (Pemda)' : 'Kanan (Sekolah/Tut Wuri)'} berhasil diunggah`);
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleImportFromHistory = () => {
    const imported = buildMonthlyRowsFromHistory(records, config.bulan, config.tahun);
    if (imported.length === 0) {
      showToast('Belum ada data kartu tersimpan di Riwayat LensaHadir');
      return;
    }
    setRows(imported);
    setConfig((prev) => ({ ...prev, customWeeklyTrend: undefined }));
    setUploadStatus({
      type: 'success',
      message: `Berhasil menarik ${imported.length} pegawai dari Riwayat LensaHadir.`,
    });
    showToast(`${imported.length} data pegawai ditarik dari Riwayat`);
  };

  const handleLoadSample = () => {
    const sample = getSampleMonthlyRows();
    setRows(sample);
    setConfig((prev) => ({
      ...prev,
      bulan: 9,
      tahun: 2026,
      hariKerjaEfektif: 26,
      polaHariKerja: 'Senin–Sabtu (6 Hari Kerja)',
      tanggalTtd: '2026-09-30',
      customWeeklyTrend: undefined,
    }));
    setUploadStatus({
      type: 'success',
      message: 'Contoh data 11 guru/pegawai (September 2026, 26 Hari Kerja Efektif) berhasil dimuat.',
    });
    showToast('Contoh data 11 pegawai berhasil dimuat');
  };

  const handleAddRow = () => {
    const newRow: MonthlyRecapRow = {
      id: `mrec_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`,
      nama: '',
      nip: '-',
      jabatan: 'Guru Kelas',
      golongan: 'III/a',
      kategori: 'PNS',
      h: config.hariKerjaEfektif,
      td: 0,
      i: 0,
      s: 0,
      tk: 0,
    };
    setRows((prev) => [...prev, newRow]);
  };

  const handleUpdateRow = (
    id: string,
    field: keyof MonthlyRecapRow,
    value: string | number
  ) => {
    setRows((prev) =>
      prev.map((r) => {
        if (r.id !== id) return r;
        const next = { ...r, [field]: value };
        if (field === 'golongan' && typeof value === 'string') {
          next.kategori = inferKategoriFromGolongan(value);
        }
        return next;
      })
    );
  };

  const handleDeleteRow = (id: string) => {
    setRows((prev) => prev.filter((r) => r.id !== id));
  };

  const handleClearAll = () => {
    setRows([]);
    setUploadStatus(null);
    setConfirmClear(false);
    setConfig((prev) => ({ ...prev, customWeeklyTrend: undefined }));
    showToast('Daftar data rekapitulasi bulanan dikosongkan');
  };

  const handleGenerateReport = () => {
    if (rows.length === 0) {
      showToast('Upload file "Rekapan Absensi Bulanan" atau tambahkan minimal 1 pegawai terlebih dahulu');
      return;
    }
    setIsGenerating(true);
    setTimeout(() => {
      setIsGenerating(false);
      setActiveTab('preview');
      window.scrollTo({ top: 0, behavior: 'smooth' });
      showToast(
        `Laporan Rekapitulasi Absensi Foto TimeMark Bulan ${monthName} ${config.tahun} berhasil di-generate (${rows.length} personil)`
      );
    }, 300);
  };

  // Download full A4 PDF directly to PC Downloads folder
  const handleDownloadPdf = async (): Promise<string | null> => {
    if (rows.length === 0) {
      showToast('Belum ada data pegawai untuk diekspor ke PDF');
      return null;
    }
    setIsExportingPdf(true);
    try {
      const pdfBlob = await renderMonthlyRecapToPdfBlob(rows, config, settings);
      if (pdfBlob) {
        const cleanSchool = (settings.subInstansi || 'SEKOLAH')
          .replace(/\s+/g, '_')
          .replace(/[^A-Za-z0-9_]/g, '');
        const filename = `Laporan_Rekapitulasi_Absensi_Foto_TimeMark_${cleanSchool}_Bulan_${monthName}_${config.tahun}.pdf`;
        triggerBrowserDownload(pdfBlob, filename);
        showToast(`File PDF A4 berhasil diunduh: ${filename}`);
        return filename;
      } else {
        showToast('Gagal menghasilkan file PDF A4');
        return null;
      }
    } catch (err) {
      console.error(err);
      showToast('Terjadi kesalahan saat menghasilkan PDF A4');
      return null;
    } finally {
      setIsExportingPdf(false);
    }
  };

  const handleSaveToDrive = async () => {
    if (rows.length === 0) {
      showToast('Belum ada data pegawai untuk disimpan ke Drive');
      return;
    }
    setIsSavingDrive(true);
    try {
      const filename = await handleDownloadPdf();
      if (filename) {
        setDriveModalInfo({ filename });
      }
    } finally {
      setIsSavingDrive(false);
    }
  };

  const handleDownloadPng = async () => {
    if (rows.length === 0) return;
    setIsExportingPng(true);
    try {
      for (let i = 0; i < pages.length; i++) {
        const blob = await renderMonthlyRecapPageToPngBlob(i, rows, config, settings);
        if (blob) {
          const filename = `Laporan_Rekapitulasi_Absensi_${monthName}_${config.tahun}_Hal_${i + 1}.png`;
          triggerBrowserDownload(blob, filename);
          if (i < pages.length - 1) await new Promise((r) => setTimeout(r, 400));
        }
      }
      showToast(`Gambar A4 PNG (${pages.length} halaman) berhasil diunduh`);
    } catch (err) {
      console.error(err);
      showToast('Gagal mengunduh gambar PNG');
    } finally {
      setIsExportingPng(false);
    }
  };

  // Build SVG coordinates for WYSIWYG Trend Chart
  const buildSvgTrendChart = () => {
    const pts = stats.weeklyTrend;
    const svgW = 360;
    const svgH = 92;
    const padL = 24;
    const padR = 16;
    const padT = 12;
    const padB = 22;
    const plotW = svgW - padL - padR;
    const plotH = svgH - padT - padB;
    const maxVal = Math.max(1, stats.totalPersonil);

    const coords = pts.map((pt, idx) => {
      const x = padL + (pts.length > 1 ? (idx / (pts.length - 1)) * plotW : plotW / 2);
      const norm =
        pt.present >= maxVal
          ? 1
          : pt.present === maxVal - 1
          ? 0.55
          : Math.max(0.08, (pt.present / maxVal) * 0.55);
      const y = padT + plotH * (1 - norm);
      return { x, y, pt };
    });

    const linePath = coords
      .map((c, idx) => `${idx === 0 ? 'M' : 'L'} ${c.x.toFixed(1)} ${c.y.toFixed(1)}`)
      .join(' ');
    const areaPath =
      coords.length >= 2
        ? `${linePath} L ${coords[coords.length - 1].x.toFixed(1)} ${(padT + plotH).toFixed(1)} L ${coords[0].x.toFixed(1)} ${(padT + plotH).toFixed(1)} Z`
        : '';

    return (
      <svg viewBox={`0 0 ${svgW} ${svgH}`} className="w-full h-[94px] overflow-visible">
        <defs>
          <linearGradient id="monthlyTrendFill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#2563eb" stopOpacity="0.2" />
            <stop offset="100%" stopColor="#2563eb" stopOpacity="0.02" />
          </linearGradient>
        </defs>

        {/* Horizontal gridlines */}
        {[0, 0.45, 1].map((frac, idx) => {
          const gy = padT + plotH * (1 - frac);
          return (
            <line
              key={idx}
              x1={padL}
              y1={gy}
              x2={padL + plotW}
              y2={gy}
              stroke="#e2e8f0"
              strokeWidth="1"
            />
          );
        })}

        {/* Y axis ticks */}
        <text x={padL - 5} y={padT + 3} textAnchor="end" fontSize="8" fill="#94a3b8" fontWeight="600">
          {maxVal}
        </text>
        {maxVal > 1 && (
          <text
            x={padL - 5}
            y={padT + plotH * 0.55 + 3}
            textAnchor="end"
            fontSize="8"
            fill="#94a3b8"
            fontWeight="600"
          >
            {maxVal - 1}
          </text>
        )}
        <text
          x={padL - 5}
          y={padT + plotH + 3}
          textAnchor="end"
          fontSize="8"
          fill="#94a3b8"
          fontWeight="600"
        >
          0
        </text>

        {/* Area & Line */}
        {areaPath && <path d={areaPath} fill="url(#monthlyTrendFill)" />}
        {linePath && (
          <path d={linePath} fill="none" stroke="#2563eb" strokeWidth="2.2" strokeLinejoin="round" />
        )}

        {/* Orange dip markers */}
        {coords.map((c, idx) =>
          c.pt.td > 0 || c.pt.absent > 0 ? (
            <g key={idx}>
              <circle cx={c.x} cy={c.y} r="3.8" fill="#f59e0b" stroke="#ffffff" strokeWidth="1.5" />
              <rect
                x={c.x - 34}
                y={c.y + 6}
                width="68"
                height="13"
                rx="3"
                fill="#fef3c7"
                stroke="#f59e0b"
                strokeWidth="0.8"
              />
              <text
                x={c.x}
                y={c.y + 14.5}
                textAnchor="middle"
                fontSize="7"
                fontWeight="700"
                fill="#b45309"
              >
                {c.pt.td > 0 ? `${c.pt.td} TD (Dinas Luar)` : `${c.pt.absent} Absen`}
              </text>
            </g>
          ) : null
        )}

        {/* X axis week labels */}
        {coords.map((c, idx) => (
          <text
            key={idx}
            x={c.x}
            y={padT + plotH + 14}
            textAnchor="middle"
            fontSize="7.2"
            fill="#64748b"
          >
            {c.pt.label}
          </text>
        ))}
      </svg>
    );
  };

  const instansiHeaderLines = (settings.namaInstansi || 'PEMERINTAH KABUPATEN\nDINAS PENDIDIKAN')
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean);

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Header Banner & Mode Tabs */}
      <div className="no-print bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="bg-gradient-to-r from-[#1e3a8a] via-[#1d4ed8] to-indigo-700 px-5 py-4 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-white/15 rounded-xl shrink-0">
              <BarChart3 className="h-5 w-5 text-white" />
            </div>
            <div>
              <h1 className="text-base sm:text-lg font-black uppercase tracking-tight">
                Perhitungan Rekapitulasi Absensi Per Bulan
              </h1>
              <p className="text-xs text-blue-100">
                Upload File Rekapan Absensi Bulanan → Laporan Analitik &amp; Tabel Rekapitulasi PDF A4 Siap Cetak
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onOpenSettings}
            className="bg-white/15 hover:bg-white/25 text-white px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition self-start sm:self-auto shrink-0"
          >
            <Settings className="h-3.5 w-3.5" />
            Atur Kop &amp; Kepala Sekolah
          </button>
        </div>

        {/* Sub-Tabs */}
        <div className="px-5 py-3 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setActiveTab('editor')}
              className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition ${
                activeTab === 'editor'
                  ? 'bg-[#1d4ed8] text-white shadow-sm'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              <Edit3 className="h-3.5 w-3.5" />
              1. Upload &amp; Kelola Data ({rows.length} Pegawai)
            </button>

            <button
              type="button"
              onClick={handleGenerateReport}
              className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition ${
                activeTab === 'preview'
                  ? 'bg-[#1d4ed8] text-white shadow-sm'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              <Eye className="h-3.5 w-3.5" />
              2. Hasil Generate Laporan PDF A4 ({pages.length} Hal)
            </button>
          </div>

          <div className="text-xs text-slate-500 font-medium flex items-center gap-3">
            <span>
              Periode: <strong className="text-slate-800">{monthName} {config.tahun}</strong>
            </span>
            <span className="text-slate-300">|</span>
            <span>
              Disiplin Tugas:{' '}
              <strong className="text-emerald-700">{stats.tingkatDisiplinPct.toFixed(1)}%</strong>
            </span>
          </div>
        </div>
      </div>

      {/* ================================================================= */}
      {/* TAB 1: UPLOAD REKAPAN ABSENSI BULANAN & KELOLA DATA               */}
      {/* ================================================================= */}
      {activeTab === 'editor' && (
        <div className="no-print space-y-6">
          {/* Card 1: Tombol Upload "Rekapan Absensi Bulanan" */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5 sm:p-6 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
              <div>
                <h2 className="text-sm font-black text-slate-900 uppercase tracking-wider flex items-center gap-2">
                  <Upload className="h-4 w-4 text-[#1d4ed8]" />
                  Upload &quot;Rekapan Absensi Bulanan&quot;
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Unggah 1 file bulanan atau beberapa file rekapan (<b>Excel .xlsx / .xls, CSV, PDF, atau JSON</b>) — otomatis dihitung menjadi Laporan Rekapitulasi Absensi Foto TimeMark 1 bulan penuh.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => downloadMonthlyExcelTemplate(config.bulan, config.tahun)}
                  className="px-3 py-2 rounded-xl border border-emerald-200 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 text-xs font-bold flex items-center gap-1.5 transition"
                >
                  <FileSpreadsheet className="h-3.5 w-3.5" />
                  Unduh Template Excel
                </button>
                {records.length > 0 && (
                  <button
                    type="button"
                    onClick={handleImportFromHistory}
                    className="px-3 py-2 rounded-xl border border-indigo-200 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs font-bold flex items-center gap-1.5 transition"
                  >
                    <History className="h-3.5 w-3.5" />
                    Tarik dari Riwayat ({records.length})
                  </button>
                )}
                <button
                  type="button"
                  onClick={handleLoadSample}
                  className="px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700 text-xs font-bold flex items-center gap-1.5 transition"
                >
                  <Sparkles className="h-3.5 w-3.5 text-amber-500" />
                  Muat Contoh Data
                </button>
              </div>
            </div>

            {/* Primary Upload Button & Drop Area */}
            <input
              ref={fileUploadRef}
              type="file"
              accept=".xlsx,.xls,.csv,.pdf,.json,.png,.jpg,.jpeg"
              multiple
              onChange={handleFileUpload}
              className="hidden"
            />
            <div
              onClick={() => fileUploadRef.current?.click()}
              className="rounded-2xl border-2 border-dashed border-[#1d4ed8]/40 hover:border-[#1d4ed8] bg-blue-50/40 hover:bg-blue-50/70 p-6 sm:p-8 text-center cursor-pointer transition group"
            >
              <div className="mx-auto mb-3 h-12 w-12 rounded-2xl bg-[#1d4ed8] text-white flex items-center justify-center shadow-md shadow-blue-600/20 group-hover:scale-105 transition-transform">
                <Upload className="h-6 w-6" />
              </div>
              <button
                type="button"
                disabled={isParsing}
                className="bg-[#1d4ed8] hover:bg-[#1e3a8a] text-white px-6 py-2.5 rounded-xl font-black text-sm shadow-sm transition inline-flex items-center gap-2"
              >
                <Upload className="h-4 w-4" />
                {isParsing ? 'Membaca Seluruh Halaman & Menghitung Data...' : 'Upload "Rekapan Absensi Bulanan"'}
              </button>
              <p className="text-xs text-slate-500 mt-2.5">
                Mendukung <b>PDF (.pdf)</b> (tabel, kalender harian 1–31, scan, maupun kumpulan kartu harian), <b>Excel (.xlsx / .xls)</b>, <b>CSV</b>, &amp; <b>Gambar</b>
              </p>
            </div>

            {uploadStatus && (
              <div
                className={`rounded-xl px-4 py-3 text-xs font-semibold flex flex-col sm:flex-row sm:items-center justify-between gap-3 border ${
                  uploadStatus.type === 'success'
                    ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                    : 'bg-rose-50 border-rose-200 text-rose-700'
                }`}
              >
                <div className="flex items-start gap-2.5">
                  {uploadStatus.type === 'success' ? (
                    <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0 mt-0.5" />
                  ) : (
                    <AlertCircle className="h-4 w-4 text-rose-600 shrink-0 mt-0.5" />
                  )}
                  <div>
                    {uploadStatus.fileName && (
                      <span className="font-bold mr-1">[{uploadStatus.fileName}]</span>
                    )}
                    {uploadStatus.message}
                  </div>
                </div>

                {uploadStatus.type === 'success' && rows.length > 0 && (
                  <button
                    type="button"
                    onClick={handleGenerateReport}
                    disabled={isGenerating}
                    className="shrink-0 bg-[#1d4ed8] hover:bg-[#1e3a8a] text-white px-4 py-2 rounded-xl font-black text-xs flex items-center gap-1.5 shadow-sm transition"
                  >
                    <Sparkles className="h-3.5 w-3.5 text-amber-300" />
                    {isGenerating
                      ? 'Menghitung...'
                      : 'Generate Laporan Perhitungan Rekapitulasi Absensi'}
                  </button>
                )}
              </div>
            )}
          </div>

          {/* Card 2: Pengaturan Periode, Hari Kerja Efektif, & Logo Kop */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5 sm:p-6 space-y-5">
            <h2 className="text-sm font-black text-slate-900 uppercase tracking-wider border-b border-slate-100 pb-3">
              Pengaturan Periode, Hari Kerja Efektif &amp; Logo Kop
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">Bulan Laporan</label>
                <select
                  value={config.bulan}
                  onChange={(e) => handleChangePeriod(Number(e.target.value), config.tahun)}
                  className="w-full rounded-xl border border-slate-300 bg-white p-2.5 text-sm font-bold text-slate-900 focus:border-[#1d4ed8] outline-none"
                >
                  {INDONESIAN_MONTHS.map((m, idx) => (
                    <option key={m} value={idx + 1}>
                      {m}
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">Tahun</label>
                <input
                  type="number"
                  min={2020}
                  max={2040}
                  value={config.tahun}
                  onChange={(e) =>
                    handleChangePeriod(config.bulan, parseInt(e.target.value, 10) || 2026)
                  }
                  className="w-full rounded-xl border border-slate-300 bg-white p-2.5 text-sm font-bold text-slate-900 focus:border-[#1d4ed8] outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">Hari Kerja Efektif</label>
                <input
                  type="number"
                  min={1}
                  max={31}
                  value={config.hariKerjaEfektif}
                  onChange={(e) =>
                    setConfig((prev) => ({
                      ...prev,
                      hariKerjaEfektif: Math.max(1, parseInt(e.target.value, 10) || 1),
                    }))
                  }
                  className="w-full rounded-xl border border-slate-300 bg-white p-2.5 text-sm font-bold text-slate-900 focus:border-[#1d4ed8] outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">Pola Hari Kerja</label>
                <select
                  value={config.polaHariKerja}
                  onChange={(e) =>
                    handleChangePeriod(
                      config.bulan,
                      config.tahun,
                      e.target.value as MonthlyRecapConfig['polaHariKerja']
                    )
                  }
                  className="w-full rounded-xl border border-slate-300 bg-white p-2.5 text-xs font-bold text-slate-900 focus:border-[#1d4ed8] outline-none"
                >
                  <option value="Senin–Sabtu (6 Hari Kerja)">Senin–Sabtu (6 Hari Kerja)</option>
                  <option value="Senin–Jumat (5 Hari Kerja)">Senin–Jumat (5 Hari Kerja)</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">Tanggal Tanda Tangan</label>
                <input
                  type="date"
                  value={config.tanggalTtd}
                  onChange={(e) => setConfig((prev) => ({ ...prev, tanggalTtd: e.target.value }))}
                  className="w-full rounded-xl border border-slate-300 bg-white p-2.5 text-xs font-bold text-slate-900 focus:border-[#1d4ed8] outline-none"
                />
              </div>
            </div>

            {/* Optional Logo Uploads for Kop Kiri & Kop Kanan */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-100">
              <div className="flex items-center justify-between gap-3 rounded-xl border border-slate-200 bg-slate-50 p-3">
                <div className="flex items-center gap-3">
                  <img
                    src={config.logoKiri || DEFAULT_LOGO_KIRI}
                    alt="Logo Kiri"
                    className="h-11 w-11 rounded-lg object-contain bg-white border border-slate-200 p-1"
                  />
                  <div>
                    <div className="text-xs font-bold text-slate-800">Logo Kiri (Pemda/Kabupaten)</div>
                    <div className="text-[11px] text-slate-500">Opsional — ganti dengan logo resmi daerah</div>
                  </div>
                </div>
                <div className="flex items-center gap-1.5">
                  <input
                    ref={logoKiriRef}
                    type="file"
                    accept="image/*"
                    onChange={(e) => handleLogoUpload(e, 'kiri')}
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => logoKiriRef.current?.click()}
                    className="px-2.5 py-1.5 rounded-lg bg-white border border-slate-300 hover:bg-slate-100 text-xs font-bold text-slate-700 flex items-center gap-1"
                  >
                    <ImageIcon className="h-3.5 w-3.5" />
                    Ganti
                  </button>
                  {config.logoKiri && (
                    <button
                      type="button"
                      onClick={() => setConfig((prev) => ({ ...prev, logoKiri: undefined }))}
                      className="text-[11px] font-bold text-rose-600 hover:underline px-1"
                    >
                      Reset
                    </button>
                  )}
                </div>
              </div>

              <div className="flex items-center justify-between gap-3 rounded-xl border border-slate-200 bg-slate-50 p-3">
                <div className="flex items-center gap-3">
                  <img
                    src={config.logoKanan || DEFAULT_LOGO_KANAN}
                    alt="Logo Kanan"
                    className="h-11 w-11 rounded-lg object-contain bg-white border border-slate-200 p-1"
                  />
                  <div>
                    <div className="text-xs font-bold text-slate-800">Logo Kanan (Tut Wuri Handayani)</div>
                    <div className="text-[11px] text-slate-500">Opsional — ganti dengan logo PNG pilihan</div>
                  </div>
                </div>
                <div className="flex items-center gap-1.5">
                  <input
                    ref={logoKananRef}
                    type="file"
                    accept="image/*"
                    onChange={(e) => handleLogoUpload(e, 'kanan')}
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => logoKananRef.current?.click()}
                    className="px-2.5 py-1.5 rounded-lg bg-white border border-slate-300 hover:bg-slate-100 text-xs font-bold text-slate-700 flex items-center gap-1"
                  >
                    <ImageIcon className="h-3.5 w-3.5" />
                    Ganti
                  </button>
                  {config.logoKanan && (
                    <button
                      type="button"
                      onClick={() => setConfig((prev) => ({ ...prev, logoKanan: undefined }))}
                      className="text-[11px] font-bold text-rose-600 hover:underline px-1"
                    >
                      Reset
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Live 4 KPI Summary Strip */}
          {rows.length > 0 && (
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
              <div className="bg-white rounded-xl border border-slate-200 border-l-4 border-l-blue-600 p-4 shadow-xs">
                <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                  Hari Kerja Efektif
                </div>
                <div className="text-xl font-black text-slate-900 mt-1">
                  {config.hariKerjaEfektif} Hari
                </div>
                <div className="text-[11px] text-slate-500 mt-0.5">{config.polaHariKerja}</div>
              </div>
              <div className="bg-white rounded-xl border border-slate-200 border-l-4 border-l-emerald-600 p-4 shadow-xs">
                <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                  Tingkat Disiplin Tugas
                </div>
                <div className="text-xl font-black text-slate-900 mt-1">
                  {stats.tingkatDisiplinPct.toFixed(1)}%
                </div>
                <div className="text-[11px] text-slate-500 mt-0.5">
                  {stats.totalAbsenNonTugas} Absen / Alpa / Bolos
                </div>
              </div>
              <div className="bg-white rounded-xl border border-slate-200 border-l-4 border-l-indigo-600 p-4 shadow-xs">
                <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                  Total Guru &amp; Tendik
                </div>
                <div className="text-xl font-black text-slate-900 mt-1">
                  {stats.totalPersonil} Personil
                </div>
                <div className="text-[11px] text-slate-500 mt-0.5">{stats.personilBreakdownText}</div>
              </div>
              <div className="bg-white rounded-xl border border-slate-200 border-l-4 border-l-amber-500 p-4 shadow-xs">
                <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                  Presensi Fisik di Sekolah
                </div>
                <div className="text-xl font-black text-slate-900 mt-1">
                  {stats.presensiFisikPct.toFixed(2)}%
                </div>
                <div className="text-[11px] text-slate-500 mt-0.5">
                  {stats.totalH} Hadir • {stats.totalTD} Tugas Dinas
                </div>
              </div>
            </div>
          )}

          {/* Card 3: Tabel Data Rekapitulasi Pegawai (Editable) */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100 flex flex-wrap items-center justify-between gap-3">
              <div>
                <h2 className="text-sm font-black text-slate-900 uppercase tracking-wider">
                  Data Perhitungan Rekapitulasi Pegawai ({rows.length} Personil)
                </h2>
                <p className="text-xs text-slate-500">
                  Hasil unggahan dapat langsung diperiksa atau disunting sebelum dicetak ke PDF A4.
                </p>
              </div>
              <button
                type="button"
                onClick={handleAddRow}
                className="px-3.5 py-2 rounded-xl bg-blue-50 hover:bg-blue-100 text-[#1d4ed8] text-xs font-bold flex items-center gap-1.5 transition"
              >
                <Plus className="h-4 w-4" />
                Tambah Baris Pegawai
              </button>
            </div>

            {rows.length === 0 ? (
              <div className="p-10 text-center text-slate-500 space-y-2">
                <p className="text-sm font-bold text-slate-700">
                  Belum ada data pegawai untuk bulan {monthName} {config.tahun}
                </p>
                <p className="text-xs">
                  Klik <b>Upload &quot;Rekapan Absensi Bulanan&quot;</b> di atas, tarik dari Riwayat, atau klik <b>Muat Contoh Data</b> untuk langsung melihat hasil laporan PDF A4.
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-xs border-collapse min-w-[920px]">
                  <thead>
                    <tr className="bg-[#1e3a8a] text-white">
                      <th className="py-2.5 px-2 text-center w-10">No</th>
                      <th className="py-2.5 px-2 text-left">Nama Lengkap &amp; Gelar</th>
                      <th className="py-2.5 px-2 text-left w-44">NIP</th>
                      <th className="py-2.5 px-2 text-left w-36">Tugas / Jabatan</th>
                      <th className="py-2.5 px-2 text-center w-20">Gol.</th>
                      <th className="py-2.5 px-2 text-center w-24">Status</th>
                      <th className="py-2.5 px-1 text-center w-14 bg-[#2563eb]">H</th>
                      <th className="py-2.5 px-1 text-center w-14 bg-[#2563eb]">TD</th>
                      <th className="py-2.5 px-1 text-center w-14 bg-[#2563eb]">I</th>
                      <th className="py-2.5 px-1 text-center w-14 bg-[#2563eb]">S</th>
                      <th className="py-2.5 px-1 text-center w-14 bg-[#2563eb]">TK</th>
                      <th className="py-2.5 px-2 text-center w-16">Total</th>
                      <th className="py-2.5 px-2 text-center w-20">% Hadir</th>
                      <th className="py-2.5 px-2 text-center w-10"></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {rows.map((r, idx) => {
                      const totalEff = (r.h || 0) + (r.td || 0);
                      const pct = Math.min(
                        100,
                        (totalEff / Math.max(1, config.hariKerjaEfektif)) * 100
                      );
                      return (
                        <tr key={r.id} className="hover:bg-slate-50">
                          <td className="py-2 px-2 text-center font-bold text-slate-500">
                            {idx + 1}
                          </td>
                          <td className="py-1.5 px-1.5">
                            <input
                              type="text"
                              value={r.nama}
                              onChange={(e) => handleUpdateRow(r.id, 'nama', e.target.value)}
                              placeholder="Nama & Gelar (contoh: S.Pd)"
                              className="w-full rounded-lg border border-slate-200 px-2 py-1.5 font-bold text-slate-900 focus:border-[#1d4ed8] outline-none"
                            />
                          </td>
                          <td className="py-1.5 px-1.5">
                            <input
                              type="text"
                              value={r.nip}
                              onChange={(e) => handleUpdateRow(r.id, 'nip', e.target.value)}
                              className="w-full rounded-lg border border-slate-200 px-2 py-1.5 font-mono text-[11px] text-slate-700 focus:border-[#1d4ed8] outline-none"
                            />
                          </td>
                          <td className="py-1.5 px-1.5">
                            <input
                              type="text"
                              value={r.jabatan}
                              onChange={(e) => handleUpdateRow(r.id, 'jabatan', e.target.value)}
                              className="w-full rounded-lg border border-slate-200 px-2 py-1.5 text-slate-800 focus:border-[#1d4ed8] outline-none"
                            />
                          </td>
                          <td className="py-1.5 px-1.5">
                            <input
                              type="text"
                              value={r.golongan}
                              onChange={(e) => handleUpdateRow(r.id, 'golongan', e.target.value)}
                              className="w-full rounded-lg border border-slate-200 px-1.5 py-1.5 text-center font-semibold text-slate-800 focus:border-[#1d4ed8] outline-none"
                            />
                          </td>
                          <td className="py-1.5 px-1.5">
                            <select
                              value={r.kategori}
                              onChange={(e) =>
                                handleUpdateRow(
                                  r.id,
                                  'kategori',
                                  e.target.value as PegawaiKategori
                                )
                              }
                              className="w-full rounded-lg border border-slate-200 px-1.5 py-1.5 bg-white font-semibold text-slate-700 focus:border-[#1d4ed8] outline-none"
                            >
                              <option value="PNS">PNS</option>
                              <option value="PPPK">PPPK</option>
                              <option value="GTT">GTT</option>
                              <option value="Lainnya">Lainnya</option>
                            </select>
                          </td>
                          {(['h', 'td', 'i', 's', 'tk'] as const).map((field) => (
                            <td key={field} className="py-1.5 px-1">
                              <input
                                type="number"
                                min={0}
                                max={31}
                                value={r[field]}
                                onChange={(e) =>
                                  handleUpdateRow(
                                    r.id,
                                    field,
                                    Math.max(0, parseInt(e.target.value, 10) || 0)
                                  )
                                }
                                className="w-full rounded-lg border border-slate-200 py-1.5 text-center font-bold text-slate-900 focus:border-[#1d4ed8] outline-none"
                              />
                            </td>
                          ))}
                          <td className="py-2 px-2 text-center font-black text-slate-900">
                            {totalEff}
                          </td>
                          <td className="py-2 px-2 text-center">
                            <span
                              className={`inline-block px-2 py-0.5 rounded-md font-bold text-[11px] ${
                                pct >= 95
                                  ? 'bg-emerald-50 text-emerald-700'
                                  : pct >= 80
                                  ? 'bg-amber-50 text-amber-700'
                                  : 'bg-rose-50 text-rose-700'
                              }`}
                            >
                              {pct.toFixed(1)}%
                            </span>
                          </td>
                          <td className="py-2 px-1 text-center">
                            <button
                              type="button"
                              onClick={() => handleDeleteRow(r.id)}
                              className="p-1 text-slate-400 hover:text-rose-600 rounded transition"
                              title="Hapus baris"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}

            {/* Editable Catatan & Verifikasi Administrasi */}
            <div className="p-5 bg-slate-50 border-t border-slate-200 space-y-1.5">
              <label className="text-xs font-bold text-slate-700">
                Catatan &amp; Verifikasi Administrasi (Opsional — 1 baris = 1 poin; kosongkan untuk otomatis)
              </label>
              <textarea
                rows={3}
                value={config.catatanAdmin}
                onChange={(e) => setConfig((prev) => ({ ...prev, catatanAdmin: e.target.value }))}
                placeholder="Biarkan kosong agar sistem menyusun Catatan & Verifikasi Administrasi secara otomatis sesuai data bulanan."
                className="w-full rounded-xl border border-slate-300 bg-white p-3 text-xs text-slate-800 focus:border-[#1d4ed8] outline-none"
              />
            </div>
          </div>

          {/* Bottom Actions */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div>
              {!confirmClear ? (
                <button
                  type="button"
                  onClick={() => setConfirmClear(true)}
                  disabled={rows.length === 0}
                  className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs flex items-center gap-1.5 transition disabled:opacity-40"
                >
                  <RotateCcw className="h-4 w-4" />
                  Kosongkan Data
                </button>
              ) : (
                <div className="flex items-center gap-2 bg-rose-50 border border-rose-200 px-3 py-2 rounded-xl">
                  <span className="text-xs font-bold text-rose-700">Hapus semua baris?</span>
                  <button
                    type="button"
                    onClick={handleClearAll}
                    className="px-3 py-1 rounded-lg bg-rose-600 text-white text-xs font-bold"
                  >
                    Ya
                  </button>
                  <button
                    type="button"
                    onClick={() => setConfirmClear(false)}
                    className="px-3 py-1 rounded-lg bg-white border border-slate-200 text-slate-600 text-xs font-bold"
                  >
                    Batal
                  </button>
                </div>
              )}
            </div>

            <div className="flex flex-wrap items-center gap-2.5 w-full sm:w-auto justify-end">
              <button
                type="button"
                onClick={handleGenerateReport}
                disabled={rows.length === 0 || isGenerating}
                className="w-full sm:w-auto bg-[#1d4ed8] hover:bg-[#1e3a8a] text-white px-7 py-3.5 rounded-xl font-black text-xs sm:text-sm shadow-lg shadow-blue-900/20 flex items-center justify-center gap-2 transition disabled:opacity-40"
              >
                <Sparkles className="h-4 w-4 text-amber-300" />
                {isGenerating
                  ? 'Menghitung & Menyusun Laporan...'
                  : 'Generate Laporan Perhitungan Rekapitulasi Absensi'}
              </button>

              <button
                type="button"
                onClick={handleDownloadPdf}
                disabled={rows.length === 0 || isExportingPdf}
                className="w-full sm:w-auto bg-emerald-600 hover:bg-emerald-700 text-white px-5 py-3.5 rounded-xl font-black text-xs sm:text-sm shadow-sm flex items-center justify-center gap-2 transition disabled:opacity-40"
              >
                <FileDown className="h-4 w-4" />
                {isExportingPdf ? 'Membuat PDF...' : 'Unduh PDF'}
              </button>

              <button
                type="button"
                onClick={handleSaveToDrive}
                disabled={rows.length === 0 || isSavingDrive || isExportingPdf}
                className="w-full sm:w-auto bg-amber-600 hover:bg-amber-700 text-white px-5 py-3.5 rounded-xl font-black text-xs sm:text-sm shadow-sm flex items-center justify-center gap-2 transition disabled:opacity-40"
              >
                <HardDrive className="h-4 w-4" />
                {isSavingDrive ? 'Menyiapkan...' : 'Simpan ke Drive'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================================================================= */}
      {/* TAB 2: HASIL GENERATE LAPORAN PERHITUNGAN REKAPITULASI (PDF A4)   */}
      {/* ================================================================= */}
      {activeTab === 'preview' && (
        <div className="space-y-6">
          {/* Toolbar */}
          <div className="no-print bg-white border border-slate-200 rounded-2xl p-4 shadow-sm flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => setActiveTab('editor')}
                className="bg-slate-100 hover:bg-slate-200 text-slate-700 px-4 py-2.5 rounded-xl font-bold text-xs flex items-center gap-1.5 transition"
              >
                <Edit3 className="h-4 w-4" />
                Edit / Upload Ulang
              </button>
              <button
                type="button"
                onClick={onOpenSettings}
                className="bg-slate-100 hover:bg-slate-200 text-slate-700 px-4 py-2.5 rounded-xl font-bold text-xs flex items-center gap-1.5 transition"
              >
                <Settings className="h-4 w-4" />
                Kop &amp; Kepala Sekolah
              </button>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={handleDownloadPdf}
                disabled={isExportingPdf || rows.length === 0}
                className="bg-[#1d4ed8] hover:bg-[#1e3a8a] text-white px-6 py-2.5 rounded-xl font-black text-xs sm:text-sm flex items-center gap-2 shadow-md shadow-blue-900/20 transition disabled:opacity-50"
              >
                <FileDown className="h-4 w-4" />
                {isExportingPdf ? 'Menyusun PDF...' : 'Unduh PDF'}
              </button>

              <button
                type="button"
                onClick={handleSaveToDrive}
                disabled={isSavingDrive || isExportingPdf || rows.length === 0}
                className="bg-amber-600 hover:bg-amber-700 text-white px-4 py-2.5 rounded-xl font-black text-xs flex items-center gap-1.5 shadow-sm transition disabled:opacity-50"
              >
                <HardDrive className="h-4 w-4" />
                {isSavingDrive ? 'Menyiapkan...' : 'Simpan ke Drive'}
              </button>

              <button
                type="button"
                onClick={handleDownloadPng}
                disabled={isExportingPng || rows.length === 0}
                className="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2.5 rounded-xl font-bold text-xs flex items-center gap-1.5 shadow-sm transition disabled:opacity-50"
              >
                <Download className="h-4 w-4" />
                {isExportingPng ? 'Mengunduh...' : 'Unduh PNG'}
              </button>

              <button
                type="button"
                onClick={() => window.print()}
                className="bg-slate-800 hover:bg-slate-900 text-white px-4 py-2.5 rounded-xl font-bold text-xs flex items-center gap-1.5 shadow-sm transition"
              >
                <Printer className="h-4 w-4" />
                Cetak A4
              </button>
            </div>
          </div>

          {/* Paginated A4 Sheets */}
          <div id="dailyReportPrintContainer" className="space-y-8">
            {pages.map((page) => (
              <div key={page.pageNumber} className="overflow-x-auto pb-2 print:overflow-visible print:pb-0">
                <section className="a4-sheet mx-auto w-[794px] min-h-[1123px] bg-white border border-slate-300 shadow-xl px-[38px] py-[30px] flex flex-col justify-between text-slate-900">
                  <div>
                    {/* HEADER WITH 2 LOGOS (PAGE 1) */}
                    {page.isFirstPage ? (
                      <>
                        <div className="flex items-center justify-between gap-3 pb-2.5 border-b-[2.5px] border-[#1e40af]">
                          <img
                            src={config.logoKiri || DEFAULT_LOGO_KIRI}
                            alt="Logo Daerah"
                            className="h-[64px] w-[64px] object-contain shrink-0 ml-2"
                          />
                          <div className="text-center flex-1 leading-tight">
                            {instansiHeaderLines[0] && (
                              <div className="text-[11px] font-bold tracking-[0.06em] text-slate-700 uppercase">
                                {instansiHeaderLines[0]}
                              </div>
                            )}
                            {instansiHeaderLines[1] && (
                              <div className="text-[10.5px] font-bold tracking-[0.05em] text-slate-600 uppercase mt-0.5">
                                {instansiHeaderLines[1]}
                              </div>
                            )}
                            <h2 className="text-[15.5px] font-black text-slate-950 uppercase tracking-tight mt-1">
                              LAPORAN REKAPITULASI ABSENSI FOTO TIMEMARK
                            </h2>
                            <div className="text-[12.5px] font-extrabold text-[#1d4ed8] uppercase mt-0.5">
                              {settings.subInstansi || 'SATUAN PENDIDIKAN'} – BULAN {monthName.toUpperCase()} {config.tahun}
                            </div>
                            <div className="text-[9.5px] text-slate-500 mt-1">
                              Berdasarkan Kalender Pendidikan &amp; Rekap Kehadiran Digital (TimeMark) • Periode: {stats.periodLabel}
                            </div>
                          </div>
                          <img
                            src={config.logoKanan || DEFAULT_LOGO_KANAN}
                            alt="Logo Tut Wuri Handayani"
                            className="h-[64px] w-[64px] object-contain shrink-0 mr-2"
                          />
                        </div>

                        {/* 4 KPI CARDS */}
                        <div className="grid grid-cols-4 gap-2.5 mt-3.5">
                          <div className="rounded-lg border border-slate-200 border-l-[3.5px] border-l-blue-600 px-3 py-2 bg-white">
                            <div className="text-[8px] font-bold text-slate-500 uppercase tracking-wider">
                              HARI KERJA EFEKTIF
                            </div>
                            <div className="text-[16px] font-black text-slate-900 leading-tight mt-0.5">
                              {config.hariKerjaEfektif} Hari
                            </div>
                            <div className="text-[8px] text-slate-500 mt-0.5">
                              {config.polaHariKerja}
                            </div>
                          </div>

                          <div className="rounded-lg border border-slate-200 border-l-[3.5px] border-l-emerald-600 px-3 py-2 bg-white">
                            <div className="text-[8px] font-bold text-slate-500 uppercase tracking-wider">
                              TINGKAT DISIPLIN TUGAS
                            </div>
                            <div className="text-[16px] font-black text-slate-900 leading-tight mt-0.5">
                              {stats.tingkatDisiplinPct.toFixed(1)}%
                            </div>
                            <div className="text-[8px] text-slate-500 mt-0.5">
                              {stats.totalAbsenNonTugas} Absen / Alpa / Bolos
                            </div>
                          </div>

                          <div className="rounded-lg border border-slate-200 border-l-[3.5px] border-l-indigo-600 px-3 py-2 bg-white">
                            <div className="text-[8px] font-bold text-slate-500 uppercase tracking-wider">
                              TOTAL GURU &amp; TENDIK
                            </div>
                            <div className="text-[16px] font-black text-slate-900 leading-tight mt-0.5">
                              {stats.totalPersonil} Personil
                            </div>
                            <div className="text-[8px] text-slate-500 mt-0.5 truncate">
                              {stats.personilBreakdownText}
                            </div>
                          </div>

                          <div className="rounded-lg border border-slate-200 border-l-[3.5px] border-l-amber-500 px-3 py-2 bg-white">
                            <div className="text-[8px] font-bold text-slate-500 uppercase tracking-wider">
                              PRESENSI FISIK DI SEKOLAH
                            </div>
                            <div className="text-[16px] font-black text-slate-900 leading-tight mt-0.5">
                              {stats.presensiFisikPct.toFixed(2)}%
                            </div>
                            <div className="text-[8px] text-slate-500 mt-0.5">
                              {stats.totalH} Hadir • {stats.totalTD} Tugas Dinas
                            </div>
                          </div>
                        </div>

                        {/* VISUAL ANALYTICS BOX */}
                        <div className="mt-3 rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 grid grid-cols-12 gap-4 items-center">
                          {/* Left: Kurva Tren Kehadiran Harian Pegawai */}
                          <div className="col-span-7">
                            <div className="flex items-start justify-between gap-2 mb-1">
                              <div className="text-[10px] font-bold text-slate-900 leading-tight">
                                Kurva Tren Kehadiran Harian Pegawai (1–{stats.daysInMonth} {monthName} {config.tahun})
                              </div>
                              <span className="shrink-0 bg-emerald-50 text-emerald-700 text-[8.5px] font-bold px-2 py-0.5 rounded-md">
                                {stats.tingkatDisiplinPct >= 99.5
                                  ? `Sempurna / ${stats.totalPersonil} Pegawai Aktif`
                                  : `${stats.totalPersonil} Pegawai Aktif`}
                              </span>
                            </div>
                            {buildSvgTrendChart()}
                          </div>

                          {/* Right: Distribusi Status Kehadiran */}
                          <div className="col-span-5 space-y-2">
                            <div className="text-[10px] font-bold text-slate-900">
                              Distribusi Status Kehadiran
                            </div>

                            <div className="space-y-0.5">
                              <div className="flex items-center justify-between text-[8.5px] font-bold">
                                <span className="text-emerald-700 flex items-center gap-1">
                                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-600 inline-block" />
                                  Hadir TimeMark Fisik ({stats.presensiFisikPct.toFixed(2)}%)
                                </span>
                                <span className="text-slate-900">{stats.totalH} Hari</span>
                              </div>
                              <div className="h-1.5 w-full bg-slate-200 rounded-full overflow-hidden">
                                <div
                                  className="h-full bg-emerald-600 rounded-full"
                                  style={{ width: `${Math.max(stats.presensiFisikPct > 0 ? 4 : 0, stats.presensiFisikPct)}%` }}
                                />
                              </div>
                            </div>

                            <div className="space-y-0.5">
                              <div className="flex items-center justify-between text-[8.5px] font-bold">
                                <span className="text-amber-700 flex items-center gap-1">
                                  <span className="h-1.5 w-1.5 rounded-full bg-amber-500 inline-block" />
                                  Tugas Dinas / TD ({stats.tdPct.toFixed(2)}%)
                                </span>
                                <span className="text-slate-900">{stats.totalTD} Hari</span>
                              </div>
                              <div className="h-1.5 w-full bg-slate-200 rounded-full overflow-hidden">
                                <div
                                  className="h-full bg-amber-500 rounded-full"
                                  style={{ width: `${Math.max(stats.tdPct > 0 ? 4 : 0, stats.tdPct)}%` }}
                                />
                              </div>
                            </div>

                            <div className="space-y-0.5">
                              <div className="flex items-center justify-between text-[8.5px] font-bold">
                                <span className="text-rose-700 flex items-center gap-1">
                                  <span className="h-1.5 w-1.5 rounded-full bg-rose-600 inline-block" />
                                  Izin / Sakit / Alpa ({stats.absenPct.toFixed(2)}%)
                                </span>
                                <span className="text-slate-900">{stats.totalAbsenNonTugas} Hari</span>
                              </div>
                              <div className="h-1.5 w-full bg-slate-200 rounded-full overflow-hidden">
                                <div
                                  className="h-full bg-rose-600 rounded-full"
                                  style={{ width: `${Math.max(stats.absenPct > 0 ? 4 : 0, stats.absenPct)}%` }}
                                />
                              </div>
                            </div>
                          </div>
                        </div>
                      </>
                    ) : (
                      <div className="pb-2 mb-3 border-b-2 border-[#1e40af] text-[10px] font-bold text-slate-600 uppercase">
                        Lanjutan — Laporan Rekapitulasi Absensi Bulan {monthName} {config.tahun} ({settings.subInstansi})
                      </div>
                    )}

                    {/* TABLE SECTION HEADER */}
                    <div className="mt-3.5 mb-1.5 flex items-center justify-between">
                      <h3 className="text-[10.5px] font-black uppercase text-slate-900 tracking-tight">
                        DAFTAR REKAPITULASI PRESENSI PEGAWAI BULAN {monthName.toUpperCase()} {config.tahun}
                      </h3>
                      <span className="text-[9px] font-semibold text-slate-500">
                        Kebutuhan Hari Kerja Efektif: {config.hariKerjaEfektif} Hari
                      </span>
                    </div>

                    {/* MAIN RECAP TABLE */}
                    <table className="w-full border-collapse text-[9.5px]">
                      <thead>
                        <tr className="bg-[#1e3a8a] text-white [print-color-adjust:exact] [-webkit-print-color-adjust:exact]">
                          <th rowSpan={2} className="border border-white/25 py-1.5 px-1.5 text-center w-[28px]">
                            No
                          </th>
                          <th rowSpan={2} className="border border-white/25 py-1.5 px-2 text-left w-[158px]">
                            Nama Lengkap &amp; Gelar
                          </th>
                          <th rowSpan={2} className="border border-white/25 py-1.5 px-1.5 text-center w-[124px]">
                            NIP
                          </th>
                          <th rowSpan={2} className="border border-white/25 py-1.5 px-2 text-left w-[118px]">
                            Tugas / Jabatan
                          </th>
                          <th rowSpan={2} className="border border-white/25 py-1.5 px-1 text-center w-[42px]">
                            Gol.
                          </th>
                          <th colSpan={5} className="border border-white/25 py-1 px-1 text-center">
                            Rincian Kehadiran (Hari)
                          </th>
                          <th rowSpan={2} className="border border-white/25 py-1 px-1 text-center w-[48px] leading-tight">
                            Total<br />Efektif
                          </th>
                          <th rowSpan={2} className="border border-white/25 py-1.5 px-1.5 text-center w-[58px]">
                            % Hadir
                          </th>
                        </tr>
                        <tr className="bg-[#2563eb] text-white [print-color-adjust:exact] [-webkit-print-color-adjust:exact]">
                          <th className="border border-white/25 py-1 text-center w-[28px]">H</th>
                          <th className="border border-white/25 py-1 text-center w-[28px]">TD</th>
                          <th className="border border-white/25 py-1 text-center w-[26px]">I</th>
                          <th className="border border-white/25 py-1 text-center w-[26px]">S</th>
                          <th className="border border-white/25 py-1 text-center w-[26px]">TK</th>
                        </tr>
                      </thead>
                      <tbody>
                        {page.rows.map((r, idx) => {
                          const totalEff = (r.h || 0) + (r.td || 0);
                          const pct = Math.min(
                            100,
                            (totalEff / Math.max(1, config.hariKerjaEfektif)) * 100
                          );
                          return (
                            <tr
                              key={r.id}
                              className={idx % 2 === 1 ? 'bg-slate-50/80' : 'bg-white'}
                            >
                              <td className="border border-slate-300 py-1.5 px-1 text-center text-slate-600 font-semibold">
                                {page.startIndex + idx + 1}
                              </td>
                              <td className="border border-slate-300 py-1.5 px-2 font-bold text-slate-900">
                                {r.nama || '-'}
                              </td>
                              <td className="border border-slate-300 py-1.5 px-1.5 text-center text-[8.8px] text-slate-700 leading-tight">
                                {r.nip || '-'}
                              </td>
                              <td className="border border-slate-300 py-1.5 px-2 text-slate-800">
                                {r.jabatan || '-'}
                              </td>
                              <td className="border border-slate-300 py-1.5 px-1 text-center font-semibold text-slate-700">
                                {r.golongan || '-'}
                              </td>
                              <td className="border border-slate-300 py-1.5 px-1 text-center font-bold text-slate-900">
                                {r.h || 0}
                              </td>
                              <td
                                className={`border border-slate-300 py-1.5 px-1 text-center ${
                                  r.td > 0 ? 'font-bold text-amber-600' : 'text-slate-500'
                                }`}
                              >
                                {r.td || 0}
                              </td>
                              <td
                                className={`border border-slate-300 py-1.5 px-1 text-center ${
                                  r.i > 0 ? 'font-bold text-blue-600' : 'text-slate-500'
                                }`}
                              >
                                {r.i || 0}
                              </td>
                              <td
                                className={`border border-slate-300 py-1.5 px-1 text-center ${
                                  r.s > 0 ? 'font-bold text-orange-600' : 'text-slate-500'
                                }`}
                              >
                                {r.s || 0}
                              </td>
                              <td
                                className={`border border-slate-300 py-1.5 px-1 text-center ${
                                  r.tk > 0 ? 'font-bold text-rose-600' : 'text-slate-500'
                                }`}
                              >
                                {r.tk || 0}
                              </td>
                              <td className="border border-slate-300 py-1.5 px-1 text-center font-bold text-slate-900">
                                {totalEff}
                              </td>
                              <td className="border border-slate-300 py-1 px-1 text-center">
                                <span
                                  className={`inline-block px-1.5 py-0.5 rounded font-bold text-[8.8px] ${
                                    pct >= 95
                                      ? 'bg-emerald-50 text-emerald-700'
                                      : pct >= 80
                                      ? 'bg-amber-50 text-amber-700'
                                      : 'bg-rose-50 text-rose-700'
                                  }`}
                                >
                                  {pct.toFixed(1)}%
                                </span>
                              </td>
                            </tr>
                          );
                        })}

                        {/* SUMMARY FOOTER ROW ON LAST PAGE */}
                        {page.isLastPage && (
                          <tr className="bg-slate-100 font-extrabold text-slate-900">
                            <td
                              colSpan={5}
                              className="border border-slate-300 py-2 px-2 text-center uppercase tracking-wide text-[9px]"
                            >
                              JUMLAH / RATA-RATA KESELURUHAN
                            </td>
                            <td className="border border-slate-300 py-2 px-1 text-center text-[#1d4ed8]">
                              {stats.totalH}
                            </td>
                            <td
                              className={`border border-slate-300 py-2 px-1 text-center ${
                                stats.totalTD > 0 ? 'text-amber-600' : ''
                              }`}
                            >
                              {stats.totalTD}
                            </td>
                            <td className="border border-slate-300 py-2 px-1 text-center">
                              {stats.totalI}
                            </td>
                            <td className="border border-slate-300 py-2 px-1 text-center">
                              {stats.totalS}
                            </td>
                            <td
                              className={`border border-slate-300 py-2 px-1 text-center ${
                                stats.totalTK > 0 ? 'text-rose-600' : ''
                              }`}
                            >
                              {stats.totalTK}
                            </td>
                            <td className="border border-slate-300 py-2 px-1 text-center">
                              {stats.totalEfektif}
                            </td>
                            <td className="border border-slate-300 py-2 px-1 text-center text-emerald-700">
                              {stats.tingkatDisiplinPct.toFixed(1)}%
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>

                    {/* BOTTOM NOTES + SIGNATURE ON LAST PAGE */}
                    {page.isLastPage && (
                      <div className="mt-4 grid grid-cols-12 gap-5 items-start">
                        <div className="col-span-7 rounded-lg border border-dashed border-slate-300 bg-slate-50/90 p-3">
                          <div className="text-[9.5px] font-bold text-slate-900 mb-1.5">
                            Catatan &amp; Verifikasi Administrasi:
                          </div>
                          <ul className="list-disc pl-4 space-y-1 text-[8.8px] text-slate-700 leading-relaxed">
                            {adminNotesList.map((note, idx) => (
                              <li key={idx}>{note}</li>
                            ))}
                          </ul>
                        </div>

                        <div className="col-span-5 text-center text-[10px] leading-snug pt-0.5">
                          <div>
                            {settings.kota || 'Tempat'}, {formatIndonesianShortDate(config.tanggalTtd)}
                          </div>
                          <div className="font-bold text-slate-900 mt-0.5">
                            {settings.jabatanPimpinan || 'Kepala Sekolah'}
                          </div>
                          <div className="h-[58px]" />
                          <div className="font-extrabold underline text-slate-950">
                            {settings.namaPimpinan || '....................................'}
                          </div>
                          <div className="text-slate-600 text-[9.5px] mt-0.5">
                            NIP. {settings.nipPimpinan || '-'}
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* PAGE FOOTER BAR */}
                  <div className="pt-2.5 mt-4 border-t border-slate-200 flex items-center justify-between text-[8.5px] text-slate-500">
                    <span>
                      Sistem Administrasi Kepegawaian &amp; Absensi Digital {settings.subInstansi || 'LensaHadir'}
                    </span>
                    <span className="truncate max-w-[260px]">
                      {settings.alamatInstansi || settings.kota || 'LensaHadir'}
                    </span>
                    <span className="font-semibold">
                      Halaman {page.pageNumber} dari {page.totalPages}
                    </span>
                  </div>
                </section>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* MODAL SIMPAN KE GOOGLE DRIVE */}
      <SaveToDriveModal
        isOpen={Boolean(driveModalInfo)}
        onClose={() => setDriveModalInfo(null)}
        reportTitle={`Rekapitulasi Absensi Bulanan (${monthName} ${config.tahun})`}
        filename={driveModalInfo?.filename || ''}
        onRedownload={async () => {
          await handleDownloadPdf();
        }}
        isRedownloading={isExportingPdf}
      />
    </div>
  );
};
