import React, { useState } from 'react';
import {
  ArrowLeft,
  ShieldCheck,
  User,
  Building2,
  KeyRound,
  Lock,
  Eye,
  EyeOff,
  Send,
  AlertCircle,
  MessageCircle,
  Mail,
  CheckCircle2,
  Copy,
  ExternalLink,
  RotateCcw,
} from 'lucide-react';
import { AdminRegistrationRequest } from '../types/attendance';

interface AdminRegisterPageProps {
  onBackToLogin: () => void;
  onSubmitRegistration: (req: AdminRegistrationRequest) => void;
  showToast: (msg: string) => void;
}

export const OWNER_ADMIN_CHANNEL_URL =
  'https://whatsapp.com/channel/0029Vb9PPK7AInPqBMzg9X2Y';

export const REGISTRATION_AUTO_MESSAGE =
  'Saya ingin punya aplikasi LensaHadir. Mohon Informasinya. Terima';

export const REGISTRATION_AUTO_REPLY =
  'Terima Kasih. Kami akan menghubungi Anda jika semuanya sudah Siap!!';

export const AdminRegisterPage: React.FC<AdminRegisterPageProps> = ({
  onBackToLogin,
  onSubmitRegistration,
  showToast,
}) => {
  const [nama, setNama] = useState('');
  const [nip, setNip] = useState('');
  const [golRuang, setGolRuang] = useState('');
  const [jabatan, setJabatan] = useState(
    'Administrator Utama Lembaga / Satuan Dinas'
  );
  const [lembaga, setLembaga] = useState('');
  const [noWa, setNoWa] = useState('');
  const [email, setEmail] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');

  const [submittedRequest, setSubmittedRequest] =
    useState<AdminRegistrationRequest | null>(null);
  const [sentTime, setSentTime] = useState('');

  const buildClipboardMessage = (req: AdminRegistrationRequest): string => {
    return [
      REGISTRATION_AUTO_MESSAGE,
      '',
      'Data Pendaftaran Admin (1 Sekolah / Lembaga / Dinas):',
      `- Nama Lengkap: ${req.nama}`,
      req.nip ? `- NIP / ID: ${req.nip}` : null,
      req.jabatan ? `- Jabatan: ${req.jabatan}` : null,
      req.golRuang ? `- Gol. Ruang: ${req.golRuang}` : null,
      `- Sekolah / Lembaga / Dinas: ${req.lembaga}`,
      `- Nomor WA: ${req.noWa}`,
      req.email ? `- Email: ${req.email}` : null,
      `- Usulan Username: ${req.username}`,
    ]
      .filter((line) => line !== null)
      .join('\n');
  };

  const handleCopy = (text: string, feedback = 'Pesan pendaftaran disalin ke clipboard') => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text).then(() => {
        showToast(feedback);
      });
    }
  };

  const handleKirimClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    setError('');

    const cleanNama = nama.trim();
    const cleanLembaga = lembaga.trim();
    const cleanWa = noWa.trim();
    const cleanEmail = email.trim();
    const cleanUsername = username.trim().replace(/\s+/g, '');
    const cleanPassword = password.trim();

    if (!cleanNama) {
      e.preventDefault();
      setError('Nama Lengkap Admin wajib diisi.');
      return;
    }

    if (!cleanLembaga) {
      e.preventDefault();
      setError('Nama Sekolah / Lembaga / Satuan Dinas wajib diisi.');
      return;
    }

    const waDigits = cleanWa.replace(/[^0-9]/g, '');
    if (!cleanWa || waDigits.length < 9 || waDigits.length > 15) {
      e.preventDefault();
      setError(
        'Nomor WA aktif wajib diisi dengan angka yang valid (9–15 digit) agar Admin dapat menghubungi Anda kembali.'
      );
      return;
    }

    if (cleanEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
      e.preventDefault();
      setError('Format Email Admin tidak valid (contoh: admin@sekolah.sch.id).');
      return;
    }

    if (!cleanUsername || cleanUsername.length < 3) {
      e.preventDefault();
      setError('Username Admin wajib diisi minimal 3 karakter tanpa spasi.');
      return;
    }

    if (!cleanPassword || cleanPassword.length < 4) {
      e.preventDefault();
      setError('Password Admin wajib diisi minimal 4 karakter.');
      return;
    }

    const newReq: AdminRegistrationRequest = {
      id: `REG_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      nama: cleanNama,
      nip: nip.trim(),
      jabatan:
        jabatan.trim() || 'Administrator Utama Lembaga / Satuan Dinas',
      lembaga: cleanLembaga,
      golRuang: golRuang.trim(),
      noWa: cleanWa,
      email: cleanEmail,
      username: cleanUsername,
      password: cleanPassword,
      status: 'menunggu',
      createdAt: Date.now(),
    };

    onSubmitRegistration(newReq);
    setSubmittedRequest(newReq);
    setSentTime(
      new Date().toLocaleTimeString('id-ID', {
        hour: '2-digit',
        minute: '2-digit',
      })
    );

    const fullMsg = buildClipboardMessage(newReq);
    if (navigator.clipboard) {
      navigator.clipboard.writeText(fullMsg).catch(() => {
        // Ignore clipboard rejection
      });
    }

    showToast(
      'Formulir registrasi terkirim & pesan disalin. Balasan konfirmasi otomatis diterima.'
    );
  };

  return (
    <div className="max-w-3xl mx-auto space-y-5 animate-fadeIn">
      {/* Back to Login */}
      <div className="flex items-center justify-between">
        <button
          type="button"
          onClick={onBackToLogin}
          className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-600 hover:text-indigo-700 transition-colors cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4" />
          Kembali ke Halaman Login
        </button>
        <span className="text-xs font-semibold text-slate-500">
          Khusus Role Admin · 1 Sekolah / Lembaga / Dinas
        </span>
      </div>

      {/* Main Card */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xl overflow-hidden">
        {/* Header */}
        <div className="bg-indigo-900 px-6 py-5 text-white">
          <div className="flex items-start gap-3">
            <div className="p-2.5 rounded-xl bg-white/15 shrink-0">
              <ShieldCheck className="h-5 w-5 text-emerald-300" />
            </div>
            <div>
              <h1 className="text-lg sm:text-xl font-black tracking-tight">
                Formulir Daftar / Registrasi Akun Admin
              </h1>
              <p className="text-xs text-indigo-200 mt-0.5 leading-relaxed">
                Pendaftaran ini khusus untuk <b>Role Administrator Utama (1 Sekolah atau 1 Satuan Dinas)</b>. Untuk Guru/Pegawai dan Pimpinan, akun dibuat oleh Admin instansi masing-masing.
              </p>
            </div>
          </div>
        </div>

        {/* Body */}
        {!submittedRequest ? (
          <div className="p-6 sm:p-8 space-y-6">
            {error && (
              <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold flex items-center gap-2">
                <AlertCircle className="h-4 w-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {/* Section 1: Data Diri Calon Administrator Utama */}
            <div className="space-y-4">
              <div className="text-xs font-black uppercase tracking-wider text-indigo-700 flex items-center gap-1.5 border-b border-slate-100 pb-2">
                <User className="h-4 w-4" />
                1. Data Diri Admin (Administrator Utama Sekolah / Satuan Dinas)
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700">
                    Nama Lengkap Admin <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={nama}
                    onChange={(e) => {
                      setNama(e.target.value);
                      setError('');
                    }}
                    placeholder="Nama Lengkap Calon Administrator Utama"
                    className="block w-full rounded-xl border border-slate-300 p-2.5 text-sm font-semibold text-slate-900 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700">
                    NIP / ID Administrator (Opsional)
                  </label>
                  <input
                    type="text"
                    value={nip}
                    onChange={(e) => setNip(e.target.value)}
                    placeholder="Nomor Induk Pegawai / ID Admin"
                    className="block w-full rounded-xl border border-slate-300 p-2.5 text-sm font-mono text-slate-900 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700">
                    Jabatan Administrator
                  </label>
                  <input
                    type="text"
                    value={jabatan}
                    onChange={(e) => setJabatan(e.target.value)}
                    placeholder="Contoh: Operator Sekolah / Admin Dinas"
                    className="block w-full rounded-xl border border-slate-300 p-2.5 text-sm text-slate-900 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700">
                    Gol. Ruang (Opsional)
                  </label>
                  <input
                    type="text"
                    value={golRuang}
                    onChange={(e) => setGolRuang(e.target.value)}
                    placeholder="Contoh: Penata / III/c"
                    className="block w-full rounded-xl border border-slate-300 p-2.5 text-sm font-semibold text-slate-900 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
                  />
                </div>

                <div className="space-y-1.5 md:col-span-2">
                  <label className="text-xs font-bold text-slate-700 flex items-center gap-1">
                    <Building2 className="h-3.5 w-3.5 text-indigo-600" />
                    Nama Sekolah / Lembaga / Satuan Dinas{' '}
                    <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={lembaga}
                    onChange={(e) => {
                      setLembaga(e.target.value);
                      setError('');
                    }}
                    placeholder="Contoh: UPTD SD Negeri ... / Dinas Pendidikan Kabupaten Kupang"
                    className="block w-full rounded-xl border border-slate-300 p-2.5 text-sm font-semibold text-slate-900 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 flex items-center gap-1">
                    <MessageCircle className="h-3.5 w-3.5 text-emerald-600" />
                    Nomor WA Aktif Calon Admin{' '}
                    <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="tel"
                    value={noWa}
                    onChange={(e) => {
                      setNoWa(e.target.value);
                      setError('');
                    }}
                    placeholder="Contoh: 081234567890"
                    className="block w-full rounded-xl border border-slate-300 p-2.5 text-sm font-medium text-slate-900 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
                  />
                  <p className="text-[11px] text-slate-500">
                    Digunakan Admin pemilik aplikasi untuk menghubungi Anda kembali via WhatsApp.
                  </p>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 flex items-center gap-1">
                    <Mail className="h-3.5 w-3.5 text-indigo-600" />
                    Email Admin (Opsional)
                  </label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => {
                      setEmail(e.target.value);
                      setError('');
                    }}
                    placeholder="Contoh: admin@sekolah.sch.id"
                    className="block w-full rounded-xl border border-slate-300 p-2.5 text-sm font-medium text-slate-900 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
                  />
                </div>
              </div>
            </div>

            {/* Section 2: Usulan Akun Login Administrator */}
            <div className="space-y-4 pt-2 border-t border-slate-200">
              <div className="text-xs font-black uppercase tracking-wider text-indigo-700 flex items-center gap-1.5 border-b border-slate-100 pb-2">
                <KeyRound className="h-4 w-4" />
                2. Usulan Akun Login Admin (Role: Administrator Utama)
              </div>

              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 flex items-center gap-1">
                    <User className="h-3.5 w-3.5 text-indigo-600" />
                    Username Admin <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => {
                      setUsername(e.target.value.replace(/\s+/g, ''));
                      setError('');
                    }}
                    placeholder="Contoh: admin.sdn1"
                    className="block w-full rounded-xl border border-slate-300 bg-white p-2.5 text-sm font-mono font-bold text-slate-900 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 flex items-center gap-1">
                    <Lock className="h-3.5 w-3.5 text-indigo-600" />
                    Password Admin <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={(e) => {
                        setPassword(e.target.value);
                        setError('');
                      }}
                      placeholder="Minimal 4 karakter"
                      className="block w-full rounded-xl border border-slate-300 bg-white p-2.5 pr-10 text-sm font-mono font-bold text-slate-900 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword((prev) => !prev)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-indigo-600"
                      title={showPassword ? 'Sembunyikan password' : 'Tampilkan password'}
                    >
                      {showPassword ? (
                        <EyeOff className="h-4 w-4" />
                      ) : (
                        <Eye className="h-4 w-4" />
                      )}
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Automatic Message Preview */}
            <div className="p-4 rounded-xl bg-emerald-50/70 border border-emerald-200 space-y-1.5">
              <div className="flex items-center justify-between gap-2">
                <span className="text-[11px] font-bold text-emerald-900">
                  Pesan Otomatis ke Admin Pemilik Aplikasi
                </span>
                <span className="text-[11px] text-emerald-700 font-medium">
                  Saluran Resmi Admin LensaHadir
                </span>
              </div>
              <p className="text-xs sm:text-sm font-semibold text-slate-900 bg-white px-3.5 py-2.5 rounded-lg border border-emerald-200">
                &ldquo;{REGISTRATION_AUTO_MESSAGE}&rdquo;
              </p>
            </div>

            {/* Submit Actions */}
            <div className="pt-2 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={onBackToLogin}
                className="w-full sm:w-auto px-5 py-3 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-100 text-xs font-bold transition"
              >
                Batal
              </button>
              <a
                href={OWNER_ADMIN_CHANNEL_URL}
                target="_blank"
                rel="noopener noreferrer"
                onClick={handleKirimClick}
                className="w-full sm:w-auto px-7 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black uppercase tracking-wide flex items-center justify-center gap-2 shadow-md shadow-emerald-600/20 transition"
              >
                <Send className="h-4 w-4" />
                Kirim
                <ExternalLink className="h-3.5 w-3.5" />
              </a>
            </div>
          </div>
        ) : (
          /* Post-Submit Confirmation & Automatic Admin Reply View */
          <div className="p-6 sm:p-8 space-y-5">
            <div className="bg-slate-100 rounded-2xl p-4 sm:p-5 space-y-3.5 border border-slate-200">
              {/* Prospective User Sent Message */}
              <div className="flex justify-end">
                <div className="max-w-[88%] bg-emerald-600 text-white rounded-2xl rounded-tr-sm px-4 py-3 shadow-xs space-y-1.5">
                  <div className="text-[10px] font-bold text-emerald-100">
                    {submittedRequest.nama} ({submittedRequest.lembaga}) · {sentTime}
                  </div>
                  <p className="text-xs sm:text-sm font-semibold leading-relaxed">
                    {REGISTRATION_AUTO_MESSAGE}
                  </p>
                  <div className="text-[11px] text-emerald-100/90 pt-1 border-t border-emerald-500/50">
                    WA: {submittedRequest.noWa} · Usulan Username: @{submittedRequest.username}
                  </div>
                </div>
              </div>

              {/* Automatic Admin Confirmation Reply */}
              <div className="flex justify-start">
                <div className="max-w-[88%] bg-white text-slate-800 rounded-2xl rounded-tl-sm px-4 py-3.5 shadow-xs border border-slate-200">
                  <div className="flex items-center gap-1.5 text-[10px] font-black text-emerald-700 uppercase tracking-wider mb-1">
                    <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" />
                    Konfirmasi Otomatis Admin Pemilik Aplikasi · {sentTime}
                  </div>
                  <p className="text-sm font-bold text-slate-900 leading-relaxed">
                    {REGISTRATION_AUTO_REPLY}
                  </p>
                </div>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-900 flex items-start gap-2.5">
              <MessageCircle className="h-4 w-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>
                Data pendaftaran Admin Anda untuk <b>{submittedRequest.lembaga}</b> sudah tercatat, dan pesan otomatis telah disalin. Admin pemilik aplikasi dapat langsung menghubungi nomor WhatsApp Anda (<b>{submittedRequest.noWa}</b>) saat akun siap digunakan.
              </span>
            </div>

            <div className="flex flex-wrap items-center gap-2.5">
              <a
                href={OWNER_ADMIN_CHANNEL_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white py-3 px-4 rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-sm transition whitespace-nowrap"
              >
                <MessageCircle className="h-4 w-4" />
                Buka Tautan Admin Pemilik Aplikasi
                <ExternalLink className="h-3.5 w-3.5" />
              </a>
              <button
                type="button"
                onClick={() =>
                  handleCopy(
                    buildClipboardMessage(submittedRequest),
                    'Pesan & data pendaftaran disalin ke clipboard'
                  )
                }
                className="px-4 py-3 rounded-xl border border-slate-300 bg-white hover:bg-slate-100 text-slate-700 font-bold text-xs flex items-center gap-1.5 transition"
              >
                <Copy className="h-3.5 w-3.5" />
                Salin Pesan
              </button>
              <button
                type="button"
                onClick={() => setSubmittedRequest(null)}
                className="px-4 py-3 rounded-xl border border-slate-300 bg-white hover:bg-slate-100 text-slate-700 font-bold text-xs flex items-center gap-1.5 transition"
              >
                <RotateCcw className="h-3.5 w-3.5" />
                Daftar Lagi
              </button>
            </div>

            <button
              type="button"
              onClick={onBackToLogin}
              className="w-full py-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition"
            >
              Kembali ke Halaman Login
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
