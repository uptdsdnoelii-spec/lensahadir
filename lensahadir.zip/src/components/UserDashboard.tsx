import React, { useMemo } from 'react';
import {
  LayoutDashboard,
  FileText,
  History,
  UserCog,
  HelpCircle,
  CheckCircle2,
  CalendarDays,
  BarChart3,
  User,
  Briefcase,
  ChevronRight,
  Clock,
  Sparkles,
} from 'lucide-react';
import {
  AttendanceRecord,
  AppSettings,
  AuthSession,
  ManagedUser,
} from '../types/attendance';

interface UserDashboardProps {
  currentUser: AuthSession;
  managedUser: ManagedUser | null;
  settings: AppSettings;
  records: AttendanceRecord[];
  submittedRecordIds: Set<string>;
  isPimpinan: boolean;
  isGuruPegawai: boolean;
  onNavigate: (page: 'form' | 'statistics') => void;
  onOpenHistory: () => void;
  onOpenProfile: () => void;
  onOpenHelp: () => void;
  onSelectRecord: (rec: AttendanceRecord) => void;
}

const formatDisplayDate = (dateStr: string): string => {
  if (!dateStr) return '-';
  try {
    const [y, m, d] = dateStr.split('-').map((n) => parseInt(n, 10));
    if (!y || !m || !d) return dateStr;
    const dt = new Date(y, m - 1, d);
    return dt.toLocaleDateString('id-ID', {
      weekday: 'long',
      day: '2-digit',
      month: 'long',
      year: 'numeric',
    });
  } catch {
    return dateStr;
  }
};

export const UserDashboard: React.FC<UserDashboardProps> = ({
  currentUser,
  managedUser,
  settings,
  records,
  submittedRecordIds,
  isPimpinan,
  isGuruPegawai,
  onNavigate,
  onOpenHistory,
  onOpenProfile,
  onOpenHelp,
  onSelectRecord,
}) => {
  const todayIso = new Date().toISOString().split('T')[0];
  const currentMonthPrefix = todayIso.slice(0, 7); // YYYY-MM

  const stats = useMemo(() => {
    const total = records.length;
    const sentCount = records.filter(
      (r) => Boolean(r.sentToAdmin || submittedRecordIds.has(r.id))
    ).length;
    const thisMonthCount = records.filter((r) =>
      (r.tanggal || '').startsWith(currentMonthPrefix)
    ).length;
    const todayRecord = records.find((r) => r.tanggal === todayIso) || null;
    return {
      total,
      sentCount,
      unsentCount: Math.max(0, total - sentCount),
      thisMonthCount,
      todayRecord,
    };
  }, [records, submittedRecordIds, currentMonthPrefix, todayIso]);

  const recentRecords = useMemo(() => {
    return [...records]
      .sort((a, b) => (b.tanggal || '').localeCompare(a.tanggal || '') || b.createdAt - a.createdAt)
      .slice(0, 5);
  }, [records]);

  const displayNama = managedUser?.nama || currentUser.nama;
  const displayNip = managedUser?.nip || currentUser.nip || '-';
  const displayStatus = managedUser?.statusPegawai || currentUser.statusPegawai || '-';
  const displayGol = managedUser?.golRuang || currentUser.golRuang || '-';
  const displayJabatan = managedUser?.jabatan || currentUser.jabatan || '-';

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top User Executive Banner */}
      <div
        className={`rounded-2xl p-6 sm:p-7 text-white shadow-xl border ${
          isPimpinan
            ? 'bg-gradient-to-br from-slate-900 via-indigo-900 to-slate-900 border-indigo-700/50'
            : 'bg-gradient-to-br from-indigo-800 via-blue-900 to-slate-900 border-indigo-700/50'
        }`}
      >
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-indigo-100 bg-white/15 px-2.5 py-1 rounded-md">
              {isPimpinan ? (
                <Briefcase className="h-3.5 w-3.5 text-amber-300" />
              ) : (
                <LayoutDashboard className="h-3.5 w-3.5 text-emerald-300" />
              )}
              Dashboard {currentUser.role}
            </div>
            <h1 className="text-xl sm:text-2xl font-black tracking-tight">
              Selamat Datang, {displayNama}
            </h1>
            <p className="text-xs sm:text-sm text-indigo-200/90">
              {settings.subInstansi || settings.namaInstansi}
              {displayJabatan !== '-' ? ` • ${displayJabatan}` : ''}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            {isPimpinan ? (
              <button
                type="button"
                onClick={() => onNavigate('statistics')}
                className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs sm:text-sm px-5 py-3 rounded-xl shadow-lg shadow-emerald-950/30 transition flex items-center gap-2"
              >
                <BarChart3 className="h-4 w-4" />
                Statistik Absensi
              </button>
            ) : (
              <button
                type="button"
                onClick={() => onNavigate('form')}
                className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs sm:text-sm px-5 py-3 rounded-xl shadow-lg shadow-emerald-950/30 transition flex items-center gap-2"
              >
                <FileText className="h-4 w-4" />
                Isi Absensi Harian
              </button>
            )}
            <button
              type="button"
              onClick={onOpenProfile}
              className="bg-white/10 hover:bg-white/20 text-white font-bold text-xs px-4 py-3 rounded-xl transition flex items-center gap-1.5"
            >
              <UserCog className="h-4 w-4 text-emerald-300" />
              Pengaturan Data Diri
            </button>
            <button
              type="button"
              onClick={onOpenHelp}
              className="bg-sky-500/20 hover:bg-sky-500/35 border border-sky-300/40 text-white font-bold text-xs px-4 py-3 rounded-xl transition flex items-center gap-1.5"
              title="Tanya Admin melalui Saluran Bantuan"
            >
              <HelpCircle className="h-4 w-4 text-sky-200" />
              Help
            </button>
          </div>
        </div>

        {/* User KPI Summary Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mt-6">
          <div className="bg-white/10 backdrop-blur-xs rounded-xl p-4 border border-white/10">
            <p className="text-[11px] font-semibold text-indigo-200 uppercase tracking-wider">
              Status Hari Ini
            </p>
            <p
              className={`text-lg sm:text-xl font-black mt-1 ${
                stats.todayRecord ? 'text-emerald-300' : 'text-amber-300'
              }`}
            >
              {stats.todayRecord ? stats.todayRecord.statusKehadiran : 'Belum Absen'}
            </p>
            <p className="text-[11px] text-indigo-200/80 mt-0.5 truncate">
              {formatDisplayDate(todayIso)}
            </p>
          </div>

          <div className="bg-white/10 backdrop-blur-xs rounded-xl p-4 border border-white/10">
            <p className="text-[11px] font-semibold text-indigo-200 uppercase tracking-wider">
              Absensi Bulan Ini
            </p>
            <p className="text-2xl font-black mt-1 text-sky-300">
              {stats.thisMonthCount}
            </p>
            <p className="text-[11px] text-indigo-200/80 mt-0.5">
              Kartu tercatat bulan berjalan
            </p>
          </div>

          <div className="bg-white/10 backdrop-blur-xs rounded-xl p-4 border border-white/10">
            <p className="text-[11px] font-semibold text-indigo-200 uppercase tracking-wider">
              Total Riwayat
            </p>
            <p className="text-2xl font-black mt-1">{stats.total}</p>
            <p className="text-[11px] text-indigo-200/80 mt-0.5">
              Semua kartu absensi Anda
            </p>
          </div>

          <div className="bg-white/10 backdrop-blur-xs rounded-xl p-4 border border-white/10">
            <p className="text-[11px] font-semibold text-indigo-200 uppercase tracking-wider">
              Tersimpan di Admin
            </p>
            <p className="text-2xl font-black mt-1 text-emerald-300">
              {stats.sentCount}
            </p>
            <p className="text-[11px] text-indigo-200/80 mt-0.5">
              {stats.unsentCount > 0
                ? `${stats.unsentCount} belum dikirim ke Admin`
                : 'Semua riwayat sudah sinkron'}
            </p>
          </div>
        </div>
      </div>

      {/* Quick Menu Cards (Scoped to Role Permissions) */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5">
        <h2 className="text-xs font-black uppercase tracking-wider text-slate-500 mb-3">
          Akses Cepat Menu {currentUser.role}
        </h2>
        <div
          className={`grid grid-cols-1 sm:grid-cols-2 ${
            isPimpinan ? 'lg:grid-cols-3' : 'lg:grid-cols-4'
          } gap-3`}
        >
          <button
            type="button"
            onClick={() => onNavigate('form')}
            className="flex items-center gap-3 p-4 rounded-xl border border-slate-200 hover:border-indigo-400 hover:bg-indigo-50/40 transition text-left group"
          >
            <div className="p-2.5 rounded-xl bg-indigo-50 text-indigo-600 group-hover:bg-indigo-600 group-hover:text-white transition shrink-0">
              <FileText className="h-5 w-5" />
            </div>
            <div className="min-w-0">
              <div className="text-xs font-black text-slate-900">Form Absensi</div>
              <div className="text-[11px] text-slate-500">Buat &amp; cetak kartu harian</div>
            </div>
          </button>

          <button
            type="button"
            onClick={onOpenHistory}
            className="flex items-center gap-3 p-4 rounded-xl border border-slate-200 hover:border-indigo-400 hover:bg-indigo-50/40 transition text-left group"
          >
            <div className="p-2.5 rounded-xl bg-amber-50 text-amber-600 group-hover:bg-amber-600 group-hover:text-white transition shrink-0">
              <History className="h-5 w-5" />
            </div>
            <div className="min-w-0">
              <div className="text-xs font-black text-slate-900">
                Riwayat ({records.length})
              </div>
              <div className="text-[11px] text-slate-500">
                {isGuruPegawai ? 'Lihat & Simpan ke Admin' : 'Daftar kartu tersimpan'}
              </div>
            </div>
          </button>

          <button
            type="button"
            onClick={onOpenProfile}
            className="flex items-center gap-3 p-4 rounded-xl border border-slate-200 hover:border-emerald-400 hover:bg-emerald-50/40 transition text-left group"
          >
            <div className="p-2.5 rounded-xl bg-emerald-50 text-emerald-600 group-hover:bg-emerald-600 group-hover:text-white transition shrink-0">
              <UserCog className="h-5 w-5" />
            </div>
            <div className="min-w-0">
              <div className="text-xs font-black text-slate-900">
                Pengaturan Data Diri
              </div>
              <div className="text-[11px] text-slate-500">
                Otomatis tersimpan ke Admin
              </div>
            </div>
          </button>

          {isPimpinan && (
            <button
              type="button"
              onClick={() => onNavigate('statistics')}
              className="flex items-center gap-3 p-4 rounded-xl border border-slate-200 hover:border-indigo-400 hover:bg-indigo-50/40 transition text-left group"
            >
              <div className="p-2.5 rounded-xl bg-indigo-50 text-indigo-700 group-hover:bg-indigo-600 group-hover:text-white transition shrink-0">
                <BarChart3 className="h-5 w-5" />
              </div>
              <div className="min-w-0">
                <div className="text-xs font-black text-slate-900">
                  Statistik Absensi
                </div>
                <div className="text-[11px] text-slate-500">
                  Kurva, diagram &amp; simpulan disiplin
                </div>
              </div>
            </button>
          )}

          <button
            type="button"
            onClick={onOpenHelp}
            className="flex items-center gap-3 p-4 rounded-xl border border-slate-200 hover:border-sky-400 hover:bg-sky-50/40 transition text-left group"
          >
            <div className="p-2.5 rounded-xl bg-sky-50 text-sky-600 group-hover:bg-sky-600 group-hover:text-white transition shrink-0">
              <HelpCircle className="h-5 w-5" />
            </div>
            <div className="min-w-0">
              <div className="text-xs font-black text-slate-900">
                Help — Tanya Admin
              </div>
              <div className="text-[11px] text-slate-500">
                Kirim pertanyaan ke saluran Admin
              </div>
            </div>
          </button>
        </div>
      </div>

      {/* Lower 2-Column Overview: Data Diri + Riwayat Terbaru */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Ringkasan Data Diri (Strictly NO Username/Password/Konfirmasi) */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5 flex flex-col justify-between space-y-4">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="text-xs font-black uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                <User className="h-3.5 w-3.5 text-indigo-600" />
                Ringkasan Data Diri
              </h2>
              <span className="px-2 py-0.5 rounded-md bg-indigo-50 text-indigo-700 border border-indigo-200 text-[10px] font-extrabold">
                {currentUser.role}
              </span>
            </div>

            <div className="divide-y divide-slate-100 text-xs">
              <div className="py-2 flex justify-between gap-2">
                <span className="text-slate-500 font-medium">Nama</span>
                <span className="font-bold text-slate-900 text-right">{displayNama}</span>
              </div>
              <div className="py-2 flex justify-between gap-2">
                <span className="text-slate-500 font-medium">NIP / ID</span>
                <span className="font-mono font-semibold text-slate-800 text-right">
                  {displayNip}
                </span>
              </div>
              <div className="py-2 flex justify-between gap-2">
                <span className="text-slate-500 font-medium">Status</span>
                <span className="font-bold text-slate-800 text-right">{displayStatus}</span>
              </div>
              <div className="py-2 flex justify-between gap-2">
                <span className="text-slate-500 font-medium">Gol. Ruang</span>
                <span className="font-semibold text-slate-800 text-right">{displayGol}</span>
              </div>
              <div className="py-2 flex justify-between gap-2">
                <span className="text-slate-500 font-medium">Jabatan</span>
                <span className="font-semibold text-slate-800 text-right">
                  {displayJabatan}
                </span>
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={onOpenProfile}
            className="w-full py-2.5 px-4 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 font-bold text-xs flex items-center justify-center gap-1.5 transition"
          >
            <UserCog className="h-4 w-4" />
            Ubah Pengaturan Data Diri
          </button>
        </div>

        {/* Riwayat Absensi Terbaru (Hanya untuk Pimpinan; Admin melihat lewat Dashboard Admin) */}
        {isPimpinan ? (
          <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 shadow-sm p-5 flex flex-col justify-between space-y-4">
            <div className="space-y-3">
              <div className="flex items-center justify-between gap-2">
                <h2 className="text-xs font-black uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                  <CalendarDays className="h-3.5 w-3.5 text-indigo-600" />
                  Riwayat Absensi Terbaru
                </h2>
                <button
                  type="button"
                  onClick={onOpenHistory}
                  className="text-xs font-bold text-indigo-600 hover:underline flex items-center gap-0.5"
                >
                  Lihat Semua
                  <ChevronRight className="h-3.5 w-3.5" />
                </button>
              </div>

              {recentRecords.length === 0 ? (
                <div className="border-2 border-dashed border-slate-200 rounded-xl p-8 text-center space-y-2.5">
                  <div className="inline-flex p-2.5 rounded-xl bg-slate-100 text-slate-400">
                    <Clock className="h-6 w-6" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-700">
                      Belum Ada Kartu Absensi Tersimpan
                    </p>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      Mulai buat absensi harian melalui tombol Form Absensi.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => onNavigate('form')}
                    className="inline-flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-xl text-xs font-bold transition"
                  >
                    <Sparkles className="h-3.5 w-3.5" />
                    Buat Absensi Sekarang
                  </button>
                </div>
              ) : (
                <div className="divide-y divide-slate-100 border border-slate-100 rounded-xl overflow-hidden">
                  {recentRecords.map((rec) => {
                    const isSent = Boolean(rec.sentToAdmin || submittedRecordIds.has(rec.id));
                    return (
                      <div
                        key={rec.id}
                        className="p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 hover:bg-slate-50 transition"
                      >
                        <div className="min-w-0">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="text-xs font-black text-slate-900">
                              {formatDisplayDate(rec.tanggal)}
                            </span>
                            <span className="px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 border border-indigo-200 text-[10px] font-bold">
                              {rec.statusKehadiran}
                            </span>
                            {isSent && (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] font-bold">
                                <CheckCircle2 className="h-3 w-3" />
                                Tersimpan di Admin
                              </span>
                            )}
                          </div>
                          <p className="text-[11px] text-slate-500 mt-0.5 truncate">
                            {rec.nama}
                            {rec.catatan ? ` — ${rec.catatan}` : ''}
                          </p>
                        </div>

                        <div className="flex items-center gap-1.5 shrink-0">
                          <button
                            type="button"
                            onClick={() => onSelectRecord(rec)}
                            className="px-3 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-100 text-slate-700 text-[11px] font-bold transition"
                          >
                            Buka Kartu
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 shadow-sm p-5 flex flex-col justify-between space-y-4">
            <div className="space-y-3">
              <h2 className="text-xs font-black uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                <CalendarDays className="h-3.5 w-3.5 text-indigo-600" />
                Alur Absensi Harian Guru / Pegawai
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                  <div className="text-xs font-black text-indigo-700">1. Isi Form Absensi</div>
                  <p className="text-[11px] text-slate-600 leading-relaxed">
                    Lengkapi status kehadiran serta unggah foto TimeMark masuk dan pulang setiap hari kerja.
                  </p>
                </div>
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                  <div className="text-xs font-black text-indigo-700">2. Cetak &amp; Unduh PNG</div>
                  <p className="text-[11px] text-slate-600 leading-relaxed">
                    Cetak kartu absensi harian Anda dan simpan gambar PNG sebagai arsip bukti dukung.
                  </p>
                </div>
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                  <div className="text-xs font-black text-indigo-700">3. Simpan ke Admin</div>
                  <p className="text-[11px] text-slate-600 leading-relaxed">
                    Tekan <b>Simpan ke Admin</b> agar absensi tersimpan otomatis di akun Admin sesuai hari, bulan, dan tahun.
                  </p>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-100">
              <p className="text-xs text-slate-500">
                Riwayat absensi keseluruhan dikelola oleh Admin dan Pimpinan unit kerja.
              </p>
              <button
                type="button"
                onClick={() => onNavigate('form')}
                className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold flex items-center gap-1.5 transition"
              >
                <FileText className="h-3.5 w-3.5" />
                Buka Form Absensi
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
