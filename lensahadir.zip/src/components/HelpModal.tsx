import React, { useState } from 'react';
import {
  X,
  HelpCircle,
  MessageCircle,
  Send,
  Copy,
  CheckCircle2,
  ExternalLink,
  AlertCircle,
  RotateCcw,
} from 'lucide-react';

interface HelpModalProps {
  isOpen: boolean;
  onClose: () => void;
  senderName?: string;
  showToast: (msg: string) => void;
}

const ADMIN_HELP_CHANNEL_URL =
  'https://whatsapp.com/channel/0029Vb9PPK7AInPqBMzg9X2Y';

const AUTO_REPLY_TEXT =
  'Terima Kasih. Kami Akan Menghubungi Anda Kembali, setelah semuanya ditindaklanjuti';

const QUICK_APP_OPTIONS = [
  'LensaHadir',
  'LensaHadir (Form Absensi)',
  'LensaHadir (Laporan Disiplin Harian)',
  'LensaHadir (Rekap Bulanan PDF)',
  'LensaHadir (Manajemen Pengguna)',
];

export const HelpModal: React.FC<HelpModalProps> = ({
  isOpen,
  onClose,
  senderName,
  showToast,
}) => {
  const [namaAplikasi, setNamaAplikasi] = useState('LensaHadir');
  const [pertanyaanTambahan, setPertanyaanTambahan] = useState('');
  const [error, setError] = useState('');
  const [sentMessage, setSentMessage] = useState<string | null>(null);
  const [sentTime, setSentTime] = useState<string>('');

  if (!isOpen) return null;

  const trimmedApp = namaAplikasi.trim();
  const composedMessage = trimmedApp
    ? `Hallo admin aplikasi ${trimmedApp}${
        pertanyaanTambahan.trim() ? `\n\nPertanyaan: ${pertanyaanTambahan.trim()}` : ''
      }`
    : 'Hallo admin aplikasi ............[isikan aplikasi mana yang mau ditanyakan]';

  const handleClose = () => {
    setError('');
    setSentMessage(null);
    setPertanyaanTambahan('');
    onClose();
  };

  const handleCopyMessage = (text: string) => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text).then(() => {
        showToast('Pesan pertanyaan disalin ke clipboard');
      });
    }
  };

  const handleSendClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    if (!trimmedApp) {
      e.preventDefault();
      setError('Silakan isi nama aplikasi yang ingin ditanyakan terlebih dahulu.');
      return;
    }

    setError('');
    const finalMsg = composedMessage;
    setSentMessage(finalMsg);
    setSentTime(
      new Date().toLocaleTimeString('id-ID', {
        hour: '2-digit',
        minute: '2-digit',
      })
    );

    if (navigator.clipboard) {
      navigator.clipboard.writeText(finalMsg).catch(() => {
        // Ignore clipboard rejection
      });
    }
    showToast('Pesan terkirim & disalin. Balasan otomatis Admin telah diterima.');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 p-4 backdrop-blur-xs animate-fadeIn">
      <div className="relative w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-emerald-700 px-5 py-4 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-white/15">
              <HelpCircle className="h-5 w-5 text-white" />
            </div>
            <div>
              <h3 className="text-base font-black uppercase tracking-tight">
                Help — Tanya Admin
              </h3>
              <p className="text-[11px] text-emerald-100">
                Pusat bantuan &amp; konsultasi langsung ke Saluran Admin
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={handleClose}
            className="p-1.5 rounded-lg text-emerald-100 hover:bg-white/15 hover:text-white transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Body */}
        <div className="overflow-y-auto p-5 space-y-4">
          {!sentMessage ? (
            <>
              {error && (
                <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold flex items-center gap-2">
                  <AlertCircle className="h-4 w-4 shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700">
                  Aplikasi yang Ingin Ditanyakan <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  value={namaAplikasi}
                  onChange={(e) => {
                    setNamaAplikasi(e.target.value);
                    setError('');
                  }}
                  placeholder="Isikan aplikasi mana yang mau ditanyakan (contoh: LensaHadir)"
                  className="block w-full rounded-xl border border-slate-300 p-3 text-sm font-semibold text-slate-900 focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 outline-none"
                />
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {QUICK_APP_OPTIONS.map((opt) => (
                    <button
                      key={opt}
                      type="button"
                      onClick={() => {
                        setNamaAplikasi(opt);
                        setError('');
                      }}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition ${
                        namaAplikasi === opt
                          ? 'bg-emerald-600 text-white'
                          : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700">
                  Detail Pertanyaan / Kendala (Opsional)
                </label>
                <textarea
                  rows={3}
                  value={pertanyaanTambahan}
                  onChange={(e) => setPertanyaanTambahan(e.target.value)}
                  placeholder="Tuliskan pertanyaan atau kendala yang ingin disampaikan kepada Admin..."
                  className="block w-full rounded-xl border border-slate-300 p-3 text-sm text-slate-800 focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 outline-none resize-none"
                />
              </div>

              {/* Message Preview */}
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-black uppercase tracking-wider text-slate-500">
                    Pratinjau Pesan Awal ke Admin
                  </span>
                  <button
                    type="button"
                    onClick={() => handleCopyMessage(composedMessage)}
                    className="text-[11px] font-bold text-emerald-700 hover:underline flex items-center gap-1"
                  >
                    <Copy className="h-3 w-3" />
                    Salin Pesan
                  </button>
                </div>
                <p className="text-xs font-medium text-slate-800 whitespace-pre-line bg-white p-3 rounded-lg border border-slate-200">
                  {composedMessage}
                </p>
              </div>

              {/* Send Action -> Opens WhatsApp Channel link & triggers Auto Reply */}
              <div className="pt-1 flex flex-col sm:flex-row items-center gap-2.5">
                <a
                  href={ADMIN_HELP_CHANNEL_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={handleSendClick}
                  className="w-full sm:flex-1 bg-emerald-600 hover:bg-emerald-700 text-white py-3 px-4 rounded-xl font-black text-xs uppercase tracking-wide flex items-center justify-center gap-2 shadow-md shadow-emerald-600/20 transition"
                >
                  <Send className="h-4 w-4" />
                  Kirim &amp; Tanya Admin
                  <ExternalLink className="h-3.5 w-3.5" />
                </a>
                <button
                  type="button"
                  onClick={handleClose}
                  className="w-full sm:w-auto px-4 py-3 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-100 font-bold text-xs transition"
                >
                  Tutup
                </button>
              </div>
            </>
          ) : (
            /* Chat Confirmation + Automatic Admin Reply View */
            <div className="space-y-4">
              <div className="bg-slate-100 rounded-2xl p-4 space-y-3 border border-slate-200">
                {/* User Sent Bubble */}
                <div className="flex justify-end">
                  <div className="max-w-[85%] bg-emerald-600 text-white rounded-2xl rounded-tr-sm px-4 py-3 shadow-xs">
                    <div className="text-[10px] font-bold text-emerald-100 mb-1">
                      {senderName || 'Anda'} • {sentTime}
                    </div>
                    <p className="text-xs whitespace-pre-line leading-relaxed">
                      {sentMessage}
                    </p>
                  </div>
                </div>

                {/* Automatic Admin Reply Bubble */}
                <div className="flex justify-start">
                  <div className="max-w-[88%] bg-white text-slate-800 rounded-2xl rounded-tl-sm px-4 py-3 shadow-xs border border-slate-200">
                    <div className="flex items-center gap-1.5 text-[10px] font-black text-emerald-700 uppercase tracking-wider mb-1">
                      <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" />
                      Balasan Otomatis Admin • {sentTime}
                    </div>
                    <p className="text-xs sm:text-sm font-semibold text-slate-900 leading-relaxed">
                      {AUTO_REPLY_TEXT}
                    </p>
                  </div>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-[11px] text-emerald-900 flex items-start gap-2">
                <MessageCircle className="h-4 w-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>
                  Pesan awal Anda telah disalin otomatis. Anda dapat membuka kembali tautan saluran Admin di bawah ini kapan saja.
                </span>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <a
                  href={ADMIN_HELP_CHANNEL_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white py-2.5 px-4 rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-sm transition"
                >
                  <MessageCircle className="h-4 w-4" />
                  Buka Saluran Tanya Admin
                  <ExternalLink className="h-3.5 w-3.5" />
                </a>
                <button
                  type="button"
                  onClick={() => handleCopyMessage(sentMessage)}
                  className="px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white hover:bg-slate-100 text-slate-700 font-bold text-xs flex items-center gap-1.5 transition"
                >
                  <Copy className="h-3.5 w-3.5" />
                  Salin
                </button>
                <button
                  type="button"
                  onClick={() => setSentMessage(null)}
                  className="px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white hover:bg-slate-100 text-slate-700 font-bold text-xs flex items-center gap-1.5 transition"
                >
                  <RotateCcw className="h-3.5 w-3.5" />
                  Tanya Lagi
                </button>
              </div>

              <button
                type="button"
                onClick={handleClose}
                className="w-full py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition"
              >
                Tutup
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
