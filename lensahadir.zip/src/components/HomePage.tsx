import React from 'react';
import {
  ArrowRight,
  Lock,
  FileText,
  ExternalLink,
  Check,
  History,
  HelpCircle,
} from 'lucide-react';
import { AppSettings } from '../types/attendance';

interface HomePageProps {
  settings: AppSettings;
  isLoggedIn: boolean;
  canViewRecentHistory: boolean;
  recordsCount: number;
  onGoToLogin: () => void;
  onGoToDashboard: () => void;
  onOpenHistory: () => void;
  onOpenHelp: () => void;
}

const SE_DISIPLIN_PDF =
  '/assets/aistudio/Laporan_Disiplin_dan_Rekapan_Presensi_Time_Mark_b2780ffd.pdf';
const SE_GAJI_PDF =
  '/assets/aistudio/SURAT_EDARAN_PEMBAYARAN_GAJI_ASN_7322916e.pdf';
const DEVELOPER_AVATAR_URL =
  '/assets/aistudio/yakang_blogger_ikon_ba9a3c56.jpg';

const CORE_CAPABILITIES = [
  {
    index: '01.',
    title: 'Kartu Absensi Foto TimeMark Harian',
    summary:
      'Setiap guru dan pegawai mencatat kehadiran harian (H, I, S, C, TD, TB, TS) dengan unggahan foto TimeMark masuk dan pulang, lengkap dengan identitas NIP, golongan ruang, jabatan, dan ekspor gambar PNG resolusi tinggi.',
    detail: 'Sinkron otomatis ke akun Admin per pengguna, hari, bulan, dan tahun.',
    span: 'lg:col-span-2',
  },
  {
    index: '02.',
    title: 'Laporan Disiplin Jam Kerja Harian A4',
    summary:
      'Menyusun kartu absensi harian seluruh pegawai ke dalam dokumen PDF A4 berformat 3 kartu per halaman dengan nomor urut, kop instansi otomatis, dan pengesahan Kepala Sekolah sesuai Lampiran I Surat Edaran.',
    detail: 'Siap kirim sebagai soft copy maupun arsip cetak harian.',
    span: 'lg:col-span-1',
  },
  {
    index: '03.',
    title: 'Perhitungan Rekapitulasi Absensi Bulanan',
    summary:
      'Mengimpor rekapan bulanan (PDF, Excel, CSV, atau data tersimpan di Admin) untuk menghitung otomatis jumlah hari kerja efektif, kehadiran, izin, sakit, cuti, tugas dinas, dan tanpa berita menjadi laporan PDF A4.',
    detail: 'Mengikuti struktur Lampiran II dan tabel rekap bulanan resmi.',
    span: 'lg:col-span-1',
  },
  {
    index: '04.',
    title: 'Tata Kelola Akun Multi-Peran & Pengaturan Instansi',
    summary:
      'Pemisahan wewenang yang tertib antara Administrator Utama Lembaga/Satuan Dinas, Pimpinan unit kerja, dan Guru/Pegawai. Dilengkapi kontrol kop instansi, pembaruan data diri mandiri, serta layanan bantuan Admin.',
    detail: 'Kendali akun terpusat dengan privasi kredensial penuh oleh Admin.',
    span: 'lg:col-span-2',
  },
];

export const HomePage: React.FC<HomePageProps> = ({
  settings,
  isLoggedIn,
  canViewRecentHistory,
  recordsCount,
  onGoToLogin,
  onGoToDashboard,
  onOpenHistory,
  onOpenHelp,
}) => {
  return (
    <div className="space-y-16 sm:space-y-24 pb-8 animate-fadeIn">
      {/* ================================================================= */}
      {/* 1. HERO SECTION — Proposition & Single Dominant Focal Anchor      */}
      {/* ================================================================= */}
      <section
        id="tentang"
        className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-stretch pt-2 sm:pt-4"
      >
        {/* Left Editorial Column */}
        <div className="lg:col-span-7 flex flex-col justify-between space-y-8">
          <div className="space-y-5">
            <div className="flex flex-wrap items-center gap-2 text-xs font-semibold text-slate-500">
              <span className="text-indigo-700 font-bold">LensaHadir</span>
              <span aria-hidden="true">·</span>
              <span>Sistem Administrasi Presensi Foto TimeMark</span>
              <span aria-hidden="true">·</span>
              <span>Lingkup Satuan Pendidikan &amp; OPD</span>
            </div>

            <h1
              className="font-extrabold tracking-tight text-slate-900 leading-[1.1]"
              style={{
                fontSize: 'clamp(2.15rem, 3.8vw, 3.25rem)',
                textWrap: 'balance',
              }}
            >
              Dokumentasi Presensi TimeMark Harian dan Rekap Bulanan Siap Lapor
            </h1>

            <p className="text-base text-slate-600 leading-relaxed max-w-[62ch]">
              LensaHadir membantu satuan pendidikan dan unit kerja pemerintah mengelola bukti dukung foto TimeMark masuk dan pulang, menyusun Laporan Disiplin Jam Kerja Harian format A4, hingga menghitung Rekapitulasi Absensi Bulanan secara tertib dan selaras dengan ketentuan pelaporan resmi Pemerintah Kabupaten Kupang.
            </p>
          </div>

          {/* Primary Conversion Block — 1 Dominant CTA + Subtle Secondary Utility */}
          <div className="space-y-5">
            <div className="flex flex-wrap items-center gap-3">
              {isLoggedIn ? (
                <button
                  type="button"
                  onClick={onGoToDashboard}
                  className="bg-indigo-700 hover:bg-indigo-800 text-white px-7 py-3.5 rounded-xl font-bold text-sm transition-colors flex items-center gap-2.5 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <span>Buka Dashboard Sistem</span>
                  <ArrowRight className="h-4 w-4" />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={onGoToLogin}
                  className="bg-indigo-700 hover:bg-indigo-800 text-white px-7 py-3.5 rounded-xl font-bold text-sm transition-colors flex items-center gap-2.5 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <Lock className="h-4 w-4" />
                  <span>Masuk ke Sistem</span>
                  <ArrowRight className="h-4 w-4" />
                </button>
              )}

              <a
                href="#regulasi"
                className="px-5 py-3.5 rounded-xl border border-slate-300 bg-white hover:bg-slate-100 text-slate-800 font-semibold text-sm transition-colors whitespace-nowrap shrink-0"
              >
                Lihat Dasar Surat Edaran
              </a>
            </div>

            <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 text-xs text-slate-500 pt-1">
              <span>Akses Multi-Peran: Admin, Pimpinan &amp; Guru/Pegawai</span>
              {canViewRecentHistory && recordsCount > 0 && (
                <>
                  <span aria-hidden="true">·</span>
                  <button
                    type="button"
                    onClick={onOpenHistory}
                    className="text-slate-700 hover:text-indigo-700 font-semibold underline-offset-4 hover:underline inline-flex items-center gap-1 cursor-pointer"
                  >
                    <History className="h-3.5 w-3.5" />
                    <span>{recordsCount} riwayat tersimpan di perangkat ini</span>
                  </button>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Right Architectural Preview Panel (Real Document Workflow Visual) */}
        <div className="lg:col-span-5 flex">
          <div className="w-full rounded-2xl bg-slate-900 text-slate-100 p-6 sm:p-7 flex flex-col justify-between border border-slate-800">
            <div className="space-y-5">
              <div className="flex items-center justify-between gap-2 pb-4 border-b border-slate-800">
                <div>
                  <p className="text-xs font-semibold text-slate-400">
                    Standar Pelaporan Terintegrasi
                  </p>
                  <p className="text-sm font-bold text-white mt-0.5">
                    Alur Presensi ke Laporan Berjenjang
                  </p>
                </div>
                <span className="font-mono text-xs text-slate-400 tabular-nums">
                  A4 · PDF / PNG
                </span>
              </div>

              {/* Structured Document Output Preview */}
              <div className="space-y-3.5">
                <div className="p-4 rounded-xl bg-slate-800/70 border border-slate-700/80 space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-white">
                      1. Kartu Absensi Harian Pegawai
                    </span>
                    <span className="font-mono text-[11px] text-slate-400 tabular-nums">
                      TimeMark
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Identitas ASN/PPPK/GTT, foto masuk &amp; pulang TimeMark, keterangan kehadiran, serta pengiriman langsung ke akun Admin.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-800/70 border border-slate-700/80 space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-white">
                      2. Laporan Disiplin Harian (Lampiran I)
                    </span>
                    <span className="font-mono text-[11px] text-slate-400 tabular-nums">
                      3 Kartu / Hal
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Rekap bukti dukung harian dalam lembar PDF A4 berkop instansi dengan tanda tangan Kepala Sekolah atau Pimpinan OPD.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-800/70 border border-slate-700/80 space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-white">
                      3. Rekapitulasi Bulanan (Lampiran II)
                    </span>
                    <span className="font-mono text-[11px] text-slate-400 tabular-nums">
                      H · I · S · C · TD · TB
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Perhitungan kehadiran bulanan siap cetak Hard Copy dan arsip Soft Copy untuk penyampaian rutin awal bulan.
                  </p>
                </div>
              </div>
            </div>

            <div className="pt-5 mt-5 border-t border-slate-800 flex items-center justify-between gap-3 text-xs text-slate-400">
              <span className="truncate">
                {settings.subInstansi || settings.namaInstansi}
              </span>
              <span className="font-mono text-slate-300 whitespace-nowrap shrink-0 tabular-nums">
                T.A. 2026
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* ================================================================= */}
      {/* FULL-WIDTH REFERENCE SUMMARY STRIP (4-Column Balanced Row)        */}
      {/* ================================================================= */}
      <section className="border-y border-slate-200 py-7">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
          <div className="space-y-1">
            <p className="font-mono text-2xl sm:text-3xl font-bold text-slate-900 tabular-nums">
              2 SE
            </p>
            <p className="text-xs font-semibold text-slate-800">
              Dasar Surat Edaran Bupati
            </p>
            <p className="text-xs text-slate-500">
              Kabupaten Kupang Tahun 2026
            </p>
          </div>

          <div className="space-y-1">
            <p className="font-mono text-2xl sm:text-3xl font-bold text-slate-900 tabular-nums">
              3 Peran
            </p>
            <p className="text-xs font-semibold text-slate-800">
              Hak Akses Terstruktur
            </p>
            <p className="text-xs text-slate-500">
              Admin, Pimpinan &amp; Guru/Pegawai
            </p>
          </div>

          <div className="space-y-1">
            <p className="font-mono text-2xl sm:text-3xl font-bold text-slate-900 tabular-nums">
              1 Okt 2026
            </p>
            <p className="text-xs font-semibold text-slate-800">
              Pemberlakuan TimeMark
            </p>
            <p className="text-xs text-slate-500">
              Dasar pembayaran gaji ASN
            </p>
          </div>

          <div className="space-y-1">
            <p className="font-mono text-2xl sm:text-3xl font-bold text-slate-900 tabular-nums">
              A4 PDF
            </p>
            <p className="text-xs font-semibold text-slate-800">
              Format Soft &amp; Hard Copy
            </p>
            <p className="text-xs text-slate-500">
              Siap setor berjenjang ke BKPSDM
            </p>
          </div>
        </div>
      </section>

      {/* ================================================================= */}
      {/* 2. LANDASAN REGULASI — 2 SURAT EDARAN BUPATI KUPANG               */}
      {/* ================================================================= */}
      <section id="regulasi" className="space-y-8">
        <div className="max-w-3xl space-y-3">
          <p className="text-xs font-bold text-indigo-700">
            Dasar &amp; Kepentingan Penggunaan Aplikasi
          </p>
          <h2
            className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900"
            style={{ textWrap: 'balance' }}
          >
            Dibangun Selaras dengan 2 Surat Edaran Resmi Bupati Kupang
          </h2>
          <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
            Pengembangan LensaHadir berangkat dari kebutuhan nyata di lingkungan satuan pendidikan dan instansi pemerintah daerah dalam menindaklanjuti kewajiban pelaporan presensi berbasis foto TimeMark sesuai dua regulasi resmi berikut:
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-stretch">
          {/* Regulasi 1: SE Disiplin Jam Kerja & Presensi TimeMark */}
          <article className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-7 flex flex-col justify-between space-y-6">
            <div className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500 pb-3.5 border-b border-slate-100">
                <span className="font-semibold text-slate-800">
                  Surat Edaran Bupati Kupang I
                </span>
                <span className="font-mono text-slate-700 font-semibold tabular-nums">
                  11 Maret 2026
                </span>
              </div>

              <div className="space-y-1.5">
                <p className="font-mono text-xs font-semibold text-indigo-700 tabular-nums">
                  Nomor: BU.800/828/BKPSDM/III/2026
                </p>
                <h3 className="text-lg font-bold text-slate-900 leading-snug">
                  Penegasan Disiplin Masuk Keluar Kantor &amp; Format Pelaporan Presensi TimeMark
                </h3>
                <p className="text-xs text-slate-500">
                  Dipertegas melalui Surat Kecamatan Kupang Barat No. 800/42/KCKB/XI/2026 (5 November 2026) untuk UPTD Puskesmas, Dukcapil, serta UPTD SD dan SMP.
                </p>
              </div>

              <ul className="space-y-2.5 text-sm text-slate-600">
                <li className="flex items-start gap-2.5">
                  <Check className="h-4 w-4 text-indigo-700 shrink-0 mt-0.5" />
                  <span>
                    <strong className="text-slate-900 font-semibold">Lampiran I (Laporan Disiplin Jam Kerja Harian):</strong>{' '}
                    Bukti dukung harian berupa dokumentasi foto TimeMark absen masuk dan absen pulang yang direkap dalam bentuk <strong className="text-slate-800">file soft copy</strong> untuk ASN, PPPK, dan PPPK Paruh Waktu.
                  </span>
                </li>
                <li className="flex items-start gap-2.5">
                  <Check className="h-4 w-4 text-indigo-700 shrink-0 mt-0.5" />
                  <span>
                    <strong className="text-slate-900 font-semibold">Lampiran II (Rekapitulasi Perhitungan Presensi TimeMark):</strong>{' '}
                    Lembaran rekapan keseluruhan pegawai yang ditandatangani kepala unit kerja, memuat hari kerja, tanpa berita, izin, sakit, cuti, terlambat, dan jumlah hadir.
                  </span>
                </li>
                <li className="flex items-start gap-2.5">
                  <Check className="h-4 w-4 text-indigo-700 shrink-0 mt-0.5" />
                  <span>
                    Disampaikan secara tertib dan berkala kepada pimpinan wilayah/kecamatan paling lambat setiap tanggal 2 bulan berjalan.
                  </span>
                </li>
              </ul>
            </div>

            <div className="pt-4 border-t border-slate-100 flex items-center justify-between gap-3">
              <span className="text-xs text-slate-500">
                Dokumen rujukan resmi (PDF)
              </span>
              <a
                href={SE_DISIPLIN_PDF}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 text-xs font-bold text-indigo-700 hover:text-indigo-900 transition-colors whitespace-nowrap shrink-0"
              >
                <FileText className="h-3.5 w-3.5" />
                <span>Buka Dokumen SE I</span>
                <ExternalLink className="h-3.5 w-3.5" />
              </a>
            </div>
          </article>

          {/* Regulasi 2: SE Pembayaran Gaji ASN Berdasarkan Absensi TimeMark */}
          <article className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-7 flex flex-col justify-between space-y-6">
            <div className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500 pb-3.5 border-b border-slate-100">
                <span className="font-semibold text-slate-800">
                  Surat Edaran Bupati Kupang II
                </span>
                <span className="font-mono text-slate-700 font-semibold tabular-nums">
                  23 September 2026
                </span>
              </div>

              <div className="space-y-1.5">
                <p className="font-mono text-xs font-semibold text-indigo-700 tabular-nums">
                  Nomor: Bu.900/3221/BKPSDM/IX/2026
                </p>
                <h3 className="text-lg font-bold text-slate-900 leading-snug">
                  Pembayaran Gaji ASN Berdasarkan Absensi Time Mark
                </h3>
                <p className="text-xs text-slate-500">
                  Ditetapkan di Oelamasi oleh Sekretaris Daerah a.n. Bupati Kupang untuk seluruh Perangkat Daerah, Dinas, Puskesmas, Kecamatan, Kelurahan, dan Sekolah.
                </p>
              </div>

              <ul className="space-y-2.5 text-sm text-slate-600">
                <li className="flex items-start gap-2.5">
                  <Check className="h-4 w-4 text-indigo-700 shrink-0 mt-0.5" />
                  <span>
                    Terhitung mulai <strong className="text-slate-900 font-semibold">1 Oktober 2026</strong>, pembayaran gaji ASN di lingkungan Pemerintah Kabupaten Kupang dilaksanakan berdasarkan absensi melalui aplikasi Time Mark.
                  </span>
                </li>
                <li className="flex items-start gap-2.5">
                  <Check className="h-4 w-4 text-indigo-700 shrink-0 mt-0.5" />
                  <span>
                    <strong className="text-slate-900 font-semibold">Rekapan Absensi Time Mark</strong> wajib dicetak setiap bulan dan dikumpulkan secara berjenjang di lingkungan Dinas, Puskesmas, Kecamatan, Kelurahan, dan Sekolah.
                  </span>
                </li>
                <li className="flex items-start gap-2.5">
                  <Check className="h-4 w-4 text-indigo-700 shrink-0 mt-0.5" />
                  <span>
                    Pimpinan unit kerja menyerahkan rekap absensi (<strong className="text-slate-800">Hard Copy dan Soft Copy</strong>) ke Sekretaris Daerah melalui BKPSDM Kabupaten Kupang setiap tanggal 1 awal bulan.
                  </span>
                </li>
              </ul>
            </div>

            <div className="pt-4 border-t border-slate-100 flex items-center justify-between gap-3">
              <span className="text-xs text-slate-500">
                Dokumen rujukan resmi (PDF)
              </span>
              <a
                href={SE_GAJI_PDF}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 text-xs font-bold text-indigo-700 hover:text-indigo-900 transition-colors whitespace-nowrap shrink-0"
              >
                <FileText className="h-3.5 w-3.5" />
                <span>Buka Dokumen SE II</span>
                <ExternalLink className="h-3.5 w-3.5" />
              </a>
            </div>
          </article>
        </div>
      </section>

      {/* ================================================================= */}
      {/* 3. CORE CAPABILITIES — Asymmetric Editorial Bento Grid            */}
      {/* ================================================================= */}
      <section id="fitur" className="space-y-8">
        <div className="max-w-3xl space-y-3">
          <p className="text-xs font-bold text-indigo-700">
            Fitur Utama Aplikasi
          </p>
          <h2
            className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900"
            style={{ textWrap: 'balance' }}
          >
            Dirancang Khusus untuk Alur Kerja Sekolah dan Unit Kerja Daerah
          </h2>
          <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
            Setiap modul dirancang langsung menjawab format Lampiran I dan Lampiran II Surat Edaran sehingga operator, guru/pegawai, dan kepala sekolah tidak perlu menyusun tabel laporan secara manual berulang kali.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          {CORE_CAPABILITIES.map((cap) => (
            <div
              key={cap.index}
              className={`${cap.span} bg-white rounded-2xl border border-slate-200 p-6 sm:p-7 flex flex-col justify-between space-y-5`}
            >
              <div className="space-y-3">
                <div className="flex items-baseline gap-2.5">
                  <span className="font-mono text-sm font-bold text-indigo-700 tabular-nums">
                    {cap.index}
                  </span>
                  <h3 className="text-base sm:text-lg font-bold text-slate-900">
                    {cap.title}
                  </h3>
                </div>
                <p className="text-sm text-slate-600 leading-relaxed">
                  {cap.summary}
                </p>
              </div>
              <p className="pt-4 border-t border-slate-100 text-xs font-medium text-slate-500">
                {cap.detail}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* ================================================================= */}
      {/* 4. PROFIL PEMBUAT APLIKASI — Y. LOMANG                            */}
      {/* ================================================================= */}
      <section
        id="pembuat"
        className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-10"
      >
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Author Monogram & Role Block */}
          <div className="lg:col-span-4 space-y-4">
            <div className="flex items-center gap-4">
              <img
                src={DEVELOPER_AVATAR_URL}
                alt="Y. Lomang - Pengembang & Inisiator Aplikasi LensaHadir"
                className="h-20 w-20 rounded-full object-cover shadow-md ring-2 ring-emerald-500/30 shrink-0 bg-white"
              />
              <div>
                <p className="text-xs font-semibold text-indigo-700">
                  Pengembang &amp; Inisiator Aplikasi
                </p>
                <h2 className="text-xl font-extrabold text-slate-900 tracking-tight">
                  Y. Lomang
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Blogger &amp; Penggiat Pendidikan Sekolah
                </p>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 text-xs text-slate-500 space-y-1">
              <p>Fokus Pengembangan: Digitalisasi Administrasi Sekolah</p>
              <p>Wilayah Implementasi: Satuan Pendidikan &amp; Unit Kerja Daerah</p>
            </div>
          </div>

          {/* Author Statement */}
          <div className="lg:col-span-8 space-y-4 lg:pl-6 lg:border-l lg:border-slate-200">
            <h3 className="text-lg sm:text-xl font-bold text-slate-900 leading-snug">
              Karya Independen oleh Seorang Blogger sekaligus Penggiat Pendidikan Sekolah
            </h3>
            <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
              Aplikasi <strong className="text-slate-900 font-semibold">LensaHadir</strong> dikembangkan oleh <strong className="text-slate-900 font-semibold">Y. Lomang</strong>, seorang Blogger sekaligus Penggiat Pendidikan Sekolah yang peduli terhadap kemudahan tata kelola administrasi guru dan tenaga kependidikan.
            </p>
            <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
              Aplikasi ini lahir dari kepedulian praktis di lapangan agar para guru, pegawai, operator sekolah, serta pimpinan satuan pendidikan dapat memenuhi kewajiban pelaporan absensi foto TimeMark harian dan rekapitulasi bulanan sesuai kedua Surat Edaran Bupati Kupang secara lebih cepat, rapi, seragam, dan dapat dipertanggungjawabkan.
            </p>
            <div className="pt-2 flex flex-wrap items-center gap-4 text-xs">
              <button
                type="button"
                onClick={onOpenHelp}
                className="font-bold text-indigo-700 hover:text-indigo-900 inline-flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <HelpCircle className="h-4 w-4" />
                <span>Hubungi / Tanya Admin Aplikasi</span>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* ================================================================= */}
      {/* 5. FINAL CONVERSION BANNER — Masuk ke Sistem                      */}
      {/* ================================================================= */}
      <section className="rounded-2xl bg-slate-900 text-white p-7 sm:p-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-2 max-w-xl">
          <p className="text-xs font-semibold text-slate-400">
            Portal Login Resmi LensaHadir
          </p>
          <h2
            className="text-xl sm:text-2xl font-extrabold tracking-tight text-white"
            style={{ textWrap: 'balance' }}
          >
            Siap Mengelola Presensi TimeMark dan Laporan Disiplin Hari Ini?
          </h2>
          <p className="text-sm text-slate-300 leading-relaxed">
            Masuk menggunakan akun Administrator Utama, Pimpinan, atau Guru/Pegawai yang telah terdaftar pada satuan pendidikan atau unit kerja Anda.
          </p>
        </div>

        <div className="shrink-0">
          {isLoggedIn ? (
            <button
              type="button"
              onClick={onGoToDashboard}
              className="w-full md:w-auto bg-white hover:bg-slate-100 text-slate-900 px-7 py-3.5 rounded-xl font-bold text-sm transition-colors flex items-center justify-center gap-2 whitespace-nowrap cursor-pointer"
            >
              <span>Buka Dashboard</span>
              <ArrowRight className="h-4 w-4" />
            </button>
          ) : (
            <button
              type="button"
              onClick={onGoToLogin}
              className="w-full md:w-auto bg-white hover:bg-slate-100 text-slate-900 px-7 py-3.5 rounded-xl font-bold text-sm transition-colors flex items-center justify-center gap-2 whitespace-nowrap cursor-pointer"
            >
              <Lock className="h-4 w-4" />
              <span>Login Masuk ke Sistem</span>
              <ArrowRight className="h-4 w-4" />
            </button>
          )}
        </div>
      </section>
    </div>
  );
};
