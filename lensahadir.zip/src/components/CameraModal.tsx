import React, { useEffect, useRef, useState } from 'react';
import { Camera, RefreshCw, Check, X, AlertCircle } from 'lucide-react';

interface CameraModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCapture: (imageDataUrl: string) => void;
  title: string;
  employeeName?: string;
}

export const CameraModal: React.FC<CameraModalProps> = ({
  isOpen,
  onClose,
  onCapture,
  title,
  employeeName,
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [stampWatermark, setStampWatermark] = useState<boolean>(true);

  // Start camera stream
  const startCamera = async (mode: 'user' | 'environment') => {
    setErrorMsg(null);
    if (stream) {
      stream.getTracks().forEach((track) => track.stop());
    }

    try {
      const newStream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: mode,
          width: { ideal: 1280 },
          height: { ideal: 960 },
        },
        audio: false,
      });

      setStream(newStream);
      if (videoRef.current) {
        videoRef.current.srcObject = newStream;
      }
    } catch (err: any) {
      console.warn('Camera access failed:', err);
      setErrorMsg('Izin kamera tidak diberikan atau perangkat tidak mendukung. Anda dapat menggunakan tombol Unggah File Foto.');
    }
  };

  useEffect(() => {
    if (isOpen) {
      setCapturedImage(null);
      startCamera(facingMode);
    } else {
      if (stream) {
        stream.getTracks().forEach((track) => track.stop());
        setStream(null);
      }
    }

    return () => {
      if (stream) {
        stream.getTracks().forEach((track) => track.stop());
      }
    };
  }, [isOpen, facingMode]);

  // Flip camera
  const toggleFacingMode = () => {
    setFacingMode((prev) => (prev === 'user' ? 'environment' : 'user'));
  };

  // Capture snapshot from video
  const takeSnapshot = () => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas) return;

    const width = video.videoWidth || 640;
    const height = video.videoHeight || 480;

    canvas.width = width;
    canvas.height = height;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Draw video frame (flip horizontally if front camera for natural selfie look)
    if (facingMode === 'user') {
      ctx.translate(width, 0);
      ctx.scale(-1, 1);
      ctx.drawImage(video, 0, 0, width, height);
      ctx.setTransform(1, 0, 0, 1, 0, 0);
    } else {
      ctx.drawImage(video, 0, 0, width, height);
    }

    // Optional Watermark stamp
    if (stampWatermark) {
      const now = new Date();
      const timeStr = now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' }) + ' WIB';
      const dateStr = now.toLocaleDateString('id-ID', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });

      // Bottom banner overlay
      const bannerHeight = Math.max(50, Math.floor(height * 0.12));
      ctx.fillStyle = 'rgba(15, 23, 42, 0.78)';
      ctx.fillRect(0, height - bannerHeight, width, bannerHeight);

      // Watermark text
      ctx.fillStyle = '#ffffff';
      ctx.font = `bold ${Math.floor(bannerHeight * 0.35)}px 'Plus Jakarta Sans', sans-serif`;
      ctx.fillText(`LENSAHADIR • ${timeStr}`, 16, height - bannerHeight + Math.floor(bannerHeight * 0.45));

      ctx.fillStyle = '#94a3b8';
      ctx.font = `${Math.floor(bannerHeight * 0.28)}px 'Plus Jakarta Sans', sans-serif`;
      const infoText = `${dateStr}${employeeName ? ` • ${employeeName}` : ''}`;
      ctx.fillText(infoText, 16, height - bannerHeight + Math.floor(bannerHeight * 0.82));
    }

    const dataUrl = canvas.toDataURL('image/jpeg', 0.92);
    setCapturedImage(dataUrl);
  };

  const confirmPhoto = () => {
    if (capturedImage) {
      onCapture(capturedImage);
      onClose();
    }
  };

  const retakePhoto = () => {
    setCapturedImage(null);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-lg overflow-hidden rounded-2xl bg-slate-900 text-white shadow-2xl border border-slate-700">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 px-5 py-4">
          <div className="flex items-center gap-2">
            <Camera className="h-5 w-5 text-indigo-400" />
            <h3 className="text-base font-bold uppercase tracking-wide text-slate-100">{title}</h3>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1 text-slate-400 hover:bg-slate-800 hover:text-white transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Viewport Area */}
        <div className="relative aspect-[4/3] w-full bg-black overflow-hidden flex items-center justify-center">
          {errorMsg ? (
            <div className="p-6 text-center">
              <AlertCircle className="mx-auto h-12 w-12 text-amber-400 mb-3" />
              <p className="text-sm font-medium text-slate-200 mb-4">{errorMsg}</p>
              <button
                onClick={onClose}
                className="px-4 py-2 text-xs font-semibold bg-slate-800 text-slate-200 rounded-lg hover:bg-slate-700"
              >
                Tutup & Unggah File Saja
              </button>
            </div>
          ) : capturedImage ? (
            <img
              src={capturedImage}
              alt="Hasil Kamera"
              className="h-full w-full object-cover"
            />
          ) : (
            <>
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className={`h-full w-full object-cover ${facingMode === 'user' ? '-scale-x-100' : ''}`}
              />
              {/* Center Focus Target Overlay */}
              <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
                <div className="h-44 w-44 rounded-full border-2 border-dashed border-white/40 shadow-inner flex items-center justify-center">
                  <div className="h-2 w-2 rounded-full bg-indigo-400/80 animate-ping" />
                </div>
              </div>
            </>
          )}

          {/* Hidden Canvas for capture */}
          <canvas ref={canvasRef} className="hidden" />
        </div>

        {/* Watermark checkbox toggle */}
        <div className="bg-slate-950/80 px-5 py-2.5 border-t border-slate-800 flex items-center justify-between text-xs text-slate-300">
          <label className="flex items-center gap-2 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={stampWatermark}
              onChange={(e) => setStampWatermark(e.target.checked)}
              className="rounded border-slate-700 text-indigo-600 focus:ring-0"
            />
            <span>Sematkan Watermark Waktu & Tanggal Otomatis</span>
          </label>
          <span className="text-[11px] font-mono text-slate-400">
            {facingMode === 'user' ? 'Kamera Depan' : 'Kamera Belakang'}
          </span>
        </div>

        {/* Controls Footer */}
        <div className="p-4 bg-slate-900 border-t border-slate-800 flex items-center justify-between gap-3">
          {capturedImage ? (
            <>
              <button
                onClick={retakePhoto}
                className="flex-1 py-3 px-4 rounded-xl border border-slate-700 text-slate-200 hover:bg-slate-800 font-semibold text-sm transition-colors flex items-center justify-center gap-2"
              >
                <RefreshCw className="h-4 w-4" />
                Ambil Ulang
              </button>
              <button
                onClick={confirmPhoto}
                className="flex-1 py-3 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm shadow-lg shadow-indigo-600/30 transition-colors flex items-center justify-center gap-2"
              >
                <Check className="h-4 w-4" />
                Gunakan Foto Ini
              </button>
            </>
          ) : (
            <>
              <button
                onClick={toggleFacingMode}
                disabled={!!errorMsg}
                className="p-3 rounded-xl border border-slate-700 text-slate-300 hover:bg-slate-800 transition-colors disabled:opacity-40"
                title="Putar Kamera Depan / Belakang"
              >
                <RefreshCw className="h-5 w-5" />
              </button>

              <button
                onClick={takeSnapshot}
                disabled={!!errorMsg}
                className="flex-1 py-3.5 px-6 rounded-xl bg-indigo-600 hover:bg-indigo-500 active:scale-98 text-white font-extrabold text-base shadow-lg shadow-indigo-600/40 transition-all flex items-center justify-center gap-2 disabled:opacity-40"
              >
                <div className="h-4 w-4 rounded-full bg-white ring-4 ring-indigo-400/40" />
                Jepret Foto
              </button>

              <button
                onClick={onClose}
                className="py-3 px-4 rounded-xl text-slate-400 hover:text-slate-200 text-sm font-semibold transition-colors"
              >
                Batal
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
