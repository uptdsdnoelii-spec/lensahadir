import React, { useState, useMemo } from 'react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  Legend,
} from 'recharts';
import {
  BarChart3,
  TrendingUp,
  PieChart as PieChartIcon,
  Calendar,
  Search,
  Users,
  CheckCircle2,
  AlertTriangle,
  ClipboardList,
  Eye,
  Filter,
  FileText,
} from 'lucide-react';
import {
  AttendanceRecord,
  AdminSubmissionRecord,
  AppSettings,
  StatusPegawai,
  StatusKehadiran,
} from '../types/attendance';
import { INDONESIAN_MONTHS, getDaysInMonth } from '../utils/monthlyRecapParser';

interface LeaderStatisticsPageProps {
  settings: AppSettings;
  records: AttendanceRecord[];
  adminSubmissions: AdminSubmissionRecord[];
  onSelectRecord: (rec: AttendanceRecord) => void;
  onGoToForm: () => void;
}

type StatMode = 'daily' | 'monthly';

interface NormalizedEntry {
  id: string;
  nama: string;
  nip: string;
  golRuang: string;
  jabatan: string;
  statusPegawai: StatusPegawai;
  tanggal: string; // YYYY-MM-DD
  statusKehadiran: StatusKehadiran;
  catatan: string;
  fotoMasuk: string;
  fotoKeluar: string;
  createdAt: number;
  sourceRecord: AttendanceRecord;
}

interface EmployeeStatRow {
  key: string;
  nama: string;
  nip: string;
  jabatan: string;
  golRuang: string;
  statusPegawai: StatusPegawai;
  h: number;
  td: number;
  ic: number;
  s: number;
  tb: number;
  total: number;
  disciplinePct: number;
  latestRecord: AttendanceRecord;
}

const STATUS_PEGAWAI_FILTER_OPTIONS: ('ALL' | StatusPegawai)[] = [
  'ALL',
  'ASN',
  'PPPK',
  'PPPK Paruh Waktu',
  'Honor/GTT',
  'Tenaga Kontrak',
  'Penjaga Sekolah',
];

const CHART_COLORS = {
  hadir: '#16A34A',
  tugasDinas: '#2563EB',
  ijinCuti: '#D97706',
  sakit: '#EA580C',
  tanpaBerita: '#DC2626',
};

const classifyStatus = (
  st: StatusKehadiran
): 'h' | 'td' | 'ic' | 's' | 'tb' => {
  if (!st || st.startsWith('Hadir')) return 'h';
  if (st.startsWith('Tugas Dinas') || st.startsWith('Tugas Belajar')) return 'td';
  if (st.startsWith('Ijin') || st.startsWith('Cuti')) return 'ic';
  if (st.startsWith('Sakit')) return 's';
  return 'tb';
};

const formatDateLongId = (iso: string): string => {
  if (!iso) return '-';
  const parts = iso.split('-').map((p) => parseInt(p, 10));
  if (parts.length !== 3 || parts.some(Number.isNaN)) return iso;
  const dt = new Date(parts[0], parts[1] - 1, parts[2]);
  return dt.toLocaleDateString('id-ID', {
    weekday: 'long',
    day: '2-digit',
    month: 'long',
    year: 'numeric',
  });
};

const formatShortDateLabel = (iso: string): string => {
  const parts = iso.split('-');
  if (parts.length !== 3) return iso;
  const mIdx = parseInt(parts[1], 10) - 1;
  const shortMonth = (INDONESIAN_MONTHS[mIdx] || '').slice(0, 3);
  return `${parts[2]} ${shortMonth}`;
};

const getDisciplineTier = (
  pct: number,
  tbCount: number
): { label: string; textClass: string; barClass: string } => {
  if (tbCount > 0 && pct < 85) {
    return {
      label: 'Perlu Pembinaan',
      textClass: 'text-rose-700',
      barClass: 'bg-rose-600',
    };
  }
  if (pct >= 90 && tbCount === 0) {
    return {
      label: 'Sangat Baik',
      textClass: 'text-emerald-700',
      barClass: 'bg-emerald-600',
    };
  }
  if (pct >= 75) {
    return {
      label: 'Baik',
      textClass: 'text-indigo-700',
      barClass: 'bg-indigo-600',
    };
  }
  return {
    label: 'Perlu Pembinaan',
    textClass: 'text-amber-700',
    barClass: 'bg-amber-600',
  };
};

export const LeaderStatisticsPage: React.FC<LeaderStatisticsPageProps> = ({
  settings,
  records,
  adminSubmissions,
  onSelectRecord,
  onGoToForm,
}) => {
  // Combine & deduplicate Riwayat records + Admin Submissions
  const allEntries = useMemo<NormalizedEntry[]>(() => {
    const map = new Map<string, NormalizedEntry>();

    // 1. From Riwayat (records)
    for (const r of records) {
      if (!r.tanggal || !r.nama) continue;
      const dedupeKey = `${r.nama.trim().toLowerCase()}__${r.tanggal}`;
      const existing = map.get(dedupeKey);
      if (!existing || r.createdAt >= existing.createdAt) {
        map.set(dedupeKey, {
          id: r.id,
          nama: r.nama.trim(),
          nip: r.nip?.trim() || '-',
          golRuang: r.golRuang?.trim() || '-',
          jabatan: r.jabatan?.trim() || '-',
          statusPegawai: r.statusPegawai || 'ASN',
          tanggal: r.tanggal,
          statusKehadiran: r.statusKehadiran || 'Hadir (H)',
          catatan: r.catatan || '',
          fotoMasuk: r.fotoMasuk,
          fotoKeluar: r.fotoKeluar,
          createdAt: r.createdAt || 0,
          sourceRecord: r,
        });
      }
    }

    // 2. From Admin Submissions (in case any submission is not in local records)
    for (const s of adminSubmissions) {
      if (!s.tanggal || !s.nama) continue;
      const dedupeKey = `${s.nama.trim().toLowerCase()}__${s.tanggal}`;
      if (!map.has(dedupeKey)) {
        const asRecord: AttendanceRecord = {
          id: s.recordId || s.id,
          nama: s.nama.trim(),
          nip: s.nip?.trim() || '',
          golRuang: s.golRuang?.trim() || '',
          jabatan: s.jabatan?.trim() || '',
          statusPegawai: s.statusPegawai || 'ASN',
          tanggal: s.tanggal,
          statusKehadiran: s.statusKehadiran || 'Hadir (H)',
          catatan: s.catatan || '',
          fotoMasuk: s.fotoMasuk,
          fotoKeluar: s.fotoKeluar,
          createdAt: s.submittedAt || 0,
          ownerUserId: s.userId,
          ownerUsername: s.username,
          sentToAdmin: true,
          sentToAdminAt: s.submittedAt,
        };
        map.set(dedupeKey, {
          id: asRecord.id,
          nama: asRecord.nama,
          nip: asRecord.nip || '-',
          golRuang: asRecord.golRuang || '-',
          jabatan: asRecord.jabatan || '-',
          statusPegawai: asRecord.statusPegawai,
          tanggal: asRecord.tanggal,
          statusKehadiran: asRecord.statusKehadiran,
          catatan: asRecord.catatan,
          fotoMasuk: asRecord.fotoMasuk,
          fotoKeluar: asRecord.fotoKeluar,
          createdAt: asRecord.createdAt,
          sourceRecord: asRecord,
        });
      }
    }

    return Array.from(map.values()).sort(
      (a, b) => b.tanggal.localeCompare(a.tanggal) || b.createdAt - a.createdAt
    );
  }, [records, adminSubmissions]);

  // Distinct sorted dates and years available in data
  const availableDates = useMemo(() => {
    const set = new Set<string>();
    allEntries.forEach((e) => set.add(e.tanggal));
    return Array.from(set).sort((a, b) => b.localeCompare(a));
  }, [allEntries]);

  const availableYears = useMemo(() => {
    const set = new Set<number>([new Date().getFullYear()]);
    allEntries.forEach((e) => {
      const y = parseInt(e.tanggal.slice(0, 4), 10);
      if (!Number.isNaN(y)) set.add(y);
    });
    return Array.from(set).sort((a, b) => b - a);
  }, [allEntries]);

  const latestIso = availableDates[0] || new Date().toISOString().split('T')[0];
  const latestYear = parseInt(latestIso.slice(0, 4), 10) || new Date().getFullYear();
  const latestMonth = parseInt(latestIso.slice(5, 7), 10) || new Date().getMonth() + 1;

  // Interactive Filters
  const [mode, setMode] = useState<StatMode>('monthly');
  const [selectedDate, setSelectedDate] = useState<string>(latestIso);
  const [selectedMonth, setSelectedMonth] = useState<number>(latestMonth); // 0 = All months in year, 1-12 = specific month
  const [selectedYear, setSelectedYear] = useState<number>(latestYear);
  const [statusFilter, setStatusFilter] = useState<'ALL' | StatusPegawai>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Entries filtered by Status Kepegawaian (for trend charts)
  const statusScopedEntries = useMemo(() => {
    if (statusFilter === 'ALL') return allEntries;
    return allEntries.filter((e) => e.statusPegawai === statusFilter);
  }, [allEntries, statusFilter]);

  // Active Period Entries
  const periodEntries = useMemo(() => {
    if (mode === 'daily') {
      return statusScopedEntries.filter((e) => e.tanggal === selectedDate);
    }
    const yearStr = String(selectedYear);
    if (selectedMonth === 0) {
      return statusScopedEntries.filter((e) => e.tanggal.startsWith(`${yearStr}-`));
    }
    const monthPrefix = `${yearStr}-${String(selectedMonth).padStart(2, '0')}`;
    return statusScopedEntries.filter((e) => e.tanggal.startsWith(monthPrefix));
  }, [statusScopedEntries, mode, selectedDate, selectedMonth, selectedYear]);

  // Period Totals & Composition
  const summary = useMemo(() => {
    let h = 0;
    let td = 0;
    let ic = 0;
    let s = 0;
    let tb = 0;
    const uniquePeople = new Set<string>();
    const uniqueDates = new Set<string>();

    for (const entry of periodEntries) {
      uniquePeople.add(entry.nama.toLowerCase());
      uniqueDates.add(entry.tanggal);
      const cls = classifyStatus(entry.statusKehadiran);
      if (cls === 'h') h++;
      else if (cls === 'td') td++;
      else if (cls === 'ic') ic++;
      else if (cls === 's') s++;
      else tb++;
    }

    const total = periodEntries.length;
    const aktif = h + td;
    const tidakHadir = ic + s + tb;
    const disciplineRate = total > 0 ? Number(((aktif / total) * 100).toFixed(1)) : 0;
    const hadirOnlyRate = total > 0 ? Number(((h / total) * 100).toFixed(1)) : 0;

    return {
      h,
      td,
      ic,
      s,
      tb,
      aktif,
      tidakHadir,
      total,
      uniquePeopleCount: uniquePeople.size,
      uniqueDatesCount: uniqueDates.size,
      disciplineRate,
      hadirOnlyRate,
    };
  }, [periodEntries]);

  // 1. Trend Curve Series (Daily: 14-day window ending selectedDate; Monthly: per day 1..31 or Jan..Des)
  const trendData = useMemo(() => {
    if (mode === 'daily') {
      const parts = selectedDate.split('-').map((p) => parseInt(p, 10));
      const endDate =
        parts.length === 3 && !parts.some(Number.isNaN)
          ? new Date(parts[0], parts[1] - 1, parts[2])
          : new Date();

      const bucketMap = new Map<
        string,
        { hadirAktif: number; izinSakitCuti: number; tanpaBerita: number }
      >();
      for (const e of statusScopedEntries) {
        const cur = bucketMap.get(e.tanggal) || {
          hadirAktif: 0,
          izinSakitCuti: 0,
          tanpaBerita: 0,
        };
        const cls = classifyStatus(e.statusKehadiran);
        if (cls === 'h' || cls === 'td') cur.hadirAktif++;
        else if (cls === 'tb') cur.tanpaBerita++;
        else cur.izinSakitCuti++;
        bucketMap.set(e.tanggal, cur);
      }

      const points = [];
      for (let offset = 13; offset >= 0; offset--) {
        const dt = new Date(endDate);
        dt.setDate(endDate.getDate() - offset);
        const iso = `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(
          2,
          '0'
        )}-${String(dt.getDate()).padStart(2, '0')}`;
        const val = bucketMap.get(iso) || {
          hadirAktif: 0,
          izinSakitCuti: 0,
          tanpaBerita: 0,
        };
        points.push({
          label: formatShortDateLabel(iso),
          iso,
          hadirAktif: val.hadirAktif,
          izinSakitCuti: val.izinSakitCuti,
          tanpaBerita: val.tanpaBerita,
        });
      }
      return points;
    }

    if (selectedMonth === 0) {
      // Monthly curve Jan - Des for selectedYear
      const yearStr = String(selectedYear);
      const months = Array.from({ length: 12 }, (_, idx) => ({
        label: INDONESIAN_MONTHS[idx].slice(0, 3),
        hadirAktif: 0,
        izinSakitCuti: 0,
        tanpaBerita: 0,
      }));
      for (const e of statusScopedEntries) {
        if (!e.tanggal.startsWith(`${yearStr}-`)) continue;
        const mIdx = parseInt(e.tanggal.slice(5, 7), 10) - 1;
        if (mIdx < 0 || mIdx > 11) continue;
        const cls = classifyStatus(e.statusKehadiran);
        if (cls === 'h' || cls === 'td') months[mIdx].hadirAktif++;
        else if (cls === 'tb') months[mIdx].tanpaBerita++;
        else months[mIdx].izinSakitCuti++;
      }
      return months;
    }

    // Specific Month: day 1..daysInMonth
    const daysCount = getDaysInMonth(selectedMonth, selectedYear);
    const monthPrefix = `${selectedYear}-${String(selectedMonth).padStart(2, '0')}-`;
    const days = Array.from({ length: daysCount }, (_, i) => ({
      label: String(i + 1).padStart(2, '0'),
      hadirAktif: 0,
      izinSakitCuti: 0,
      tanpaBerita: 0,
    }));
    for (const e of statusScopedEntries) {
      if (!e.tanggal.startsWith(monthPrefix)) continue;
      const dIdx = parseInt(e.tanggal.slice(8, 10), 10) - 1;
      if (dIdx < 0 || dIdx >= daysCount) continue;
      const cls = classifyStatus(e.statusKehadiran);
      if (cls === 'h' || cls === 'td') days[dIdx].hadirAktif++;
      else if (cls === 'tb') days[dIdx].tanpaBerita++;
      else days[dIdx].izinSakitCuti++;
    }
    return days;
  }, [mode, selectedDate, selectedMonth, selectedYear, statusScopedEntries]);

  // 2. Donut Chart Data (Status Kehadiran Composition)
  const compositionData = useMemo(() => {
    return [
      { name: 'Hadir (H)', value: summary.h, color: CHART_COLORS.hadir },
      { name: 'Tugas Dinas / Belajar', value: summary.td, color: CHART_COLORS.tugasDinas },
      { name: 'Ijin / Cuti', value: summary.ic, color: CHART_COLORS.ijinCuti },
      { name: 'Sakit (S)', value: summary.s, color: CHART_COLORS.sakit },
      { name: 'Tanpa Berita (TB)', value: summary.tb, color: CHART_COLORS.tanpaBerita },
    ].filter((item) => item.value > 0);
  }, [summary]);

  // 3. Bar Chart Data by Status Pegawai
  const byEmploymentStatusData = useMemo(() => {
    const map = new Map<
      StatusPegawai,
      {
        status: string;
        Hadir: number;
        TugasDinas: number;
        IzinSakitCuti: number;
        TanpaBerita: number;
        total: number;
        rate: number;
      }
    >();

    for (const e of periodEntries) {
      const cur = map.get(e.statusPegawai) || {
        status: e.statusPegawai,
        Hadir: 0,
        TugasDinas: 0,
        IzinSakitCuti: 0,
        TanpaBerita: 0,
        total: 0,
        rate: 0,
      };
      cur.total++;
      const cls = classifyStatus(e.statusKehadiran);
      if (cls === 'h') cur.Hadir++;
      else if (cls === 'td') cur.TugasDinas++;
      else if (cls === 'tb') cur.TanpaBerita++;
      else cur.IzinSakitCuti++;
      cur.rate = Number((((cur.Hadir + cur.TugasDinas) / cur.total) * 100).toFixed(1));
      map.set(e.statusPegawai, cur);
    }

    return Array.from(map.values()).sort((a, b) => b.total - a.total);
  }, [periodEntries]);

  // 4. Detailed Per-Employee Statistics Table
  const employeeStats = useMemo<EmployeeStatRow[]>(() => {
    const map = new Map<string, EmployeeStatRow>();

    for (const e of periodEntries) {
      const key = e.nama.toLowerCase();
      let row = map.get(key);
      if (!row) {
        row = {
          key,
          nama: e.nama,
          nip: e.nip,
          jabatan: e.jabatan,
          golRuang: e.golRuang,
          statusPegawai: e.statusPegawai,
          h: 0,
          td: 0,
          ic: 0,
          s: 0,
          tb: 0,
          total: 0,
          disciplinePct: 0,
          latestRecord: e.sourceRecord,
        };
        map.set(key, row);
      }
      row.total++;
      const cls = classifyStatus(e.statusKehadiran);
      if (cls === 'h') row.h++;
      else if (cls === 'td') row.td++;
      else if (cls === 'ic') row.ic++;
      else if (cls === 's') row.s++;
      else row.tb++;

      if (
        e.tanggal > row.latestRecord.tanggal ||
        (e.tanggal === row.latestRecord.tanggal &&
          e.createdAt > row.latestRecord.createdAt)
      ) {
        row.latestRecord = e.sourceRecord;
      }
    }

    const list = Array.from(map.values()).map((r) => ({
      ...r,
      disciplinePct:
        r.total > 0 ? Number((((r.h + r.td) / r.total) * 100).toFixed(1)) : 0,
    }));

    return list.sort((a, b) => b.disciplinePct - a.disciplinePct || b.total - a.total);
  }, [periodEntries]);

  const filteredEmployeeStats = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return employeeStats;
    return employeeStats.filter(
      (r) =>
        r.nama.toLowerCase().includes(q) ||
        r.nip.toLowerCase().includes(q) ||
        r.jabatan.toLowerCase().includes(q) ||
        r.statusPegawai.toLowerCase().includes(q)
    );
  }, [employeeStats, searchQuery]);

  // Top 10 Employee Discipline Bar Data
  const employeeBarData = useMemo(() => {
    return employeeStats.slice(0, 10).map((r) => ({
      namaSingkat: r.nama.length > 20 ? `${r.nama.slice(0, 18)}…` : r.nama,
      namaLengkap: r.nama,
      disiplin: r.disciplinePct,
      total: r.total,
    }));
  }, [employeeStats]);

  // 5. Executive Conclusion / Rekapan Simpulan Pimpinan
  const executiveConclusions = useMemo(() => {
    const perfectEmployees = employeeStats.filter(
      (e) => e.disciplinePct === 100 && e.tb === 0
    );
    const attentionEmployees = employeeStats.filter(
      (e) => e.tb > 0 || e.disciplinePct < 80
    );
    const topStatusGroup = [...byEmploymentStatusData].sort(
      (a, b) => b.rate - a.rate || b.total - a.total
    )[0];

    let overallRating = 'Belum Tersedia Data';
    let recommendation =
      'Belum terdapat catatan absensi pada periode terpilih. Pastikan guru/pegawai menyimpan kartu absensi ke Riwayat secara rutin.';

    if (summary.total > 0) {
      if (summary.disciplineRate >= 90 && summary.tb === 0) {
        overallRating = 'Sangat Baik (Disiplin Terjaga)';
        recommendation =
          'Pertahankan konsistensi kedisiplinan lembaga dan berikan apresiasi berkala kepada pegawai dengan kehadiran penuh.';
      } else if (summary.disciplineRate >= 80 && summary.tb <= 1) {
        overallRating = 'Baik (Stabil)';
        recommendation =
          'Lakukan pemantauan rutin pada catatan izin/sakit dan pastikan konfirmasi kehadiran harian tetap tepat waktu.';
      } else if (summary.tb > 0) {
        overallRating = 'Perlu Perhatian Khusus (Terdapat Tanpa Berita)';
        recommendation =
          'Segera lakukan klarifikasi dan pembinaan internal terhadap pegawai dengan catatan Tanpa Berita (TB) agar tidak berdampak pada evaluasi kinerja maupun administrasi gaji.';
      } else {
        overallRating = 'Perlu Pembinaan & Evaluasi';
        recommendation =
          'Lakukan koordinasi singkat dengan staf terkait tingginya rasio ketidakhadiran guna menjaga kelancaran layanan satuan pendidikan.';
      }
    }

    return {
      overallRating,
      recommendation,
      perfectEmployees,
      attentionEmployees,
      topStatusGroup,
    };
  }, [employeeStats, byEmploymentStatusData, summary]);

  const periodLabel =
    mode === 'daily'
      ? formatDateLongId(selectedDate)
      : selectedMonth === 0
      ? `Sepanjang Tahun ${selectedYear}`
      : `${INDONESIAN_MONTHS[selectedMonth - 1]} ${selectedYear}`;

  const overallTier = getDisciplineTier(summary.disciplineRate, summary.tb);

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* ================================================================= */}
      {/* HEADER & FILTER BAR                                               */}
      {/* ================================================================= */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 space-y-5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
              <span className="font-bold text-indigo-700">Pemantauan Pimpinan</span>
              <span aria-hidden="true">·</span>
              <span>{settings.subInstansi || settings.namaInstansi}</span>
              <span aria-hidden="true">·</span>
              <span className="font-mono tabular-nums text-slate-700 font-semibold">
                {periodLabel}
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-extrabold tracking-tight text-slate-900">
              Statistik Absensi &amp; Analisis Disiplin Pegawai
            </h1>
            <p className="text-xs sm:text-sm text-slate-500">
              Rekap otomatis dari data Riwayat absensi guru dan pegawai sebagai dasar pemantauan serta pembinaan disiplin lembaga.
            </p>
          </div>

          {/* Mode Segmented Control: Harian | Bulanan */}
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl border border-slate-200 self-start lg:self-center shrink-0">
            <button
              type="button"
              onClick={() => setMode('daily')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                mode === 'daily'
                  ? 'bg-white text-indigo-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Statistik Harian
            </button>
            <button
              type="button"
              onClick={() => setMode('monthly')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                mode === 'monthly'
                  ? 'bg-white text-indigo-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Statistik Bulanan
            </button>
          </div>
        </div>

        {/* Filter Controls Row */}
        <div className="pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2.5">
            {mode === 'daily' ? (
              <>
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-slate-400" />
                  <input
                    type="date"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                    className="rounded-xl border border-slate-300 px-3 py-2 text-xs font-semibold text-slate-800 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
                  />
                </div>
                {availableDates.length > 0 && (
                  <div className="flex flex-wrap items-center gap-1.5">
                    <span className="text-[11px] font-medium text-slate-400">
                      Tanggal tersedia:
                    </span>
                    {availableDates.slice(0, 4).map((d) => (
                      <button
                        key={d}
                        type="button"
                        onClick={() => setSelectedDate(d)}
                        className={`px-2.5 py-1.5 rounded-lg text-[11px] font-mono font-semibold transition cursor-pointer ${
                          selectedDate === d
                            ? 'bg-indigo-700 text-white'
                            : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                        }`}
                      >
                        {formatShortDateLabel(d)}
                      </button>
                    ))}
                  </div>
                )}
              </>
            ) : (
              <>
                <select
                  value={selectedMonth}
                  onChange={(e) => setSelectedMonth(Number(e.target.value))}
                  className="rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-800 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
                >
                  <option value={0}>Semua Bulan (Tahunan)</option>
                  {INDONESIAN_MONTHS.map((m, idx) => (
                    <option key={m} value={idx + 1}>
                      {m}
                    </option>
                  ))}
                </select>
                <select
                  value={selectedYear}
                  onChange={(e) => setSelectedYear(Number(e.target.value))}
                  className="rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs font-mono font-semibold text-slate-800 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
                >
                  {availableYears.map((y) => (
                    <option key={y} value={y}>
                      {y}
                    </option>
                  ))}
                </select>
              </>
            )}
          </div>

          <div className="flex items-center gap-2">
            <Filter className="h-3.5 w-3.5 text-slate-400" />
            <select
              value={statusFilter}
              onChange={(e) =>
                setStatusFilter(e.target.value as 'ALL' | StatusPegawai)
              }
              className="rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-800 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
            >
              {STATUS_PEGAWAI_FILTER_OPTIONS.map((opt) => (
                <option key={opt} value={opt}>
                  {opt === 'ALL' ? 'Semua Status Pegawai' : opt}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* ================================================================= */}
      {/* EMPTY STATE FOR PERIOD (WITH QUICK JUMP TO AVAILABLE DATA)        */}
      {/* ================================================================= */}
      {summary.total === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-10 text-center space-y-4">
          <div className="inline-flex p-3.5 rounded-2xl bg-slate-100 text-slate-500">
            <BarChart3 className="h-7 w-7" />
          </div>
          <div className="space-y-1 max-w-md mx-auto">
            <h2 className="text-base font-bold text-slate-900">
              Belum Ada Data Absensi pada {periodLabel}
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 leading-relaxed">
              Statistik dihitung otomatis dari data Riwayat yang disimpan oleh guru dan pegawai. Pilih tanggal/bulan yang telah memiliki catatan atau catat absensi baru.
            </p>
          </div>
          <div className="flex flex-wrap items-center justify-center gap-2.5 pt-1">
            {availableDates.length > 0 && (
              <button
                type="button"
                onClick={() => {
                  const latest = availableDates[0];
                  setSelectedDate(latest);
                  setSelectedYear(parseInt(latest.slice(0, 4), 10));
                  setSelectedMonth(parseInt(latest.slice(5, 7), 10));
                  setStatusFilter('ALL');
                }}
                className="px-5 py-2.5 rounded-xl bg-indigo-700 hover:bg-indigo-800 text-white text-xs font-bold transition cursor-pointer"
              >
                Tampilkan Periode Terbaru ({formatShortDateLabel(availableDates[0])})
              </button>
            )}
            <button
              type="button"
              onClick={onGoToForm}
              className="px-5 py-2.5 rounded-xl border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 text-xs font-bold flex items-center gap-1.5 transition cursor-pointer"
            >
              <FileText className="h-3.5 w-3.5" />
              Buka Form Absensi
            </button>
          </div>
        </div>
      ) : (
        <>
          {/* ================================================================= */}
          {/* 1. 4-COLUMN KPI SUMMARY STRIP                                     */}
          {/* ================================================================= */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span className="font-semibold">Tingkat Kedisiplinan</span>
                <span className={`font-bold ${overallTier.textClass}`}>
                  {overallTier.label}
                </span>
              </div>
              <p className="font-mono text-2xl sm:text-3xl font-extrabold text-slate-900 tabular-nums">
                {summary.disciplineRate}%
              </p>
              <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                <div
                  className={`h-full ${overallTier.barClass} rounded-full transition-all`}
                  style={{ width: `${Math.min(100, summary.disciplineRate)}%` }}
                />
              </div>
              <p className="text-[11px] text-slate-500 font-mono tabular-nums">
                {summary.aktif} dari {summary.total} catatan (H + TD/TS)
              </p>
            </div>

            <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span className="font-semibold">Total Catatan Riwayat</span>
                <Users className="h-4 w-4 text-slate-400" />
              </div>
              <p className="font-mono text-2xl sm:text-3xl font-extrabold text-slate-900 tabular-nums">
                {summary.total}
              </p>
              <p className="text-xs text-slate-600 font-medium">
                <span className="font-mono font-bold text-slate-900 tabular-nums">
                  {summary.uniquePeopleCount}
                </span>{' '}
                guru/pegawai tercatat
              </p>
              <p className="text-[11px] text-slate-500 font-mono tabular-nums">
                {summary.uniqueDatesCount} hari aktif terekam
              </p>
            </div>

            <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span className="font-semibold">Hadir &amp; Tugas Dinas</span>
                <CheckCircle2 className="h-4 w-4 text-emerald-600" />
              </div>
              <p className="font-mono text-2xl sm:text-3xl font-extrabold text-emerald-700 tabular-nums">
                {summary.aktif}
              </p>
              <div className="flex items-center gap-3 text-xs text-slate-600 font-mono tabular-nums">
                <span>Hadir: <b>{summary.h}</b></span>
                <span aria-hidden="true">·</span>
                <span>TD/TS: <b>{summary.td}</b></span>
              </div>
              <p className="text-[11px] text-slate-500 font-mono tabular-nums">
                Hadir langsung: {summary.hadirOnlyRate}%
              </p>
            </div>

            <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span className="font-semibold">Ketidakhadiran</span>
                <AlertTriangle
                  className={`h-4 w-4 ${
                    summary.tb > 0 ? 'text-rose-600' : 'text-amber-500'
                  }`}
                />
              </div>
              <p
                className={`font-mono text-2xl sm:text-3xl font-extrabold tabular-nums ${
                  summary.tb > 0 ? 'text-rose-700' : 'text-slate-900'
                }`}
              >
                {summary.tidakHadir}
              </p>
              <div className="flex flex-wrap items-center gap-2 text-xs text-slate-600 font-mono tabular-nums">
                <span>I/C: <b>{summary.ic}</b></span>
                <span aria-hidden="true">·</span>
                <span>S: <b>{summary.s}</b></span>
                <span aria-hidden="true">·</span>
                <span className={summary.tb > 0 ? 'text-rose-700 font-bold' : ''}>
                  TB: <b>{summary.tb}</b>
                </span>
              </div>
              <p className="text-[11px] text-slate-500">
                {summary.tb > 0
                  ? `${summary.tb} catatan Tanpa Berita perlu pembinaan`
                  : 'Nihil catatan Tanpa Berita (TB)'}
              </p>
            </div>
          </div>

          {/* ================================================================= */}
          {/* 2. KURVA TREN KEHADIRAN + DIAGRAM KOMPOSISI (DONUT)               */}
          {/* ================================================================= */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
            {/* Curve Chart */}
            <div className="lg:col-span-8 bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                    <TrendingUp className="h-4 w-4 text-indigo-700" />
                    {mode === 'daily'
                      ? 'Kurva Tren Disiplin 14 Hari Terakhir'
                      : selectedMonth === 0
                      ? `Kurva Tren Kehadiran Bulanan (${selectedYear})`
                      : `Kurva Tren Kehadiran Harian (${INDONESIAN_MONTHS[selectedMonth - 1]} ${selectedYear})`}
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Perbandingan dinamika Hadir/Tugas Dinas, Izin/Sakit/Cuti, dan Tanpa Berita
                  </p>
                </div>
              </div>

              <div className="h-72 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart
                    data={trendData}
                    margin={{ top: 10, right: 12, left: -16, bottom: 0 }}
                  >
                    <defs>
                      <linearGradient id="gradHadir" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#16A34A" stopOpacity={0.28} />
                        <stop offset="95%" stopColor="#16A34A" stopOpacity={0.02} />
                      </linearGradient>
                      <linearGradient id="gradIzin" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#D97706" stopOpacity={0.25} />
                        <stop offset="95%" stopColor="#D97706" stopOpacity={0.02} />
                      </linearGradient>
                      <linearGradient id="gradTB" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#DC2626" stopOpacity={0.25} />
                        <stop offset="95%" stopColor="#DC2626" stopOpacity={0.02} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" vertical={false} />
                    <XAxis
                      dataKey="label"
                      tick={{ fontSize: 11, fill: '#64748B' }}
                      axisLine={{ stroke: '#CBD5E1' }}
                      tickLine={false}
                    />
                    <YAxis
                      allowDecimals={false}
                      tick={{ fontSize: 11, fill: '#64748B' }}
                      axisLine={false}
                      tickLine={false}
                    />
                    <Tooltip
                      contentStyle={{
                        borderRadius: '12px',
                        border: '1px solid #E2E8F0',
                        fontSize: '12px',
                        boxShadow: '0 10px 25px -5px rgba(15, 23, 42, 0.1)',
                      }}
                    />
                    <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                    <Area
                      type="monotone"
                      dataKey="hadirAktif"
                      name="Hadir & Tugas Dinas"
                      stroke="#16A34A"
                      strokeWidth={2.5}
                      fill="url(#gradHadir)"
                    />
                    <Area
                      type="monotone"
                      dataKey="izinSakitCuti"
                      name="Ijin / Sakit / Cuti"
                      stroke="#D97706"
                      strokeWidth={2}
                      fill="url(#gradIzin)"
                    />
                    <Area
                      type="monotone"
                      dataKey="tanpaBerita"
                      name="Tanpa Berita (TB)"
                      stroke="#DC2626"
                      strokeWidth={2}
                      fill="url(#gradTB)"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Donut Composition Diagram */}
            <div className="lg:col-span-4 bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 flex flex-col justify-between space-y-4">
              <div>
                <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <PieChartIcon className="h-4 w-4 text-indigo-700" />
                  Diagram Komposisi Kehadiran
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Proporsi status absensi pada periode aktif
                </p>
              </div>

              <div className="h-52 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={compositionData}
                      dataKey="value"
                      nameKey="name"
                      cx="50%"
                      cy="50%"
                      innerRadius={52}
                      outerRadius={80}
                      paddingAngle={2}
                    >
                      {compositionData.map((entry) => (
                        <Cell key={entry.name} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip
                      formatter={(val) => {
                        const num = Number(val ?? 0);
                        return [
                          `${num} catatan (${summary.total > 0 ? ((num / summary.total) * 100).toFixed(1) : '0.0'}%)`,
                          'Jumlah',
                        ];
                      }}
                      contentStyle={{
                        borderRadius: '10px',
                        border: '1px solid #E2E8F0',
                        fontSize: '12px',
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>

              <div className="space-y-2 pt-2 border-t border-slate-100 text-xs">
                {compositionData.map((item) => {
                  const pct = ((item.value / summary.total) * 100).toFixed(1);
                  return (
                    <div
                      key={item.name}
                      className="flex items-center justify-between gap-2"
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        <span
                          className="h-2.5 w-2.5 rounded-xs shrink-0"
                          style={{ backgroundColor: item.color }}
                        />
                        <span className="text-slate-700 truncate font-medium">
                          {item.name}
                        </span>
                      </div>
                      <span className="font-mono font-bold text-slate-900 tabular-nums shrink-0">
                        {item.value}{' '}
                        <span className="text-slate-400 font-normal">({pct}%)</span>
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* ================================================================= */}
          {/* 3. DIAGRAM BATANG: STATUS KEPEGAWAIAN & PERBANDINGAN PEGAWAI      */}
          {/* ================================================================= */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            {/* Bar Chart by Employment Status */}
            <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 space-y-4">
              <div>
                <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <BarChart3 className="h-4 w-4 text-indigo-700" />
                  Diagram Batang per Status Kepegawaian
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Distribusi catatan kehadiran berdasarkan kelompok ASN, PPPK, Honor/GTT, dan lainnya
                </p>
              </div>

              <div className="h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={byEmploymentStatusData}
                    margin={{ top: 8, right: 12, left: -16, bottom: 0 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" vertical={false} />
                    <XAxis
                      dataKey="status"
                      tick={{ fontSize: 11, fill: '#475569' }}
                      axisLine={{ stroke: '#CBD5E1' }}
                      tickLine={false}
                    />
                    <YAxis
                      allowDecimals={false}
                      tick={{ fontSize: 11, fill: '#64748B' }}
                      axisLine={false}
                      tickLine={false}
                    />
                    <Tooltip
                      contentStyle={{
                        borderRadius: '10px',
                        border: '1px solid #E2E8F0',
                        fontSize: '12px',
                      }}
                    />
                    <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '6px' }} />
                    <Bar
                      dataKey="Hadir"
                      stackId="a"
                      fill={CHART_COLORS.hadir}
                      radius={[0, 0, 0, 0]}
                    />
                    <Bar
                      dataKey="TugasDinas"
                      name="Tugas Dinas"
                      stackId="a"
                      fill={CHART_COLORS.tugasDinas}
                    />
                    <Bar
                      dataKey="IzinSakitCuti"
                      name="Izin/Sakit/Cuti"
                      stackId="a"
                      fill={CHART_COLORS.ijinCuti}
                    />
                    <Bar
                      dataKey="TanpaBerita"
                      name="Tanpa Berita"
                      stackId="a"
                      fill={CHART_COLORS.tanpaBerita}
                      radius={[4, 4, 0, 0]}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Horizontal Bar Chart: Discipline Rate per Employee */}
            <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 space-y-4">
              <div>
                <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <BarChart3 className="h-4 w-4 text-emerald-700" />
                  Diagram Tingkat Kedisiplinan per Pegawai (%)
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Persentase kehadiran efektif (Hadir + Tugas Dinas/Belajar) hingga 10 pegawai tercatat
                </p>
              </div>

              <div className="h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={employeeBarData}
                    layout="vertical"
                    margin={{ top: 4, right: 20, left: 10, bottom: 0 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" horizontal={false} />
                    <XAxis
                      type="number"
                      domain={[0, 100]}
                      tickFormatter={(v) => `${v}%`}
                      tick={{ fontSize: 11, fill: '#64748B' }}
                      axisLine={{ stroke: '#CBD5E1' }}
                      tickLine={false}
                    />
                    <YAxis
                      type="category"
                      dataKey="namaSingkat"
                      width={130}
                      tick={{ fontSize: 11, fill: '#334155' }}
                      axisLine={false}
                      tickLine={false}
                    />
                    <Tooltip
                      formatter={(value, _name, item) => {
                        const payload = (item as { payload?: { total?: number; namaLengkap?: string } })?.payload;
                        return [
                          `${Number(value ?? 0)}% (${payload?.total ?? 0} catatan)`,
                          payload?.namaLengkap || 'Disiplin',
                        ];
                      }}
                      contentStyle={{
                        borderRadius: '10px',
                        border: '1px solid #E2E8F0',
                        fontSize: '12px',
                      }}
                    />
                    <Bar
                      dataKey="disiplin"
                      name="Disiplin (%)"
                      fill="#1D4ED8"
                      radius={[0, 6, 6, 0]}
                      barSize={18}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          {/* ================================================================= */}
          {/* 4. TABEL STATISTIK RINCI PER GURU / PEGAWAI                       */}
          {/* ================================================================= */}
          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
            <div className="p-5 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h2 className="text-sm font-bold text-slate-900">
                  Tabel Statistik Kehadiran Rinci per Pegawai
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Menampilkan {filteredEmployeeStats.length} pegawai pada periode {periodLabel}
                </p>
              </div>
              <div className="relative w-full sm:w-72">
                <Search className="h-4 w-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Cari nama, NIP, atau jabatan..."
                  className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-300 text-xs focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none"
                />
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse min-w-[780px]">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-bold text-slate-600">
                    <th className="py-3 px-4 w-10 text-center">No</th>
                    <th className="py-3 px-4">Nama / NIP / Jabatan</th>
                    <th className="py-3 px-3">Status</th>
                    <th className="py-3 px-3 text-right">H</th>
                    <th className="py-3 px-3 text-right">TD/TS</th>
                    <th className="py-3 px-3 text-right">I/C</th>
                    <th className="py-3 px-3 text-right">S</th>
                    <th className="py-3 px-3 text-right">TB</th>
                    <th className="py-3 px-3 text-right">Total</th>
                    <th className="py-3 px-4 w-44">Disiplin &amp; Kategori</th>
                    <th className="py-3 px-4 text-right">Kartu</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-xs">
                  {filteredEmployeeStats.map((row, idx) => {
                    const tier = getDisciplineTier(row.disciplinePct, row.tb);
                    return (
                      <tr key={row.key} className="hover:bg-slate-50/80 transition">
                        <td className="py-3 px-4 text-center font-mono text-slate-500 tabular-nums">
                          {idx + 1}
                        </td>
                        <td className="py-3 px-4">
                          <div className="font-bold text-slate-900">{row.nama}</div>
                          <div className="text-[11px] text-slate-500 mt-0.5">
                            <span className="font-mono">{row.nip}</span>
                            {row.jabatan !== '-' ? ` · ${row.jabatan}` : ''}
                          </div>
                        </td>
                        <td className="py-3 px-3 font-medium text-slate-700 whitespace-nowrap">
                          {row.statusPegawai}
                        </td>
                        <td className="py-3 px-3 text-right font-mono font-bold text-emerald-700 tabular-nums">
                          {row.h}
                        </td>
                        <td className="py-3 px-3 text-right font-mono font-semibold text-indigo-700 tabular-nums">
                          {row.td}
                        </td>
                        <td className="py-3 px-3 text-right font-mono text-amber-700 tabular-nums">
                          {row.ic}
                        </td>
                        <td className="py-3 px-3 text-right font-mono text-orange-700 tabular-nums">
                          {row.s}
                        </td>
                        <td
                          className={`py-3 px-3 text-right font-mono tabular-nums ${
                            row.tb > 0
                              ? 'font-bold text-rose-700'
                              : 'text-slate-400'
                          }`}
                        >
                          {row.tb}
                        </td>
                        <td className="py-3 px-3 text-right font-mono font-bold text-slate-900 tabular-nums">
                          {row.total}
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex items-center justify-between gap-2 text-[11px] mb-1">
                            <span className="font-mono font-bold text-slate-900 tabular-nums">
                              {row.disciplinePct}%
                            </span>
                            <span className={`font-semibold ${tier.textClass}`}>
                              {tier.label}
                            </span>
                          </div>
                          <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                            <div
                              className={`h-full ${tier.barClass} rounded-full`}
                              style={{ width: `${Math.min(100, row.disciplinePct)}%` }}
                            />
                          </div>
                        </td>
                        <td className="py-3 px-4 text-right">
                          <button
                            type="button"
                            onClick={() => onSelectRecord(row.latestRecord)}
                            className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-indigo-50 hover:border-indigo-300 hover:text-indigo-700 text-slate-700 font-semibold text-[11px] transition cursor-pointer whitespace-nowrap"
                          >
                            <Eye className="h-3.5 w-3.5" />
                            Lihat
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
                <tfoot>
                  <tr className="bg-slate-50 border-t border-slate-200 font-bold text-xs text-slate-900">
                    <td colSpan={3} className="py-3 px-4">
                      Total Keseluruhan Periode
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums text-emerald-700">
                      {summary.h}
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums text-indigo-700">
                      {summary.td}
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums text-amber-700">
                      {summary.ic}
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums text-orange-700">
                      {summary.s}
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums text-rose-700">
                      {summary.tb}
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums">
                      {summary.total}
                    </td>
                    <td colSpan={2} className="py-3 px-4 font-mono tabular-nums">
                      Rata-rata Disiplin: {summary.disciplineRate}%
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>

          {/* ================================================================= */}
          {/* 5. REKAPAN SIMPULAN EKSEKUTIF PENGELOLAAN DISIPLIN                */}
          {/* ================================================================= */}
          <div className="bg-slate-900 text-slate-100 rounded-2xl p-6 sm:p-7 space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <ClipboardList className="h-5 w-5 text-indigo-400 shrink-0" />
                <div>
                  <h2 className="text-base font-bold text-white">
                    Rekapan Simpulan Eksekutif Pimpinan
                  </h2>
                  <p className="text-xs text-slate-400">
                    Ringkasan analitis pengelolaan disiplin lembaga · {periodLabel}
                  </p>
                </div>
              </div>
              <span className="font-mono text-xs font-semibold text-emerald-300 tabular-nums">
                Status: {executiveConclusions.overallRating}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              {/* Simpulan 1: Gambaran Umum */}
              <div className="p-4 rounded-xl bg-slate-800/70 border border-slate-700/80 space-y-2">
                <p className="text-xs font-bold text-indigo-300">
                  01. Gambaran Umum Kedisiplinan
                </p>
                <p className="text-xs text-slate-200 leading-relaxed">
                  Dari total{' '}
                  <strong className="font-mono text-white tabular-nums">
                    {summary.total}
                  </strong>{' '}
                  catatan absensi yang mencakup{' '}
                  <strong className="font-mono text-white tabular-nums">
                    {summary.uniquePeopleCount}
                  </strong>{' '}
                  guru/pegawai, tingkat kehadiran efektif mencapai{' '}
                  <strong className="font-mono text-emerald-300 tabular-nums">
                    {summary.disciplineRate}%
                  </strong>{' '}
                  ({summary.h} Hadir dan {summary.td} Tugas Dinas/Belajar).
                </p>
              </div>

              {/* Simpulan 2: Capaian Positif */}
              <div className="p-4 rounded-xl bg-slate-800/70 border border-slate-700/80 space-y-2">
                <p className="text-xs font-bold text-emerald-300">
                  02. Capaian Positif &amp; Konsistensi
                </p>
                <p className="text-xs text-slate-200 leading-relaxed">
                  Terdapat{' '}
                  <strong className="font-mono text-white tabular-nums">
                    {executiveConclusions.perfectEmployees.length}
                  </strong>{' '}
                  pegawai dengan catatan kehadiran 100% pada periode ini.
                  {executiveConclusions.topStatusGroup && (
                    <>
                      {' '}
                      Kelompok status kepegawaian tertinggi adalah{' '}
                      <strong className="text-white">
                        {executiveConclusions.topStatusGroup.status}
                      </strong>{' '}
                      (<span className="font-mono tabular-nums">{executiveConclusions.topStatusGroup.rate}%</span>).
                    </>
                  )}
                </p>
              </div>

              {/* Simpulan 3: Fokus Perhatian & Pembinaan */}
              <div className="p-4 rounded-xl bg-slate-800/70 border border-slate-700/80 space-y-2">
                <p className="text-xs font-bold text-amber-300">
                  03. Perhatian &amp; Tindak Lanjut Pembinaan
                </p>
                <p className="text-xs text-slate-200 leading-relaxed">
                  {executiveConclusions.attentionEmployees.length > 0 ? (
                    <>
                      Terdapat{' '}
                      <strong className="font-mono text-rose-300 tabular-nums">
                        {executiveConclusions.attentionEmployees.length}
                      </strong>{' '}
                      pegawai yang memerlukan perhatian/pembinaan (
                      {executiveConclusions.attentionEmployees
                        .slice(0, 3)
                        .map((e) => e.nama)
                        .join(', ')}
                      {executiveConclusions.attentionEmployees.length > 3
                        ? `, +${executiveConclusions.attentionEmployees.length - 3} lainnya`
                        : ''}
                      ).
                    </>
                  ) : (
                    'Tidak ditemukan catatan Tanpa Berita (TB) maupun pegawai di bawah ambang disiplin 80% pada periode ini.'
                  )}
                </p>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800 text-xs text-slate-300 leading-relaxed">
              <strong className="text-white">Rekomendasi Pimpinan:</strong>{' '}
              {executiveConclusions.recommendation}
            </div>
          </div>
        </>
      )}
    </div>
  );
};
