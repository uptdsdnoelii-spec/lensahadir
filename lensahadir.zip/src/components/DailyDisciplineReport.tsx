import React, { useState, useRef } from 'react';
import {
  Plus,
  Upload,
  Trash2,
  ArrowUp,
  ArrowDown,
  Settings,
  Printer,
  Download,
  FileSpreadsheet,
  Eye,
  Edit3,
  Calendar,
  Building2,
  History,
  CheckCircle2,
  RotateCcw,
  Images,
  ListOrdered,
  FileCheck2,
  FileDown,
  X,
  HardDrive,
  Link2,
  Calculator,
} from 'lucide-react';
import {
  AdminSubmissionRecord,
  AppSettings,
  AttendanceRecord,
  DailyReportCardItem,
  DailyReportFooterSummary,
} from '../types/attendance';
import { renderAttendanceCardToBlob, triggerBrowserDownload } from '../utils/cardCanvasRenderer';
import {
  formatIndonesianFullDate,
  formatIndonesianShortDate,
  paginateReportItems,
  renderDailyReportPageToBlob,
  renderDailyReportToPdfBlob,
  trimCardImageToTable,
} from '../utils/dailyReportCanvasRenderer';
import { ADMIN_GOOGLE_DRIVE_FOLDER_URL, SaveToDriveModal } from './SaveToDriveModal';

const FOOTER_STORAGE_KEY = 'lensahadir_daily_report_footer_v1';

const EMPTY_FOOTER_SUMMARY: DailyReportFooterSummary = {
  driveLink: '',
  jumlahGuruPegawai: '',
  hadir: '',
  ijin: '',
  sakit: '',
  cuti: '',
  tugasDinas: '',
  tugasBelajar: '',
  tanpaBerita: '',
};

const loadStoredFooterSummary = (): DailyReportFooterSummary => {
  try {
    const raw = localStorage.getItem(FOOTER_STORAGE_KEY);
    if (!raw) return EMPTY_FOOTER_SUMMARY;
    const parsed = JSON.parse(raw);
    return { ...EMPTY_FOOTER_SUMMARY, ...parsed };
  } catch {
    return EMPTY_FOOTER_SUMMARY;
  }
};

interface DailyDisciplineReportProps {
  settings: AppSettings;
  records: AttendanceRecord[];
  adminSubmissions?: AdminSubmissionRecord[];
  items: DailyReportCardItem[];
  setItems: React.Dispatch<React.SetStateAction<DailyReportCardItem[]>>;
  reportDate: string;
  setReportDate: React.Dispatch<React.SetStateAction<string>>;
  onOpenSettings: () => void;
  showToast: (msg: string) => void;
}

export const DailyDisciplineReport: React.FC<DailyDisciplineReportProps> = ({
  settings,
  records,
  adminSubmissions = [],
  items,
  setItems,
  reportDate,
  setReportDate,
  onOpenSettings,
  showToast,
}) => {
  const [activeTab, setActiveTab] = useState<'editor' | 'preview'>('editor');
  const [isExportingPdf, setIsExportingPdf] = useState(false);
  const [isExportingPng, setIsExportingPng] = useState(false);
  const [isSavingDrive, setIsSavingDrive] = useState(false);
  const [driveModalInfo, setDriveModalInfo] = useState<{ filename: string } | null>(null);
  const [exportingPageNum, setExportingPageNum] = useState<number | null>(null);
  const [confirmReset, setConfirmReset] = useState(false);
  const [historyPickerItemId, setHistoryPickerItemId] = useState<string | null>(null);
  const [isImportingHistory, setIsImportingHistory] = useState(false);
  const [downloadPreview, setDownloadPreview] = useState<{ url: string; filename: string } | null>(
    null
  );
  const [footerSummary, setFooterSummary] = useState<DailyReportFooterSummary>(() =>
    loadStoredFooterSummary()
  );

  const updateFooterSummary = (patch: Partial<DailyReportFooterSummary>) => {
    setFooterSummary((prev) => {
      const next = { ...prev, ...patch };
      try {
        localStorage.setItem(FOOTER_STORAGE_KEY, JSON.stringify(next));
      } catch {
        // ignore storage quota
      }
      return next;
    });
  };

  const handleAutoCalculateDailyRecap = () => {
    const dedupMap = new Map<string, string>();
    for (const r of records) {
      if (r.tanggal === reportDate && r.nama?.trim()) {
        dedupMap.set(r.nama.trim().toLowerCase(), r.statusKehadiran);
      }
    }
    for (const s of adminSubmissions) {
      if (s.tanggal === reportDate && s.nama?.trim()) {
        dedupMap.set(s.nama.trim().toLowerCase(), s.statusKehadiran);
      }
    }

    if (dedupMap.size === 0) {
      showToast(`Belum ada catatan Riwayat pada tanggal ${formatIndonesianShortDate(reportDate)}`);
      return;
    }

    let hadir = 0;
    let ijin = 0;
    let sakit = 0;
    let cuti = 0;
    let tugasDinas = 0;
    let tugasBelajar = 0;
    let tanpaBerita = 0;

    dedupMap.forEach((status) => {
      if (status === 'Hadir (H)') hadir++;
      else if (status === 'Ijin (I)') ijin++;
      else if (status === 'Sakit (S)') sakit++;
      else if (status === 'Cuti (C)') cuti++;
      else if (status === 'Tugas Dinas (TD)') tugasDinas++;
      else if (status === 'Tugas Belajar (TS)') tugasBelajar++;
      else if (status === 'Tanpa Berita (TB)') tanpaBerita++;
    });

    updateFooterSummary({
      jumlahGuruPegawai: String(dedupMap.size),
      hadir: String(hadir),
      ijin: String(ijin),
      sakit: String(sakit),
      cuti: String(cuti),
      tugasDinas: String(tugasDinas),
      tugasBelajar: String(tugasBelajar),
      tanpaBerita: String(tanpaBerita),
    });

    showToast(
      `Rekap Absensi Harian terisi otomatis (${dedupMap.size} pegawai pada ${formatIndonesianShortDate(reportDate)})`
    );
  };

  const handleSumManualRecapTotal = () => {
    const toNum = (v: string) => {
      const n = parseInt(v, 10);
      return Number.isNaN(n) || n < 0 ? 0 : n;
    };
    const total =
      toNum(footerSummary.hadir) +
      toNum(footerSummary.ijin) +
      toNum(footerSummary.sakit) +
      toNum(footerSummary.cuti) +
      toNum(footerSummary.tugasDinas) +
      toNum(footerSummary.tugasBelajar) +
      toNum(footerSummary.tanpaBerita);
    updateFooterSummary({ jumlahGuruPegawai: String(total) });
    showToast(`Jumlah Guru/Pegawai dihitung otomatis: ${total} Orang`);
  };

  const batchInputRef = useRef<HTMLInputElement>(null);

  const uploadedItems = items.filter((it) => Boolean(it.imageUrl));
  const pages = paginateReportItems(items);

  // Compute next sequence number automatically
  const getNextOrderNumber = (currentItems: DailyReportCardItem[]): number => {
    if (currentItems.length === 0) return 1;
    const maxNum = currentItems.reduce(
      (max, it) => (Number.isFinite(it.orderNumber) && it.orderNumber > max ? it.orderNumber : max),
      0
    );
    return maxNum + 1;
  };

  // Add a new empty upload slot ("Tambah Kartu Laporan Harian")
  const handleAddCardSlot = () => {
    const nextOrder = getNextOrderNumber(items);
    const newItem: DailyReportCardItem = {
      id: `card_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      orderNumber: nextOrder,
      imageUrl: '',
    };
    setItems((prev) => [...prev, newItem]);
    showToast(`Kotak Upload Kartu Laporan Harian No. ${nextOrder} ditambahkan`);
  };

  // Handle single card image upload (with automatic table crop so it fits cleanly 3 per A4 page)
  const handleSingleFileUpload = (
    e: React.ChangeEvent<HTMLInputElement>,
    itemId: string
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (ev) => {
      const rawDataUrl = ev.target?.result as string;
      const trimmedUrl = await trimCardImageToTable(rawDataUrl);
      setItems((prev) =>
        prev.map((it) =>
          it.id === itemId ? { ...it, imageUrl: trimmedUrl, fileName: file.name } : it
        )
      );
      showToast(`Kartu "${file.name}" berhasil diunggah`);
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  // Handle batch multi-file upload
  const handleBatchUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []) as File[];
    if (files.length === 0) return;

    const readPromises = files.map(
      (file) =>
        new Promise<{ url: string; name: string }>((resolve) => {
          const reader = new FileReader();
          reader.onload = async (ev) => {
            const raw = (ev.target?.result as string) || '';
            const trimmed = raw ? await trimCardImageToTable(raw) : '';
            resolve({ url: trimmed, name: file.name });
          };
          reader.onerror = () => resolve({ url: '', name: file.name });
          reader.readAsDataURL(file);
        })
    );

    Promise.all(readPromises).then((results) => {
      const valid = results.filter((r) => Boolean(r.url));
      if (valid.length === 0) return;

      setItems((prev) => {
        const updated = [...prev];
        let fileIdx = 0;

        // Fill empty existing slots first
        for (let i = 0; i < updated.length && fileIdx < valid.length; i++) {
          if (!updated[i].imageUrl) {
            updated[i] = {
              ...updated[i],
              imageUrl: valid[fileIdx].url,
              fileName: valid[fileIdx].name,
            };
            fileIdx++;
          }
        }

        // Append remaining files with auto-incremented numbers
        let nextOrder = getNextOrderNumber(updated);
        while (fileIdx < valid.length) {
          updated.push({
            id: `card_${Date.now()}_${fileIdx}_${Math.random().toString(36).slice(2, 6)}`,
            orderNumber: nextOrder++,
            imageUrl: valid[fileIdx].url,
            fileName: valid[fileIdx].name,
          });
          fileIdx++;
        }
        return updated;
      });

      showToast(`${valid.length} Kartu Laporan Harian berhasil diunggah`);
    });

    e.target.value = '';
  };

  // Import a card directly from LensaHadir History (auto-trimmed to clean table bounds)
  const handleImportFromHistory = async (record: AttendanceRecord) => {
    if (!historyPickerItemId) return;
    setIsImportingHistory(true);
    try {
      const blob = await renderAttendanceCardToBlob(record, settings);
      if (!blob) {
        showToast('Gagal merender kartu dari riwayat');
        return;
      }
      const rawDataUrl = await new Promise<string>((resolve) => {
        const reader = new FileReader();
        reader.onload = () => resolve((reader.result as string) || '');
        reader.readAsDataURL(blob);
      });
      const trimmedUrl = await trimCardImageToTable(rawDataUrl);

      setItems((prev) =>
        prev.map((it) =>
          it.id === historyPickerItemId
            ? {
                ...it,
                imageUrl: trimmedUrl,
                fileName: `${record.nama} (${record.tanggal})`,
              }
            : it
        )
      );
      setHistoryPickerItemId(null);
      showToast(`Kartu "${record.nama}" berhasil dimasukkan dari Riwayat`);
    } catch (err) {
      console.error(err);
      showToast('Gagal mengambil kartu dari riwayat');
    } finally {
      setIsImportingHistory(false);
    }
  };

  // Update order number for a specific slot
  const handleChangeOrderNumber = (itemId: string, rawVal: string) => {
    const parsed = parseInt(rawVal, 10);
    setItems((prev) =>
      prev.map((it) =>
        it.id === itemId
          ? { ...it, orderNumber: Number.isNaN(parsed) || parsed < 1 ? 1 : parsed }
          : it
      )
    );
  };

  // Re-number sequentially 1, 2, 3...
  const handleAutoRenumber = () => {
    setItems((prev) => prev.map((it, idx) => ({ ...it, orderNumber: idx + 1 })));
    showToast('Nomor urut telah dirapikan secara berurutan (1, 2, 3, ...)');
  };

  // Move card up/down in list
  const handleMoveItem = (index: number, direction: 'up' | 'down') => {
    const targetIdx = direction === 'up' ? index - 1 : index + 1;
    if (targetIdx < 0 || targetIdx >= items.length) return;
    setItems((prev) => {
      const copy = [...prev];
      const temp = copy[index];
      copy[index] = copy[targetIdx];
      copy[targetIdx] = temp;
      return copy.map((it, idx) => ({ ...it, orderNumber: idx + 1 }));
    });
  };

  // Remove a slot
  const handleRemoveItem = (itemId: string) => {
    setItems((prev) => {
      if (prev.length <= 1) {
        return [{ id: `card_${Date.now()}`, orderNumber: 1, imageUrl: '' }];
      }
      return prev
        .filter((it) => it.id !== itemId)
        .map((it, idx) => ({ ...it, orderNumber: idx + 1 }));
    });
    showToast('Kotak Kartu Laporan Harian dihapus');
  };

  // Reset entire daily report
  const handleConfirmReset = () => {
    setItems([{ id: `card_${Date.now()}`, orderNumber: 1, imageUrl: '' }]);
    setReportDate(new Date().toISOString().split('T')[0]);
    setFooterSummary(EMPTY_FOOTER_SUMMARY);
    try {
      localStorage.removeItem(FOOTER_STORAGE_KEY);
    } catch {
      // ignore
    }
    setConfirmReset(false);
    setActiveTab('editor');
    showToast('Rekapan Laporan Disiplin berhasil direset');
  };

  // Download full multi-page A4 PDF directly to PC Downloads folder
  const handleDownloadA4Pdf = async (): Promise<string | null> => {
    if (uploadedItems.length === 0) {
      showToast('Unggah minimal 1 Kartu Laporan Harian terlebih dahulu');
      return null;
    }
    setIsExportingPdf(true);
    try {
      const pdfBlob = await renderDailyReportToPdfBlob(
        pages,
        reportDate,
        settings,
        footerSummary
      );
      if (pdfBlob) {
        const filename = `LAPORAN_DISIPLIN_JAM_KERJA_HARIAN_${reportDate || 'TANGGAL'}.pdf`;
        triggerBrowserDownload(pdfBlob, filename);
        showToast(`PDF A4 (${pages.length} Halaman) berhasil diunduh: ${filename}`);
        return filename;
      } else {
        showToast('Gagal menghasilkan file PDF A4');
        return null;
      }
    } catch (err) {
      console.error(err);
      showToast('Terjadi kesalahan saat membuat PDF A4');
      return null;
    } finally {
      setIsExportingPdf(false);
    }
  };

  // Download PDF A4 and open target Google Drive folder modal
  const handleSaveToDrive = async () => {
    if (uploadedItems.length === 0) {
      showToast('Unggah minimal 1 Kartu Laporan Harian terlebih dahulu');
      return;
    }
    setIsSavingDrive(true);
    try {
      const filename = await handleDownloadA4Pdf();
      if (filename) {
        setDriveModalInfo({ filename });
      }
    } finally {
      setIsSavingDrive(false);
    }
  };

  // Download single A4 page as PNG
  const handleDownloadSinglePagePng = async (pageIndex: number) => {
    const page = pages[pageIndex];
    if (!page) return;
    setExportingPageNum(page.pageNumber);
    try {
      const blob = await renderDailyReportPageToBlob(page, reportDate, settings, footerSummary);
      if (blob) {
        const filename = `LAPORAN_DISIPLIN_HARIAN_${reportDate || 'TANGGAL'}_HAL_${page.pageNumber}.png`;
        triggerBrowserDownload(blob, filename);
        const previewUrl = URL.createObjectURL(blob);
        setDownloadPreview({ url: previewUrl, filename });
        showToast(`Halaman ${page.pageNumber} berhasil diunduh: ${filename}`);
      } else {
        showToast('Gagal menghasilkan gambar halaman A4');
      }
    } catch (err) {
      console.error(err);
      showToast('Terjadi kesalahan saat mengunduh PNG');
    } finally {
      setExportingPageNum(null);
    }
  };

  // Download all A4 pages as PNG files sequentially
  const handleDownloadAllPagesPng = async () => {
    if (uploadedItems.length === 0) {
      showToast('Unggah minimal 1 Kartu Laporan Harian terlebih dahulu');
      return;
    }
    setIsExportingPng(true);
    try {
      let lastBlobUrl = '';
      let lastFilename = '';
      for (let i = 0; i < pages.length; i++) {
        const page = pages[i];
        const blob = await renderDailyReportPageToBlob(page, reportDate, settings, footerSummary);
        if (blob) {
          const filename = `LAPORAN_DISIPLIN_HARIAN_${reportDate || 'TANGGAL'}_HAL_${page.pageNumber}.png`;
          triggerBrowserDownload(blob, filename);
          lastBlobUrl = URL.createObjectURL(blob);
          lastFilename = filename;
          if (i < pages.length - 1) {
            await new Promise((r) => setTimeout(r, 450));
          }
        }
      }
      if (pages.length === 1 && lastBlobUrl) {
        setDownloadPreview({ url: lastBlobUrl, filename: lastFilename });
      }
      showToast(
        `${pages.length} halaman A4 Laporan Disiplin berhasil diunduh ke folder Unduhan`
      );
    } catch (err) {
      console.error(err);
      showToast('Gagal mengunduh seluruh halaman PNG');
    } finally {
      setIsExportingPng(false);
    }
  };

  const handlePrintA4 = () => {
    if (uploadedItems.length === 0) {
      showToast('Unggah minimal 1 Kartu Laporan Harian sebelum mencetak');
      return;
    }
    window.print();
  };

  const handleGoToPreview = () => {
    if (uploadedItems.length === 0) {
      showToast('Unggah minimal 1 Kartu Laporan Harian terlebih dahulu');
      return;
    }
    setActiveTab('preview');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Header Banner & Mode Tabs (Hidden on Print) */}
      <div className="no-print bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="bg-gradient-to-r from-[#1f4e79] via-[#2e75b6] to-indigo-800 px-5 py-4 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-white/15 rounded-xl shrink-0">
              <FileSpreadsheet className="h-5 w-5 text-white" />
            </div>
            <div>
              <h1 className="text-base sm:text-lg font-black uppercase tracking-tight">
                Laporan Disiplin Jam Kerja Harian
              </h1>
              <p className="text-xs text-blue-100">
                Format Resmi A4 PDF — 3 Kartu per Halaman, Dilanjutkan Otomatis Sesuai Jumlah Guru/Pegawai
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={onOpenSettings}
              className="bg-white/15 hover:bg-white/25 text-white px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition"
            >
              <Settings className="h-3.5 w-3.5" />
              Atur Kop Instansi
            </button>
          </div>
        </div>

        {/* Sub-navigation Tabs */}
        <div className="px-5 py-3 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setActiveTab('editor')}
              className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition ${
                activeTab === 'editor'
                  ? 'bg-[#2e75b6] text-white shadow-sm'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              <Edit3 className="h-3.5 w-3.5" />
              1. Pengaturan &amp; Upload Kartu ({uploadedItems.length})
            </button>

            <button
              type="button"
              onClick={handleGoToPreview}
              className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition ${
                activeTab === 'preview'
                  ? 'bg-[#2e75b6] text-white shadow-sm'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              <Eye className="h-3.5 w-3.5" />
              2. Pratinjau Lembar A4 ({pages.length} Halaman)
            </button>
          </div>

          <div className="text-xs text-slate-500 font-medium flex items-center gap-3">
            <span>
              Total Guru/Pegawai:{' '}
              <strong className="text-slate-800">{uploadedItems.length}</strong>
            </span>
            <span className="text-slate-300">|</span>
            <span>
              Susunan A4:{' '}
              <strong className="text-[#2e75b6]">
                3 Kartu/Hal ({pages.length} Lembar)
              </strong>
            </span>
          </div>
        </div>
      </div>

      {/* ================================================================= */}
      {/* TAB 1: PENGATURAN & UPLOAD KARTU LAPORAN HARIAN                   */}
      {/* ================================================================= */}
      {activeTab === 'editor' && (
        <div className="no-print space-y-6">
          {/* Bagian 1 & 2: Nama Satuan Pendidikan (Otomatis dari Kop Instansi) & Hari / Tanggal */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5 sm:p-6 space-y-5">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h2 className="text-sm font-black text-slate-900 uppercase tracking-wider flex items-center gap-2">
                <Building2 className="h-4 w-4 text-[#2e75b6]" />
                Identitas Laporan &amp; Kop Instansi
              </h2>
              <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-1 rounded-lg flex items-center gap-1">
                <CheckCircle2 className="h-3 w-3" />
                Tersinkron dengan Kop Instansi
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {/* 1. Kotak Isian 'Nama Satuan Pendidikan' (otomatis dari Kop Instansi) */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 flex items-center justify-between">
                  <span>1. Nama Satuan Pendidikan</span>
                  <button
                    type="button"
                    onClick={onOpenSettings}
                    className="text-[11px] font-bold text-[#2e75b6] hover:underline flex items-center gap-1"
                  >
                    <Settings className="h-3 w-3" />
                    Ubah di Kop Instansi
                  </button>
                </label>
                <input
                  type="text"
                  readOnly
                  value={settings.subInstansi || ''}
                  placeholder="Akan terisi otomatis sesuai pengaturan di Kop Instansi"
                  className="block w-full rounded-xl border border-slate-300 bg-slate-50 p-3 text-sm font-bold text-slate-800 cursor-default focus:outline-none"
                />
                <p className="text-[11px] text-slate-500">
                  Terisi otomatis dari pengaturan <b>Kop Instansi</b>. Kop surat &amp; tanda tangan{' '}
                  <b>{settings.jabatanPimpinan || 'Kepala Sekolah'}</b> ({settings.namaPimpinan || '-'}) juga mengikuti data Kop Instansi.
                </p>
              </div>

              {/* 2. Hari / Tanggal */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                  <Calendar className="h-3.5 w-3.5 text-[#2e75b6]" />
                  2. Hari / Tanggal
                </label>
                <input
                  type="date"
                  value={reportDate}
                  onChange={(e) => setReportDate(e.target.value)}
                  className="block w-full rounded-xl border border-slate-300 bg-white p-3 text-sm font-bold text-slate-900 focus:border-[#2e75b6] focus:ring-1 focus:ring-[#2e75b6] outline-none"
                />
                <p className="text-[11px] text-slate-500">
                  Tampilan pada laporan A4:{' '}
                  <strong className="text-slate-800">
                    {formatIndonesianFullDate(reportDate)}
                  </strong>
                </p>
              </div>
            </div>
          </div>

          {/* Bagian 3, 4, 5: Daftar Upload "Kartu Laporan Harian" + Nomor Urut Biru */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5 sm:p-6 space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
              <div>
                <h2 className="text-sm font-black text-slate-900 uppercase tracking-wider flex items-center gap-2">
                  <Images className="h-4 w-4 text-[#2e75b6]" />
                  3. Upload &quot;Kartu Laporan Harian&quot; (3 Kartu per Halaman A4)
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Unggah Kartu Laporan Harian masing-masing guru/pegawai. Kotak biru nomor urut otomatis tampil di sudut kiri atas tabel sesuai format PDF.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2 shrink-0">
                {items.length > 1 && (
                  <button
                    type="button"
                    onClick={handleAutoRenumber}
                    className="px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700 text-xs font-bold flex items-center gap-1.5 transition"
                    title="Urutkan ulang nomor menjadi 1, 2, 3, ..."
                  >
                    <ListOrdered className="h-3.5 w-3.5 text-[#2e75b6]" />
                    Urutkan Nomor
                  </button>
                )}

                <input
                  ref={batchInputRef}
                  type="file"
                  accept="image/*"
                  multiple
                  onChange={handleBatchUpload}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => batchInputRef.current?.click()}
                  className="px-3.5 py-2 rounded-xl border border-[#2e75b6]/30 bg-[#5b9bd5]/10 hover:bg-[#5b9bd5]/20 text-[#1f4e79] text-xs font-bold flex items-center gap-1.5 transition"
                >
                  <Upload className="h-3.5 w-3.5" />
                  Upload Banyak Sekaligus
                </button>
              </div>
            </div>

            {/* List of Upload Boxes */}
            <div className="space-y-5">
              {items.map((item, idx) => (
                <div
                  key={item.id}
                  className="rounded-2xl border border-slate-200 bg-slate-50/70 p-4 sm:p-5 space-y-4 transition hover:border-[#5b9bd5]/60"
                >
                  {/* Row Control Header */}
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      {/* Preview of the exact White-Bordered Blue Number Box (#5b9bd5) */}
                      <div
                        className="w-10 h-8 bg-[#5b9bd5] border-2 border-white ring-1 ring-[#2e75b6] text-white font-serif font-bold text-base flex items-center justify-center shadow-xs shrink-0 select-none"
                        title="Pratinjau Kotak Nomor Urut Biru"
                      >
                        {item.orderNumber}
                      </div>
                      <div className="flex items-center gap-2">
                        <label className="text-xs font-bold text-slate-700">No. Urut:</label>
                        <input
                          type="number"
                          min={1}
                          value={item.orderNumber}
                          onChange={(e) => handleChangeOrderNumber(item.id, e.target.value)}
                          className="w-16 rounded-lg border border-slate-300 bg-white px-2.5 py-1 text-sm font-bold text-slate-900 text-center focus:border-[#2e75b6] focus:ring-1 focus:ring-[#2e75b6] outline-none"
                        />
                      </div>
                      <span className="text-[11px] font-semibold text-slate-500 bg-white border border-slate-200 px-2 py-0.5 rounded-md">
                        Hal. {Math.floor(idx / 3) + 1}
                      </span>
                      {item.fileName && (
                        <span className="hidden sm:inline-block text-xs text-slate-500 font-medium truncate max-w-[220px]">
                          {item.fileName}
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-1.5">
                      {records.length > 0 && (
                        <button
                          type="button"
                          onClick={() => setHistoryPickerItemId(item.id)}
                          className="px-2.5 py-1.5 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs font-bold flex items-center gap-1 transition"
                          title="Ambil kartu langsung dari Riwayat LensaHadir"
                        >
                          <History className="h-3.5 w-3.5" />
                          Ambil dari Riwayat
                        </button>
                      )}

                      <button
                        type="button"
                        disabled={idx === 0}
                        onClick={() => handleMoveItem(idx, 'up')}
                        className="p-1.5 rounded-lg border border-slate-200 bg-white text-slate-600 hover:bg-slate-100 disabled:opacity-30 transition"
                        title="Pindah ke atas"
                      >
                        <ArrowUp className="h-3.5 w-3.5" />
                      </button>

                      <button
                        type="button"
                        disabled={idx === items.length - 1}
                        onClick={() => handleMoveItem(idx, 'down')}
                        className="p-1.5 rounded-lg border border-slate-200 bg-white text-slate-600 hover:bg-slate-100 disabled:opacity-30 transition"
                        title="Pindah ke bawah"
                      >
                        <ArrowDown className="h-3.5 w-3.5" />
                      </button>

                      <button
                        type="button"
                        onClick={() => handleRemoveItem(item.id)}
                        className="p-1.5 rounded-lg border border-rose-200 bg-rose-50 text-rose-600 hover:bg-rose-100 transition"
                        title="Hapus kotak kartu ini"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Upload Box or Uploaded Card Preview with Top-Left Blue Number Box inside table header */}
                  {!item.imageUrl ? (
                    <label className="flex flex-col items-center justify-center rounded-xl border-2 border-dashed border-slate-300 hover:border-[#2e75b6] bg-white px-6 py-8 cursor-pointer transition group">
                      <div className="p-3 rounded-xl bg-[#5b9bd5]/10 text-[#2e75b6] mb-2.5 group-hover:scale-105 transition-transform">
                        <Upload className="h-6 w-6" />
                      </div>
                      <p className="text-sm font-bold text-slate-800">
                        Klik untuk Upload &quot;Kartu Laporan Harian&quot; (No. {item.orderNumber})
                      </p>
                      <p className="text-xs text-slate-500 mt-1">
                        Format PNG / JPG hasil cetak kartu LensaHadir (Landscape)
                      </p>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={(e) => handleSingleFileUpload(e, item.id)}
                        className="hidden"
                      />
                    </label>
                  ) : (
                    <div className="bg-white rounded-xl border border-slate-200 p-4 space-y-2.5">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-[11px] font-semibold text-slate-500">
                          Pratinjau Kartu (Kotak biru nomor urut otomatis terpasang di sudut kiri atas tabel)
                        </span>
                        <label className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold flex items-center gap-1.5 cursor-pointer transition shrink-0">
                          <Upload className="h-3.5 w-3.5" />
                          Ganti Gambar
                          <input
                            type="file"
                            accept="image/*"
                            onChange={(e) => handleSingleFileUpload(e, item.id)}
                            className="hidden"
                          />
                        </label>
                      </div>
                      <div className="flex justify-center">
                        <div className="relative inline-block max-w-full">
                          <img
                            src={item.imageUrl}
                            alt={`Kartu Laporan Harian No. ${item.orderNumber}`}
                            className="block max-h-[300px] w-auto max-w-full object-contain"
                          />
                          {/* Exact white-bordered blue number badge tucked inside top-left header */}
                          <div
                            className="absolute bg-[#5b9bd5] border-[1.5px] border-white text-white font-serif font-bold flex items-center justify-center select-none pointer-events-none"
                            style={{
                              left: '0.8%',
                              top: '2%',
                              width: '5.8%',
                              height: '13.5%',
                              fontSize: 'clamp(11px, 1.5vw, 18px)',
                            }}
                          >
                            {item.orderNumber}
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* 4. Tombol Tambah "Kartu Laporan Harian" */}
            <div className="pt-2">
              <button
                type="button"
                onClick={handleAddCardSlot}
                className="w-full py-3.5 px-5 rounded-xl border-2 border-dashed border-[#2e75b6] bg-[#5b9bd5]/10 hover:bg-[#5b9bd5]/20 text-[#1f4e79] font-black text-sm flex items-center justify-center gap-2 transition"
              >
                <Plus className="h-5 w-5" />
                Tambah &quot;Kartu Laporan Harian&quot; (No. {getNextOrderNumber(items)})
              </button>
            </div>
          </div>

          {/* Bagian 4: Isian Link Google Drive & Rekap Absensi Harian (Sisi Kiri Bawah Tabel) */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5 sm:p-6 space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
              <div>
                <h2 className="text-sm font-black text-slate-900 uppercase tracking-wider flex items-center gap-2">
                  <Link2 className="h-4 w-4 text-[#2e75b6]" />
                  4. Link Google Drive &amp; Rekap Absensi Harian (Sisi Kiri Bawah Tabel)
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Akan ditampilkan rapi pada bagian kiri bawah tabel tepat di samping tanda tangan Kepala Sekolah (Halaman Terakhir A4).
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={handleAutoCalculateDailyRecap}
                  className="px-3.5 py-2 rounded-xl border border-indigo-200 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs font-bold flex items-center gap-1.5 transition"
                >
                  <Calculator className="h-3.5 w-3.5" />
                  Hitung Otomatis dari Riwayat
                </button>
              </div>
            </div>

            {/* Link Google Drive Input */}
            <div className="space-y-1.5">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <label className="text-xs font-bold text-slate-700">
                  Link Google Drive
                </label>
                <button
                  type="button"
                  onClick={() => updateFooterSummary({ driveLink: ADMIN_GOOGLE_DRIVE_FOLDER_URL })}
                  className="text-[11px] font-bold text-emerald-700 hover:text-emerald-800 hover:underline flex items-center gap-1"
                >
                  <HardDrive className="h-3 w-3" />
                  Gunakan Link Folder Drive Instansi
                </button>
              </div>
              <input
                type="url"
                value={footerSummary.driveLink}
                onChange={(e) => updateFooterSummary({ driveLink: e.target.value })}
                placeholder="Tempelkan link Google Drive arsip dokumentasi/absensi (kosongkan untuk garis titik-titik)"
                className="block w-full rounded-xl border border-slate-300 bg-white p-3 text-xs sm:text-sm font-medium text-slate-900 focus:border-[#2e75b6] focus:ring-1 focus:ring-[#2e75b6] outline-none"
              />
            </div>

            {/* Rekap Absensi Harian Grid */}
            <div className="space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="text-xs font-bold text-slate-700 uppercase tracking-wide">
                  Rekap Absensi Harian (Satuan: Orang)
                </span>
                <button
                  type="button"
                  onClick={handleSumManualRecapTotal}
                  className="text-[11px] font-bold text-[#2e75b6] hover:underline"
                >
                  Jumlahkan Total Guru/Pegawai Otomatis
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                {[
                  { key: 'jumlahGuruPegawai', label: 'Jumlah Guru/Pegawai' },
                  { key: 'hadir', label: 'Jumlah Hadir (H)' },
                  { key: 'ijin', label: 'Jumlah Ijin (I)' },
                  { key: 'sakit', label: 'Jumlah Sakit (S)' },
                  { key: 'cuti', label: 'Jumlah Cuti (C)' },
                  { key: 'tugasDinas', label: 'Jumlah Tugas Dinas (TD)' },
                  { key: 'tugasBelajar', label: 'Jlh Tugas Belajar (TS)' },
                  { key: 'tanpaBerita', label: 'Jlh Tanpa Berita (TB)' },
                ].map((field) => (
                  <div
                    key={field.key}
                    className="rounded-xl border border-slate-200 bg-slate-50/70 p-3 space-y-1.5"
                  >
                    <label className="block text-[11px] font-bold text-slate-700">
                      {field.label}
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="number"
                        min={0}
                        value={footerSummary[field.key as keyof DailyReportFooterSummary]}
                        onChange={(e) =>
                          updateFooterSummary({ [field.key]: e.target.value })
                        }
                        placeholder="......"
                        className="w-full rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-sm font-bold text-slate-900 focus:border-[#2e75b6] outline-none"
                      />
                      <span className="text-xs font-semibold text-slate-500 shrink-0">Orang</span>
                    </div>
                  </div>
                ))}
              </div>
              <p className="text-[11px] text-slate-500">
                Kolom yang dibiarkan kosong akan dicetak sebagai <b>...... Orang</b> pada dokumen A4 agar tetap dapat diisi manual bila diperlukan.
              </p>
            </div>
          </div>

          {/* Bottom Action Bar */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              {!confirmReset ? (
                <button
                  type="button"
                  onClick={() => setConfirmReset(true)}
                  className="px-5 py-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs flex items-center gap-2 transition"
                >
                  <RotateCcw className="h-4 w-4" />
                  Reset Rekapan
                </button>
              ) : (
                <div className="flex items-center gap-2 bg-rose-50 border border-rose-200 px-3 py-2 rounded-xl">
                  <span className="text-xs font-bold text-rose-700">Hapus semua unggahan?</span>
                  <button
                    type="button"
                    onClick={handleConfirmReset}
                    className="px-3 py-1 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition"
                  >
                    Ya, Reset
                  </button>
                  <button
                    type="button"
                    onClick={() => setConfirmReset(false)}
                    className="px-3 py-1 rounded-lg bg-white border border-slate-200 text-slate-600 text-xs font-bold transition"
                  >
                    Batal
                  </button>
                </div>
              )}
            </div>

            <button
              type="button"
              onClick={handleGoToPreview}
              className="w-full sm:w-auto bg-[#2e75b6] hover:bg-[#1f4e79] text-white px-8 py-3.5 rounded-xl font-black text-sm shadow-lg shadow-blue-900/20 flex items-center justify-center gap-2 transition"
            >
              <FileCheck2 className="h-5 w-5" />
              Susun &amp; Lihat Lembar A4 ({pages.length} Halaman)
            </button>
          </div>
        </div>
      )}

      {/* ================================================================= */}
      {/* TAB 2: PRATINJAU & UNDUH PDF A4 (3 KARTU PER HALAMAN)             */}
      {/* ================================================================= */}
      {activeTab === 'preview' && (
        <div className="space-y-6">
          {/* Action Toolbar (Hidden on Print) */}
          <div className="no-print bg-white border border-slate-200 rounded-2xl p-4 shadow-sm flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => setActiveTab('editor')}
                className="bg-slate-100 hover:bg-slate-200 text-slate-700 px-4 py-2.5 rounded-xl font-bold text-xs flex items-center gap-1.5 transition"
              >
                <Edit3 className="h-4 w-4" />
                Edit / Tambah Kartu
              </button>

              <button
                type="button"
                onClick={onOpenSettings}
                className="bg-slate-100 hover:bg-slate-200 text-slate-700 px-4 py-2.5 rounded-xl font-bold text-xs flex items-center gap-1.5 transition"
              >
                <Settings className="h-4 w-4" />
                Kop &amp; Kepala Sekolah
              </button>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={handleDownloadA4Pdf}
                disabled={isExportingPdf || uploadedItems.length === 0}
                className="bg-[#2e75b6] hover:bg-[#1f4e79] text-white px-5 py-2.5 rounded-xl font-black text-xs flex items-center gap-1.5 shadow-sm transition disabled:opacity-50"
              >
                <FileDown className="h-4 w-4" />
                {isExportingPdf
                  ? 'Membuat PDF...'
                  : `Unduh PDF A4 (${pages.length} Hal)`}
              </button>

              <button
                type="button"
                onClick={handleSaveToDrive}
                disabled={isSavingDrive || isExportingPdf || uploadedItems.length === 0}
                className="bg-amber-600 hover:bg-amber-700 text-white px-4 py-2.5 rounded-xl font-black text-xs flex items-center gap-1.5 shadow-sm transition disabled:opacity-50"
              >
                <HardDrive className="h-4 w-4" />
                {isSavingDrive ? 'Menyiapkan...' : 'Simpan ke Drive'}
              </button>

              <button
                type="button"
                onClick={handleDownloadAllPagesPng}
                disabled={isExportingPng || uploadedItems.length === 0}
                className="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2.5 rounded-xl font-bold text-xs flex items-center gap-1.5 shadow-sm transition disabled:opacity-50"
              >
                <Download className="h-4 w-4" />
                {isExportingPng ? 'Mengunduh...' : 'Unduh PNG'}
              </button>

              <button
                type="button"
                onClick={handlePrintA4}
                disabled={uploadedItems.length === 0}
                className="bg-slate-800 hover:bg-slate-900 text-white px-4 py-2.5 rounded-xl font-bold text-xs flex items-center gap-1.5 shadow-sm transition disabled:opacity-50"
              >
                <Printer className="h-4 w-4" />
                Cetak A4
              </button>
            </div>
          </div>

          {/* Paginated A4 Sheets Container (3 Cards per Page matching PDF format) */}
          <div id="dailyReportPrintContainer" className="space-y-8">
            {pages.map((page, pageIdx) => {
              // Compact slightly only when Page 1 has 3 cards AND is also the last page (fits signature on same A4 page)
              const isCompactFirstAndLast =
                page.isFirstPage && page.isLastPage && page.items.length === 3;

              return (
                <div key={page.pageNumber} className="space-y-2">
                  {/* Per-Page Screen Label & Single PNG Download Button (Hidden on Print) */}
                  <div className="no-print max-w-[794px] mx-auto flex items-center justify-between px-1">
                    <span className="text-xs font-bold text-slate-500">
                      Lembar Kertas A4 — Halaman {page.pageNumber} dari {page.totalPages} ({page.items.length} Kartu)
                    </span>
                    <button
                      type="button"
                      onClick={() => handleDownloadSinglePagePng(pageIdx)}
                      disabled={exportingPageNum === page.pageNumber}
                      className="text-xs font-bold text-emerald-700 hover:text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 px-3 py-1 rounded-lg flex items-center gap-1.5 transition disabled:opacity-50"
                    >
                      <Download className="h-3.5 w-3.5" />
                      {exportingPageNum === page.pageNumber
                        ? 'Memproses...'
                        : `Unduh Hal ${page.pageNumber} (PNG)`}
                    </button>
                  </div>

                  {/* Scroll wrapper for small screens so A4 sheet preserves true paper proportions */}
                  <div className="overflow-x-auto pb-2 print:overflow-visible print:pb-0">
                    <section
                      className="a4-sheet mx-auto w-[794px] min-h-[1123px] bg-white border border-slate-300 shadow-xl px-[46px] py-[34px] flex flex-col justify-between text-black"
                      style={{ fontFamily: '"Times New Roman", Times, Georgia, serif' }}
                    >
                      <div>
                        {/* PAGE 1: KOP INSTANSI + GARIS BIRU + JUDUL BIRU BERGARIS BAWAH + META */}
                        {page.isFirstPage && (
                          <div className={isCompactFirstAndLast ? 'mb-3' : 'mb-4'}>
                            {/* Kop Instansi mengikuti pengaturan di Kop Instansi */}
                            <div className="text-center pb-1.5">
                              {settings.namaInstansi && (
                                <div className="text-[15.5px] font-bold uppercase tracking-wide leading-tight whitespace-pre-line">
                                  {settings.namaInstansi}
                                </div>
                              )}
                              {settings.subInstansi && (
                                <div className="text-[16px] font-bold uppercase tracking-wide leading-tight mt-0.5">
                                  {settings.subInstansi}
                                </div>
                              )}
                              {settings.alamatInstansi && (
                                <div className="text-[12.5px] italic text-slate-900 mt-0.5">
                                  {settings.alamatInstansi}
                                </div>
                              )}
                            </div>

                            {/* Garis Kop Biru Tebal (#2e75b6) sesuai format PDF */}
                            <div className="h-[4.5px] bg-[#2e75b6] w-full mb-3.5 [print-color-adjust:exact] [-webkit-print-color-adjust:exact]" />

                            {/* Judul Laporan: Biru tua bergaris bawah */}
                            <h2 className="text-center text-[15.5px] font-bold uppercase tracking-wide text-[#1f4e79] underline decoration-[1.5px] underline-offset-4 mb-3">
                              LAPORAN DISIPLIN JAM KERJA HARIAN
                            </h2>

                            {/* Identitas Satuan Pendidikan & Hari/Tanggal */}
                            <table className="text-[14px] leading-snug">
                              <tbody>
                                <tr>
                                  <td className="pr-5 py-0.5 whitespace-nowrap">
                                    Nama Satuan Pendidikan
                                  </td>
                                  <td className="pr-2 py-0.5">:</td>
                                  <td className="py-0.5">{settings.subInstansi || '-'}</td>
                                </tr>
                                <tr>
                                  <td className="pr-5 py-0.5 whitespace-nowrap">
                                    Hari / Tanggal
                                  </td>
                                  <td className="pr-2 py-0.5">:</td>
                                  <td className="py-0.5">
                                    {formatIndonesianFullDate(reportDate)}
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                          </div>
                        )}

                        {/* KARTU LAPORAN HARIAN (3 KARTU PER HALAMAN A4) */}
                        <div className={isCompactFirstAndLast ? 'space-y-2.5' : 'space-y-4'}>
                          {page.items.map((item) => (
                            <div key={item.id} className="a4-card-block flex justify-center">
                              <div className="relative inline-block max-w-full leading-none">
                                <img
                                  src={item.imageUrl}
                                  alt={`Kartu Laporan Harian No. ${item.orderNumber}`}
                                  className={`block object-contain max-w-full w-auto ${
                                    isCompactFirstAndLast
                                      ? 'max-h-[212px]'
                                      : page.isFirstPage
                                      ? 'max-h-[268px]'
                                      : page.isLastPage && page.items.length === 3
                                      ? 'max-h-[248px]'
                                      : 'max-h-[296px]'
                                  }`}
                                />
                                {/* Kotak Biru Nomor Urut dengan garis tepi putih di sudut kiri atas dalam header tabel */}
                                <div
                                  className="absolute bg-[#5b9bd5] border-[1.5px] border-white text-white font-bold flex items-center justify-center select-none pointer-events-none [print-color-adjust:exact] [-webkit-print-color-adjust:exact]"
                                  style={{
                                    left: '0.8%',
                                    top: '2%',
                                    width: '5.8%',
                                    height: '13.5%',
                                    fontSize: isCompactFirstAndLast ? '14px' : '16px',
                                  }}
                                >
                                  {item.orderNumber}
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* BOTTOM SECTION: KIRI LINK GOOGLE DRIVE & REKAP HARIAN | KANAN TANDA TANGAN KEPALA SEKOLAH */}
                      <div className={isCompactFirstAndLast ? 'mt-2' : 'mt-3.5'}>
                        {page.isLastPage && (
                          <div className="flex items-start justify-between gap-6 pt-1">
                            {/* SISI KIRI BAWAH TABEL: Link Google Drive & Rekap Absensi Harian */}
                            <div className="flex-1 max-w-[420px] text-[12px] leading-[1.35] text-black">
                              <div className="font-bold">Link Google Drive :</div>
                              {footerSummary.driveLink.trim() ? (
                                <a
                                  href={footerSummary.driveLink.trim()}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="block text-[10.5px] text-[#1f4e79] underline break-all mb-1.5"
                                >
                                  {footerSummary.driveLink.trim()}
                                </a>
                              ) : (
                                <div className="text-[11.5px] text-slate-700 mb-1.5">
                                  ......................................................................
                                </div>
                              )}

                              <div className="font-bold mt-1 mb-0.5">Rekap Absensi Harian :</div>
                              <table className="text-[11.8px] leading-[1.32]">
                                <tbody>
                                  {[
                                    ['Jumlah Guru/Pegawai', footerSummary.jumlahGuruPegawai],
                                    ['Jumlah Hadir (H)', footerSummary.hadir],
                                    ['Jumlah Ijin (I)', footerSummary.ijin],
                                    ['Jumlah Sakit (S)', footerSummary.sakit],
                                    ['Jumlah Cuti (C)', footerSummary.cuti],
                                    ['Jumlah Tugas Dinas (TD)', footerSummary.tugasDinas],
                                    ['Jlh Tugas Belajar (TS)', footerSummary.tugasBelajar],
                                    ['Jlh Tanpa Berita (TB)', footerSummary.tanpaBerita],
                                  ].map(([label, rawVal]) => (
                                    <tr key={label}>
                                      <td className="pr-3 whitespace-nowrap">{label}</td>
                                      <td className="pr-1.5">:</td>
                                      <td className="whitespace-nowrap">
                                        {rawVal?.trim() ? rawVal.trim() : '......'} Orang
                                      </td>
                                    </tr>
                                  ))}
                                </tbody>
                              </table>
                            </div>

                            {/* SISI KANAN BAWAH TABEL: Tanda Tangan Kepala Sekolah */}
                            <div className="w-[255px] shrink-0 text-[13px] leading-snug">
                              <div>
                                {settings.kota || 'Tempat'}, {formatIndonesianShortDate(reportDate)}
                              </div>
                              <div>{settings.jabatanPimpinan || 'Kepala Sekolah'}</div>
                              <div className={isCompactFirstAndLast ? 'h-[58px]' : 'h-[66px]'} />
                              <div className="font-bold underline">
                                {settings.namaPimpinan || '....................................'}
                              </div>
                              <div>NIP. {settings.nipPimpinan || '-'}</div>
                            </div>
                          </div>
                        )}

                        {page.totalPages > 1 && (
                          <div className="pt-2 text-right text-[10.5px] italic text-slate-500">
                            Halaman {page.pageNumber} dari {page.totalPages}
                          </div>
                        )}
                      </div>
                    </section>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ================================================================= */}
      {/* MODAL: PILIH KARTU DARI RIWAYAT LENSAHADIR                        */}
      {/* ================================================================= */}
      {historyPickerItemId && (
        <div className="no-print fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs animate-fadeIn">
          <div className="w-full max-w-lg rounded-2xl bg-white shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[80vh]">
            <div className="flex items-center justify-between bg-[#1f4e79] px-5 py-4 text-white">
              <div className="flex items-center gap-2">
                <History className="h-5 w-5" />
                <div>
                  <h3 className="text-sm font-bold">Pilih Kartu dari Riwayat LensaHadir</h3>
                  <p className="text-[11px] text-blue-100">
                    Kartu akan otomatis disesuaikan ke tabel laporan A4 &amp; dimasukkan ke rekapan
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setHistoryPickerItemId(null)}
                className="rounded-lg p-1 text-blue-100 hover:bg-white/15"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-2.5 bg-slate-50">
              {isImportingHistory ? (
                <div className="py-12 text-center text-sm font-bold text-[#2e75b6]">
                  Memproses kartu absensi...
                </div>
              ) : (
                records.map((rec) => (
                  <button
                    key={rec.id}
                    type="button"
                    onClick={() => handleImportFromHistory(rec)}
                    className="w-full text-left bg-white hover:bg-blue-50/70 border border-slate-200 hover:border-[#5b9bd5] rounded-xl p-3.5 flex items-center justify-between gap-3 transition"
                  >
                    <div className="min-w-0">
                      <div className="text-sm font-bold text-slate-900 truncate">
                        {rec.nama}
                      </div>
                      <div className="text-xs text-slate-500 mt-0.5">
                        {rec.statusPegawai} · {rec.tanggal} · {rec.statusKehadiran}
                      </div>
                    </div>
                    <span className="shrink-0 text-xs font-bold text-[#2e75b6] bg-[#5b9bd5]/15 px-3 py-1.5 rounded-lg">
                      Pilih
                    </span>
                  </button>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* ================================================================= */}
      {/* MODAL PREVIEW & UNDUH PNG A4 (FAIL-SAFE)                          */}
      {/* ================================================================= */}
      {downloadPreview && (
        <div className="no-print fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-xs animate-fadeIn">
          <div className="relative w-full max-w-3xl overflow-hidden rounded-2xl bg-white shadow-2xl border border-slate-200 flex flex-col max-h-[90vh]">
            <div className="flex items-center justify-between border-b border-slate-100 bg-slate-50 px-5 py-3.5">
              <div className="flex items-center gap-2">
                <div className="rounded-lg bg-emerald-600 p-1.5 text-white">
                  <Download className="h-4 w-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">
                    Lembar A4 Laporan Disiplin Siap Diunduh
                  </h3>
                  <p className="text-[11px] text-slate-500 font-mono">
                    {downloadPreview.filename}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setDownloadPreview(null)}
                className="rounded-lg p-1 text-slate-400 hover:bg-slate-200 hover:text-slate-700 transition"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="flex-1 overflow-auto p-4 bg-slate-100 flex items-center justify-center">
              <img
                src={downloadPreview.url}
                alt="Pratinjau Lembar A4 PNG"
                className="max-h-[62vh] w-auto rounded-lg shadow-md border border-slate-300 object-contain bg-white"
              />
            </div>

            <div className="border-t border-slate-200 bg-white p-4 flex flex-col sm:flex-row items-center justify-between gap-3">
              <p className="text-[11px] text-slate-500 text-center sm:text-left">
                Jika unduhan otomatis tidak berjalan, klik <b>Simpan File PNG</b> atau klik kanan pada gambar lalu pilih <i>Simpan Gambar</i>.
              </p>
              <div className="flex items-center gap-2 shrink-0">
                <a
                  href={downloadPreview.url}
                  download={downloadPreview.filename}
                  className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-2 shadow-sm transition"
                >
                  <Download className="h-4 w-4" />
                  Simpan File PNG
                </a>
                <button
                  type="button"
                  onClick={() => setDownloadPreview(null)}
                  className="px-4 py-2.5 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-100 font-bold text-xs transition"
                >
                  Tutup
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL SIMPAN KE GOOGLE DRIVE */}
      <SaveToDriveModal
        isOpen={Boolean(driveModalInfo)}
        onClose={() => setDriveModalInfo(null)}
        reportTitle="Laporan Disiplin Jam Kerja Harian"
        filename={driveModalInfo?.filename || ''}
        onRedownload={async () => {
          await handleDownloadA4Pdf();
        }}
        isRedownloading={isExportingPdf}
      />
    </div>
  );
};
